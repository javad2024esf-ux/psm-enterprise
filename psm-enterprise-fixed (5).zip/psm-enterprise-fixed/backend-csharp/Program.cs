using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using Serilog;
using PSM.Api.Configuration;
using PSM.Api.Models;
using PSM.Api.Authorization;
using PSM.Api.Data;
using PSM.Api.Services;
using PSM.Api.Repositories;
using PSM.Api.Migrations.Runner;
using PSM.Api.Middleware;
using PSM.Api.Infrastructure.Configuration;
using PSM.Api.Infrastructure.Logging;
using PSM.Api.Infrastructure.Exceptions;
using PSM.Api.Infrastructure.Caching;
using PSM.Api.Infrastructure.Repositories;
using dotenv.net;
using System.Text;
using System.Text.Json;

// Load .env if present
if (File.Exists(".env"))
    DotEnv.Load(options: new DotEnvOptions(envFilePaths: [".env"]));

// Dapper: map snake_case columns to PascalCase properties
Dapper.DefaultTypeMap.MatchNamesWithUnderscores = true;

// Load configuration from environment - Enterprise Quality Configuration Management
ApplicationConfiguration appConfig;
try
{
    appConfig = ConfigurationFactory.CreateFromEnvironment();
}
catch (Exception ex)
{
    Console.WriteLine($"FATAL: Configuration validation failed: {ex.Message}");
    throw;
}

// Serilog with structured logging
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information()
    .WriteTo.Console(outputTemplate: "[{Timestamp:HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}")
    .WriteTo.File(appConfig.Logging.LogFilePath, rollingInterval: RollingInterval.Day)
    .Enrich.FromLogContext()
    .CreateLogger();

var builder = WebApplication.CreateBuilder(args);
builder.Host.UseSerilog();

// Initialize secrets manager
var secretsManager = new SecretsManager();
secretsManager.RegisterSecret("JWT_SECRET", appConfig.Jwt.Secret);

if (!string.IsNullOrEmpty(appConfig.Api.AnthropicApiKey))
    secretsManager.RegisterSecret("ANTHROPIC_API_KEY", appConfig.Api.AnthropicApiKey);

if (!string.IsNullOrEmpty(appConfig.Api.LicenseSecret))
    secretsManager.RegisterSecret("PSM_LICENSE_SECRET", appConfig.Api.LicenseSecret);

builder.Services.AddSingleton(secretsManager);
builder.Services.AddSingleton(appConfig);

// Database - Enterprise pattern with connection pooling
builder.Services.AddSingleton<IDbConnectionFactory>(_ => new NpgsqlConnectionFactory(appConfig.Database.BuildConnectionString()));
builder.Services.AddSingleton<IDbHelper, DbHelper>();

// Unit of Work pattern for repository coordination
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();

// In-memory cache (used by DashboardService KPI cache, permission cache, etc.)
builder.Services.AddMemoryCache();
builder.Services.AddStackExchangeRedisCache(options =>
{
    options.Configuration = Environment.GetEnvironmentVariable("REDIS_CONNECTION") ?? "localhost:6379";
});

// Enterprise Caching Services
builder.Services.AddScoped<IDistributedCacheService, DistributedCacheService>();
builder.Services.AddScoped<ICacheInvalidationManager, CacheInvalidationManager>();

// Structured Logging
builder.Services.AddScoped(provider => 
    new StructuredLogger(Log.Logger, new LoggingContext { CorrelationId = Guid.NewGuid().ToString("N") }));

// Repositories
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IRefreshTokenRepository, RefreshTokenRepository>();
builder.Services.AddScoped<IRoleRepository, RoleRepository>();
builder.Services.AddScoped<IRecordRepository, RecordRepository>();
builder.Services.AddScoped<IAuditRepository, AuditRepository>();
builder.Services.AddScoped<INotificationRepository, NotificationRepository>();
builder.Services.AddScoped<IHazopRepository, HazopRepository>();
builder.Services.AddScoped<ILopaRepository, LopaRepository>();
builder.Services.AddScoped<IBowTieRepository, BowTieRepository>();
builder.Services.AddScoped<IWorkflowRepository, WorkflowRepository>();
builder.Services.AddScoped<IDocumentRepository, DocumentRepository>();
builder.Services.AddScoped<IActionRegisterRepository, ActionRegisterRepository>();

builder.Services.AddScoped<IPermitRepository, PermitRepository>();
builder.Services.AddScoped<IIntegrationRepository, IntegrationRepository>();
builder.Services.AddScoped<ILicenseRepository, LicenseRepository>();

// Integrated Risk Model Repositories
builder.Services.AddScoped<IBarrierRepository, BarrierRepository>();
builder.Services.AddScoped<IUnifiedBarrierRepository, UnifiedBarrierRepository>();
builder.Services.AddScoped<IIncidentRepository, IncidentRepository>();
builder.Services.AddScoped<IIncidentBarrierRepository, IncidentBarrierRepository>();
builder.Services.AddScoped<IIncidentHazopRepository, IncidentHazopRepository>();
builder.Services.AddScoped<IIncidentLopaRepository, IncidentLopaRepository>();
builder.Services.AddScoped<IIncidentBowTieRepository, IncidentBowTieRepository>();
builder.Services.AddScoped<ICrossAnalysisRepository, CrossAnalysisRepository>();
builder.Services.AddScoped<IHazopLopaIntegrationRepository, HazopLopaIntegrationRepository>();

// Core Services
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<ITokenService, TokenService>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IRecordService, RecordService>();
builder.Services.AddScoped<IAuditService, AuditService>();
builder.Services.AddScoped<INotificationService, NotificationService>();
builder.Services.AddScoped<IPermissionService, PermissionService>();
builder.Services.AddScoped<IHazopService, HazopService>();
builder.Services.AddScoped<ILopaService, LopaService>();
builder.Services.AddScoped<IBowTieService, BowTieService>();
builder.Services.AddScoped<IWorkflowService, WorkflowService>();
builder.Services.AddScoped<IAiAssistService, AiAssistService>();
builder.Services.AddScoped<IDocumentService, DocumentService>();
builder.Services.AddScoped<IActionRegisterService, ActionRegisterService>();

builder.Services.AddScoped<IPermitService, PermitService>();
builder.Services.AddScoped<IIntegrationService, IntegrationService>();
builder.Services.AddScoped<ILicenseService, LicenseService>();

// Risk Assessment Services
builder.Services.AddScoped<IBarrierService, BarrierService>();
builder.Services.AddScoped<IIncidentService, IncidentService>();
builder.Services.AddScoped<IIntegratedRiskService, IntegratedRiskService>();
builder.Services.AddScoped<IIntegratedRiskModelService, IntegratedRiskModelService>();
builder.Services.AddScoped<IHazopLopaIntegrationService, HazopLopaIntegrationService>();

// Rate Limiting
builder.Services.AddScoped<IRateLimitService, RateLimitService>();
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ICurrentUserService, CurrentUserService>();
builder.Services.AddScoped<IChangeManagementService, ChangeManagementService>();

builder.Services.AddScoped<IChangeManagementRepository, ChangeManagementRepository>();

builder.Services.AddSingleton<IPasswordHasher, PasswordHasher>();
builder.Services.AddSingleton(Log.Logger);
builder.Services.AddScoped<AdminSeeder>();
builder.Services.AddHttpClient<AiAssistService>();

// JWT Authentication
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(opt =>
    {
        opt.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSecret)),
            ValidateIssuer   = true,
            ValidIssuer      = "PSM-Enterprise",
            ValidateAudience = true,
            ValidAudience    = "PSM-API",
            ValidateLifetime = true,
            ClockSkew        = TimeSpan.FromSeconds(5), // Minimal skew for time sync issues
            RequireExpirationTime = true
        };
        
        // Validate token format and prevent token manipulation
        opt.Events = new JwtBearerEvents
        {
            OnChallenge = context =>
            {
                context.HandleResponse();
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                context.Response.ContentType = "application/json";
                return context.Response.WriteAsJsonAsync(new 
                { 
                    success = false, 
                    error = "Invalid or missing authentication token" 
                });
            },
            OnForbidden = context =>
            {
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                context.Response.ContentType = "application/json";
                return context.Response.WriteAsJsonAsync(new 
                { 
                    success = false, 
                    error = "Insufficient permissions for this resource" 
                });
            }
        };
    });

// PSM Policy-Based Authorization
builder.Services.AddScoped<IAuthorizationHandler, PsmRequirementHandler>();

builder.Services.AddAuthorization(opt =>
{
    // ── کار مجوز کار ────────────────────────────────────────────────────────
    opt.AddPolicy(PsmPolicies.CanApprovePermit,
        p => p.AddRequirements(new PsmRequirement("WORK_PERMIT", PsmAction.Approve)));

    // ── HAZOP ────────────────────────────────────────────────────────────────
    opt.AddPolicy(PsmPolicies.CanCloseHazop,
        p => p.AddRequirements(new PsmRequirement("HAZOP", PsmAction.Approve)));

    opt.AddPolicy(PsmPolicies.CanWriteHazop,
        p => p.AddRequirements(new PsmRequirement("HAZOP", PsmAction.Write)));

    // ── MOC ──────────────────────────────────────────────────────────────────
    opt.AddPolicy(PsmPolicies.CanReviewMOC,
        p => p.AddRequirements(new PsmRequirement("MOC", PsmAction.Write)));

    opt.AddPolicy(PsmPolicies.CanApproveMOC,
        p => p.AddRequirements(new PsmRequirement("MOC", PsmAction.Approve)));

    // ── PSSR ─────────────────────────────────────────────────────────────────
    opt.AddPolicy(PsmPolicies.CanApprovePSSR,
        p => p.AddRequirements(new PsmRequirement("PSSR", PsmAction.Approve)));

    // ── حوادث ────────────────────────────────────────────────────────────────
    opt.AddPolicy(PsmPolicies.CanCloseIncident,
        p => p.AddRequirements(new PsmRequirement("INCIDENT", PsmAction.Approve)));

    // ── LOPA ─────────────────────────────────────────────────────────────────
    opt.AddPolicy(PsmPolicies.CanApproveLopa,
        p => p.AddRequirements(new PsmRequirement("LOPA", PsmAction.Approve)));

    // ── کاربران ──────────────────────────────────────────────────────────────
    opt.AddPolicy(PsmPolicies.CanManageUsers,
        p => p.AddRequirements(new PsmRequirement("Users", PsmAction.Write)));

    opt.AddPolicy(PsmPolicies.CanDeleteUsers,
        p => p.AddRequirements(new PsmRequirement("Users", PsmAction.Delete)));

    // ── مجوز کار — حذف ───────────────────────────────────────────────────────
    opt.AddPolicy(PsmPolicies.CanDeletePermit,
        p => p.AddRequirements(new PsmRequirement("WORK_PERMIT", PsmAction.Delete)));

    // ── پلتفرم هوش مصنوعی ────────────────────────────────────────────────────
    opt.AddPolicy(PsmPolicies.CanUseAI,
        p => p.AddRequirements(new PsmRequirement("AI-Platform", PsmAction.Read)));

    opt.AddPolicy(PsmPolicies.CanAdminAI,
        p => p.AddRequirements(new PsmRequirement("AI-Platform", PsmAction.Approve)));

    // ── Audit ─────────────────────────────────────────────────────────────────
    opt.AddPolicy(PsmPolicies.CanReadAudit,
        p => p.AddRequirements(new PsmRequirement("Audit", PsmAction.Read)));

    opt.AddPolicy(PsmPolicies.CanReadAuditFull,
        p => p.AddRequirements(new PsmRequirement("Audit", PsmAction.Approve)));

    // ── Change Management ─────────────────────────────────────────────────────
    opt.AddPolicy(PsmPolicies.CanCreateChange,
        p => p.AddRequirements(new PsmRequirement("MOC", PsmAction.Write)));

    opt.AddPolicy(PsmPolicies.CanAdvanceWorkflow,
        p => p.AddRequirements(new PsmRequirement("MOC", PsmAction.Write)));

    opt.AddPolicy(PsmPolicies.CanRejectWorkflow,
        p => p.AddRequirements(new PsmRequirement("MOC", PsmAction.Approve)));

    opt.AddPolicy(PsmPolicies.CanAssignTraining,
        p => p.AddRequirements(new PsmRequirement("MOC", PsmAction.Write)));

    opt.AddPolicy(PsmPolicies.CanVerifyPSSR,
        p => p.AddRequirements(new PsmRequirement("PSSR", PsmAction.Approve)));

    opt.AddPolicy(PsmPolicies.CanApproveStartup,
        p => p.AddRequirements(new PsmRequirement("MOC", PsmAction.Approve)));

    opt.AddPolicy(PsmPolicies.CanRejectStartup,
        p => p.AddRequirements(new PsmRequirement("MOC", PsmAction.Approve)));
});

// Response Compression
builder.Services.AddResponseCompression(opts =>
{
    opts.EnableForHttps = true;
});

// CORS
builder.Services.AddCors(opt => opt.AddDefaultPolicy(p =>
    p.WithOrigins(corsOrigins)
     .AllowAnyMethod()
     .AllowAnyHeader()
     .AllowCredentials()));

// Rate Limiting Middleware
builder.Services.AddPsmRateLimiting();

// Dashboard KPI Aggregation
builder.Services.AddScoped<IDashboardRepository, DashboardRepository>();
builder.Services.AddScoped<IDashboardService, DashboardService>();
builder.Services.AddScoped<IKpiPublisher, KpiPublisher>();
builder.Services.AddScoped<IHazopChainService, HazopChainService>();
builder.Services.AddScoped<ILopaBowTieIntegrationService, LopaBowTieIntegrationService>();
builder.Services.AddScoped<IDocumentAttachmentService, DocumentAttachmentService>();
builder.Services.AddScoped<IPsmRelationshipService, PsmRelationshipService>();
builder.Services.AddScoped<IPsmRelationshipRepository, PsmRelationshipRepository>();
builder.Services.AddScoped<IPsmDomainEntityRepository, PsmDomainEntityRepository>();
builder.Services.AddScoped<IPsmDomainEntityService, PsmDomainEntityService>();
builder.Services.AddScoped<ICrossModuleIntegrationService, CrossModuleIntegrationService>();
builder.Services.AddScoped<IAIIntegrationService, AIIntegrationService>();
builder.Services.AddScoped<IHazopChainRepository, HazopChainRepository>();
builder.Services.AddScoped<IDocumentAttachmentRepository, DocumentAttachmentRepository>();

// Domain Events (cross-module cascade notifications)
builder.Services.AddScoped<PSM.Api.Events.IEventAuditRepository, PSM.Api.Events.EventAuditRepository>();
builder.Services.AddScoped<PSM.Api.Events.IEventDispatcher, PSM.Api.Events.EventDispatcher>();
builder.Services.AddScoped<PSM.Api.Events.BarrierStatusChanged_UpdateLopaIplHandler>();
builder.Services.AddScoped<PSM.Api.Events.BarrierStatusChanged_UpdateBowTieHandler>();
builder.Services.AddScoped<PSM.Api.Events.BarrierStatusChanged_UpdateDashboardHandler>();
builder.Services.AddScoped<PSM.Api.Events.BarrierStatusChanged_UpdateRiskAnalyticsHandler>();
builder.Services.AddScoped<PSM.Api.Events.BarrierStatusChanged_NotificationHandler>();
builder.Services.AddScoped<PSM.Api.Events.BarrierStatusChanged_AuditHandler>();
builder.Services.AddScoped<PSM.Api.Events.IncidentCreated_UpdateBarriersHandler>();
builder.Services.AddScoped<PSM.Api.Events.IncidentCreated_UpdateHazopHandler>();
builder.Services.AddScoped<PSM.Api.Events.IncidentCreated_UpdateLopaHandler>();
builder.Services.AddScoped<PSM.Api.Events.IncidentCreated_UpdateBowTieHandler>();
builder.Services.AddScoped<PSM.Api.Events.IncidentCreated_UpdateKpiHandler>();
builder.Services.AddScoped<PSM.Api.Events.IncidentCreated_UpdateDashboardHandler>();
builder.Services.AddScoped<PSM.Api.Events.IncidentCreated_AuditHandler>();

// Controllers
builder.Services.AddControllers()
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        o.JsonSerializerOptions.DefaultIgnoreCondition =
            System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
    });

// Swagger (development only)
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "PSM Enterprise API", Version = "v5.0" });
    c.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        In   = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Name = "Authorization",
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
    });
    c.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id   = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

// Application Configuration
builder.Services.AddSingleton(_ => new AppConfig
{
    JwtSecret        = jwtSecret,
    JwtExpiresIn     = Env("JWT_EXPIRES_IN", "24h"),
    DataDir          = Env("DATA_DIR", Path.Combine(AppContext.BaseDirectory, "data")),
    AiEnabled        = Env("AI_ENABLED", "false") == "true",
    AnthropicApiKey  = Env("ANTHROPIC_API_KEY", ""), // Should be set via environment variable
    AiModel          = Env("AI_MODEL", "claude-sonnet-4-6"),
    LicenseSecret    = Env("PSM_LICENSE_SECRET", ""), // Must be set securely in production
});

builder.WebHost.UseUrls($"http://0.0.0.0:{port}");

var app = builder.Build();

// Run Migrations
using (var scope = app.Services.CreateScope())
{
    var dbHelper = scope.ServiceProvider.GetRequiredService<IDbHelper>();
    var migrationRunner = new MigrationRunner(dbHelper, Log.Logger);
    await migrationRunner.RunAsync();

    // First-run seed: creates the initial Admin account if the users table is empty.
    var adminSeeder = scope.ServiceProvider.GetRequiredService<AdminSeeder>();
    await adminSeeder.RunAsync();

    // Wire up domain event subscriptions (cross-module cascade notifications)
    var dispatcher = scope.ServiceProvider.GetRequiredService<PSM.Api.Events.IEventDispatcher>();
    dispatcher.Subscribe<PSM.Api.Events.BarrierStatusChangedEvent, PSM.Api.Events.BarrierStatusChanged_UpdateLopaIplHandler>();
    dispatcher.Subscribe<PSM.Api.Events.BarrierStatusChangedEvent, PSM.Api.Events.BarrierStatusChanged_UpdateBowTieHandler>();
    dispatcher.Subscribe<PSM.Api.Events.BarrierStatusChangedEvent, PSM.Api.Events.BarrierStatusChanged_UpdateDashboardHandler>();
    dispatcher.Subscribe<PSM.Api.Events.BarrierStatusChangedEvent, PSM.Api.Events.BarrierStatusChanged_UpdateRiskAnalyticsHandler>();
    dispatcher.Subscribe<PSM.Api.Events.BarrierStatusChangedEvent, PSM.Api.Events.BarrierStatusChanged_NotificationHandler>();
    dispatcher.Subscribe<PSM.Api.Events.BarrierStatusChangedEvent, PSM.Api.Events.BarrierStatusChanged_AuditHandler>();
    dispatcher.Subscribe<PSM.Api.Events.IncidentCreatedEvent, PSM.Api.Events.IncidentCreated_UpdateBarriersHandler>();
    dispatcher.Subscribe<PSM.Api.Events.IncidentCreatedEvent, PSM.Api.Events.IncidentCreated_UpdateHazopHandler>();
    dispatcher.Subscribe<PSM.Api.Events.IncidentCreatedEvent, PSM.Api.Events.IncidentCreated_UpdateLopaHandler>();
    dispatcher.Subscribe<PSM.Api.Events.IncidentCreatedEvent, PSM.Api.Events.IncidentCreated_UpdateBowTieHandler>();
    dispatcher.Subscribe<PSM.Api.Events.IncidentCreatedEvent, PSM.Api.Events.IncidentCreated_UpdateKpiHandler>();
    dispatcher.Subscribe<PSM.Api.Events.IncidentCreatedEvent, PSM.Api.Events.IncidentCreated_UpdateDashboardHandler>();
    dispatcher.Subscribe<PSM.Api.Events.IncidentCreatedEvent, PSM.Api.Events.IncidentCreated_AuditHandler>();
}

// Middleware Pipeline - Security First with Enterprise Patterns
// Exception handling must be first to catch all errors
app.UseMiddleware<PSM.Api.Infrastructure.Middleware.EnterpriseExceptionHandlingMiddleware>();
app.UseMiddleware<PSM.Api.Infrastructure.Middleware.RequestResponseLoggingMiddleware>();

// Security headers
app.UseMiddleware<SecurityHeadersMiddleware>();

// CSRF protection
app.UseMiddleware<CsrfTokenMiddleware>();

// Development only endpoints
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{
    // Production: disable Swagger
    // Remove any development-only features
}

app.UseCors();
app.UseResponseCompression();
app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();

// Health check endpoint
app.MapGet("/health", () => Results.Ok(new { status = "ok", version = "5.0.0", timestamp = DateTime.UtcNow }));
app.MapGet("/health/detailed", (IStructuredLogger logger) =>
{
    var context = new LoggingContext { CorrelationId = Guid.NewGuid().ToString("N") };
    var structuredLogger = logger.WithContext(context);
    structuredLogger.LogInformation("Health check detailed");
    return Results.Ok(new
    {
        status = "ok",
        version = "5.0.0",
        timestamp = DateTime.UtcNow,
        environment = appConfig.Environment,
        database = appConfig.Database.Host
    });
});

app.MapControllers();

// Startup Banner
Log.Information("╔══════════════════════════════════════════════════╗");
Log.Information("║  PSM Enterprise — C# ASP.NET Core Server v5.0  ║");
Log.Information("║  Phase 5: Enterprise Quality Refactoring        ║");
Log.Information("╚══════════════════════════════════════════════════╝");
Log.Information("[SERVER] Listening on http://0.0.0.0:{Port}", appConfig.Port);
Log.Information("[DB]     PostgreSQL: {Host}:{DbPort}/{Db}",
    appConfig.Database.Host, appConfig.Database.Port, appConfig.Database.Database);
Log.Information("[CACHE]  Redis: {RedisConnection}",
    Environment.GetEnvironmentVariable("REDIS_CONNECTION") ?? "localhost:6379");
Log.Information("[CONFIG] Environment: {Environment}", appConfig.Environment);

app.Run();
