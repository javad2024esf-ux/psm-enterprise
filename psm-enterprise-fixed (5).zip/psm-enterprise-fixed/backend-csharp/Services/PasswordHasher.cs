namespace PSM.Api.Services;

public interface IPasswordHasher
{
    string Hash(string password);
    bool Verify(string password, string hash);
}

public class PasswordHasher : IPasswordHasher
{
    public string Hash(string password)
    {
        // ✅ Fix: Validate and trim password before hashing
        if (string.IsNullOrEmpty(password))
            throw new ArgumentException("رمز عبور نمی‌تواند خالی باشد", nameof(password));

        var cleanPassword = password.Trim();
        return BCrypt.Net.BCrypt.HashPassword(cleanPassword, workFactor: 12);
    }

    public bool Verify(string password, string hash)
    {
        try 
        { 
            // ✅ Fix: Validate inputs and trim password before verification
            if (string.IsNullOrEmpty(password) || string.IsNullOrEmpty(hash))
                return false;

            var cleanPassword = password.Trim();
            return BCrypt.Net.BCrypt.Verify(cleanPassword, hash); 
        }
        catch 
        { 
            return false; 
        }
    }
}
