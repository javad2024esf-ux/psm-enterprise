using PSM.Api.DTOs;
using PSM.Api.Repositories;
using System.Text.Json;

namespace PSM.Api.Services;

public interface IHazopLopaIntegrationService
{
    // ─── LOPA Study Creation from HAZOP ──────────────────────────────────
    Task<LopaStudyDto> CreateLopaStudyFromHazopAsync(CreateLopaFromHazopRequest request,
        string userId, string? ipAddress = null, string? userAgent = null);

    // ─── LOPA Scenario Creation from HAZOP Deviation ──────────────────────
    Task<LopaScenarioDto> CreateLopaScenarioFromHazopDeviationAsync(
        CreateLopaScenarioFromHazopDeviationRequest request, string userId,
        string? ipAddress = null, string? userAgent = null);

    // ─── Integration Summary and Traceability ────────────────────────────
    Task<HazopLopaIntegrationSummaryDto> GetIntegrationSummaryAsync(string hazopStudyId);
    
    Task<List<LopaStudyWithHazopTracingDto>> GetLopaStudiesWithHazopTracingAsync(string hazopStudyId);
    
    Task<LopaScenarioWithTracingDto> GetLopaScenarioWithTracingAsync(string lopaScenarioId);

    // ─── Query Methods ───────────────────────────────────────────────────
    Task<IEnumerable<LopaScenarioDto>> GetLopaScenariosByHazopDeviationAsync(string hazopDeviationId);

    // ─── Bulk Operations ────────────────────────────────────────────────
    Task<List<LopaScenarioDto>> CreateLopaScenariosManyFromHazopDeviationsAsync(
        string lopaStudyId, List<HazopDeviationDto> deviations, string userId,
        string? ipAddress = null, string? userAgent = null);

    // ─── Audit Trail Access ─────────────────────────────────────────────
    Task<List<HazopLopaAuditTrailDto>> GetIntegrationAuditTrailAsync(string? hazopStudyId = null,
        string? lopaStudyId = null, int limit = 100, int offset = 0);

    Task<int> GetIntegrationAuditTrailCountAsync(string? hazopStudyId = null,
        string? lopaStudyId = null);
}

public class HazopLopaIntegrationService : IHazopLopaIntegrationService
{
    private readonly IHazopLopaIntegrationRepository _integrationRepo;
    private readonly IHazopRepository _hazopRepo;
    private readonly ILopaRepository _lopaRepo;
    private readonly IAuditService _auditService;

    public HazopLopaIntegrationService(
        IHazopLopaIntegrationRepository integrationRepo,
        IHazopRepository hazopRepo,
        ILopaRepository lopaRepo,
        IAuditService auditService)
    {
        _integrationRepo = integrationRepo;
        _hazopRepo = hazopRepo;
        _lopaRepo = lopaRepo;
        _auditService = auditService;
    }

    // ─── LOPA Study Creation from HAZOP ──────────────────────────────────
    public async Task<LopaStudyDto> CreateLopaStudyFromHazopAsync(CreateLopaFromHazopRequest request,
        string userId, string? ipAddress = null, string? userAgent = null)
    {
        if (string.IsNullOrWhiteSpace(request.hazop_study_id))
            throw new ArgumentException("hazop_study_id is required");

        // Verify HAZOP study exists
        var hazopStudy = await _hazopRepo.GetStudyAsync(request.hazop_study_id);
        if (hazopStudy == null)
            throw new InvalidOperationException($"HAZOP Study {request.hazop_study_id} not found");

        // ── INTEGRATION GATE: only Approved/Completed HAZOP studies may seed a LOPA ──
        // Accepted statuses are "Approved" (alias) and "Completed" (the DB enum value).
        // "Draft" and "Active" studies may still have unreviewed deviations.
        var allowedStatuses = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { "Approved", "Completed" };
        if (!allowedStatuses.Contains(hazopStudy.Status ?? ""))
            throw new InvalidOperationException(
                $"HAZOP Study '{hazopStudy.Title}' has status '{hazopStudy.Status}'. " +
                "Only studies with status 'Completed' (Approved) may be used to create a LOPA study. " +
                "Please complete the HAZOP review and mark the study as Completed before proceeding.");

        // Create LOPA study
        var lopaStudyId = Guid.NewGuid().ToString();
        var lopaTitle = request.lopa_title ?? $"LOPA from {hazopStudy.Title}";
        
        var lopaStudyData = new
        {
            hazop_reference = new
            {
                study_id = request.hazop_study_id,
                study_title = hazopStudy.Title
            },
            created_from_hazop = true,
            include_all_deviations = request.include_all_deviations,
            selected_deviation_ids = request.selected_deviation_ids,
            additional_data = request.additional_data
        };

        var lopaStudyJson = JsonSerializer.Serialize(lopaStudyData);

        await _lopaRepo.CreateStudyAsync(
            lopaStudyId,
            lopaTitle,
            request.hazop_study_id,
            request.facility ?? hazopStudy.Facility,
            request.unit ?? hazopStudy.Unit,
            request.lead_engineer ?? hazopStudy.LeadEngineer,
            "Draft",
            userId,
            lopaStudyJson);

        // Update LOPA study with creation metadata
        await _integrationRepo.UpdateLopaStudyHazopReferenceAsync(lopaStudyId, request.hazop_study_id);

        // Log audit trail
        await _integrationRepo.LogIntegrationActionAsync(
            action: "LOPA_STUDY_CREATED_FROM_HAZOP",
            hazopStudyId: request.hazop_study_id,
            hazopNodeId: null,
            hazopDeviationId: null,
            lopaStudyId: lopaStudyId,
            lopaScenarioId: null,
            performedBy: userId,
            ipAddress: ipAddress,
            userAgent: userAgent,
            details: new Dictionary<string, object>
            {
                { "lopa_title", lopaTitle },
                { "facility", request.facility ?? "" },
                { "unit", request.unit ?? "" },
                { "include_all_deviations", request.include_all_deviations }
            });

        // If include_all_deviations, create scenarios for all deviations
        if (request.include_all_deviations)
        {
            var deviations = await _hazopRepo.ListDeviationsByStudyAsync(request.hazop_study_id);
            foreach (var deviation in deviations)
            {
                try
                {
                    await CreateLopaScenarioFromHazopDeviationAsync(
                        new CreateLopaScenarioFromHazopDeviationRequest
                        {
                            hazop_study_id = request.hazop_study_id,
                            hazop_node_id = deviation.NodeId,
                            hazop_deviation_id = deviation.Id,
                            lopa_study_id = lopaStudyId,
                            scenario_number = $"{deviation.Id.Substring(0, 8)}",
                            initiating_event = deviation.Deviation,
                            consequence_description = deviation.Consequences,
                            consequence_severity = deviation.Severity,
                            target_risk = 0.0001,
                            notes = $"Created from HAZOP Deviation: {deviation.Parameter}"
                        },
                        userId,
                        ipAddress,
                        userAgent);
                }
                catch (Exception ex)
                {
                    // Log but continue with other deviations
                    await _auditService.LogAsync(
                        module: "HAZOP-LOPA",
                        action: "BULK_SCENARIO_CREATION_ERROR",
                        details: $"Failed to create LOPA scenario for deviation {deviation.Id}: {ex.Message}",
                        userId: userId);
                }
            }
        }

        return await _lopaRepo.GetStudyAsync(lopaStudyId) ?? throw new InvalidOperationException("Failed to retrieve created LOPA study");
    }

    // ─── LOPA Scenario Creation from HAZOP Deviation ──────────────────────
    public async Task<LopaScenarioDto> CreateLopaScenarioFromHazopDeviationAsync(
        CreateLopaScenarioFromHazopDeviationRequest request, string userId,
        string? ipAddress = null, string? userAgent = null)
    {
        if (string.IsNullOrWhiteSpace(request.lopa_study_id))
            throw new ArgumentException("lopa_study_id is required");

        if (string.IsNullOrWhiteSpace(request.hazop_deviation_id))
            throw new ArgumentException("hazop_deviation_id is required");

        // Verify LOPA study exists
        var lopaStudy = await _lopaRepo.GetStudyAsync(request.lopa_study_id);
        if (lopaStudy == null)
            throw new InvalidOperationException($"LOPA Study {request.lopa_study_id} not found");

        // Verify HAZOP deviation exists
        var hazopDeviation = await _hazopRepo.GetDeviationAsync(request.hazop_deviation_id);
        if (hazopDeviation == null)
            throw new InvalidOperationException($"HAZOP Deviation {request.hazop_deviation_id} not found");

        // Determine HAZOP references
        var hazopStudyId = request.hazop_study_id ?? hazopDeviation.StudyId;
        var hazopNodeId = request.hazop_node_id ?? hazopDeviation.NodeId;

        // Create LOPA scenario with traceability
        var lopaScenarioId = Guid.NewGuid().ToString();
        var scenarioNumber = request.scenario_number ?? $"SC-{DateTime.UtcNow:yyyyMMddHHmmss}";

        var scenarioData = new
        {
            hazop_reference = new
            {
                study_id = hazopStudyId,
                node_id = hazopNodeId,
                deviation_id = request.hazop_deviation_id,
                deviation_text = hazopDeviation.Deviation,
                guide_word = hazopDeviation.GuideWord,
                parameter = hazopDeviation.Parameter
            },
            created_from_hazop = true,
            additional_data = request.data
        };

        var scenarioJson = JsonSerializer.Serialize(scenarioData);

        await _lopaRepo.CreateScenarioAsync(
            lopaScenarioId,
            request.lopa_study_id,
            request.hazop_deviation_id,
            scenarioNumber,
            request.initiating_event ?? hazopDeviation.Deviation,
            Convert.ToDouble(request.initiating_frequency ?? 1.0),
            request.consequence_description ?? hazopDeviation.Consequences,
            Convert.ToInt32(request.consequence_severity ?? hazopDeviation.Severity),
            Convert.ToDouble(request.target_risk ?? 0.0001),
            request.notes,
            scenarioJson);

        // Update with HAZOP references
        await _integrationRepo.UpdateLopaScenarioHazopReferencesAsync(
            lopaScenarioId,
            hazopStudyId,
            hazopNodeId,
            request.hazop_deviation_id);

        // Log audit trail
        await _integrationRepo.LogIntegrationActionAsync(
            action: "LOPA_SCENARIO_CREATED_FROM_HAZOP_DEVIATION",
            hazopStudyId: hazopStudyId,
            hazopNodeId: hazopNodeId,
            hazopDeviationId: request.hazop_deviation_id,
            lopaStudyId: request.lopa_study_id,
            lopaScenarioId: lopaScenarioId,
            performedBy: userId,
            ipAddress: ipAddress,
            userAgent: userAgent,
            details: new Dictionary<string, object>
            {
                { "scenario_number", scenarioNumber },
                { "initiating_event", request.initiating_event ?? "" },
                { "consequence_description", request.consequence_description ?? "" }
            });

        return await _lopaRepo.GetScenarioAsync(lopaScenarioId) ?? throw new InvalidOperationException("Failed to retrieve created LOPA scenario");
    }

    // ─── Integration Summary and Traceability ────────────────────────────
    public Task<HazopLopaIntegrationSummaryDto> GetIntegrationSummaryAsync(string hazopStudyId) =>
        _integrationRepo.GetIntegrationSummaryAsync(hazopStudyId);

    public async Task<List<LopaStudyWithHazopTracingDto>> GetLopaStudiesWithHazopTracingAsync(string hazopStudyId)
    {
        var lopaStudies = await _integrationRepo.GetLopaStudiesByHazopStudyAsync(hazopStudyId);
        var hazopStudy  = await _hazopRepo.GetStudyAsync(hazopStudyId);

        // Fan-out: load scenarios for all studies in parallel
        var studyTasks = lopaStudies.Select(async lopaStudy =>
        {
            var rawScenarios = (await _lopaRepo.ListScenariosByStudyAsync(lopaStudy.Id!)).ToList();

            // Load tracing for all scenarios in parallel (no sync-over-async)
            var tracedScenarios = await Task.WhenAll(
                rawScenarios.Select(s => GetLopaScenarioWithTracingAsync(s.Id!)));

            var scenarioList = tracedScenarios.ToList();
            var deviationCount = scenarioList
                .Where(s => !string.IsNullOrWhiteSpace(s.HazopDeviationId))
                .DistinctBy(s => s.HazopDeviationId)
                .Count();

            return new LopaStudyWithHazopTracingDto
            {
                Id                         = lopaStudy.Id,
                Title                      = lopaStudy.Title,
                HazopStudyId               = lopaStudy.HazopStudyId,
                Facility                   = lopaStudy.Facility,
                Unit                       = lopaStudy.Unit,
                LeadEngineer               = lopaStudy.LeadEngineer,
                Status                     = lopaStudy.Status,
                CreatedAt                  = lopaStudy.CreatedAt,
                UpdatedAt                  = lopaStudy.UpdatedAt,
                ScenarioCount              = rawScenarios.Count,
                RelatedHazopDeviationCount = deviationCount,
                RelatedHazopStudy          = hazopStudy,
                Scenarios                  = scenarioList,
            };
        });

        return (await Task.WhenAll(studyTasks)).ToList();
    }

    public async Task<LopaScenarioWithTracingDto> GetLopaScenarioWithTracingAsync(string lopaScenarioId)
    {
        var scenario = await _lopaRepo.GetScenarioAsync(lopaScenarioId);
        if (scenario == null)
            throw new InvalidOperationException($"LOPA Scenario {lopaScenarioId} not found");

        var hazopDeviation = await _integrationRepo.GetHazopDeviationByLopaScenarioAsync(lopaScenarioId);
        var hazopNode = hazopDeviation != null ? await _hazopRepo.GetNodeAsync(hazopDeviation.NodeId!) : null;
        var ipls = await _lopaRepo.ListIplsByScenarioAsync(lopaScenarioId);

        return new LopaScenarioWithTracingDto
        {
            Id = scenario.Id,
            StudyId = scenario.StudyId,
            HazopStudyId = scenario.HazopStudyId,
            HazopNodeId = scenario.HazopNodeId,
            HazopDeviationId = scenario.HazopDeviationId,
            ScenarioNumber = scenario.ScenarioNumber,
            InitiatingEvent = scenario.InitiatingEvent,
            InitiatingFrequency = scenario.InitiatingFrequency,
            ConsequenceDescription = scenario.ConsequenceDescription,
            ConsequenceSeverity = scenario.ConsequenceSeverity,
            TargetRisk = scenario.TargetRisk,
            Notes = scenario.Notes,
            IplCount = ipls.Count(),
            SourceHazopDeviation = hazopDeviation,
            SourceHazopNode = hazopNode,
            Ipls = ipls.ToList()
        };
    }

    // ─── Bulk Operations ────────────────────────────────────────────────
    public async Task<List<LopaScenarioDto>> CreateLopaScenariosManyFromHazopDeviationsAsync(
        string lopaStudyId, List<HazopDeviationDto> deviations, string userId,
        string? ipAddress = null, string? userAgent = null)
    {
        var scenarios = new List<LopaScenarioDto>();

        foreach (var deviation in deviations)
        {
            try
            {
                var scenario = await CreateLopaScenarioFromHazopDeviationAsync(
                    new CreateLopaScenarioFromHazopDeviationRequest
                    {
                        lopa_study_id = lopaStudyId,
                        hazop_study_id = deviation.StudyId,
                        hazop_node_id = deviation.NodeId,
                        hazop_deviation_id = deviation.Id,
                        scenario_number = $"SC-{deviation.Id?.Substring(0, 8)}",
                        initiating_event = deviation.Deviation,
                        consequence_description = deviation.Consequences,
                        consequence_severity = deviation.Severity,
                        target_risk = 0.0001
                    },
                    userId,
                    ipAddress,
                    userAgent);

                scenarios.Add(scenario);
            }
            catch (Exception ex)
            {
                await _auditService.LogAsync(
                    module: "HAZOP-LOPA",
                    action: "BULK_SCENARIO_CREATION_ERROR",
                    details: $"Failed to create scenario for deviation {deviation.Id}: {ex.Message}",
                    userId: userId);
            }
        }

        return scenarios;
    }

    // ─── Query Methods ──────────────────────────────────────────────────────
    public async Task<IEnumerable<LopaScenarioDto>> GetLopaScenariosByHazopDeviationAsync(string hazopDeviationId)
    {
        try
        {
            // Get all LOPA studies and find scenarios linked to this HAZOP deviation
            var scenarios = await _lopaRepo.ListAllScenariosAsync();
            return scenarios.Where(s => s.HazopDeviationId == hazopDeviationId).ToList();
        }
        catch
        {
            // Return empty list if error
            return new List<LopaScenarioDto>();
        }
    }

    // ─── Audit Trail Access ─────────────────────────────────────────────
    public Task<List<HazopLopaAuditTrailDto>> GetIntegrationAuditTrailAsync(string? hazopStudyId = null,
        string? lopaStudyId = null, int limit = 100, int offset = 0) =>
        _integrationRepo.GetAuditTrailAsync(hazopStudyId, lopaStudyId, limit, offset);

    public Task<int> GetIntegrationAuditTrailCountAsync(string? hazopStudyId = null,
        string? lopaStudyId = null) =>
        _integrationRepo.GetAuditTrailCountAsync(hazopStudyId, lopaStudyId);
}
