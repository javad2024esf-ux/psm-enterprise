using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace PSM.Api.Services;

public interface ICurrentUserService
{
    string? GetUserId();
    string? GetUsername();
    string? GetRole();
    string? GetUnit();
}

public class CurrentUserService : ICurrentUserService
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public CurrentUserService(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    public string? GetUserId() =>
        _httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

    public string? GetUsername() =>
        _httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.Name);

    public string? GetRole() =>
        _httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.Role);

    public string? GetUnit() =>
        _httpContextAccessor.HttpContext?.User?.FindFirstValue("unit");
}
