using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Repositories;
using PSM.Api.Services;
using System.Text.Json;

namespace PSM.Api.Services;

public interface IHazopService
{
    Task<IEnumerable<PSM.Api.DTOs.HazopStudyWithCountsDto>> ListStudiesAsync();
    Task<PSM.Api.DTOs.HazopStudyDto?> GetStudyAsync(string id);
    Task<PSM.Api.DTOs.HazopStudyDto> CreateStudyAsync(CreateHazopStudyRequest req, string? userId);
    Task<(bool found, PSM.Api.DTOs.HazopStudyDto? study)> UpdateStudyAsync(string id, UpdateHazopStudyRequest req);
    Task<bool> DeleteStudyAsync(string id);

    Task<IEnumerable<PSM.Api.DTOs.HazopNodeWithCountsDto>> ListNodesAsync(string studyId);
    Task<PSM.Api.DTOs.HazopNodeDto> CreateNodeAsync(string studyId, CreateHazopNodeRequest req);
    Task<(bool found, PSM.Api.DTOs.HazopNodeDto? node)> UpdateNodeAsync(string id, UpdateHazopNodeRequest req);
    Task<bool> DeleteNodeAsync(string id);

    Task<IEnumerable<PSM.Api.DTOs.HazopDeviationDto>> ListDeviationsByStudyAsync(string studyId);
    Task<IEnumerable<PSM.Api.DTOs.HazopDeviationDto>> ListDeviationsByNodeAsync(string nodeId);
    Task<(bool found, PSM.Api.DTOs.HazopDeviationDto? deviation)> CreateDeviationAsync(string nodeId, CreateHazopDeviationRequest req);
    Task<(bool found, PSM.Api.DTOs.HazopDeviationDto? deviation)> UpdateDeviationAsync(string id, UpdateHazopDeviationRequest req);
    Task<bool> DeleteDeviationAsync(string id);

    Task<PSM.Api.DTOs.HazopAnalyticsDto> GetAnalyticsAsync();

    /// <summary>HAZOP-Studies دسترسی این ماژول ثابت است (مطابق Node: req.user.role==='Admin' OR checkPermission)</summary>
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class HazopService : IHazopService
{
    private readonly IHazopRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "HAZOP-Studies";

    public HazopService(IHazopRepository repo, IPermissionService perms)
    {
        _repo = repo;
        _perms = perms;
    }

    public Task<bool> CheckPermAsync(string role, PsmAction action) =>
        _perms.CheckPermissionAsync(role, Module, action);

    public Task<IEnumerable<PSM.Api.DTOs.HazopStudyWithCountsDto>> ListStudiesAsync() => _repo.ListStudiesAsync();

    public Task<PSM.Api.DTOs.HazopStudyDto?> GetStudyAsync(string id) => _repo.GetStudyAsync(id);

    public async Task<PSM.Api.DTOs.HazopStudyDto> CreateStudyAsync(CreateHazopStudyRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateStudyAsync(
            id, req.title ?? "Untitled", req.facility, req.unit, req.lead_engineer, req.scope,
            req.methodology ?? "HAZOP (IEC 61882)", req.status ?? "Draft", req.start_date, req.end_date,
            userId, JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetStudyAsync(id))!;
    }

    public async Task<(bool found, PSM.Api.DTOs.HazopStudyDto? study)> UpdateStudyAsync(string id, UpdateHazopStudyRequest req)
    {
        if (!await _repo.StudyExistsAsync(id)) return (false, null);
        await _repo.UpdateStudyAsync(
            id, req.title ?? "Untitled", req.facility, req.unit, req.lead_engineer, req.scope,
            req.methodology ?? "HAZOP (IEC 61882)", req.status ?? "Draft", req.start_date, req.end_date,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetStudyAsync(id));
    }

    public async Task<bool> DeleteStudyAsync(string id)
    {
        if (!await _repo.StudyExistsAsync(id)) return false;
        await _repo.SoftDeleteStudyAsync(id);
        return true;
    }

    public Task<IEnumerable<PSM.Api.DTOs.HazopNodeWithCountsDto>> ListNodesAsync(string studyId) => _repo.ListNodesAsync(studyId);

    public async Task<PSM.Api.DTOs.HazopNodeDto> CreateNodeAsync(string studyId, CreateHazopNodeRequest req)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateNodeAsync(id, studyId, req.node_number!, req.description!,
            req.process_line, req.design_intent, req.p_and_id);
        return (await _repo.GetNodeAsync(id))!;
    }

    public async Task<(bool found, PSM.Api.DTOs.HazopNodeDto? node)> UpdateNodeAsync(string id, UpdateHazopNodeRequest req)
    {
        if (!await _repo.NodeExistsAsync(id)) return (false, null);
        await _repo.UpdateNodeAsync(id, req.node_number!, req.description!,
            req.process_line, req.design_intent, req.p_and_id);
        return (true, await _repo.GetNodeAsync(id));
    }

    public async Task<bool> DeleteNodeAsync(string id)
    {
        if (!await _repo.NodeExistsAsync(id)) return false;
        await _repo.SoftDeleteNodeAsync(id);
        return true;
    }

    public Task<IEnumerable<PSM.Api.DTOs.HazopDeviationDto>> ListDeviationsByStudyAsync(string studyId) => _repo.ListDeviationsByStudyAsync(studyId);
    public Task<IEnumerable<PSM.Api.DTOs.HazopDeviationDto>> ListDeviationsByNodeAsync(string nodeId) => _repo.ListDeviationsByNodeAsync(nodeId);

    /// <summary>بانددهی ریسک — دقیقاً مطابق منطق Node: severity*likelihood با محدودیت‌های صحیح</summary>
    private static string BandRisk(int severity, int likelihood)
    {
        var score = severity * likelihood;
        if (score >= 20) return "Critical";
        if (score >= 12) return "High";
        if (score >= 6) return "Medium";
        return "Low";
    }

    private static int ClampToInt(object? value, int fallback)
    {
        if (value is null) return fallback;
        if (value is int i) return i;
        if (value is JsonElement je)
        {
            if (je.ValueKind == JsonValueKind.Number && je.TryGetInt32(out var n)) return n;
            if (je.ValueKind == JsonValueKind.String && int.TryParse(je.GetString(), out var s)) return s;
        }
        return int.TryParse(value.ToString(), out var parsed) ? parsed : fallback;
    }

    public async Task<(bool found, PSM.Api.DTOs.HazopDeviationDto? deviation)> CreateDeviationAsync(string nodeId, CreateHazopDeviationRequest req)
    {
        var node = await _repo.GetNodeStudyIdAsync(nodeId);
        if (node is null) return (false, null);
        string studyId = node?.GetType().GetProperty("StudyId")?.GetValue(node) as string ?? string.Empty;

        var id = Guid.NewGuid().ToString();
        var severity = ClampToInt(req.severity, 3);
        var likelihood = ClampToInt(req.likelihood, 3);
        var riskLevel = BandRisk(severity, likelihood);

        await _repo.CreateDeviationAsync(
            id, studyId, nodeId, req.guide_word!, req.parameter!, req.deviation!,
            req.causes, req.consequences, req.existing_safeguards, req.recommendations,
            severity, likelihood, req.status ?? "Open", riskLevel,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));

        return (true, await _repo.GetDeviationAsync(id));
    }

    public async Task<(bool found, PSM.Api.DTOs.HazopDeviationDto? deviation)> UpdateDeviationAsync(string id, UpdateHazopDeviationRequest req)
    {
        if (!await _repo.DeviationExistsAsync(id)) return (false, null);

        var severity = ClampToInt(req.severity, 3);
        var likelihood = ClampToInt(req.likelihood, 3);
        var riskLevel = BandRisk(severity, likelihood);

        await _repo.UpdateDeviationAsync(
            id, req.guide_word!, req.parameter!, req.deviation!,
            req.causes, req.consequences, req.existing_safeguards, req.recommendations,
            severity, likelihood, req.status ?? "Open", riskLevel,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));

        return (true, await _repo.GetDeviationAsync(id));
    }

    public async Task<bool> DeleteDeviationAsync(string id)
    {
        if (!await _repo.DeviationExistsAsync(id)) return false;
        await _repo.SoftDeleteDeviationAsync(id);
        return true;
    }

    public Task<PSM.Api.DTOs.HazopAnalyticsDto> GetAnalyticsAsync() => _repo.GetAnalyticsAsync();
}
