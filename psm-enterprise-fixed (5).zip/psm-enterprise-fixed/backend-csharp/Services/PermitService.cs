using System.Text.Json;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

// ════════════════════════════════════════════════════════════════════════════
// Interface
// ════════════════════════════════════════════════════════════════════════════
public interface IPermitService
{
    Task<bool> CheckPermAsync(string role, PsmAction action);

    Task<(IEnumerable<PermitListDto> Rows, long Total)> ListAsync(
        string? state, string? permitType, string? riskLevel,
        string? tenantId, int limit, int offset);

    Task<PermitDetailDto?> GetAsync(string id, string userRole);

    Task<PermitDetailDto> CreateAsync(CreatePermitRequest req, string userId, string userRole);

    Task<PermitDetailDto> UpdateAsync(string id, UpdatePermitRequest req, string userId, string userRole);

    Task DeleteAsync(string id, string userId);

    Task<PermitDetailDto> ApproveAsync(string id, ApprovePermitRequest req, string userId, string userRole);

    Task<PermitDetailDto> CloseAsync(string id, ClosePermitRequest req, string userId);

    // Sub-resource helpers
    Task<PermitDetailDto> AddCrewMemberAsync(string id, CreateCrewMemberRequest req, string userId);
    Task<PermitDetailDto> AddSafetyRecordAsync(string id, AddSafetyRecordRequest req, string userId);
    Task<PermitDetailDto> AddLessonAsync(string id, AddLessonRequest req, string userId);
}

// ════════════════════════════════════════════════════════════════════════════
// Implementation
// ════════════════════════════════════════════════════════════════════════════
public class PermitService : IPermitService
{
    private readonly IPermitRepository   _repo;
    private readonly IPermissionService  _perms;
    private readonly IAuditService       _audit;
    private readonly IWorkflowService    _workflow;
    private readonly INotificationService _notify;
    private readonly ILogger<PermitService> _log;

    private const string Module   = "WORK_PERMIT";
    private const string TenantId = "tenant_1";   // single-tenant default (see migration 014b)

    // SLA target hours per state (driven by business rules, not schema)
    private static readonly Dictionary<string, decimal> StateSlaHours = new()
    {
        ["Draft"]                    = 24m,
        ["Supervisor_Review"]        = 8m,
        ["HSE_Review"]               = 8m,
        ["Area_Manager_Approval"]    = 4m,
        ["Active"]                   = 0m,   // no SLA once active
        ["Completion"]               = 4m,
        ["Closed"]                   = 0m,
    };

    public PermitService(
        IPermitRepository    repo,
        IPermissionService   perms,
        IAuditService        audit,
        IWorkflowService     workflow,
        INotificationService notify,
        ILogger<PermitService> log)
    {
        _repo     = repo;
        _perms    = perms;
        _audit    = audit;
        _workflow = workflow;
        _notify   = notify;
        _log      = log;
    }

    // ── RBAC ─────────────────────────────────────────────────────────────────
    public Task<bool> CheckPermAsync(string role, PsmAction action) =>
        _perms.CheckPermissionAsync(role, Module, action);

    // ── List ─────────────────────────────────────────────────────────────────
    public Task<(IEnumerable<PermitListDto> Rows, long Total)> ListAsync(
        string? state, string? permitType, string? riskLevel,
        string? tenantId, int limit, int offset) =>
        _repo.ListAsync(state, permitType, riskLevel, tenantId, limit, offset);

    // ── Get detail ────────────────────────────────────────────────────────────
    public async Task<PermitDetailDto?> GetAsync(string id, string userRole)
    {
        var permit = await _repo.GetByIdAsync(id);
        if (permit is null) return null;

        return await BuildDetailAsync(permit, userRole);
    }

    // ── Create ────────────────────────────────────────────────────────────────
    public async Task<PermitDetailDto> CreateAsync(
        CreatePermitRequest req, string userId, string userRole)
    {
        ValidateCreate(req);

        var id       = $"wp_{Guid.NewGuid():N}";
        var tenantId = req.TenantId ?? TenantId;

        await _repo.WithTransactionAsync(async (conn, tx) =>
        {
            await _repo.CreateAsync(conn, tx,
                id, tenantId,
                req.PermitType, req.JobTitle, req.Description, req.Location,
                req.JobDate, req.EstimatedDuration,
                req.ContractorName, req.ContractorLicense, req.Supervisor,
                req.RiskLevel, req.RequiredPpe, req.RequiredEquipment,
                req.AdditionalMeasures, req.WatchPerson, req.Tags, userId);

            // SLA entry for the initial Draft state
            await _repo.InsertSlaEntryAsync(conn, tx, id, "Draft", StateSlaHours["Draft"]);

            // Crew members
            foreach (var member in req.Crew ?? Enumerable.Empty<CreateCrewMemberRequest>())
                await _repo.AddCrewMemberAsync(conn, tx, id, member);
        });

        // Try to start workflow engine for this permit (non-fatal if no definition)
        await TryStartWorkflowAsync(id, req.PermitType, userId);

        // Audit
        await _audit.WriteAsync(userId, "CREATE_PERMIT", Module, id,
            $"Created {req.PermitType} permit: {req.JobTitle}");

        // Notify via central notification service
        await _notify.OnPermitEventAsync(
            id, "CREATED", req.JobTitle, req.PermitType,
            recipientUserId: null, actorName: userId);

        return (await GetAsync(id, userRole))!;
    }

    // ── Update ────────────────────────────────────────────────────────────────
    public async Task<PermitDetailDto> UpdateAsync(
        string id, UpdatePermitRequest req, string userId, string userRole)
    {
        if (!await _repo.ExistsAsync(id))
            throw new KeyNotFoundException($"Permit '{id}' not found.");

        await _repo.WithTransactionAsync(async (conn, tx) =>
            await _repo.UpdateAsync(conn, tx, id, req, userId));

        await _audit.WriteAsync(userId, "UPDATE_PERMIT", Module, id, "Permit updated");

        return (await GetAsync(id, userRole))!;
    }

    // ── Delete ────────────────────────────────────────────────────────────────
    public async Task DeleteAsync(string id, string userId)
    {
        if (!await _repo.ExistsAsync(id))
            throw new KeyNotFoundException($"Permit '{id}' not found.");

        await _repo.WithTransactionAsync(async (conn, tx) =>
            await _repo.DeleteAsync(conn, tx, id));

        await _audit.WriteAsync(userId, "DELETE_PERMIT", Module, id, "Permit deleted");
    }

    // ── Approve ───────────────────────────────────────────────────────────────
    public async Task<PermitDetailDto> ApproveAsync(
        string id, ApprovePermitRequest req, string userId, string userRole)
    {
        var permit = await _repo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Permit '{id}' not found.");

        if (permit.State is "Closed" or "Active")
            throw new InvalidOperationException($"Cannot approve permit in state '{permit.State}'.");

        var oldState = permit.State;

        bool shouldNotifyEscalation = false;

        await _repo.WithTransactionAsync(async (conn, tx) =>
        {
            // Exit current SLA entry
            await _repo.ExitSlaEntryAsync(conn, tx, id, oldState);

            // Set approval flag + advance state
            await _repo.SetApprovalAsync(conn, tx, id, req.Level, userId);

            // Compute the new state after SetApprovalAsync (reflects the nextState logic)
            var newState = req.Level.ToLower() switch
            {
                "supervisor"   => "HSE_Review",
                "hse"          => "Area_Manager_Approval",
                "area_manager" => "Active",
                _              => permit.State,
            };

            // SLA for the new state (skip if 0 or 'Active')
            if (StateSlaHours.TryGetValue(newState, out var sla) && sla > 0)
                await _repo.InsertSlaEntryAsync(conn, tx, id, newState, sla);

            // Check if escalation needed (all 3 approvals → no escalation needed)
            bool allApproved = req.Level.ToLower() == "area_manager";
            if (!allApproved)
            {
                // Check SLA on prior state for potential escalation
                var priorSlaHrs = StateSlaHours.GetValueOrDefault(oldState, 0m);
                if (priorSlaHrs > 0)
                {
                    // The DB trigger handles breach detection; we just emit escalation notification
                    shouldNotifyEscalation = true;
                }
            }
        });

        // Notification is a side effect and must not be able to roll back the
        // approval transaction above, nor write via an unrelated connection
        // while that transaction is still open.
        if (shouldNotifyEscalation)
        {
            await _notify.OnPermitEventAsync(
                id, "APPROVED", permit.JobTitle, permit.PermitType,
                recipientUserId: null, actorName: userId);
        }

        // Mirror the state transition through the workflow engine (non-fatal)
        await TryWorkflowTransitionAsync(id, req.Level, req.Comment, userId, userRole);

        await _audit.WriteAsync(userId, "APPROVE_PERMIT", Module, id,
            $"Approved at level '{req.Level}': {req.Comment}");

        return (await GetAsync(id, userRole))!;
    }

    // ── Close ─────────────────────────────────────────────────────────────────
    public async Task<PermitDetailDto> CloseAsync(
        string id, ClosePermitRequest req, string userId)
    {
        var permit = await _repo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Permit '{id}' not found.");

        if (permit.State == "Closed")
            throw new InvalidOperationException("Permit is already closed.");

        if (permit.State == "Draft")
            throw new InvalidOperationException("Cannot close a permit that has not been submitted.");

        var oldState = permit.State;

        await _repo.WithTransactionAsync(async (conn, tx) =>
        {
            // Exit SLA for current state
            await _repo.ExitSlaEntryAsync(conn, tx, id, oldState);

            await _repo.CloseAsync(conn, tx, id, req, userId);
        });

        // Mirror closure through workflow engine (non-fatal)
        await TryWorkflowTransitionAsync(id, "close", req.CompletionNotes, userId, "Admin");

        await _audit.WriteAsync(userId, "CLOSE_PERMIT", Module, id,
            $"Permit closed. Notes: {req.CompletionNotes}");

        await _notify.OnPermitEventAsync(
            id, "CLOSED", permit.JobTitle, permit.PermitType,
            recipientUserId: null, actorName: userId);

        return (await GetAsync(id, "Admin"))!;
    }

    // ── Sub-resources ─────────────────────────────────────────────────────────

    public async Task<PermitDetailDto> AddCrewMemberAsync(
        string id, CreateCrewMemberRequest req, string userId)
    {
        if (!await _repo.ExistsAsync(id))
            throw new KeyNotFoundException($"Permit '{id}' not found.");

        await _repo.WithTransactionAsync(async (conn, tx) =>
            await _repo.AddCrewMemberAsync(conn, tx, id, req));

        await _audit.WriteAsync(userId, "ADD_CREW_MEMBER", Module, id,
            $"Added crew member: {req.CrewMemberName}");

        return (await GetAsync(id, "Admin"))!;
    }

    public async Task<PermitDetailDto> AddSafetyRecordAsync(
        string id, AddSafetyRecordRequest req, string userId)
    {
        if (!await _repo.ExistsAsync(id))
            throw new KeyNotFoundException($"Permit '{id}' not found.");

        await _repo.WithTransactionAsync(async (conn, tx) =>
            await _repo.AddSafetyRecordAsync(conn, tx, id, req, userId));

        await _audit.WriteAsync(userId, "ADD_SAFETY_RECORD", Module, id,
            $"Safety check '{req.SafetyCheckType}': {req.Status}");

        return (await GetAsync(id, "Admin"))!;
    }

    public async Task<PermitDetailDto> AddLessonAsync(
        string id, AddLessonRequest req, string userId)
    {
        if (!await _repo.ExistsAsync(id))
            throw new KeyNotFoundException($"Permit '{id}' not found.");

        await _repo.WithTransactionAsync(async (conn, tx) =>
            await _repo.AddLessonAsync(conn, tx, id, req, userId));

        await _audit.WriteAsync(userId, "ADD_LESSON_LEARNED", Module, id,
            $"Lesson: {req.LessonTitle}");

        return (await GetAsync(id, "Admin"))!;
    }

    // ════════════════════════════════════════════════════════════════════════
    // Private helpers
    // ════════════════════════════════════════════════════════════════════════

    private async Task<PermitDetailDto> BuildDetailAsync(PermitDto permit, string userRole)
    {
        var crew          = await _repo.GetCrewAsync(permit.Id);
        var safety        = await _repo.GetSafetyRecordsAsync(permit.Id);
        var sla           = await _repo.GetSlaTrackingAsync(permit.Id);
        var escalations   = await _repo.GetEscalationsAsync(permit.Id);
        var lessons       = await _repo.GetLessonsAsync(permit.Id);

        // Determine available actions based on current state and role
        var actions = GetAvailableActions(permit.State, userRole,
            permit.SupervisorApproval, permit.HseApproval, permit.AreaManagerApproval);

        // Overdue: check if any open SLA entry is exceeded
        bool isOverdue = sla.Any(s => s.ExitedAt is null &&
            DateTime.UtcNow > s.EnteredAt.AddHours((double)s.TargetHours) &&
            s.TargetHours > 0);

        // Try to get workflow instance ID (non-fatal)
        string? wfInstanceId = null;
        try
        {
            var wfDetail = await _workflow.GetInstanceDetailAsync(permit.Id, userRole);
            wfInstanceId = wfDetail?.Id;
        }
        catch (Exception ex)
        {
            _log.LogDebug(ex, "No workflow instance for permit {PermitId}", permit.Id);
        }

        return new PermitDetailDto
        {
            Id                      = permit.Id,
            TenantId                = permit.TenantId,
            PermitType              = permit.PermitType,
            JobTitle                = permit.JobTitle,
            Description             = permit.Description,
            Location                = permit.Location,
            JobDate                 = permit.JobDate,
            EstimatedDuration       = permit.EstimatedDuration,
            ActualStartTime         = permit.ActualStartTime,
            ActualEndTime           = permit.ActualEndTime,
            ContractorName          = permit.ContractorName,
            ContractorLicense       = permit.ContractorLicense,
            Supervisor              = permit.Supervisor,
            State                   = permit.State,
            StateChangedAt          = permit.StateChangedAt,
            RiskLevel               = permit.RiskLevel,
            SupervisorApproval      = permit.SupervisorApproval,
            HseApproval             = permit.HseApproval,
            AreaManagerApproval     = permit.AreaManagerApproval,
            EscalationLevel         = permit.EscalationLevel,
            FormData                = permit.FormData,
            RequiredPpe             = permit.RequiredPpe,
            RequiredEquipment       = permit.RequiredEquipment,
            AdditionalMeasures      = permit.AdditionalMeasures,
            ActualDuration          = permit.ActualDuration,
            SafetyIncidents         = permit.SafetyIncidents,
            IssuesEncountered       = permit.IssuesEncountered,
            CompletionNotes         = permit.CompletionNotes,
            WatchPerson             = permit.WatchPerson,
            SafetyBriefingConducted = permit.SafetyBriefingConducted,
            EquipmentStatusCheck    = permit.EquipmentStatusCheck,
            SiteRestoration         = permit.SiteRestoration,
            ToolsReturned           = permit.ToolsReturned,
            CreatedBy               = permit.CreatedBy,
            CreatedAt               = permit.CreatedAt,
            LastModifiedBy          = permit.LastModifiedBy,
            UpdatedAt               = permit.UpdatedAt,
            Tags                    = permit.Tags,
            CustomFields            = permit.CustomFields,
            Crew                    = crew.ToList(),
            SafetyRecords           = safety.ToList(),
            SlaTracking             = sla.ToList(),
            Escalations             = escalations.ToList(),
            LessonsLearned          = lessons.ToList(),
            IsOverdue               = isOverdue,
            WorkflowInstanceId      = wfInstanceId,
            AvailableActions        = actions,
        };
    }

    private static List<string> GetAvailableActions(
        string state, string role,
        bool supervisorApproved, bool hseApproved, bool areaManagerApproved)
    {
        var actions = new List<string>();
        bool isAdmin    = role is "Admin" or "PSMManager";
        bool isSupervisor  = role is "Supervisor" or "Admin" or "PSMManager";
        bool isHse      = role is "HSEManager" or "Admin" or "PSMManager";
        bool isAreaMgr  = role is "AreaManager" or "Admin" or "PSMManager";

        switch (state)
        {
            case "Draft":
                if (isSupervisor)       actions.Add("submit");
                if (isAdmin)            actions.Add("delete");
                break;
            case "Supervisor_Review":
                if (isSupervisor && !supervisorApproved)  actions.Add("approve_supervisor");
                if (isAdmin)            actions.Add("reject");
                break;
            case "HSE_Review":
                if (isHse && !hseApproved)                actions.Add("approve_hse");
                if (isAdmin)            actions.Add("reject");
                break;
            case "Area_Manager_Approval":
                if (isAreaMgr && !areaManagerApproved)    actions.Add("approve_area_manager");
                if (isAdmin)            actions.Add("reject");
                break;
            case "Active":
                if (isSupervisor)       actions.Add("complete");
                if (isAdmin)            actions.Add("close");
                break;
            case "Completion":
                if (isSupervisor)       actions.Add("close");
                break;
        }

        return actions;
    }

    private static void ValidateCreate(CreatePermitRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.PermitType))
            throw new ArgumentException("permitType is required.");
        if (string.IsNullOrWhiteSpace(req.JobTitle))
            throw new ArgumentException("jobTitle is required.");
        if (string.IsNullOrWhiteSpace(req.Location))
            throw new ArgumentException("location is required.");
        if (string.IsNullOrWhiteSpace(req.ContractorName))
            throw new ArgumentException("contractorName is required.");
        if (string.IsNullOrWhiteSpace(req.Supervisor))
            throw new ArgumentException("supervisor is required.");
    }

    // ── Workflow engine integration (non-fatal wrappers) ──────────────────────

    private async Task TryStartWorkflowAsync(string permitId, string permitType, string userId)
    {
        try
        {
            var wfReq = new StartWorkflowRequest
            {
                recordId   = permitId,
                collection = $"PTW-{permitType.Replace(" ", "")}",
                priority   = "normal",
            };

            // Workflow may not have a definition for every permit type — that's OK
            await _workflow.StartWorkflowAsync(wfReq, userId);
        }
        catch (InvalidOperationException ex) when (
            ex.Message.Contains("No active workflow") ||
            ex.Message.Contains("already active") ||
            ex.Message.Contains("Record '") )
        {
            // Record not in records table (permits live in work_permits) or no WF definition
            _log.LogDebug("Workflow not started for permit {Id}: {Msg}", permitId, ex.Message);
        }
        catch (Exception ex)
        {
            _log.LogWarning(ex, "Non-fatal: workflow start failed for permit {Id}", permitId);
        }
    }

    private async Task TryWorkflowTransitionAsync(
        string permitId, string action, string? comment, string userId, string userRole)
    {
        try
        {
            var txReq = new TransitionRequest
            {
                recordId = permitId,
                action   = action,
                comment  = comment,
            };
            await _workflow.DoTransitionAsync(txReq, userId, userRole);
        }
        catch (Exception ex)
        {
            _log.LogDebug(ex, "Non-fatal: workflow transition '{Action}' failed for permit {Id}",
                action, permitId);
        }
    }
}
