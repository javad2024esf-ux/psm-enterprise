using PSM.Api.DTOs;
using PSM.Api.Repositories;

namespace PSM.Api.Services;
public interface IBowTieService
{
    // Diagrams
    Task<List<BowTieDiagramDto>> GetDiagramsAsync(string? hazopStudyId = null, string? lopaStudyId = null);
    Task<BowTieDiagramDetailDto?> GetDiagramAsync(string id);
    Task<string> CreateDiagramAsync(CreateBowTieDiagramDto dto, string userId);
    Task UpdateDiagramAsync(string id, UpdateBowTieDiagramDto dto, string userId);
    Task DeleteDiagramAsync(string id);

    // Causes
    Task<List<BowTieCauseDto>> GetCausesAsync(string diagramId);
    Task<string> CreateCauseAsync(CreateBowTieCauseDto dto, string userId);
    Task UpdateCauseAsync(string id, UpdateBowTieCauseDto dto, string userId);
    Task DeleteCauseAsync(string id);

    // Consequences
    Task<List<BowTieConsequenceDto>> GetConsequencesAsync(string diagramId);
    Task<string> CreateConsequenceAsync(CreateBowTieConsequenceDto dto, string userId);
    Task UpdateConsequenceAsync(string id, UpdateBowTieConsequenceDto dto, string userId);
    Task DeleteConsequenceAsync(string id);

    // Barriers
    Task<List<BowTieBarrierDto>> GetBarriersAsync(string diagramId);
    Task<string> CreateBarrierAsync(CreateBowTieBarrierDto dto, string userId);
    Task UpdateBarrierAsync(string id, UpdateBowTieBarrierDto dto, string userId);
    Task DeleteBarrierAsync(string id);

    // Controls
    Task<string> CreateControlAsync(CreateBowTieControlDto dto, string userId);
    Task UpdateControlAsync(string id, UpdateBowTieControlDto dto, string userId);
    Task DeleteControlAsync(string id);

    // Summary
    Task<BowTieSummaryDto> GetSummaryAsync();
}

public class BowTieService : IBowTieService
{
    private readonly IBowTieRepository _repository;

    public BowTieService(IBowTieRepository repository)
    {
        _repository = repository ?? throw new ArgumentNullException(nameof(repository));
    }

    public async Task<List<BowTieDiagramDto>> GetDiagramsAsync(string? hazopStudyId = null, string? lopaStudyId = null)
    {
        return await _repository.GetDiagramsAsync(hazopStudyId, lopaStudyId);
    }

    public async Task<BowTieDiagramDetailDto?> GetDiagramAsync(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("Diagram ID is required", nameof(id));

        return await _repository.GetDiagramAsync(id);
    }

    public async Task<string> CreateDiagramAsync(CreateBowTieDiagramDto dto, string userId)
    {
        if (dto == null)
            throw new ArgumentNullException(nameof(dto));

        if (string.IsNullOrWhiteSpace(dto.Title))
            throw new ArgumentException("Title is required", nameof(dto.Title));

        if (string.IsNullOrWhiteSpace(userId))
            throw new ArgumentException("User ID is required", nameof(userId));

        return await _repository.CreateDiagramAsync(dto, userId);
    }

    public async Task UpdateDiagramAsync(string id, UpdateBowTieDiagramDto dto, string userId)
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("Diagram ID is required", nameof(id));

        if (dto == null)
            throw new ArgumentNullException(nameof(dto));

        var existing = await _repository.GetDiagramAsync(id);
        if (existing == null)
            throw new KeyNotFoundException($"Diagram {id} not found");

        await _repository.UpdateDiagramAsync(id, dto, userId);
    }

    public async Task DeleteDiagramAsync(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("Diagram ID is required", nameof(id));

        var existing = await _repository.GetDiagramAsync(id);
        if (existing == null)
            throw new KeyNotFoundException($"Diagram {id} not found");

        await _repository.DeleteDiagramAsync(id);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CAUSES
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<List<BowTieCauseDto>> GetCausesAsync(string diagramId)
    {
        if (string.IsNullOrWhiteSpace(diagramId))
            throw new ArgumentException("Diagram ID is required", nameof(diagramId));

        return await _repository.GetCausesAsync(diagramId);
    }

    public async Task<string> CreateCauseAsync(CreateBowTieCauseDto dto, string userId)
    {
        if (dto == null)
            throw new ArgumentNullException(nameof(dto));

        if (string.IsNullOrWhiteSpace(dto.DiagramId))
            throw new ArgumentException("Diagram ID is required", nameof(dto.DiagramId));

        if (string.IsNullOrWhiteSpace(dto.Description))
            throw new ArgumentException("Description is required", nameof(dto.Description));

        return await _repository.CreateCauseAsync(dto, userId);
    }

    public async Task UpdateCauseAsync(string id, UpdateBowTieCauseDto dto, string userId)
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("Cause ID is required", nameof(id));

        if (dto == null)
            throw new ArgumentNullException(nameof(dto));

        await _repository.UpdateCauseAsync(id, dto, userId);
    }

    public async Task DeleteCauseAsync(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("Cause ID is required", nameof(id));

        await _repository.DeleteCauseAsync(id);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CONSEQUENCES
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<List<BowTieConsequenceDto>> GetConsequencesAsync(string diagramId)
    {
        if (string.IsNullOrWhiteSpace(diagramId))
            throw new ArgumentException("Diagram ID is required", nameof(diagramId));

        return await _repository.GetConsequencesAsync(diagramId);
    }

    public async Task<string> CreateConsequenceAsync(CreateBowTieConsequenceDto dto, string userId)
    {
        if (dto == null)
            throw new ArgumentNullException(nameof(dto));

        if (string.IsNullOrWhiteSpace(dto.DiagramId))
            throw new ArgumentException("Diagram ID is required", nameof(dto.DiagramId));

        if (string.IsNullOrWhiteSpace(dto.Description))
            throw new ArgumentException("Description is required", nameof(dto.Description));

        return await _repository.CreateConsequenceAsync(dto, userId);
    }

    public async Task UpdateConsequenceAsync(string id, UpdateBowTieConsequenceDto dto, string userId)
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("Consequence ID is required", nameof(id));

        if (dto == null)
            throw new ArgumentNullException(nameof(dto));

        await _repository.UpdateConsequenceAsync(id, dto, userId);
    }

    public async Task DeleteConsequenceAsync(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("Consequence ID is required", nameof(id));

        await _repository.DeleteConsequenceAsync(id);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // BARRIERS
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<List<BowTieBarrierDto>> GetBarriersAsync(string diagramId)
    {
        if (string.IsNullOrWhiteSpace(diagramId))
            throw new ArgumentException("Diagram ID is required", nameof(diagramId));

        return await _repository.GetBarriersAsync(diagramId);
    }

    public async Task<string> CreateBarrierAsync(CreateBowTieBarrierDto dto, string userId)
    {
        if (dto == null)
            throw new ArgumentNullException(nameof(dto));

        if (string.IsNullOrWhiteSpace(dto.DiagramId))
            throw new ArgumentException("Diagram ID is required", nameof(dto.DiagramId));

        if (string.IsNullOrWhiteSpace(dto.Description))
            throw new ArgumentException("Description is required", nameof(dto.Description));

        return await _repository.CreateBarrierAsync(dto, userId);
    }

    public async Task UpdateBarrierAsync(string id, UpdateBowTieBarrierDto dto, string userId)
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("Barrier ID is required", nameof(id));

        if (dto == null)
            throw new ArgumentNullException(nameof(dto));

        await _repository.UpdateBarrierAsync(id, dto, userId);
    }

    public async Task DeleteBarrierAsync(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("Barrier ID is required", nameof(id));

        await _repository.DeleteBarrierAsync(id);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CONTROLS
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<string> CreateControlAsync(CreateBowTieControlDto dto, string userId)
    {
        if (dto == null)
            throw new ArgumentNullException(nameof(dto));

        if (string.IsNullOrWhiteSpace(dto.BarrierId))
            throw new ArgumentException("Barrier ID is required", nameof(dto.BarrierId));

        if (string.IsNullOrWhiteSpace(dto.Description))
            throw new ArgumentException("Description is required", nameof(dto.Description));

        return await _repository.CreateControlAsync(dto, userId);
    }

    public async Task UpdateControlAsync(string id, UpdateBowTieControlDto dto, string userId)
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("Control ID is required", nameof(id));

        if (dto == null)
            throw new ArgumentNullException(nameof(dto));

        await _repository.UpdateControlAsync(id, dto, userId);
    }

    public async Task DeleteControlAsync(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("Control ID is required", nameof(id));

        await _repository.DeleteControlAsync(id);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // SUMMARY
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<BowTieSummaryDto> GetSummaryAsync()
    {
        return await _repository.GetSummaryAsync();
    }
}
