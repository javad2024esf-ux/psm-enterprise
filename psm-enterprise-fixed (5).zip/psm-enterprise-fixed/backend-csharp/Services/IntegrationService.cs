using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Repositories;
using System.Diagnostics;
using System.Text.Json;

namespace PSM.Api.Services;

public interface IIntegrationService
{
    Task<bool> CheckPermAsync(string role, PsmAction action);

    Task<IntegrationRuleListResponse> ListRulesAsync(
        string? sourceModule, string? targetModule, bool? isActive,
        int page, int limit);

    Task<IntegrationRuleDto> CreateRuleAsync(CreateIntegrationRuleRequest req, string userId);
    Task<bool> UpdateRuleAsync(string id, UpdateIntegrationRuleRequest req, string userId);
    Task<bool> DeleteRuleAsync(string id, string userId);

    Task<IntegrationEventListResponse> ListEventsAsync(
        string? sourceModule, string? eventType, string? status,
        int page, int limit);

    Task<IntegrationEventDto> RecordEventAsync(CreateIntegrationEventRequest req, string? userId = null);

    Task<IntegrationExecutionResultsResponse> ExecuteIntegrationAsync(
        string eventId, List<string>? ruleIds, string userId);

    Task<IntegrationStatsDto> GetStatsAsync();
}

public class IntegrationService : IIntegrationService
{
    private readonly IIntegrationRepository _repository;
    private readonly IPermissionService _permissionService;
    private readonly IAuditService _auditService;
    private readonly IWorkflowService _workflowService;
    private readonly ILogger<IntegrationService> _logger;

    private const string MODULE_NAME = "Integration";
    private const int MAX_RETRIES = 3;
    private const int RETRY_DELAY_MS = 1000;
    private const double RETRY_BACKOFF_MULTIPLIER = 2.0;

    private static readonly HashSet<string> VALID_EVENT_TYPES = new()
    {
        IntegrationEventTypes.StatusChange,
        IntegrationEventTypes.RecordCreated,
        IntegrationEventTypes.FieldChange,
        IntegrationEventTypes.Manual,
    };

    private static readonly HashSet<string> VALID_ACTION_TYPES = new()
    {
        IntegrationActionTypes.CreateRecord,
        IntegrationActionTypes.UpdateRecord,
        IntegrationActionTypes.SendNotification,
        IntegrationActionTypes.StartWorkflow,
        IntegrationActionTypes.CreateActionRegister,
        IntegrationActionTypes.TriggerWebhook,
    };

    private static readonly HashSet<string> VALID_EVENT_STATUSES = new()
    {
        IntegrationStatuses.Pending,
        IntegrationStatuses.Processing,
        IntegrationStatuses.Done,
        IntegrationStatuses.Failed,
    };

    public IntegrationService(
        IIntegrationRepository repository,
        IPermissionService permissionService,
        IAuditService auditService,
        IWorkflowService workflowService,
        ILogger<IntegrationService> logger)
    {
        _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        _permissionService = permissionService ?? throw new ArgumentNullException(nameof(permissionService));
        _auditService = auditService ?? throw new ArgumentNullException(nameof(auditService));
        _workflowService = workflowService ?? throw new ArgumentNullException(nameof(workflowService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public Task<bool> CheckPermAsync(string role, PsmAction action) =>
        _permissionService.CheckPermissionAsync(role, MODULE_NAME, action);

    // ── RULES ────────────────────────────────────────────────────────────────

    public async Task<IntegrationRuleListResponse> ListRulesAsync(
        string? sourceModule, string? targetModule, bool? isActive,
        int page, int limit)
    {
        try
        {
            limit = Math.Clamp(limit, 1, 100);
            page = Math.Max(page, 1);
            int offset = (page - 1) * limit;

            // FIX: ListRulesAsync interface takes (sourceModule, isActive, limit, offset) — 4 params, no targetModule
            var (rows, total) = await _repository.ListRulesAsync(
                sourceModule, isActive, limit, offset);

            _logger.LogDebug("Listed {Count} integration rules from total {Total}",
                rows.Count(), total);

            return new IntegrationRuleListResponse
            {
                Data = rows.ToList(),
                Total = (int)total,
                Page = page,
                Limit = limit,
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing integration rules");
            throw;
        }
    }

    public async Task<IntegrationRuleDto> CreateRuleAsync(CreateIntegrationRuleRequest req, string userId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(req.Name))
                throw new ArgumentException("نام قانون الزامی است");
            if (string.IsNullOrWhiteSpace(req.SourceModule))
                throw new ArgumentException("ماژول منبع الزامی است");
            if (string.IsNullOrWhiteSpace(req.TriggerEvent))
                throw new ArgumentException("نوع رویداد الزامی است");
            if (!VALID_EVENT_TYPES.Contains(req.TriggerEvent))
                throw new ArgumentException($"نوع رویداد نامعتبر: {req.TriggerEvent}");
            if (string.IsNullOrWhiteSpace(req.TargetModule))
                throw new ArgumentException("ماژول هدف الزامی است");
            if (string.IsNullOrWhiteSpace(req.ActionType))
                throw new ArgumentException("نوع عملیات الزامی است");
            if (!VALID_ACTION_TYPES.Contains(req.ActionType))
                throw new ArgumentException($"نوع عملیات نامعتبر: {req.ActionType}");

            // FIX: CreateRuleAsync interface takes (CreateIntegrationRuleRequest req, string userId)
            var id = await _repository.CreateRuleAsync(req, userId);

            await _auditService.WriteAsync(userId, "CREATE_RULE", MODULE_NAME, id,
                $"Created integration rule: {req.Name} ({req.SourceModule} → {req.TargetModule})");

            _logger.LogInformation("Integration rule created: {Id} ({Name}) by {UserId}",
                id, req.Name, userId);

            return (await _repository.GetRuleByIdAsync(id))!;
        }
        catch (ArgumentException) { throw; }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating integration rule");
            throw;
        }
    }

    public async Task<bool> UpdateRuleAsync(string id, UpdateIntegrationRuleRequest req, string userId)
    {
        try
        {
            var existing = await _repository.GetRuleByIdAsync(id);
            if (existing is null)
            {
                _logger.LogWarning("Attempt to update non-existent rule: {Id}", id);
                return false;
            }

            if (!string.IsNullOrEmpty(req.TriggerEvent) && !VALID_EVENT_TYPES.Contains(req.TriggerEvent))
                throw new ArgumentException($"نوع رویداد نامعتبر: {req.TriggerEvent}");
            if (!string.IsNullOrEmpty(req.ActionType) && !VALID_ACTION_TYPES.Contains(req.ActionType))
                throw new ArgumentException($"نوع عملیات نامعتبر: {req.ActionType}");

            await _repository.UpdateRuleAsync(id, req);

            var changes = new List<string>();
            if (!string.IsNullOrEmpty(req.Name) && req.Name != existing.Name)
                changes.Add($"Name: '{existing.Name}' → '{req.Name}'");
            if (!string.IsNullOrEmpty(req.TriggerEvent) && req.TriggerEvent != existing.TriggerEvent)
                changes.Add($"TriggerEvent: '{existing.TriggerEvent}' → '{req.TriggerEvent}'");
            if (req.IsActive.HasValue && req.IsActive != existing.IsActive)
                changes.Add($"IsActive: {existing.IsActive} → {req.IsActive}");

            var auditDetails = changes.Count > 0
                ? string.Join("; ", changes)
                : "Updated integration rule";

            await _auditService.WriteAsync(userId, "UPDATE_RULE", MODULE_NAME, id, auditDetails);

            _logger.LogInformation("Integration rule updated: {Id} by {UserId}. Changes: {Changes}",
                id, userId, string.Join(", ", changes));

            return true;
        }
        catch (ArgumentException) { throw; }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating integration rule {Id}", id);
            throw;
        }
    }

    public async Task<bool> DeleteRuleAsync(string id, string userId)
    {
        try
        {
            var existing = await _repository.GetRuleByIdAsync(id);
            if (existing is null)
            {
                _logger.LogWarning("Attempt to delete non-existent rule: {Id}", id);
                return false;
            }

            await _repository.DeleteRuleAsync(id);

            await _auditService.WriteAsync(userId, "DELETE_RULE", MODULE_NAME, id,
                $"Deleted integration rule: {existing.Name}");

            _logger.LogInformation("Integration rule deleted: {Id} by {UserId}", id, userId);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting integration rule {Id}", id);
            throw;
        }
    }

    // ── EVENTS ───────────────────────────────────────────────────────────────

    public async Task<IntegrationEventListResponse> ListEventsAsync(
        string? sourceModule, string? eventType, string? status,
        int page, int limit)
    {
        try
        {
            limit = Math.Clamp(limit, 1, 100);
            page = Math.Max(page, 1);
            int offset = (page - 1) * limit;

            if (!string.IsNullOrEmpty(status) && !VALID_EVENT_STATUSES.Contains(status))
                throw new ArgumentException($"وضعیت نامعتبر: {status}");

            // FIX: ListEventsAsync interface takes (status, sourceModule, limit, offset) — 4 params
            var (rows, total) = await _repository.ListEventsAsync(
                status, sourceModule, limit, offset);

            _logger.LogDebug("Listed {Count} integration events from total {Total}",
                rows.Count(), total);

            return new IntegrationEventListResponse
            {
                Data = rows.ToList(),
                Total = (int)total,
                Page = page,
                Limit = limit,
            };
        }
        catch (ArgumentException) { throw; }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing integration events");
            throw;
        }
    }

    public async Task<IntegrationEventDto> RecordEventAsync(CreateIntegrationEventRequest req, string? userId = null)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(req.EventType))
                throw new ArgumentException("نوع رویداد الزامی است");
            if (string.IsNullOrWhiteSpace(req.SourceModule))
                throw new ArgumentException("ماژول منبع الزامی است");
            if (string.IsNullOrWhiteSpace(req.SourceId))
                throw new ArgumentException("شناسه منبع الزامی است");

            // FIX: CreateEventAsync interface takes (CreateIntegrationEventRequest req) — 1 param
            var eventId = await _repository.CreateEventAsync(req);

            _logger.LogInformation(
                "Integration event recorded: {EventId} ({EventType}) from {SourceModule}/{SourceId}",
                eventId, req.EventType, req.SourceModule, req.SourceId);

            return (await _repository.GetEventByIdAsync(eventId))!;
        }
        catch (ArgumentException) { throw; }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error recording integration event");
            throw;
        }
    }

    // ── EXECUTION ────────────────────────────────────────────────────────────

    public async Task<IntegrationExecutionResultsResponse> ExecuteIntegrationAsync(
        string eventId, List<string>? ruleIds, string userId)
    {
        try
        {
            var evt = await _repository.GetEventByIdAsync(eventId);
            if (evt is null)
                throw new ArgumentException($"رویداد '{eventId}' یافت نشد");

            // FIX: UpdateEventStatusAsync takes (eventId, status, errorMessage?) — 3 params
            await _repository.UpdateEventStatusAsync(eventId, IntegrationStatuses.Processing);

            var rules = await _repository.GetMatchingRulesAsync(
                evt.SourceModule, evt.EventType, ruleIds);

            if (!rules.Any())
            {
                _logger.LogInformation("No matching rules for event {EventId}", eventId);
                await _repository.UpdateEventStatusAsync(eventId, IntegrationStatuses.Done);
                return new IntegrationExecutionResultsResponse();
            }

            var results = new List<IntegrationExecutionResponse>();

            foreach (var rule in rules.OrderBy(r => r.Priority))
            {
                try
                {
                    var result = await ExecuteRuleWithRetryAsync(evt, rule, userId);
                    results.Add(result);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error executing rule {RuleId} for event {EventId}",
                        rule.Id, eventId);
                    results.Add(new IntegrationExecutionResponse
                    {
                        ExecutionId = GenerateExecutionId(),
                        Status = IntegrationStatuses.Failed,
                        ErrorMessage = ex.Message,
                    });
                }
            }

            int successful = results.Count(r => r.Status == IntegrationStatuses.Success);
            int failed = results.Count(r => r.Status == IntegrationStatuses.Failed);
            string finalStatus = failed > 0 ? IntegrationStatuses.Failed : IntegrationStatuses.Done;

            await _repository.UpdateEventStatusAsync(eventId, finalStatus);

            await _auditService.WriteAsync(userId, "EXECUTE_INTEGRATION", MODULE_NAME, eventId,
                $"Executed {results.Count} rules: {successful} successful, {failed} failed");

            _logger.LogInformation(
                "Integration execution completed for event {EventId}: {Successful} successful, {Failed} failed",
                eventId, successful, failed);

            return new IntegrationExecutionResultsResponse
            {
                Executions = results,
                Successful = successful,
                Failed = failed,
                Skipped = results.Count(r => r.Status == IntegrationStatuses.Skipped),
            };
        }
        catch (ArgumentException) { throw; }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in integration execution for event {EventId}", eventId);
            throw;
        }
    }

    private async Task<IntegrationExecutionResponse> ExecuteRuleWithRetryAsync(
        IntegrationEventDto evt, IntegrationRuleDto rule, string userId, int attemptNumber = 1)
    {
        var stopwatch = Stopwatch.StartNew();
        string executionId = GenerateExecutionId();

        try
        {
            if (!ConditionMatches(rule.TriggerCondition, evt.Payload))
            {
                _logger.LogDebug("Rule {RuleId} condition did not match event {EventId}",
                    rule.Id, evt.Id);

                // FIX: CreateExecutionAsync arg4 is JsonElement? — pass null, not string
                await _repository.CreateExecutionAsync(
                    evt.Id, rule.Id, IntegrationStatuses.Skipped,
                    result: null, errorMessage: null);

                return new IntegrationExecutionResponse
                {
                    ExecutionId = executionId,
                    Status = IntegrationStatuses.Skipped,
                };
            }

            var actionResult = await ExecuteActionAsync(rule, evt);

            stopwatch.Stop();

            // FIX: serialize Dictionary result to JsonElement for CreateExecutionAsync
            var resultJson = JsonSerializer.SerializeToElement(actionResult);
            await _repository.CreateExecutionAsync(
                evt.Id, rule.Id, IntegrationStatuses.Success,
                result: resultJson,
                errorMessage: null,
                durationMs: (int)stopwatch.ElapsedMilliseconds);

            _logger.LogInformation(
                "Rule {RuleId} executed successfully for event {EventId} in {DurationMs}ms",
                rule.Id, evt.Id, stopwatch.ElapsedMilliseconds);

            return new IntegrationExecutionResponse
            {
                ExecutionId = executionId,
                Status = IntegrationStatuses.Success,
                Result = actionResult,
                DurationMs = (int)stopwatch.ElapsedMilliseconds,
            };
        }
        catch (Exception ex)
        {
            stopwatch.Stop();

            if (attemptNumber < MAX_RETRIES)
            {
                int delayMs = (int)(RETRY_DELAY_MS * Math.Pow(RETRY_BACKOFF_MULTIPLIER, attemptNumber - 1));
                _logger.LogWarning(
                    "Rule {RuleId} failed (attempt {Attempt}/{Max}), retrying in {DelayMs}ms: {Error}",
                    rule.Id, attemptNumber, MAX_RETRIES, delayMs, ex.Message);

                await Task.Delay(delayMs);
                return await ExecuteRuleWithRetryAsync(evt, rule, userId, attemptNumber + 1);
            }

            await _repository.CreateExecutionAsync(
                evt.Id, rule.Id, IntegrationStatuses.Failed,
                result: null,
                errorMessage: ex.Message);

            _logger.LogError(ex, "Rule {RuleId} failed after {Attempts} attempts for event {EventId}",
                rule.Id, MAX_RETRIES, evt.Id);

            return new IntegrationExecutionResponse
            {
                ExecutionId = executionId,
                Status = IntegrationStatuses.Failed,
                ErrorMessage = ex.Message,
                DurationMs = (int)stopwatch.ElapsedMilliseconds,
            };
        }
    }

    private async Task<Dictionary<string, object>> ExecuteActionAsync(
        IntegrationRuleDto rule, IntegrationEventDto evt)
    {
        return rule.ActionType switch
        {
            IntegrationActionTypes.CreateRecord =>
                await ExecuteCreateRecordAsync(rule, evt),
            IntegrationActionTypes.UpdateRecord =>
                await ExecuteUpdateRecordAsync(rule, evt),
            IntegrationActionTypes.SendNotification =>
                ExecuteSendNotification(rule, evt),
            IntegrationActionTypes.StartWorkflow =>
                await ExecuteStartWorkflowAsync(rule, evt),
            IntegrationActionTypes.CreateActionRegister =>
                await ExecuteCreateActionRegisterAsync(rule, evt),
            IntegrationActionTypes.TriggerWebhook =>
                await ExecuteTriggerWebhookAsync(rule, evt),
            _ => throw new NotSupportedException($"Action type not supported: {rule.ActionType}"),
        };
    }

    private async Task<Dictionary<string, object>> ExecuteCreateRecordAsync(
        IntegrationRuleDto rule, IntegrationEventDto evt)
    {
        _logger.LogDebug("Creating record in {TargetModule} via rule {RuleId}", rule.TargetModule, rule.Id);
        await Task.CompletedTask;
        return new Dictionary<string, object>
        {
            { "action", "CREATE_RECORD" },
            { "targetModule", rule.TargetModule },
            { "recordId", $"auto_{Guid.NewGuid():N}" },
        };
    }

    private async Task<Dictionary<string, object>> ExecuteUpdateRecordAsync(
        IntegrationRuleDto rule, IntegrationEventDto evt)
    {
        _logger.LogDebug("Updating record in {TargetModule} via rule {RuleId}", rule.TargetModule, rule.Id);
        await Task.CompletedTask;
        return new Dictionary<string, object>
        {
            { "action", "UPDATE_RECORD" },
            { "targetModule", rule.TargetModule },
        };
    }

    private Dictionary<string, object> ExecuteSendNotification(
        IntegrationRuleDto rule, IntegrationEventDto evt)
    {
        _logger.LogDebug("Sending notification via rule {RuleId}", rule.Id);
        return new Dictionary<string, object>
        {
            { "action", "SEND_NOTIFICATION" },
            { "notificationId", $"notif_{Guid.NewGuid():N}" },
        };
    }

    private async Task<Dictionary<string, object>> ExecuteStartWorkflowAsync(
        IntegrationRuleDto rule, IntegrationEventDto evt)
    {
        _logger.LogDebug("Starting workflow via rule {RuleId}", rule.Id);
        await Task.CompletedTask;
        return new Dictionary<string, object>
        {
            { "action", "START_WORKFLOW" },
            { "workflowStarted", true },
        };
    }

    private async Task<Dictionary<string, object>> ExecuteCreateActionRegisterAsync(
        IntegrationRuleDto rule, IntegrationEventDto evt)
    {
        _logger.LogDebug("Creating action register record via rule {RuleId}", rule.Id);
        await Task.CompletedTask;
        return new Dictionary<string, object>
        {
            { "action", "CREATE_ACTION_REGISTER" },
            { "actionId", $"act_{Guid.NewGuid():N}" },
        };
    }

    private async Task<Dictionary<string, object>> ExecuteTriggerWebhookAsync(
        IntegrationRuleDto rule, IntegrationEventDto evt)
    {
        _logger.LogDebug("Triggering webhook via rule {RuleId}", rule.Id);
        await Task.CompletedTask;
        return new Dictionary<string, object>
        {
            { "action", "TRIGGER_WEBHOOK" },
            { "success", true },
        };
    }

    // ── STATISTICS ───────────────────────────────────────────────────────────

    public async Task<IntegrationStatsDto> GetStatsAsync()
    {
        try
        {
            return await _repository.GetStatsAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting integration statistics");
            throw;
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private bool ConditionMatches(
        Dictionary<string, object>? triggerCondition,
        Dictionary<string, object>? eventPayload)
    {
        if (triggerCondition == null || triggerCondition.Count == 0)
            return true;
        if (eventPayload == null || eventPayload.Count == 0)
            return false;

        foreach (var kvp in triggerCondition)
        {
            if (!eventPayload.TryGetValue(kvp.Key, out var payloadValue))
                return false;
            if (!kvp.Value.Equals(payloadValue))
                return false;
        }
        return true;
    }

    private static string GenerateRuleId() => $"rule_{Guid.NewGuid():N}";
    private static string GenerateEventId() => $"evt_{Guid.NewGuid():N}";
    private static string GenerateExecutionId() => $"exec_{Guid.NewGuid():N}";
}
