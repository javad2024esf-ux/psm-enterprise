using PSM.Api.Models;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

public interface IAuthService
{
    Task<(User? User, string? Error)> ValidateCredentialsAsync(string username, string password);
    Task<(string AccessToken, string RefreshToken)> IssueTokensAsync(User user);
    Task<(string? AccessToken, string? RefreshToken, string? Error)> RefreshAsync(string refreshToken);
    Task RevokeRefreshTokenAsync(string token);
    Task RevokeAllTokensAsync(string userId);
}

public class AuthService : IAuthService
{
    private readonly IUserRepository         _users;
    private readonly IRefreshTokenRepository _refreshTokens;
    private readonly ITokenService           _tokenSvc;
    private readonly IPasswordHasher         _hasher;

    private const int MaxAttempts   = 5;
    private const int LockoutMinutes = 15;

    public AuthService(
        IUserRepository users,
        IRefreshTokenRepository refreshTokens,
        ITokenService tokenSvc,
        IPasswordHasher hasher)
    {
        _users         = users;
        _refreshTokens = refreshTokens;
        _tokenSvc      = tokenSvc;
        _hasher        = hasher;
    }

    public async Task<(User? User, string? Error)> ValidateCredentialsAsync(string username, string password)
    {
        // ✅ Fix: Trim username and password to remove whitespace
        var cleanUsername = (username ?? "").Trim();
        var cleanPassword = (password ?? "").Trim();

        if (string.IsNullOrEmpty(cleanUsername) || string.IsNullOrEmpty(cleanPassword))
            return (null, "نام کاربری و رمز عبور الزامی است");

        var user = await _users.GetByUsernameAsync(cleanUsername);
        if (user is null) return (null, "نام کاربری یا رمز عبور اشتباه است");

        if (user.Status == "Disabled") return (null, "حساب کاربری غیرفعال است");

        if (user.LockedUntil.HasValue && user.LockedUntil > DateTime.UtcNow)
            return (null, $"حساب قفل شده است تا {user.LockedUntil:HH:mm}");

        // ✅ Fix: Validate password hash exists
        if (string.IsNullOrEmpty(user.PasswordHash))
            return (null, "خطای سیستم: رمز عبور ذخیره نشده است");

        if (!_hasher.Verify(cleanPassword, user.PasswordHash))
        {
            await _users.IncrementFailedAttemptsAsync(user.Id);
            if (user.FailedAttempts + 1 >= MaxAttempts)
                await _users.LockAsync(user.Id, DateTime.UtcNow.AddMinutes(LockoutMinutes));
            return (null, "نام کاربری یا رمز عبور اشتباه است");
        }

        await _users.ResetFailedAttemptsAsync(user.Id);
        await _users.UpdateLastLoginAsync(user.Id);
        return (user, null);
    }

    public async Task<(string AccessToken, string RefreshToken)> IssueTokensAsync(User user)
    {
        var access  = _tokenSvc.GenerateAccessToken(user);
        var refresh = _tokenSvc.GenerateRefreshToken();

        await _refreshTokens.CreateAsync(new Models.RefreshToken
        {
            Id        = $"rt_{Guid.NewGuid():N}",
            UserId    = user.Id,
            Token     = refresh,
            ExpiresAt = DateTime.UtcNow.AddDays(7),
            CreatedAt = DateTime.UtcNow,
            Revoked   = false,
        });

        return (access, refresh);
    }

    public async Task<(string? AccessToken, string? RefreshToken, string? Error)> RefreshAsync(string refreshToken)
    {
        var rt = await _refreshTokens.GetAsync(refreshToken);
        if (rt is null) return (null, null, "توکن نامعتبر یا منقضی شده است");

        var user = await _users.GetByIdAsync(rt.UserId);
        if (user is null || user.Status != "Active") return (null, null, "کاربر یافت نشد");

        await _refreshTokens.RevokeAsync(refreshToken);
        var (access, newRefresh) = await IssueTokensAsync(user);
        return (access, newRefresh, null);
    }

    public Task RevokeRefreshTokenAsync(string token) => _refreshTokens.RevokeAsync(token);
    public Task RevokeAllTokensAsync(string userId)   => _refreshTokens.RevokeAllForUserAsync(userId);
}
