using PSM.Api.DTOs;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

// ════════════════════════════════════════════════════════════════════════════
// ILopaBowTieIntegrationService
// ════════════════════════════════════════════════════════════════════════════

public interface ILopaBowTieIntegrationService
{
    /// <summary>
    /// Creates a BowTie diagram from an approved LOPA Scenario.
    /// Risk values (MitigatedFrequency, ConsequenceSeverity, SilRequired,
    /// TargetRisk, RiskGapMet) flow from LOPA into the diagram metadata and
    /// its consequence node severity.  Each LOPA IPL is optionally imported
    /// as a prevention barrier so that IPL PFD is visible in the BowTie.
    /// </summary>
    Task<CreateBowTieFromLopaScenarioResultDto> CreateBowTieFromLopaScenarioAsync(
        CreateBowTieFromLopaScenarioRequest request,
        string userId,
        string? ipAddress = null,
        string? userAgent = null);

    /// <summary>
    /// Returns the BowTie diagram (if any) already linked to a LOPA scenario.
    /// </summary>
    Task<BowTieDiagramDetailDto?> GetLinkedBowTieDiagramAsync(string lopaScenarioId);

    /// <summary>
    /// Summary — how many scenarios in the LOPA study have a linked BowTie.
    /// </summary>
    Task<LopaBowTieIntegrationSummaryDto> GetIntegrationSummaryAsync(string lopaStudyId);
}

// ════════════════════════════════════════════════════════════════════════════
// LopaBowTieIntegrationService
// ════════════════════════════════════════════════════════════════════════════

public class LopaBowTieIntegrationService : ILopaBowTieIntegrationService
{
    private readonly ILopaRepository _lopaRepo;
    private readonly IBowTieRepository _bowTieRepo;
    private readonly IAuditService _auditService;
    private readonly ILogger<LopaBowTieIntegrationService> _logger;

    public LopaBowTieIntegrationService(
        ILopaRepository lopaRepo,
        IBowTieRepository bowTieRepo,
        IAuditService auditService,
        ILogger<LopaBowTieIntegrationService> logger)
    {
        _lopaRepo    = lopaRepo;
        _bowTieRepo  = bowTieRepo;
        _auditService = auditService;
        _logger      = logger;
    }

    // ─────────────────────────────────────────────────────────────────────
    // CreateBowTieFromLopaScenarioAsync
    // ─────────────────────────────────────────────────────────────────────

    public async Task<CreateBowTieFromLopaScenarioResultDto> CreateBowTieFromLopaScenarioAsync(
        CreateBowTieFromLopaScenarioRequest request,
        string userId,
        string? ipAddress = null,
        string? userAgent = null)
    {
        if (string.IsNullOrWhiteSpace(request.lopa_scenario_id))
            throw new ArgumentException("lopa_scenario_id is required");

        // ── 1. Load the LOPA Scenario ─────────────────────────────────────
        var scenario = await _lopaRepo.GetScenarioAsync(request.lopa_scenario_id);
        if (scenario == null)
            throw new InvalidOperationException(
                $"LOPA Scenario {request.lopa_scenario_id} not found");

        // ── 2. Reject if a BowTie already exists for this scenario ────────
        var existingDiagramId =
            await _lopaRepo.GetScenarioBowTieDiagramIdAsync(request.lopa_scenario_id);
        if (!string.IsNullOrWhiteSpace(existingDiagramId))
            throw new InvalidOperationException(
                $"LOPA Scenario {request.lopa_scenario_id} already has a linked BowTie " +
                $"diagram ({existingDiagramId}). Delete the existing diagram before creating a new one.");

        // ── 3. Build the diagram title ────────────────────────────────────
        var diagramTitle = request.bowtie_title
            ?? $"BowTie – {scenario.ScenarioNumber}: {scenario.InitiatingEvent}";

        // ── 4. Risk values from LOPA that flow into BowTie ───────────────
        //  MitigatedFrequency, ConsequenceSeverity, SilRequired,
        //  TargetRisk and RiskGapMet are stored in bowtie_diagrams.data
        //  so they are visible to the front-end without an extra LOPA fetch.
        var riskMetadata = new Dictionary<string, object>
        {
            { "source_module",          "LOPA" },
            { "lopa_scenario_id",       scenario.Id!    },
            { "lopa_study_id",          scenario.StudyId ?? "" },
            { "hazop_study_id",         scenario.HazopStudyId ?? "" },
            { "hazop_deviation_id",     scenario.HazopDeviationId ?? "" },
            { "initiating_frequency",   scenario.InitiatingFrequency },
            { "mitigated_frequency",    scenario.MitigatedFrequency },
            { "target_risk",            scenario.TargetRisk },
            { "risk_gap_met",           scenario.RiskGapMet },
            { "consequence_severity",   scenario.ConsequenceSeverity },
            { "sil_required",           scenario.SilRequired ?? "None" },
            { "sil_achieved",           scenario.SilAchieved ?? "None" },
            { "required_rrf_sis",       scenario.RequiredRrfSis },
            { "achieved_rrf_sis",       scenario.AchievedRrfSis },
        };

        // Merge any caller-supplied extra data
        if (request.data != null)
            foreach (var kv in request.data)
                riskMetadata[kv.Key] = kv.Value;

        // ── 5. Create the BowTie diagram ──────────────────────────────────
        var diagramDto = new CreateBowTieDiagramDto
        {
            Title                = diagramTitle,
            Description          = $"Generated from LOPA Scenario {scenario.ScenarioNumber}. " +
                                   $"SIL Required: {scenario.SilRequired ?? "None"}. " +
                                   $"Risk Gap Met: {scenario.RiskGapMet}.",
            LopaStudyId          = scenario.StudyId,
            HazopStudyId         = scenario.HazopStudyId,
            TopEventDescription  = request.top_event ?? scenario.InitiatingEvent,
        };

        var diagramId = await _bowTieRepo.CreateDiagramAsync(diagramDto, userId);

        // ── 6. Create the consequence node (right side of BowTie) ─────────
        //  Severity is mapped directly from the LOPA ConsequenceSeverity (1-5).
        var consequenceId = await _bowTieRepo.CreateConsequenceAsync(
            new CreateBowTieConsequenceDto
            {
                DiagramId          = diagramId,
                Description        = scenario.ConsequenceDescription
                                     ?? $"Consequence of: {scenario.InitiatingEvent}",
                Severity           = scenario.ConsequenceSeverity.ToString(),
                SortOrder          = 0,
                // ── Risk values from LOPA flow into the BowTie consequence ──
                LopaScenarioId     = scenario.Id,
                MitigatedFrequency = scenario.MitigatedFrequency,
                TargetRisk         = scenario.TargetRisk,
                SilRequired        = scenario.SilRequired,
            },
            userId);

        // ── 7. Create the cause/threat node (left side of BowTie) ────────
        //  The LOPA initiating event is the threat.
        var causeId = await _bowTieRepo.CreateCauseAsync(
            new CreateBowTieCauseDto
            {
                DiagramId   = diagramId,
                Description = scenario.InitiatingEvent ?? "Unspecified initiating event",
                Category    = "Process",
                SortOrder   = 0,
            },
            userId);

        // ── 8. Import LOPA IPLs as prevention barriers ────────────────────
        int barriersCreated = 0;

        if (request.import_ipls_as_barriers)
        {
            var ipls = (await _lopaRepo.ListIplsByScenarioAsync(
                request.lopa_scenario_id)).ToList();

            for (int i = 0; i < ipls.Count; i++)
            {
                var ipl = ipls[i];
                try
                {
                    // PFD from LOPA becomes the barrier's risk_reduction label.
                    var riskReductionLabel = ipl.Pfd > 0
                        ? $"PFD={ipl.Pfd:G4} (RRF={1.0 / ipl.Pfd:F0})"
                        : null;

                    await _bowTieRepo.CreateBarrierAsync(
                        new CreateBowTieBarrierDto
                        {
                            DiagramId     = diagramId,
                            Description   = $"[IPL] {ipl.IplName}" +
                                            (string.IsNullOrWhiteSpace(ipl.Description)
                                                ? "" : $" – {ipl.Description}"),
                            Type          = "Prevention",
                            RiskReduction = riskReductionLabel,
                            SortOrder     = i,
                        },
                        userId);

                    barriersCreated++;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex,
                        "Failed to import LOPA IPL {IplId} as BowTie barrier", ipl.Id);
                }
            }
        }

        // ── 9. Back-link: store the new diagram ID on the LOPA scenario ───
        await _lopaRepo.LinkScenarioToBowTieAsync(request.lopa_scenario_id, diagramId);

        // ── 10. Audit log ─────────────────────────────────────────────────
        await _auditService.LogAsync(
            module:  "LOPA-BowTie",
            action:  "CREATE_BOWTIE_FROM_LOPA_SCENARIO",
            details: $"Created BowTie {diagramId} from LOPA Scenario {request.lopa_scenario_id} " +
                     $"({barriersCreated} barriers imported)",
            userId:  userId);

        // ── 11. Return result ─────────────────────────────────────────────
        var diagramDetail = await _bowTieRepo.GetDiagramAsync(diagramId);

        return new CreateBowTieFromLopaScenarioResultDto
        {
            BowTieDiagramId      = diagramId,
            Diagram              = diagramDetail,
            LopaScenarioId       = scenario.Id,
            LopaStudyId          = scenario.StudyId,
            HazopStudyId         = scenario.HazopStudyId,
            HazopDeviationId     = scenario.HazopDeviationId,
            MitigatedFrequency   = scenario.MitigatedFrequency,
            TargetRisk           = scenario.TargetRisk,
            ConsequenceSeverity  = scenario.ConsequenceSeverity,
            SilRequired          = scenario.SilRequired,
            RiskGapMet           = scenario.RiskGapMet,
            BarriersCreated      = barriersCreated,
            Message              = $"BowTie diagram created successfully from LOPA Scenario " +
                                   $"{scenario.ScenarioNumber}. " +
                                   $"{barriersCreated} IPL(s) imported as prevention barriers.",
        };
    }

    // ─────────────────────────────────────────────────────────────────────
    // GetLinkedBowTieDiagramAsync
    // ─────────────────────────────────────────────────────────────────────

    public async Task<BowTieDiagramDetailDto?> GetLinkedBowTieDiagramAsync(string lopaScenarioId)
    {
        var diagramId = await _lopaRepo.GetScenarioBowTieDiagramIdAsync(lopaScenarioId);
        if (string.IsNullOrWhiteSpace(diagramId))
            return null;
        return await _bowTieRepo.GetDiagramAsync(diagramId);
    }

    // ─────────────────────────────────────────────────────────────────────
    // GetIntegrationSummaryAsync
    // ─────────────────────────────────────────────────────────────────────

    public async Task<LopaBowTieIntegrationSummaryDto> GetIntegrationSummaryAsync(
        string lopaStudyId)
    {
        var study = await _lopaRepo.GetStudyAsync(lopaStudyId);
        if (study == null)
            throw new InvalidOperationException($"LOPA Study {lopaStudyId} not found");

        var scenarios = (await _lopaRepo.ListScenariosAsync(lopaStudyId)).ToList();

        var linkedIds = new List<string>();
        foreach (var s in scenarios)
        {
            var diagramId = await _lopaRepo.GetScenarioBowTieDiagramIdAsync(s.Id!);
            if (!string.IsNullOrWhiteSpace(diagramId))
                linkedIds.Add(diagramId);
        }

        var total = scenarios.Count;
        var withBowTie = linkedIds.Count;

        return new LopaBowTieIntegrationSummaryDto
        {
            LopaStudyId              = lopaStudyId,
            LopaStudyTitle           = study.Title,
            TotalScenarios           = total,
            ScenariosWithBowTie      = withBowTie,
            CoveragePercentage       = total > 0 ? Math.Round(withBowTie * 100.0 / total, 1) : 0,
            LinkedBowTieDiagramIds   = linkedIds,
            LastIntegrationUpdate    = linkedIds.Count > 0 ? DateTime.UtcNow : null,
        };
    }
}
