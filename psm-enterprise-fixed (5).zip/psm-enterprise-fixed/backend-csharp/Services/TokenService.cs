using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using PSM.Api.Configuration;
using PSM.Api.Models;

namespace PSM.Api.Services;

public interface ITokenService
{
    string GenerateAccessToken(User user);
    string GenerateRefreshToken();
    ClaimsPrincipal? ValidateToken(string token);
}

public class TokenService : ITokenService
{
    private readonly AppConfig _config;

    public TokenService(AppConfig config) => _config = config;

    public string GenerateAccessToken(User user)
    {
        var key    = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config.JwtSecret));
        var creds  = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var expires = ParseExpiry(_config.JwtExpiresIn);

        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id),
            new Claim(ClaimTypes.Name,           user.Username),
            new Claim(ClaimTypes.Role,           user.Role),
            new Claim("fullName",                user.FullName),
            new Claim("unit",                    user.Unit ?? ""),
        };

        var token = new JwtSecurityToken(
            claims:           claims,
            expires:          DateTime.UtcNow.Add(expires),
            signingCredentials: creds
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    public string GenerateRefreshToken()
    {
        // 32 bytes from a cryptographically secure RNG (was: invalid "byte[] + byte[]"
        // expression that does not compile in C#).
        var bytes = new byte[32];
        System.Security.Cryptography.RandomNumberGenerator.Fill(bytes);
        return Convert.ToBase64String(bytes);
    }

    public ClaimsPrincipal? ValidateToken(string token)
    {
        try
        {
            var handler = new JwtSecurityTokenHandler();
            var key     = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config.JwtSecret));
            var result  = handler.ValidateToken(token, new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = key,
                ValidateIssuer   = false,
                ValidateAudience = false,
                ClockSkew = TimeSpan.Zero,
            }, out _);
            return result;
        }
        catch { return null; }
    }

    private static TimeSpan ParseExpiry(string s)
    {
        if (s.EndsWith('h') && int.TryParse(s[..^1], out var h)) return TimeSpan.FromHours(h);
        if (s.EndsWith('d') && int.TryParse(s[..^1], out var d)) return TimeSpan.FromDays(d);
        if (s.EndsWith('m') && int.TryParse(s[..^1], out var m)) return TimeSpan.FromMinutes(m);
        return TimeSpan.FromHours(24);
    }
}
