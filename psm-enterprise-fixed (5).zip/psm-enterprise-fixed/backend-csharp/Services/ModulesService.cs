using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Repositories;
using System.Text.Json;

namespace PSM.Api.Services;

// ════════════════════════════════════════════════════════════════════════════
// HIRA Service
// ════════════════════════════════════════════════════════════════════════════
public interface IHiraService
{
    Task<IEnumerable<HiraDto>> ListAsync();
    Task<HiraDto?> GetAsync(string id);
    Task<HiraDto> CreateAsync(CreateHiraRequest req, string? userId);
    Task<(bool found, HiraDto? item)> UpdateAsync(string id, UpdateHiraRequest req);
    Task<bool> DeleteAsync(string id);
    Task<IEnumerable<HiraHazardDto>> ListHazardsAsync(string hiraId);
    Task<HiraHazardDto?> CreateHazardAsync(string hiraId, CreateHiraHazardRequest req);
    Task<(bool found, HiraHazardDto? item)> UpdateHazardAsync(string id, UpdateHiraHazardRequest req);
    Task<bool> DeleteHazardAsync(string id);
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class HiraService : IHiraService
{
    private readonly IHiraRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "HIRA";

    public HiraService(IHiraRepository repo, IPermissionService perms) { _repo = repo; _perms = perms; }

    public Task<bool> CheckPermAsync(string role, PsmAction action) => _perms.CheckPermissionAsync(role, Module, action);
    public Task<IEnumerable<HiraDto>> ListAsync() => _repo.ListAsync();
    public Task<HiraDto?> GetAsync(string id) => _repo.GetAsync(id);

    public async Task<HiraDto> CreateAsync(CreateHiraRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateAsync(id, req.title ?? "Untitled", req.facility, req.department, req.assessor,
            req.status ?? "Draft", req.assessment_date, userId, JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetAsync(id))!;
    }

    public async Task<(bool found, HiraDto? item)> UpdateAsync(string id, UpdateHiraRequest req)
    {
        if (!await _repo.ExistsAsync(id)) return (false, null);
        await _repo.UpdateAsync(id, req.title ?? "Untitled", req.facility, req.department, req.assessor,
            req.status, req.assessment_date, JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetAsync(id));
    }

    public async Task<bool> DeleteAsync(string id)
    {
        if (!await _repo.ExistsAsync(id)) return false;
        await _repo.SoftDeleteAsync(id);
        return true;
    }

    public Task<IEnumerable<HiraHazardDto>> ListHazardsAsync(string hiraId) => _repo.ListHazardsAsync(hiraId);

    public async Task<HiraHazardDto?> CreateHazardAsync(string hiraId, CreateHiraHazardRequest req)
    {
        if (!await _repo.ExistsAsync(hiraId)) return null;
        var id = Guid.NewGuid().ToString();
        await _repo.CreateHazardAsync(id, hiraId, req.hazard_description, req.activity, req.potential_consequence,
            req.existing_controls, req.likelihood, req.severity, req.risk_level, req.recommended_actions,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        var hazards = await _repo.ListHazardsAsync(hiraId);
        return hazards.FirstOrDefault(h => h.id == id);
    }

    public async Task<(bool found, HiraHazardDto? item)> UpdateHazardAsync(string id, UpdateHiraHazardRequest req)
    {
        if (!await _repo.HazardExistsAsync(id)) return (false, null);
        await _repo.UpdateHazardAsync(id, req.hazard_description, req.activity, req.potential_consequence,
            req.existing_controls, req.likelihood, req.severity, req.risk_level, req.recommended_actions,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        var hazards = await _repo.ListHazardsAsync(req.hira_id ?? "");
        return (true, hazards.FirstOrDefault(h => h.id == id));
    }

    public async Task<bool> DeleteHazardAsync(string id)
    {
        if (!await _repo.HazardExistsAsync(id)) return false;
        await _repo.DeleteHazardAsync(id);
        return true;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// RCA Service
// ════════════════════════════════════════════════════════════════════════════
public interface IRcaService
{
    Task<IEnumerable<RcaDto>> ListAsync();
    Task<RcaDto?> GetAsync(string id);
    Task<RcaDto> CreateAsync(CreateRcaRequest req, string? userId);
    Task<(bool found, RcaDto? item)> UpdateAsync(string id, UpdateRcaRequest req);
    Task<bool> DeleteAsync(string id);
    Task<IEnumerable<RcaCauseDto>> ListCausesAsync(string rcaId);
    Task<RcaCauseDto?> CreateCauseAsync(string rcaId, CreateRcaCauseRequest req);
    Task<(bool found, RcaCauseDto? item)> UpdateCauseAsync(string id, UpdateRcaCauseRequest req);
    Task<bool> DeleteCauseAsync(string id);
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class RcaService : IRcaService
{
    private readonly IRcaRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "RCA";

    public RcaService(IRcaRepository repo, IPermissionService perms) { _repo = repo; _perms = perms; }

    public Task<bool> CheckPermAsync(string role, PsmAction action) => _perms.CheckPermissionAsync(role, Module, action);
    public Task<IEnumerable<RcaDto>> ListAsync() => _repo.ListAsync();
    public Task<RcaDto?> GetAsync(string id) => _repo.GetAsync(id);

    public async Task<RcaDto> CreateAsync(CreateRcaRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateAsync(id, req.title ?? "Untitled", req.incident_date, req.location, req.description,
            req.investigator, req.status ?? "Open", req.methodology, userId,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetAsync(id))!;
    }

    public async Task<(bool found, RcaDto? item)> UpdateAsync(string id, UpdateRcaRequest req)
    {
        if (!await _repo.ExistsAsync(id)) return (false, null);
        await _repo.UpdateAsync(id, req.title ?? "Untitled", req.incident_date, req.location, req.description,
            req.investigator, req.status, req.methodology,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetAsync(id));
    }

    public async Task<bool> DeleteAsync(string id)
    {
        if (!await _repo.ExistsAsync(id)) return false;
        await _repo.SoftDeleteAsync(id);
        return true;
    }

    public Task<IEnumerable<RcaCauseDto>> ListCausesAsync(string rcaId) => _repo.ListCausesAsync(rcaId);

    public async Task<RcaCauseDto?> CreateCauseAsync(string rcaId, CreateRcaCauseRequest req)
    {
        if (!await _repo.ExistsAsync(rcaId)) return null;
        var id = Guid.NewGuid().ToString();
        await _repo.CreateCauseAsync(id, rcaId, req.cause_type, req.description, req.contributing_factor,
            req.corrective_action, JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        var causes = await _repo.ListCausesAsync(rcaId);
        return causes.FirstOrDefault(c => c.id == id);
    }

    public async Task<(bool found, RcaCauseDto? item)> UpdateCauseAsync(string id, UpdateRcaCauseRequest req)
    {
        var rcaId = req.rca_id ?? "";
        await _repo.UpdateCauseAsync(id, req.cause_type, req.description, req.contributing_factor,
            req.corrective_action, JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        var causes = await _repo.ListCausesAsync(rcaId);
        return (true, causes.FirstOrDefault(c => c.id == id));
    }

    public async Task<bool> DeleteCauseAsync(string id)
    {
        await _repo.DeleteCauseAsync(id);
        return true;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Competency Service
// ════════════════════════════════════════════════════════════════════════════
public interface ICompetencyService
{
    Task<IEnumerable<CompetencyDto>> ListAsync();
    Task<CompetencyDto?> GetAsync(string id);
    Task<CompetencyDto> CreateAsync(CreateCompetencyRequest req);
    Task<(bool found, CompetencyDto? item)> UpdateAsync(string id, UpdateCompetencyRequest req);
    Task<bool> DeleteAsync(string id);
    Task<IEnumerable<CompetencyAssessmentDto>> ListAssessmentsAsync(string competencyId);
    Task<CompetencyAssessmentDto> CreateAssessmentAsync(string competencyId, CreateCompetencyAssessmentRequest req);
    Task<bool> DeleteAssessmentAsync(string id);
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class CompetencyService : ICompetencyService
{
    private readonly ICompetencyRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "Competency";

    public CompetencyService(ICompetencyRepository repo, IPermissionService perms) { _repo = repo; _perms = perms; }

    public Task<bool> CheckPermAsync(string role, PsmAction action) => _perms.CheckPermissionAsync(role, Module, action);
    public Task<IEnumerable<CompetencyDto>> ListAsync() => _repo.ListAsync();
    public Task<CompetencyDto?> GetAsync(string id) => _repo.GetAsync(id);

    public async Task<CompetencyDto> CreateAsync(CreateCompetencyRequest req)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateAsync(id, req.title ?? "Untitled", req.category, req.description, req.level,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetAsync(id))!;
    }

    public async Task<(bool found, CompetencyDto? item)> UpdateAsync(string id, UpdateCompetencyRequest req)
    {
        if (!await _repo.ExistsAsync(id)) return (false, null);
        await _repo.UpdateAsync(id, req.title ?? "Untitled", req.category, req.description, req.level,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetAsync(id));
    }

    public async Task<bool> DeleteAsync(string id)
    {
        if (!await _repo.ExistsAsync(id)) return false;
        await _repo.SoftDeleteAsync(id);
        return true;
    }

    public Task<IEnumerable<CompetencyAssessmentDto>> ListAssessmentsAsync(string competencyId) =>
        _repo.ListAssessmentsAsync(competencyId);

    public async Task<CompetencyAssessmentDto> CreateAssessmentAsync(string competencyId, CreateCompetencyAssessmentRequest req)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateAssessmentAsync(id, competencyId, req.employee_id, req.employee_name, req.score,
            req.assessor, req.assessment_date, req.notes,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        var list = await _repo.ListAssessmentsAsync(competencyId);
        return list.First(a => a.id == id);
    }

    public async Task<bool> DeleteAssessmentAsync(string id)
    {
        await _repo.DeleteAssessmentAsync(id);
        return true;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Training Service
// ════════════════════════════════════════════════════════════════════════════
public interface ITrainingService
{
    Task<IEnumerable<TrainingDto>> ListAsync();
    Task<TrainingDto?> GetAsync(string id);
    Task<TrainingDto> CreateAsync(CreateTrainingRequest req, string? userId);
    Task<(bool found, TrainingDto? item)> UpdateAsync(string id, UpdateTrainingRequest req);
    Task<bool> DeleteAsync(string id);
    Task<IEnumerable<TrainingParticipantDto>> ListParticipantsAsync(string trainingId);
    Task<TrainingParticipantDto> AddParticipantAsync(string trainingId, CreateTrainingParticipantRequest req);
    Task<bool> RemoveParticipantAsync(string id);
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class TrainingService : ITrainingService
{
    private readonly ITrainingRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "Training";

    public TrainingService(ITrainingRepository repo, IPermissionService perms) { _repo = repo; _perms = perms; }

    public Task<bool> CheckPermAsync(string role, PsmAction action) => _perms.CheckPermissionAsync(role, Module, action);
    public Task<IEnumerable<TrainingDto>> ListAsync() => _repo.ListAsync();
    public Task<TrainingDto?> GetAsync(string id) => _repo.GetAsync(id);

    public async Task<TrainingDto> CreateAsync(CreateTrainingRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateAsync(id, req.title ?? "Untitled", req.category, req.trainer, req.scheduled_date,
            req.duration_hours, req.location, req.status ?? "Scheduled", req.description, userId,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetAsync(id))!;
    }

    public async Task<(bool found, TrainingDto? item)> UpdateAsync(string id, UpdateTrainingRequest req)
    {
        if (!await _repo.ExistsAsync(id)) return (false, null);
        await _repo.UpdateAsync(id, req.title ?? "Untitled", req.category, req.trainer, req.scheduled_date,
            req.duration_hours, req.location, req.status,
            req.description, JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetAsync(id));
    }

    public async Task<bool> DeleteAsync(string id)
    {
        if (!await _repo.ExistsAsync(id)) return false;
        await _repo.SoftDeleteAsync(id);
        return true;
    }

    public Task<IEnumerable<TrainingParticipantDto>> ListParticipantsAsync(string trainingId) =>
        _repo.ListParticipantsAsync(trainingId);

    public async Task<TrainingParticipantDto> AddParticipantAsync(string trainingId, CreateTrainingParticipantRequest req)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.AddParticipantAsync(id, trainingId, req.employee_id, req.employee_name, req.status, req.passed, req.notes);
        var list = await _repo.ListParticipantsAsync(trainingId);
        return list.First(p => p.id == id);
    }

    public async Task<bool> RemoveParticipantAsync(string id)
    {
        await _repo.RemoveParticipantAsync(id);
        return true;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Contractor Service
// ════════════════════════════════════════════════════════════════════════════
public interface IContractorService
{
    Task<IEnumerable<ContractorDto>> ListAsync();
    Task<ContractorDto?> GetAsync(string id);
    Task<ContractorDto> CreateAsync(CreateContractorRequest req, string? userId);
    Task<(bool found, ContractorDto? item)> UpdateAsync(string id, UpdateContractorRequest req);
    Task<bool> DeleteAsync(string id);
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class ContractorService : IContractorService
{
    private readonly IContractorRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "Contractors";

    public ContractorService(IContractorRepository repo, IPermissionService perms) { _repo = repo; _perms = perms; }

    public Task<bool> CheckPermAsync(string role, PsmAction action) => _perms.CheckPermissionAsync(role, Module, action);
    public Task<IEnumerable<ContractorDto>> ListAsync() => _repo.ListAsync();
    public Task<ContractorDto?> GetAsync(string id) => _repo.GetAsync(id);

    public async Task<ContractorDto> CreateAsync(CreateContractorRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateAsync(id, req.name ?? "Unnamed", req.company, req.contact_person, req.contact_email,
            req.contact_phone, req.contract_number, req.contract_start, req.contract_end,
            req.status ?? "Active", req.scope_of_work, userId,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetAsync(id))!;
    }

    public async Task<(bool found, ContractorDto? item)> UpdateAsync(string id, UpdateContractorRequest req)
    {
        if (!await _repo.ExistsAsync(id)) return (false, null);
        await _repo.UpdateAsync(id, req.name ?? "Unnamed", req.company, req.contact_person, req.contact_email,
            req.contact_phone, req.contract_number, req.contract_start, req.contract_end,
            req.status, req.scope_of_work, JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetAsync(id));
    }

    public async Task<bool> DeleteAsync(string id)
    {
        if (!await _repo.ExistsAsync(id)) return false;
        await _repo.SoftDeleteAsync(id);
        return true;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// PSI Service
// ════════════════════════════════════════════════════════════════════════════
public interface IPsiService
{
    Task<IEnumerable<PsiDto>> ListAsync();
    Task<PsiDto?> GetAsync(string id);
    Task<PsiDto> CreateAsync(CreatePsiRequest req, string? userId);
    Task<(bool found, PsiDto? item)> UpdateAsync(string id, UpdatePsiRequest req);
    Task<bool> DeleteAsync(string id);
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class PsiService : IPsiService
{
    private readonly IPsiRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "PSI";

    public PsiService(IPsiRepository repo, IPermissionService perms) { _repo = repo; _perms = perms; }

    public Task<bool> CheckPermAsync(string role, PsmAction action) => _perms.CheckPermissionAsync(role, Module, action);
    public Task<IEnumerable<PsiDto>> ListAsync() => _repo.ListAsync();
    public Task<PsiDto?> GetAsync(string id) => _repo.GetAsync(id);

    public async Task<PsiDto> CreateAsync(CreatePsiRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateAsync(id, req.title ?? "Untitled", req.category, req.document_number, req.revision,
            req.status ?? "Active", req.description, req.responsible_person, req.review_date, userId,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetAsync(id))!;
    }

    public async Task<(bool found, PsiDto? item)> UpdateAsync(string id, UpdatePsiRequest req)
    {
        if (!await _repo.ExistsAsync(id)) return (false, null);
        await _repo.UpdateAsync(id, req.title ?? "Untitled", req.category, req.document_number, req.revision,
            req.status, req.description, req.responsible_person, req.review_date,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetAsync(id));
    }

    public async Task<bool> DeleteAsync(string id)
    {
        if (!await _repo.ExistsAsync(id)) return false;
        await _repo.SoftDeleteAsync(id);
        return true;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Mechanical Integrity Service
// ════════════════════════════════════════════════════════════════════════════
public interface IMechanicalIntegrityService
{
    Task<IEnumerable<MiEquipmentDto>> ListEquipmentAsync();
    Task<MiEquipmentDto?> GetEquipmentAsync(string id);
    Task<MiEquipmentDto> CreateEquipmentAsync(CreateMiEquipmentRequest req);
    Task<(bool found, MiEquipmentDto? item)> UpdateEquipmentAsync(string id, UpdateMiEquipmentRequest req);
    Task<bool> DeleteEquipmentAsync(string id);
    Task<IEnumerable<MiInspectionDto>> ListInspectionsAsync(string equipmentId);
    Task<MiInspectionDto?> CreateInspectionAsync(string equipmentId, CreateMiInspectionRequest req);
    Task<bool> DeleteInspectionAsync(string id);
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class MechanicalIntegrityService : IMechanicalIntegrityService
{
    private readonly IMechanicalIntegrityRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "MechanicalIntegrity";

    public MechanicalIntegrityService(IMechanicalIntegrityRepository repo, IPermissionService perms) { _repo = repo; _perms = perms; }

    public Task<bool> CheckPermAsync(string role, PsmAction action) => _perms.CheckPermissionAsync(role, Module, action);
    public Task<IEnumerable<MiEquipmentDto>> ListEquipmentAsync() => _repo.ListEquipmentAsync();
    public Task<MiEquipmentDto?> GetEquipmentAsync(string id) => _repo.GetEquipmentAsync(id);

    public async Task<MiEquipmentDto> CreateEquipmentAsync(CreateMiEquipmentRequest req)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateEquipmentAsync(id, req.tag_number ?? "N/A", req.equipment_name ?? "Unnamed",
            req.equipment_type, req.location, req.status ?? "Active",
            req.installation_date, req.next_inspection_date, req.responsible_person,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetEquipmentAsync(id))!;
    }

    public async Task<(bool found, MiEquipmentDto? item)> UpdateEquipmentAsync(string id, UpdateMiEquipmentRequest req)
    {
        if (!await _repo.EquipmentExistsAsync(id)) return (false, null);
        await _repo.UpdateEquipmentAsync(id, req.tag_number ?? "N/A", req.equipment_name ?? "Unnamed",
            req.equipment_type, req.location, req.status,
            req.installation_date, req.next_inspection_date, req.responsible_person,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetEquipmentAsync(id));
    }

    public async Task<bool> DeleteEquipmentAsync(string id)
    {
        if (!await _repo.EquipmentExistsAsync(id)) return false;
        await _repo.SoftDeleteEquipmentAsync(id);
        return true;
    }

    public Task<IEnumerable<MiInspectionDto>> ListInspectionsAsync(string equipmentId) =>
        _repo.ListInspectionsAsync(equipmentId);

    public async Task<MiInspectionDto?> CreateInspectionAsync(string equipmentId, CreateMiInspectionRequest req)
    {
        if (!await _repo.EquipmentExistsAsync(equipmentId)) return null;
        var id = Guid.NewGuid().ToString();
        await _repo.CreateInspectionAsync(id, equipmentId, req.inspection_type, req.inspection_date,
            req.inspector, req.result, req.findings, req.recommendations, req.next_due_date,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        var list = await _repo.ListInspectionsAsync(equipmentId);
        return list.FirstOrDefault(i => i.id == id);
    }

    public async Task<bool> DeleteInspectionAsync(string id)
    {
        await _repo.DeleteInspectionAsync(id);
        return true;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Emergency Service
// ════════════════════════════════════════════════════════════════════════════
public interface IEmergencyService
{
    Task<IEnumerable<EmergencyPlanDto>> ListAsync();
    Task<EmergencyPlanDto?> GetAsync(string id);
    Task<EmergencyPlanDto> CreateAsync(CreateEmergencyPlanRequest req, string? userId);
    Task<(bool found, EmergencyPlanDto? item)> UpdateAsync(string id, UpdateEmergencyPlanRequest req);
    Task<bool> DeleteAsync(string id);
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class EmergencyService : IEmergencyService
{
    private readonly IEmergencyRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "Emergency";

    public EmergencyService(IEmergencyRepository repo, IPermissionService perms) { _repo = repo; _perms = perms; }

    public Task<bool> CheckPermAsync(string role, PsmAction action) => _perms.CheckPermissionAsync(role, Module, action);
    public Task<IEnumerable<EmergencyPlanDto>> ListAsync() => _repo.ListAsync();
    public Task<EmergencyPlanDto?> GetAsync(string id) => _repo.GetAsync(id);

    public async Task<EmergencyPlanDto> CreateAsync(CreateEmergencyPlanRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateAsync(id, req.title ?? "Untitled", req.scenario_type, req.location, req.description,
            req.response_team, req.status ?? "Draft", req.last_drill_date, req.next_drill_date, userId,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetAsync(id))!;
    }

    public async Task<(bool found, EmergencyPlanDto? item)> UpdateAsync(string id, UpdateEmergencyPlanRequest req)
    {
        if (!await _repo.ExistsAsync(id)) return (false, null);
        await _repo.UpdateAsync(id, req.title ?? "Untitled", req.scenario_type, req.location, req.description,
            req.response_team, req.status, req.last_drill_date, req.next_drill_date,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetAsync(id));
    }

    public async Task<bool> DeleteAsync(string id)
    {
        if (!await _repo.ExistsAsync(id)) return false;
        await _repo.SoftDeleteAsync(id);
        return true;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Participation Service
// ════════════════════════════════════════════════════════════════════════════
public interface IParticipationService
{
    Task<IEnumerable<ParticipationDto>> ListAsync();
    Task<ParticipationDto?> GetAsync(string id);
    Task<ParticipationDto> CreateAsync(CreateParticipationRequest req, string? userId);
    Task<(bool found, ParticipationDto? item)> UpdateAsync(string id, UpdateParticipationRequest req);
    Task<bool> DeleteAsync(string id);
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class ParticipationService : IParticipationService
{
    private readonly IParticipationRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "Participation";

    public ParticipationService(IParticipationRepository repo, IPermissionService perms) { _repo = repo; _perms = perms; }

    public Task<bool> CheckPermAsync(string role, PsmAction action) => _perms.CheckPermissionAsync(role, Module, action);
    public Task<IEnumerable<ParticipationDto>> ListAsync() => _repo.ListAsync();
    public Task<ParticipationDto?> GetAsync(string id) => _repo.GetAsync(id);

    public async Task<ParticipationDto> CreateAsync(CreateParticipationRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateAsync(id, req.title ?? "Untitled", req.activity_type, req.activity_date,
            req.organizer, req.department, req.description, req.status ?? "Planned", userId,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetAsync(id))!;
    }

    public async Task<(bool found, ParticipationDto? item)> UpdateAsync(string id, UpdateParticipationRequest req)
    {
        if (!await _repo.ExistsAsync(id)) return (false, null);
        await _repo.UpdateAsync(id, req.title ?? "Untitled", req.activity_type, req.activity_date,
            req.organizer, req.department, req.description, req.status,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetAsync(id));
    }

    public async Task<bool> DeleteAsync(string id)
    {
        if (!await _repo.ExistsAsync(id)) return false;
        await _repo.SoftDeleteAsync(id);
        return true;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Culture Service
// ════════════════════════════════════════════════════════════════════════════
public interface ICultureService
{
    Task<IEnumerable<CultureAssessmentDto>> ListAsync();
    Task<CultureAssessmentDto?> GetAsync(string id);
    Task<CultureAssessmentDto> CreateAsync(CreateCultureAssessmentRequest req, string? userId);
    Task<(bool found, CultureAssessmentDto? item)> UpdateAsync(string id, UpdateCultureAssessmentRequest req);
    Task<bool> DeleteAsync(string id);
    Task<IEnumerable<CultureResponseDto>> ListResponsesAsync(string assessmentId);
    Task<CultureResponseDto> CreateResponseAsync(string assessmentId, CreateCultureResponseRequest req);
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class CultureService : ICultureService
{
    private readonly ICultureRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "Culture";

    public CultureService(ICultureRepository repo, IPermissionService perms) { _repo = repo; _perms = perms; }

    public Task<bool> CheckPermAsync(string role, PsmAction action) => _perms.CheckPermissionAsync(role, Module, action);
    public Task<IEnumerable<CultureAssessmentDto>> ListAsync() => _repo.ListAsync();
    public Task<CultureAssessmentDto?> GetAsync(string id) => _repo.GetAsync(id);

    public async Task<CultureAssessmentDto> CreateAsync(CreateCultureAssessmentRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateAsync(id, req.title ?? "Untitled", req.assessment_type, req.assessment_date,
            req.assessor, req.department, req.status ?? "Draft", userId,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetAsync(id))!;
    }

    public async Task<(bool found, CultureAssessmentDto? item)> UpdateAsync(string id, UpdateCultureAssessmentRequest req)
    {
        if (!await _repo.ExistsAsync(id)) return (false, null);
        await _repo.UpdateAsync(id, req.title ?? "Untitled", req.assessment_type, req.assessment_date,
            req.assessor, req.department, req.status,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetAsync(id));
    }

    public async Task<bool> DeleteAsync(string id)
    {
        if (!await _repo.ExistsAsync(id)) return false;
        await _repo.SoftDeleteAsync(id);
        return true;
    }

    public Task<IEnumerable<CultureResponseDto>> ListResponsesAsync(string assessmentId) =>
        _repo.ListResponsesAsync(assessmentId);

    public async Task<CultureResponseDto> CreateResponseAsync(string assessmentId, CreateCultureResponseRequest req)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateResponseAsync(id, assessmentId, req.question_id, req.question_text, req.score, req.comments);
        var list = await _repo.ListResponsesAsync(assessmentId);
        return list.First(r => r.id == id);
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Stakeholder Service
// ════════════════════════════════════════════════════════════════════════════
public interface IStakeholderService
{
    Task<IEnumerable<StakeholderDto>> ListAsync();
    Task<StakeholderDto?> GetAsync(string id);
    Task<StakeholderDto> CreateAsync(CreateStakeholderRequest req, string? userId);
    Task<(bool found, StakeholderDto? item)> UpdateAsync(string id, UpdateStakeholderRequest req);
    Task<bool> DeleteAsync(string id);
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class StakeholderService : IStakeholderService
{
    private readonly IStakeholderRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "Stakeholders";

    public StakeholderService(IStakeholderRepository repo, IPermissionService perms) { _repo = repo; _perms = perms; }

    public Task<bool> CheckPermAsync(string role, PsmAction action) => _perms.CheckPermissionAsync(role, Module, action);
    public Task<IEnumerable<StakeholderDto>> ListAsync() => _repo.ListAsync();
    public Task<StakeholderDto?> GetAsync(string id) => _repo.GetAsync(id);

    public async Task<StakeholderDto> CreateAsync(CreateStakeholderRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateAsync(id, req.name ?? "Unnamed", req.organization, req.role, req.email, req.phone,
            req.interest_level, req.influence_level, req.engagement_strategy, userId,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetAsync(id))!;
    }

    public async Task<(bool found, StakeholderDto? item)> UpdateAsync(string id, UpdateStakeholderRequest req)
    {
        if (!await _repo.ExistsAsync(id)) return (false, null);
        await _repo.UpdateAsync(id, req.name ?? "Unnamed", req.organization, req.role, req.email, req.phone,
            req.interest_level, req.influence_level, req.engagement_strategy,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetAsync(id));
    }

    public async Task<bool> DeleteAsync(string id)
    {
        if (!await _repo.ExistsAsync(id)) return false;
        await _repo.SoftDeleteAsync(id);
        return true;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Standards Service
// ════════════════════════════════════════════════════════════════════════════
public interface IStandardService
{
    Task<IEnumerable<StandardDto>> ListAsync();
    Task<StandardDto?> GetAsync(string id);
    Task<StandardDto> CreateAsync(CreateStandardRequest req, string? userId);
    Task<(bool found, StandardDto? item)> UpdateAsync(string id, UpdateStandardRequest req);
    Task<bool> DeleteAsync(string id);
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class StandardService : IStandardService
{
    private readonly IStandardRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "Standards";

    public StandardService(IStandardRepository repo, IPermissionService perms) { _repo = repo; _perms = perms; }

    public Task<bool> CheckPermAsync(string role, PsmAction action) => _perms.CheckPermissionAsync(role, Module, action);
    public Task<IEnumerable<StandardDto>> ListAsync() => _repo.ListAsync();
    public Task<StandardDto?> GetAsync(string id) => _repo.GetAsync(id);

    public async Task<StandardDto> CreateAsync(CreateStandardRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateAsync(id, req.title ?? "Untitled", req.standard_number, req.issuing_body, req.category,
            req.revision, req.issue_date, req.review_date, req.status ?? "Active", req.description, userId,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetAsync(id))!;
    }

    public async Task<(bool found, StandardDto? item)> UpdateAsync(string id, UpdateStandardRequest req)
    {
        if (!await _repo.ExistsAsync(id)) return (false, null);
        await _repo.UpdateAsync(id, req.title ?? "Untitled", req.standard_number, req.issuing_body, req.category,
            req.revision, req.issue_date, req.review_date, req.status, req.description,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetAsync(id));
    }

    public async Task<bool> DeleteAsync(string id)
    {
        if (!await _repo.ExistsAsync(id)) return false;
        await _repo.SoftDeleteAsync(id);
        return true;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Metrics Service
// ════════════════════════════════════════════════════════════════════════════
public interface IMetricService
{
    Task<IEnumerable<MetricDto>> ListAsync();
    Task<MetricDto?> GetAsync(string id);
    Task<MetricDto> CreateAsync(CreateMetricRequest req, string? userId);
    Task<(bool found, MetricDto? item)> UpdateAsync(string id, UpdateMetricRequest req);
    Task<bool> DeleteAsync(string id);
    Task<IEnumerable<MetricEntryDto>> ListEntriesAsync(string metricId);
    Task<MetricEntryDto> CreateEntryAsync(string metricId, CreateMetricEntryRequest req);
    Task<bool> DeleteEntryAsync(string id);
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class MetricService : IMetricService
{
    private readonly IMetricRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "Metrics";

    public MetricService(IMetricRepository repo, IPermissionService perms) { _repo = repo; _perms = perms; }

    public Task<bool> CheckPermAsync(string role, PsmAction action) => _perms.CheckPermissionAsync(role, Module, action);
    public Task<IEnumerable<MetricDto>> ListAsync() => _repo.ListAsync();
    public Task<MetricDto?> GetAsync(string id) => _repo.GetAsync(id);

    public async Task<MetricDto> CreateAsync(CreateMetricRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateAsync(id, req.title ?? "Untitled", req.category, req.metric_type, req.unit,
            req.target_value, req.frequency, req.responsible_person, req.description, userId,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetAsync(id))!;
    }

    public async Task<(bool found, MetricDto? item)> UpdateAsync(string id, UpdateMetricRequest req)
    {
        if (!await _repo.ExistsAsync(id)) return (false, null);
        await _repo.UpdateAsync(id, req.title ?? "Untitled", req.category, req.metric_type, req.unit,
            req.target_value, req.frequency, req.responsible_person, req.description,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetAsync(id));
    }

    public async Task<bool> DeleteAsync(string id)
    {
        if (!await _repo.ExistsAsync(id)) return false;
        await _repo.SoftDeleteAsync(id);
        return true;
    }

    public Task<IEnumerable<MetricEntryDto>> ListEntriesAsync(string metricId) =>
        _repo.ListEntriesAsync(metricId);

    public async Task<MetricEntryDto> CreateEntryAsync(string metricId, CreateMetricEntryRequest req)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateEntryAsync(id, metricId, req.actual_value, req.period_date, req.notes, req.recorded_by);
        var list = await _repo.ListEntriesAsync(metricId);
        return list.First(e => e.id == id);
    }

    public async Task<bool> DeleteEntryAsync(string id)
    {
        await _repo.DeleteEntryAsync(id);
        return true;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Management Review Service
// ════════════════════════════════════════════════════════════════════════════
public interface IManagementReviewService
{
    Task<IEnumerable<ManagementReviewDto>> ListAsync();
    Task<ManagementReviewDto?> GetAsync(string id);
    Task<ManagementReviewDto> CreateAsync(CreateManagementReviewRequest req, string? userId);
    Task<(bool found, ManagementReviewDto? item)> UpdateAsync(string id, UpdateManagementReviewRequest req);
    Task<bool> DeleteAsync(string id);
    Task<IEnumerable<MrActionItemDto>> ListActionItemsAsync(string reviewId);
    Task<MrActionItemDto> CreateActionItemAsync(string reviewId, CreateMrActionItemRequest req);
    Task<(bool found, MrActionItemDto? item)> UpdateActionItemAsync(string id, CreateMrActionItemRequest req);
    Task<bool> DeleteActionItemAsync(string id);
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class ManagementReviewService : IManagementReviewService
{
    private readonly IManagementReviewRepository _repo;
    private readonly IPermissionService _perms;
    private const string Module = "ManagementReview";

    public ManagementReviewService(IManagementReviewRepository repo, IPermissionService perms) { _repo = repo; _perms = perms; }

    public Task<bool> CheckPermAsync(string role, PsmAction action) => _perms.CheckPermissionAsync(role, Module, action);
    public Task<IEnumerable<ManagementReviewDto>> ListAsync() => _repo.ListAsync();
    public Task<ManagementReviewDto?> GetAsync(string id) => _repo.GetAsync(id);

    public async Task<ManagementReviewDto> CreateAsync(CreateManagementReviewRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateAsync(id, req.title ?? "Untitled", req.review_date, req.chairperson, req.location,
            req.status ?? "Planned", req.agenda, req.minutes, userId,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetAsync(id))!;
    }

    public async Task<(bool found, ManagementReviewDto? item)> UpdateAsync(string id, UpdateManagementReviewRequest req)
    {
        if (!await _repo.ExistsAsync(id)) return (false, null);
        await _repo.UpdateAsync(id, req.title ?? "Untitled", req.review_date, req.chairperson, req.location,
            req.status, req.agenda, req.minutes,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetAsync(id));
    }

    public async Task<bool> DeleteAsync(string id)
    {
        if (!await _repo.ExistsAsync(id)) return false;
        await _repo.SoftDeleteAsync(id);
        return true;
    }

    public Task<IEnumerable<MrActionItemDto>> ListActionItemsAsync(string reviewId) =>
        _repo.ListActionItemsAsync(reviewId);

    public async Task<MrActionItemDto> CreateActionItemAsync(string reviewId, CreateMrActionItemRequest req)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateActionItemAsync(id, reviewId, req.description, req.assigned_to, req.due_date, req.priority, req.status ?? "Open");
        var list = await _repo.ListActionItemsAsync(reviewId);
        return list.First(a => a.id == id);
    }

    public async Task<(bool found, MrActionItemDto? item)> UpdateActionItemAsync(string id, CreateMrActionItemRequest req)
    {
        await _repo.UpdateActionItemAsync(id, req.description, req.assigned_to, req.due_date, req.priority, req.status);
        var reviewId = req.review_id ?? "";
        var list = await _repo.ListActionItemsAsync(reviewId);
        return (true, list.FirstOrDefault(a => a.id == id));
    }

    public async Task<bool> DeleteActionItemAsync(string id)
    {
        await _repo.DeleteActionItemAsync(id);
        return true;
    }
}
