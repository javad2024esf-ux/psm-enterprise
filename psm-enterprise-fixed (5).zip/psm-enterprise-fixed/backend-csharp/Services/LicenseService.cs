using System.Security.Cryptography;
using PSM.Api.DTOs;
using PSM.Api.Configuration;
using PSM.Api.Models;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

public interface ILicenseService
{
    Task<LicenseStatusDto?> GetStatusAsync();
    Task<ActivateLicenseResponseDto> ActivateAsync(ActivateLicenseDto request);
    Task<DeactivateLicenseResponseDto> DeactivateAsync();
    bool ValidateLicenseKey(string licenseKey);
}

public class LicenseService : ILicenseService
{
    private readonly ILicenseRepository _repo;
    private readonly IAuditService _audit;
    private readonly AppConfig _config;
    private readonly ILogger<LicenseService> _logger;
    private const int LicenseKeyLength = 64;

    public LicenseService(
        ILicenseRepository repo,
        IAuditService audit,
        AppConfig config,
        ILogger<LicenseService> logger)
    {
        _repo = repo ?? throw new ArgumentNullException(nameof(repo));
        _audit = audit ?? throw new ArgumentNullException(nameof(audit));
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    private string GenerateLicenseHash(string licenseKey)
    {
        var secret = _config.LicenseSecret ?? "license_secret_2024_psm_enterprise_v9";
        using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(secret));
        var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(licenseKey));
        return Convert.ToHexString(hash);
    }

    public bool ValidateLicenseKey(string licenseKey)
    {
        if (string.IsNullOrWhiteSpace(licenseKey))
        {
            _logger.LogWarning("License validation failed: empty key");
            return false;
        }

        if (licenseKey.Length < LicenseKeyLength - 32)
        {
            _logger.LogWarning("License validation failed: key too short ({Length})", licenseKey.Length);
            return false;
        }

        try
        {
            var dataLength = licenseKey.Length - 64;
            if (dataLength < 16)
                return false;

            var licenseData = licenseKey[..dataLength];
            var providedSignature = licenseKey[dataLength..];
            var expectedSignature = GenerateLicenseHash(licenseData);

            return ConstantTimeComparison(expectedSignature, providedSignature);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "License validation error");
            return false;
        }
    }

    private static bool ConstantTimeComparison(string a, string b)
    {
        if (a.Length != b.Length) return false;
        int result = 0;
        for (int i = 0; i < a.Length; i++)
            result |= a[i] ^ b[i];
        return result == 0;
    }

    public async Task<LicenseStatusDto?> GetStatusAsync()
    {
        try
        {
            var license = await _repo.GetActiveLicenseAsync();
            if (license == null)
            {
                _logger.LogInformation("No active license found");
                return null;
            }

            var status = new LicenseStatusDto
            {
                Status      = license.Status,
                Organization = license.Organization,
                IsExpired   = license.ExpiresAt < DateTime.UtcNow,
                // FIX: DaysRemaining is int — cast explicitly from nullable TotalDays
                DaysRemaining = license.ExpiresAt.HasValue
                    ? (int)(license.ExpiresAt.Value - DateTime.UtcNow).TotalDays
                    : 0,
                // FIX: LicenseStatusDto has ExpiryDate (DateTime), not ExpiresAt (DateTime?)
                //      Map the nullable source to the non-nullable DTO field with a fallback
                ExpiryDate    = license.ExpiresAt ?? DateTime.MinValue,
                LicenseType   = license.LicenseType ?? "",
                // FIX: MaxUsers/CurrentUsers/MaxProjects/CurrentProjects are int in DTO but int? in model
                MaxUsers      = license.MaxUsers ?? 0,
                CurrentUsers  = license.CurrentUsers ?? 0,
                MaxProjects   = license.MaxProjects ?? 0,
                CurrentProjects = license.CurrentProjects ?? 0,
            };

            return status;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving license status");
            throw;
        }
    }

    public async Task<ActivateLicenseResponseDto> ActivateAsync(ActivateLicenseDto request)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(request.LicenseKey))
                return new ActivateLicenseResponseDto { Success = false, Message = "License key is required" };

            if (!ValidateLicenseKey(request.LicenseKey))
                return new ActivateLicenseResponseDto { Success = false, Message = "Invalid license key format or signature" };

            var machineId = Environment.MachineName ?? "unknown";

            var activated = await _repo.ActivateLicenseAsync(
                request.LicenseKey,
                request.Organization ?? "Unknown",
                request.ContactEmail ?? "",
                machineId);

            if (!activated)
                return new ActivateLicenseResponseDto { Success = false, Message = "Failed to activate license in database" };

            _logger.LogInformation("License activated for organization: {Organization}", request.Organization);

            // FIX: IAuditService has WriteAsync(), not LogAsync()
            await _audit.WriteAsync("System", "ACTIVATE", "LICENSE", null,
                $"organization={request.Organization}");

            return new ActivateLicenseResponseDto { Success = true, Message = "License activated successfully" };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error activating license");
            return new ActivateLicenseResponseDto { Success = false, Message = "An error occurred during license activation" };
        }
    }

    public async Task<DeactivateLicenseResponseDto> DeactivateAsync()
    {
        try
        {
            var deactivated = await _repo.DeactivateLicenseAsync();
            if (!deactivated)
                return new DeactivateLicenseResponseDto { Success = false, Message = "Failed to deactivate license" };

            _logger.LogInformation("License deactivated");

            // FIX: IAuditService has WriteAsync(), not LogAsync()
            await _audit.WriteAsync("System", "DEACTIVATE", "LICENSE");

            return new DeactivateLicenseResponseDto { Success = true, Message = "License deactivated successfully" };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deactivating license");
            return new DeactivateLicenseResponseDto { Success = false, Message = "An error occurred during license deactivation" };
        }
    }
}
