using Dapper;
using PSM.Api.Data;
using Serilog;

namespace PSM.Api.Services;

/// <summary>
/// خدمة إدارة تحديد معدل الطلب ورصدها
/// Rate limiting management and monitoring service
/// </summary>
public interface IRateLimitService
{
    Task RecordRequestAsync(string userId, string ipAddress, string endpoint, string method);
    Task RecordViolationAsync(string userId, string ipAddress, string endpoint, string method, 
        string limitName, int limitValue, int actualCount, string? userAgent);
    Task<RateLimitStatisticsDto> GetStatisticsAsync(DateTime from, DateTime to);
    Task<List<RateLimitViolationDto>> GetRecentViolationsAsync(int limit = 50);
}

public class RateLimitService : IRateLimitService
{
    private readonly IDbHelper _dbHelper;
    private readonly ILogger<RateLimitService> _logger;

    public RateLimitService(IDbHelper dbHelper, ILogger<RateLimitService> logger)
    {
        _dbHelper = dbHelper;
        _logger = logger;
    }

    /// <summary>
    /// تسجيل طلب API
    /// </summary>
    public async Task RecordRequestAsync(string userId, string ipAddress, string endpoint, string method)
    {
        try
        {
            var sql = @"
                INSERT INTO rate_limit_stats 
                (tenant_id, user_id, ip_address, endpoint_path, method, window_start, window_end, request_count)
                VALUES (@TenantId, @UserId, @IpAddress, @EndpointPath, @Method, 
                        DATE_TRUNC('minute', CURRENT_TIMESTAMP),
                        DATE_TRUNC('minute', CURRENT_TIMESTAMP) + INTERVAL '1 minute',
                        1)
                ON CONFLICT DO UPDATE SET request_count = request_count + 1, updated_at = CURRENT_TIMESTAMP
            ";

            using (var connection = _dbHelper.GetConnection())
            {
                await connection.ExecuteAsync(sql, new
                {
                    TenantId = Guid.NewGuid(),
                    UserId = string.IsNullOrEmpty(userId) ? null : Guid.TryParse(userId, out var uid) ? (Guid?)uid : null,
                    IpAddress = ipAddress,
                    EndpointPath = endpoint,
                    Method = method.ToUpper()
                });
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "خطأ في تسجيل إحصائيات حد المعدل - Error recording rate limit stats");
        }
    }

    /// <summary>
    /// تسجيل انتهاك حد المعدل
    /// </summary>
    public async Task RecordViolationAsync(string userId, string ipAddress, string endpoint, string method,
        string limitName, int limitValue, int actualCount, string? userAgent)
    {
        try
        {
            var sql = @"
                INSERT INTO rate_limit_violations
                (tenant_id, user_id, ip_address, endpoint_path, method, violation_type, limit_name, 
                 limit_value, actual_count, user_agent, violation_timestamp)
                VALUES (@TenantId, @UserId, @IpAddress, @EndpointPath, @Method, @ViolationType, @LimitName,
                        @LimitValue, @ActualCount, @UserAgent, CURRENT_TIMESTAMP)
            ";

            using (var connection = _dbHelper.GetConnection())
            {
                await connection.ExecuteAsync(sql, new
                {
                    TenantId = Guid.NewGuid(),
                    UserId = string.IsNullOrEmpty(userId) ? null : Guid.TryParse(userId, out var uid) ? (Guid?)uid : null,
                    IpAddress = ipAddress,
                    EndpointPath = endpoint,
                    Method = method.ToUpper(),
                    ViolationType = DetermineViolationType(userId, ipAddress),
                    LimitName = limitName,
                    LimitValue = limitValue,
                    ActualCount = actualCount,
                    UserAgent = userAgent ?? "unknown"
                });
            }

            _logger.LogWarning(
                "حد المعدل انتهك - Rate limit violated: {User} from {IP} on {Endpoint} ({Limit} > {Actual})",
                userId ?? "anonymous", ipAddress, endpoint, limitValue, actualCount);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "خطأ في تسجيل انتهاك حد المعدل - Error recording rate limit violation");
        }
    }

    /// <summary>
    /// احصائيات الحصول على محدودية السعر
    /// </summary>
    public async Task<RateLimitStatisticsDto> GetStatisticsAsync(DateTime from, DateTime to)
    {
        try
        {
            var sql = @"
                SELECT 
                    COUNT(*) as TotalRequests,
                    COUNT(DISTINCT user_id) as UniqueUsers,
                    COUNT(DISTINCT ip_address) as UniqueIPs,
                    COUNT(CASE WHEN rejected THEN 1 END) as RejectedRequests,
                    COUNT(DISTINCT endpoint_path) as UniqueEndpoints,
                    MAX(request_count) as MaxRequestsInWindow
                FROM rate_limit_stats
                WHERE created_at BETWEEN @From AND @To
            ";

            using (var connection = _dbHelper.GetConnection())
            {
                var result = await connection.QueryFirstOrDefaultAsync<dynamic>(sql, 
                    new { From = from, To = to });

                if (result != null)
                {
                    return new RateLimitStatisticsDto
                    {
                        TotalRequests = result.TotalRequests,
                        UniqueUsers = result.UniqueUsers,
                        UniqueIPs = result.UniqueIPs,
                        RejectedRequests = result.RejectedRequests,
                        UniqueEndpoints = result.UniqueEndpoints,
                        PeriodStart = from,
                        PeriodEnd = to
                    };
                }
            }

            return new RateLimitStatisticsDto { PeriodStart = from, PeriodEnd = to };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "خطأ في الحصول على إحصائيات حد المعدل - Error getting rate limit statistics");
            return new RateLimitStatisticsDto { PeriodStart = from, PeriodEnd = to };
        }
    }

    /// <summary>
    /// الحصول على أحدث الانتهاكات
    /// </summary>
    public async Task<List<RateLimitViolationDto>> GetRecentViolationsAsync(int limit = 50)
    {
        try
        {
            var sql = @"
                SELECT 
                    id as Id,
                    user_id as UserId,
                    ip_address as IpAddress,
                    endpoint_path as EndpointPath,
                    method as Method,
                    violation_type as ViolationType,
                    limit_name as LimitName,
                    limit_value as LimitValue,
                    actual_count as ActualCount,
                    violation_timestamp as ViolationTimestamp
                FROM rate_limit_violations
                ORDER BY violation_timestamp DESC
                LIMIT @Limit
            ";

            using (var connection = _dbHelper.GetConnection())
            {
                var violations = await connection.QueryAsync<RateLimitViolationDto>(sql, 
                    new { Limit = limit });
                return violations.ToList();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "خطأ في الحصول على انتهاكات حد المعدل - Error getting rate limit violations");
            return new List<RateLimitViolationDto>();
        }
    }

    private string DetermineViolationType(string userId, string ipAddress)
    {
        if (!string.IsNullOrEmpty(userId))
            return "per_user";
        else if (!string.IsNullOrEmpty(ipAddress))
            return "per_ip";
        else
            return "global";
    }
}

/// <summary>
/// DTO لإحصائيات حد المعدل
/// </summary>
public class RateLimitStatisticsDto
{
    public int TotalRequests { get; set; }
    public int UniqueUsers { get; set; }
    public int UniqueIPs { get; set; }
    public int RejectedRequests { get; set; }
    public int UniqueEndpoints { get; set; }
    public DateTime PeriodStart { get; set; }
    public DateTime PeriodEnd { get; set; }
}

/// <summary>
/// DTO لانتهاك حد المعدل
/// </summary>
public class RateLimitViolationDto
{
    public long Id { get; set; }
    public Guid? UserId { get; set; }
    public string IpAddress { get; set; }
    public string EndpointPath { get; set; }
    public string Method { get; set; }
    public string ViolationType { get; set; }
    public string LimitName { get; set; }
    public int LimitValue { get; set; }
    public int ActualCount { get; set; }
    public DateTime ViolationTimestamp { get; set; }
}
