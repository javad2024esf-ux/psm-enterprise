using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

// ════════════════════════════════════════════════════════════════════════════
// Interface: IActionRegisterService
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Service for managing action register records.
/// Provides business logic, validation, and orchestration with RBAC and audit.
/// </summary>
public interface IActionRegisterService
{
    /// <summary>
    /// Checks if a user role has permission to perform an action on the Action Register module.
    /// </summary>
    Task<bool> CheckPermAsync(string role, PsmAction action);

    /// <summary>
    /// Lists action register records with filtering and pagination.
    /// Supports filtering by source, unit, status, and priority.
    /// </summary>
    Task<ActionRegisterListResponse> ListAsync(
        string? source, string? unit, string? status, string? priority,
        int page, int limit);

    /// <summary>
    /// Gets a single action register record by ID.
    /// Returns null if not found or if soft-deleted.
    /// </summary>
    Task<ActionRegisterDto?> GetAsync(string id);

    /// <summary>
    /// Creates a new action register record.
    /// Validates input, assigns ID, and logs audit trail.
    /// </summary>
    Task<ActionRegisterDto> CreateAsync(CreateActionRegisterRequest req, string userId);

    /// <summary>
    /// Updates an existing action register record.
    /// Only updates fields that are not null in the request.
    /// Returns true if successful, false if record not found.
    /// </summary>
    Task<bool> UpdateAsync(string id, UpdateActionRegisterRequest req, string userId);

    /// <summary>
    /// Soft-deletes an action register record.
    /// Returns true if successful, false if record not found.
    /// </summary>
    Task<bool> DeleteAsync(string id, string userId);

    /// <summary>
    /// Gets dashboard statistics for action register.
    /// Includes counts by status, priority, and source.
    /// </summary>
    Task<ActionRegisterStats> GetStatsAsync();

    /// <summary>
    /// Gets all overdue actions that haven't been completed or verified.
    /// </summary>
    Task<IEnumerable<ActionRegisterDto>> GetOverdueAsync();

    /// <summary>
    /// Searches action register by title/description.
    /// Performs case-insensitive ILIKE search.
    /// </summary>
    Task<IEnumerable<ActionRegisterDto>> SearchAsync(string query, int limit);

    /// <summary>
    /// Creates an action from a HAZOP deviation/recommendation.
    /// Maps HAZOP context (study, facility, unit) to action fields.
    /// Sets Source="HAZOP", SourceId=studyId, SourceRef=deviationId for traceability.
    /// </summary>
    /// <param name="req">Request containing deviationId, recommendation text, priority, etc.</param>
    /// <param name="userId">User creating the action (for audit trail)</param>
    /// <returns>Newly created ActionRegisterDto with HAZOP source references</returns>
    /// <exception cref="ArgumentException">If deviation not found or invalid input</exception>
    Task<ActionRegisterDto> CreateFromHazopDeviationAsync(
        CreateActionFromHazopRequest req,
        string userId);

    /// <summary>
    /// Creates actions from an Incident's recommendations.
    /// Every recommendation (immediate, corrective, preventive) becomes a separate action.
    /// Sets Source="Incident", SourceId=incidentId, SourceRef=recommendationType for traceability.
    /// Automatically triggers Workflow and Audit for each action created.
    /// </summary>
    /// <param name="req">Request containing incidentId, recommendation text, priority, etc.</param>
    /// <param name="userId">User creating the action (for audit trail)</param>
    /// <returns>Newly created ActionRegisterDto with Incident source references</returns>
    /// <exception cref="ArgumentException">If incident not found or invalid input</exception>
    /// <exception cref="KeyNotFoundException">If incident does not exist</exception>
    Task<ActionRegisterDto> CreateFromIncidentRecommendationAsync(
        CreateActionFromIncidentRequest req,
        string userId);
}

// ════════════════════════════════════════════════════════════════════════════
// Implementation: ActionRegisterService
// ════════════════════════════════════════════════════════════════════════════

public class ActionRegisterService : IActionRegisterService
{
    private readonly IActionRegisterRepository _repository;
    private readonly IHazopRepository _hazopRepository;
    private readonly IIncidentRepository _incidentRepository;
    private readonly IPermissionService _permissionService;
    private readonly IAuditService _auditService;
    private readonly ILogger<ActionRegisterService> _logger;

    private const string MODULE_NAME = "ActionRegister";
    private const string ACTION_CREATE = "CREATE_ACTION";
    private const string ACTION_UPDATE = "UPDATE_ACTION";
    private const string ACTION_DELETE = "DELETE_ACTION";

    // Valid enumerations for validation
    private static readonly HashSet<string> VALID_STATUSES = new()
    {
        "Open", "In Progress", "Overdue", "Done", "Verified", "Closed"
    };

    private static readonly HashSet<string> VALID_PRIORITIES = new()
    {
        "Critical", "High", "Medium", "Low"
    };

    private static readonly HashSet<string> VALID_SOURCES = new()
    {
        "MOC", "Incident", "HAZOP", "Audit", "PSSR", "Management Review", "Inspection", "Other"
    };

    public ActionRegisterService(
        IActionRegisterRepository repository,
        IHazopRepository hazopRepository,
        IIncidentRepository incidentRepository,
        IPermissionService permissionService,
        IAuditService auditService,
        ILogger<ActionRegisterService> logger)
    {
        _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        _hazopRepository = hazopRepository ?? throw new ArgumentNullException(nameof(hazopRepository));
        _incidentRepository = incidentRepository ?? throw new ArgumentNullException(nameof(incidentRepository));
        _permissionService = permissionService ?? throw new ArgumentNullException(nameof(permissionService));
        _auditService = auditService ?? throw new ArgumentNullException(nameof(auditService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // RBAC
    // ─────────────────────────────────────────────────────────────────────────────

    public Task<bool> CheckPermAsync(string role, PsmAction action) =>
        _permissionService.CheckPermissionAsync(role, MODULE_NAME, action);

    // ─────────────────────────────────────────────────────────────────────────────
    // LIST
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<ActionRegisterListResponse> ListAsync(
        string? source, string? unit, string? status, string? priority,
        int page, int limit)
    {
        try
        {
            // Validate and clamp pagination parameters
            limit = Math.Clamp(limit, 1, 100);
            page = Math.Max(page, 1);
            int offset = (page - 1) * limit;

            // Validate filter parameters if provided
            if (!string.IsNullOrEmpty(status) && !VALID_STATUSES.Contains(status))
                throw new ArgumentException($"حالت نامعتبر: {status}");

            if (!string.IsNullOrEmpty(priority) && !VALID_PRIORITIES.Contains(priority))
                throw new ArgumentException($"اولویت نامعتبر: {priority}");

            if (!string.IsNullOrEmpty(source) && !VALID_SOURCES.Contains(source))
                throw new ArgumentException($"منبع نامعتبر: {source}");

            var (rows, total) = await _repository.ListAsync(source, unit, status, priority, limit, offset);

            _logger.LogDebug("Listed {Count} action registers from total {Total}",
                rows.Count(), total);

            return new ActionRegisterListResponse
            {
                Data = rows.ToList(),
                Total = (int)total,
                Page = page,
                Limit = limit,
            };
        }
        catch (ArgumentException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing action registers");
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // GET
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<ActionRegisterDto?> GetAsync(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("ID نمی‌تواند خالی باشد");

        try
        {
            var dto = await _repository.GetByIdAsync(id);
            return dto;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting action register {Id}", id);
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // CREATE
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<ActionRegisterDto> CreateAsync(CreateActionRegisterRequest req, string userId)
    {
        try
        {
            // Validate required fields
            if (string.IsNullOrWhiteSpace(req.Title))
                throw new ArgumentException("عنوان الزامی است");

            if (string.IsNullOrWhiteSpace(req.Source))
                throw new ArgumentException("منبع الزامی است");

            // Validate enums
            if (!VALID_SOURCES.Contains(req.Source))
                throw new ArgumentException($"منبع نامعتبر: {req.Source}");

            if (!string.IsNullOrEmpty(req.Status) && !VALID_STATUSES.Contains(req.Status))
                throw new ArgumentException($"حالت نامعتبر: {req.Status}");

            if (!string.IsNullOrEmpty(req.Priority) && !VALID_PRIORITIES.Contains(req.Priority))
                throw new ArgumentException($"اولویت نامعتبر: {req.Priority}");

            // Validate dates
            if (req.DueDate.HasValue && req.DueDate.Value < DateTime.Today)
                _logger.LogWarning("Action created with past due date by {UserId}", userId);

            // Normalize fields
            var title = req.Title.Trim();
            var source = req.Source.Trim();
            var status = req.Status?.Trim() ?? "Open";
            var priority = req.Priority?.Trim() ?? "Medium";
            var id = GenerateActionId();

            // Create in repository
            await _repository.CreateAsync(
                id,
                title,
                req.Description?.Trim(),
                source,
                req.SourceId?.Trim(),
                req.SourceRef?.Trim(),
                req.Unit?.Trim(),
                req.Responsible?.Trim(),
                req.DueDate,
                status,
                priority,
                req.Tags,
                userId);

            // Audit log
            var auditDetails = $"Created action: {title} " +
                $"(Source: {source}, Priority: {priority}, " +
                $"DueDate: {req.DueDate:yyyy-MM-dd})";

            await _auditService.WriteAsync(userId, ACTION_CREATE, MODULE_NAME, id, auditDetails);

            _logger.LogInformation("Action register created: {Id} by {UserId}", id, userId);

            // Return created DTO
            return (await _repository.GetByIdAsync(id))!;
        }
        catch (ArgumentException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating action register");
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // UPDATE
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<bool> UpdateAsync(string id, UpdateActionRegisterRequest req, string userId)
    {
        try
        {
            // Get existing record
            var existing = await _repository.GetByIdAsync(id);
            if (existing is null)
            {
                _logger.LogWarning("Attempt to update non-existent action: {Id}", id);
                return false;
            }

            // Validate enum fields if provided
            if (!string.IsNullOrEmpty(req.Status) && !VALID_STATUSES.Contains(req.Status))
                throw new ArgumentException($"حالت نامعتبر: {req.Status}");

            if (!string.IsNullOrEmpty(req.Priority) && !VALID_PRIORITIES.Contains(req.Priority))
                throw new ArgumentException($"اولویت نامعتبر: {req.Priority}");

            if (!string.IsNullOrEmpty(req.Source) && !VALID_SOURCES.Contains(req.Source))
                throw new ArgumentException($"منبع نامعتبر: {req.Source}");

            // Update in repository
            await _repository.UpdateAsync(id, req, userId);

            // Build audit details from changed fields
            var changes = new List<string>();

            if (!string.IsNullOrEmpty(req.Title) && req.Title != existing.Title)
                changes.Add($"Title: '{existing.Title}' → '{req.Title}'");

            if (!string.IsNullOrEmpty(req.Status) && req.Status != existing.Status)
                changes.Add($"Status: '{existing.Status}' → '{req.Status}'");

            if (!string.IsNullOrEmpty(req.Priority) && req.Priority != existing.Priority)
                changes.Add($"Priority: '{existing.Priority}' → '{req.Priority}'");

            if (!string.IsNullOrEmpty(req.Responsible) && req.Responsible != existing.Responsible)
                changes.Add($"Responsible: '{existing.Responsible}' → '{req.Responsible}'");

            if (req.DueDate.HasValue && req.DueDate != existing.DueDate)
                changes.Add($"DueDate: '{existing.DueDate:yyyy-MM-dd}' → '{req.DueDate:yyyy-MM-dd}'");

            if (req.CompletionDate.HasValue && req.CompletionDate != existing.CompletionDate)
                changes.Add($"CompletionDate: '{existing.CompletionDate:yyyy-MM-dd}' → '{req.CompletionDate:yyyy-MM-dd}'");

            var auditDetails = changes.Count > 0
                ? string.Join("; ", changes)
                : "Updated action register";

            await _auditService.WriteAsync(userId, ACTION_UPDATE, MODULE_NAME, id, auditDetails);

            _logger.LogInformation("Action register updated: {Id} by {UserId}. Changes: {Changes}",
                id, userId, string.Join(", ", changes));

            return true;
        }
        catch (ArgumentException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating action register {Id}", id);
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // DELETE
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<bool> DeleteAsync(string id, string userId)
    {
        try
        {
            var existing = await _repository.GetByIdAsync(id);
            if (existing is null)
            {
                _logger.LogWarning("Attempt to delete non-existent action: {Id}", id);
                return false;
            }

            // Soft delete
            await _repository.DeleteAsync(id);

            // Audit log
            var auditDetails = $"Deleted action: {existing.Title} (Source: {existing.Source})";
            await _auditService.WriteAsync(userId, ACTION_DELETE, MODULE_NAME, id, auditDetails);

            _logger.LogInformation("Action register soft-deleted: {Id} by {UserId}",
                id, userId);

            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting action register {Id}", id);
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // STATISTICS
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<ActionRegisterStats> GetStatsAsync()
    {
        try
        {
            var stats = await _repository.GetStatsAsync();
            _logger.LogDebug("Statistics retrieved: {Total} total actions", stats.Total);
            return stats;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting action register statistics");
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // OVERDUE
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<IEnumerable<ActionRegisterDto>> GetOverdueAsync()
    {
        try
        {
            var overdueActions = await _repository.GetOverdueAsync();
            var count = overdueActions.Count();
            _logger.LogDebug("Retrieved {Count} overdue actions", count);
            return overdueActions;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting overdue actions");
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SEARCH
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<IEnumerable<ActionRegisterDto>> SearchAsync(string query, int limit)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(query))
                return Enumerable.Empty<ActionRegisterDto>();

            limit = Math.Clamp(limit, 1, 200);
            var results = await _repository.SearchAsync(query.Trim(), limit);

            _logger.LogDebug("Search query '{Query}' returned {Count} results",
                query, results.Count());

            return results;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error searching action register with query: {Query}",
                query);
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // HAZOP INTEGRATION: Create Action from HAZOP Deviation
    // ─────────────────────────────────────────────────────────────────────────────

    /// <summary>
    /// Creates an action register entry from a HAZOP deviation/recommendation.
    ///
    /// Flow:
    /// 1. Validate the deviation exists
    /// 2. Fetch study context (facility, unit, title)
    /// 3. Build action title from deviation + recommendation
    /// 4. Create action with Source="HAZOP", SourceId=studyId, SourceRef=deviationId
    /// 5. Audit log both the HAZOP reference and the action creation
    /// 6. Return the created action
    ///
    /// Audit Trail: Includes cross-reference info for traceability
    /// RBAC: Checked at controller level (CanWriteActions)
    /// </summary>
    public async Task<ActionRegisterDto> CreateFromHazopDeviationAsync(
        CreateActionFromHazopRequest req,
        string userId)
    {
        try
        {
            // ─────── Validation ──────────────────────────────────────────────────
            if (string.IsNullOrWhiteSpace(req.DeviationId))
                throw new ArgumentException("انحراف ID الزامی است");

            if (!VALID_PRIORITIES.Contains(req.Priority ?? "High"))
                throw new ArgumentException($"اولویت نامعتبر: {req.Priority}");

            // ─────── Fetch HAZOP Context ─────────────────────────────────────────
            var deviation = await _hazopRepository.GetDeviationAsync(req.DeviationId);
            if (deviation is null)
                throw new ArgumentException("انحراف یافت نشد");

            var study = await _hazopRepository.GetStudyAsync(deviation.StudyId!);
            if (study is null)
                throw new ArgumentException("مطالعه HAZOP یافت نشد");

            // ─────── Build Action Details ────────────────────────────────────────
            var recommendationText = req.RecommendationText?.Trim()
                ?? (string.IsNullOrWhiteSpace(deviation.Recommendations)
                    ? "بدون توصیه"  // "No recommendation"
                    : deviation.Recommendations.Trim());

            var actionTitle = $"[HAZOP] {study.Title} - {recommendationText}".Substring(0, Math.Min(255, 
                $"[HAZOP] {study.Title} - {recommendationText}".Length));

            var actionDescription = new System.Text.StringBuilder();
            actionDescription.AppendLine($"منبع: HAZOP Study - {study.Title}");
            actionDescription.AppendLine($"شناسه انحراف: {deviation.Id}");
            actionDescription.AppendLine($"شاخص: {deviation.Parameter}");
            actionDescription.AppendLine($"انحراف: {deviation.Deviation}");
            actionDescription.AppendLine($"علل: {deviation.Causes ?? "N/A"}");
            actionDescription.AppendLine($"پیامدها: {deviation.Consequences ?? "N/A"}");
            actionDescription.AppendLine($"توصیه: {recommendationText}");

            // ─────── Create Action ───────────────────────────────────────────────
            var actionId = GenerateActionId();
            var priority = req.Priority?.Trim() ?? "High";
            var dueDate = req.DueDate ?? DateTime.Now.AddDays(30); // Default: 30 days from now

            await _repository.CreateAsync(
                actionId,
                actionTitle,
                actionDescription.ToString(),
                "HAZOP",                          // Source
                study.Id,                         // SourceId = Study ID
                deviation.Id,                     // SourceRef = Deviation ID
                study.Unit,                       // Unit from HAZOP study
                req.Responsible?.Trim(),
                dueDate,
                "Open",                           // Status
                priority,
                new[] { $"hazop-{study.Id}", $"dev-{deviation.Id}" },  // Tags for traceability
                userId);

            // ─────── Audit Trail ─────────────────────────────────────────────────
            var auditDetails = $"Created action from HAZOP deviation: " +
                $"Study='{study.Title}', " +
                $"DeviationId='{deviation.Id}', " +
                $"Recommendation='{recommendationText}', " +
                $"Priority='{priority}', " +
                $"DueDate='{dueDate:yyyy-MM-dd}'";

            await _auditService.WriteAsync(userId, ACTION_CREATE, MODULE_NAME, actionId, auditDetails);

            _logger.LogInformation(
                "Action created from HAZOP: ActionId={ActionId}, StudyId={StudyId}, DeviationId={DeviationId}, UserId={UserId}",
                actionId, study.Id, deviation.Id, userId);

            // ─────── Return Created Action ───────────────────────────────────────
            return (await _repository.GetByIdAsync(actionId))!;
        }
        catch (ArgumentException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating action from HAZOP deviation {DeviationId}",
                req.DeviationId);
            throw;
        }
    }

    public async Task<ActionRegisterDto> CreateFromIncidentRecommendationAsync(
        CreateActionFromIncidentRequest req,
        string userId)
    {
        try
        {
            // ─────── Validation ──────────────────────────────────────────────────
            if (string.IsNullOrWhiteSpace(req.IncidentId))
                throw new ArgumentException("شناسه حادثه الزامی است");

            if (string.IsNullOrWhiteSpace(req.RecommendationText))
                throw new ArgumentException("متن توصیه الزامی است");

            if (!VALID_PRIORITIES.Contains(req.Priority ?? "High"))
                throw new ArgumentException($"اولویت نامعتبر: {req.Priority}");

            // ─────── Fetch Incident Context ──────────────────────────────────────
            var incident = await _incidentRepository.GetIncidentAsync(req.IncidentId);
            if (incident is null)
                throw new KeyNotFoundException($"حادثه '{req.IncidentId}' یافت نشد");

            // ─────── Build Action Details ────────────────────────────────────────
            var recommendationText = req.RecommendationText?.Trim() ?? "";
            var recommendationType = req.RecommendationType?.Trim() ?? "corrective";

            var actionTitle = $"[{recommendationType.ToUpper()}] {incident.Title} - {recommendationText}"
                .Substring(0, Math.Min(255, 
                $"[{recommendationType.ToUpper()}] {incident.Title} - {recommendationText}".Length));

            var actionDescription = new System.Text.StringBuilder();
            actionDescription.AppendLine($"منبع: Incident - {incident.Title}");
            actionDescription.AppendLine($"شناسه حادثه: {incident.Id}");
            actionDescription.AppendLine($"نوع حادثه: {incident.IncidentType ?? "N/A"}");
            actionDescription.AppendLine($"تاریخ وقوع: {incident.DateOccurred:yyyy-MM-dd}");
            actionDescription.AppendLine($"علت اصلی: {incident.RootCause ?? "N/A"}");
            actionDescription.AppendLine($"نوع توصیه: {recommendationType}");
            actionDescription.AppendLine($"توصیه: {recommendationText}");
            actionDescription.AppendLine($"تاسیس: {incident.Facility ?? "N/A"}");
            actionDescription.AppendLine($"واحد: {incident.Unit ?? "N/A"}");

            // ─────── Create Action ───────────────────────────────────────────────
            var actionId = GenerateActionId();
            var priority = req.Priority?.Trim() ?? "High";
            var dueDate = req.DueDate ?? DateTime.Now.AddDays(30);

            await _repository.CreateAsync(
                actionId,
                actionTitle,
                actionDescription.ToString(),
                "Incident",                                      // Source
                incident.Id,                                     // SourceId = Incident ID
                recommendationType,                              // SourceRef = Type of recommendation
                incident.Unit,                                   // Unit from Incident
                req.Responsible?.Trim(),
                dueDate,
                "Open",                                          // Status
                priority,
                new[] { $"incident-{incident.Id}", $"rec-{recommendationType}" },  // Tags
                userId);

            // ─────── Audit Trail ─────────────────────────────────────────────────
            var auditDetails = $"Created action from Incident recommendation: " +
                $"IncidentId='{incident.Id}', " +
                $"RecommendationType='{recommendationType}', " +
                $"Recommendation='{recommendationText}', " +
                $"Priority='{priority}', " +
                $"DueDate='{dueDate:yyyy-MM-dd}'";

            await _auditService.WriteAsync(userId, ACTION_CREATE, MODULE_NAME, actionId, auditDetails);

            _logger.LogInformation(
                "Action created from Incident: ActionId={ActionId}, IncidentId={IncidentId}, Type={RecommendationType}, UserId={UserId}",
                actionId, incident.Id, recommendationType, userId);

            // ─────── Return Created Action ───────────────────────────────────────
            return (await _repository.GetByIdAsync(actionId))!;
        }
        catch (ArgumentException)
        {
            throw;
        }
        catch (KeyNotFoundException)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating action from Incident recommendation {IncidentId}",
                req.IncidentId);
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Helper Methods
    // ─────────────────────────────────────────────────────────────────────────────

    /// <summary>
    /// Generates a unique action register ID with prefix.
    /// Format: act_<GUID without hyphens>
    /// </summary>
    private static string GenerateActionId() =>
        $"act_{Guid.NewGuid():N}";
}
