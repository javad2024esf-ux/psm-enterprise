using System.Text.Json;
using PSM.Api.DTOs;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

public interface IRecordService
{
    Task<(object Result, long Total)> ListAsync(string collection, string? unit,
        string? status, int limit, int offset, string userRole, string? userUnit);
    Task<object?> GetAsync(string id, string collection);
    Task<string> CreateAsync(CreateRecordRequest req, string userId, string userRole);
    Task<string?> UpdateAsync(string id, UpdateRecordRequest req, string userId);
    Task<string?> DeleteAsync(string id, string userId);
    Task<long> CountAsync(string collection);
    Task<IEnumerable<object>> SearchAsync(string collection, string q, int limit);
    Task<string?> UpdateStatusAsync(string id, string newStatus, string userId);
}

public class RecordService : IRecordService
{
    private readonly IRecordRepository _repo;

    public RecordService(IRecordRepository repo) => _repo = repo;

    public async Task<(object Result, long Total)> ListAsync(string collection, string? unit,
        string? status, int limit, int offset, string userRole, string? userUnit)
    {
        limit = Math.Min(limit, 2000);
        offset = Math.Max(offset, 0);

        var (rows, total) = await _repo.ListAsync(collection, unit, status, limit, offset);
        return (rows, total);
    }

    public Task<dynamic?> GetAsync(string id, string collection) =>
        _repo.GetByIdAsync(id, collection);

    public async Task<string> CreateAsync(CreateRecordRequest req, string userId, string userRole)
    {
        var shortGuid = Guid.NewGuid().ToString("N")[..8];
        var id = $"rec_{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}_{shortGuid}";
        var dataJson = req.Data.ValueKind == JsonValueKind.Undefined
            ? "{}"
            : req.Data.GetRawText();

        await _repo.CreateAsync(id, req.ResolvedCollection, req.Unit, req.Status, dataJson, userId);
        return id;
    }

    public async Task<string?> UpdateAsync(string id, UpdateRecordRequest req, string userId)
    {
        var existing = await _repo.GetByIdAsync(id, "");
        if (existing is null) return "رکورد یافت نشد";

        var dataJson = req.Data.HasValue && req.Data.Value.ValueKind != JsonValueKind.Undefined
            ? req.Data.Value.GetRawText()
            : null;

        await _repo.UpdateAsync(id, req.Unit, req.Status, dataJson, userId);
        return null;
    }

    public async Task<string?> DeleteAsync(string id, string userId)
    {
        var existing = await _repo.GetByIdAsync(id, "");
        if (existing is null) return "رکورد یافت نشد";
        await _repo.SoftDeleteAsync(id, userId);
        return null;
    }

    public async Task<string?> UpdateStatusAsync(string id, string newStatus, string userId)
    {
        var existing = await _repo.GetByIdAsync(id, "");
        if (existing is null) return "رکورد یافت نشد";
        await _repo.UpdateAsync(id, null, newStatus, null, userId);
        return null;
    }

    public Task<long> CountAsync(string collection) => _repo.CountAsync(collection);

    public async Task<IEnumerable<object>> SearchAsync(string collection, string q, int limit)
    {
        var rows = await _repo.SearchAsync(collection, q, Math.Min(limit, 100));
        return rows.Cast<object>();
    }
}
