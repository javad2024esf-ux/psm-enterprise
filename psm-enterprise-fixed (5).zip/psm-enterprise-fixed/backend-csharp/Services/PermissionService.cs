using PSM.Api.Authorization;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

public interface IPermissionService
{
    // Individual permission checks
    Task<bool> CheckPermissionAsync(string role, string module, PsmAction action);
    bool IsUnitRestricted(string role, string module);
    
    // Get all permissions for a role (for RBAC matrix)
    Task<IEnumerable<string>> GetPermissionsByRoleAsync(string role);
}

public class PermissionService : IPermissionService
{
    private readonly IRoleRepository _roles;
    public PermissionService(IRoleRepository roles) => _roles = roles;

    public Task<bool> CheckPermissionAsync(string role, string module, PsmAction action) =>
        _roles.HasPermissionAsync(role, module, action);

    public bool IsUnitRestricted(string role, string _) =>
        role is "UnitHead" or "Supervisor" or "Operator";

    public async Task<IEnumerable<string>> GetPermissionsByRoleAsync(string role)
    {
        var permissions = new List<string>();
        
        // Get all role permissions from database
        var rolePerms = await _roles.GetPermissionsByRoleAsync(role);
        
        // Convert database records to permission strings
        // Format: "MODULE:Action" (e.g., "HAZOP:Read", "HAZOP:Write")
        foreach (var perm in rolePerms)
        {
            var module = perm.Module;
            if (perm.CanRead) permissions.Add($"{module}:Read");
            if (perm.CanWrite) permissions.Add($"{module}:Write");
            if (perm.CanApprove) permissions.Add($"{module}:Approve");
            if (perm.CanDelete) permissions.Add($"{module}:Delete");
        }
        
        return permissions;
    }
}
