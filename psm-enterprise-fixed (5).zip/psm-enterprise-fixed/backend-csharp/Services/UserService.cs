using PSM.Api.DTOs;
using PSM.Api.Models;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

public interface IUserService
{
    Task<IEnumerable<SafeUser>> GetAllAsync();
    Task<SafeUser?> GetByIdAsync(string id);
    Task<(SafeUser? User, string? Error)> CreateAsync(CreateUserRequest req, string creatorRole);
    Task<(SafeUser? User, string? Error)> UpdateAsync(string id, UpdateUserRequest req);
    Task<string?> DeleteAsync(string id);
    Task<string?> UnlockAsync(string id);
}

public class UserService : IUserService
{
    private readonly IUserRepository _repo;
    private readonly IPasswordHasher _hasher;

    public UserService(IUserRepository repo, IPasswordHasher hasher)
    {
        _repo   = repo;
        _hasher = hasher;
    }

    public async Task<IEnumerable<SafeUser>> GetAllAsync()
    {
        var users = await _repo.GetAllActiveAsync();
        return users.Select(SafeUser.From);
    }

    public async Task<SafeUser?> GetByIdAsync(string id)
    {
        var u = await _repo.GetByIdAsync(id);
        return u is null ? null : SafeUser.From(u);
    }

    public async Task<(SafeUser? User, string? Error)> CreateAsync(CreateUserRequest req, string creatorRole)
    {
        if (creatorRole != "Admin") return (null, "فقط Admin می‌تواند کاربر ایجاد کند");

        if (string.IsNullOrEmpty(req.Username) || string.IsNullOrEmpty(req.Password) ||
            string.IsNullOrEmpty(req.FullName) || string.IsNullOrEmpty(req.Role))
            return (null, "فیلدهای اجباری خالی است");

        if (await _repo.ExistsUsernameAsync(req.Username))
            return (null, "نام کاربری تکراری است");

        var shortGuid = Guid.NewGuid().ToString("N")[..8];
        var user = new User
        {
            Id                 = $"usr_{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}_{shortGuid}",
            Username           = req.Username,
            PasswordHash       = _hasher.Hash(req.Password),
            FullName           = req.FullName,
            Email              = req.Email,
            Role               = req.Role,
            Department         = req.Department,
            Unit               = req.Unit,
            Status             = "Active",
            MustChangePassword = true,
            CreatedAt          = DateTime.UtcNow,
        };

        await _repo.CreateAsync(user);
        return (SafeUser.From(user), null);
    }

    public async Task<(SafeUser? User, string? Error)> UpdateAsync(string id, UpdateUserRequest req)
    {
        var user = await _repo.GetByIdAsync(id);
        if (user is null) return (null, "کاربر یافت نشد");

        var updateObj = new
        {
            Id         = id,
            FullName   = req.FullName   ?? user.FullName,
            Email      = req.Email      ?? user.Email,
            Role       = req.Role       ?? user.Role,
            Department = req.Department ?? user.Department,
            Unit       = req.Unit       ?? user.Unit,
            Status     = req.Status     ?? user.Status,
            // ✅ Fix: Include PasswordHash if password is being changed
            PasswordHash = !string.IsNullOrEmpty(req.Password) ? _hasher.Hash(req.Password) : user.PasswordHash,
            // ✅ Fix: Use explicit MustChangePassword if provided, otherwise clear when password changes
            MustChangePassword = req.MustChangePassword ?? (!string.IsNullOrEmpty(req.Password) ? false : user.MustChangePassword),
        };

        await _repo.UpdateAsync(id, updateObj);

        var updated = await _repo.GetByIdAsync(id);
        return (updated is null ? null : SafeUser.From(updated), null);
    }

    public async Task<string?> DeleteAsync(string id)
    {
        var user = await _repo.GetByIdAsync(id);
        if (user is null) return "کاربر یافت نشد";
        await _repo.UpdateAsync(id, new
        {
            Id = id, FullName = user.FullName, Email = user.Email,
            Role = user.Role, Department = user.Department, Unit = user.Unit,
            Status = "Deleted",
        });
        return null;
    }

    public async Task<string?> UnlockAsync(string id)
    {
        var user = await _repo.GetByIdAsync(id);
        if (user is null) return "کاربر یافت نشد";
        await _repo.ResetFailedAttemptsAsync(id);
        return null;
    }
}
