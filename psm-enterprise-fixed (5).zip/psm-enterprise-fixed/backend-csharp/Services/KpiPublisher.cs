using PSM.Api.DTOs;

namespace PSM.Api.Services;

/// <summary>
/// Utility for modules to publish KPI updates to dashboard
/// Used as a helper to inject into existing services
/// </summary>
public interface IKpiPublisher
{
    /// <summary>Publish a KPI update event</summary>
    void PublishUpdate(string moduleName, string kpiName, object? oldValue, object? newValue, 
        string changeType = "updated", string? userId = null);
}

public class KpiPublisher : IKpiPublisher
{
    private readonly IDashboardService _dashboardService;
    private readonly ILogger<KpiPublisher> _logger;

    public KpiPublisher(IDashboardService dashboardService, ILogger<KpiPublisher> logger)
    {
        _dashboardService = dashboardService;
        _logger = logger;
    }

    public void PublishUpdate(string moduleName, string kpiName, object? oldValue, object? newValue,
        string changeType = "updated", string? userId = null)
    {
        try
        {
            var updateEvent = new KpiUpdateEventDto
            {
                ModuleName = moduleName,
                KpiName = kpiName,
                OldValue = oldValue,
                NewValue = newValue,
                ChangeType = changeType,
                UserId = userId,
                Timestamp = DateTime.UtcNow
            };

            _dashboardService.PublishKpiUpdate(updateEvent);

            _logger.LogInformation(
                "KPI Update published: {Module}/{KpiName} ({ChangeType}) by {UserId}",
                moduleName, kpiName, changeType, userId ?? "system");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error publishing KPI update for {Module}/{KpiName}", moduleName, kpiName);
        }
    }
}

/// <summary>
/// Extensions for easily publishing KPI updates from module services
/// </summary>
public static class KpiPublisherExtensions
{
    /// <summary>
    /// Publish multiple related KPI updates in batch
    /// </summary>
    public static void PublishBatch(this IKpiPublisher publisher, string moduleName,
        Dictionary<string, (object? oldValue, object? newValue)> updates, 
        string changeType = "updated", string? userId = null)
    {
        foreach (var kvp in updates)
        {
            publisher.PublishUpdate(moduleName, kvp.Key, kvp.Value.oldValue, kvp.Value.newValue, 
                changeType, userId);
        }
    }

    /// <summary>
    /// Publish count increase KPI update
    /// </summary>
    public static void PublishCountIncrease(this IKpiPublisher publisher, string moduleName,
        string kpiName, int oldCount, int newCount, string? userId = null)
    {
        publisher.PublishUpdate(moduleName, kpiName, oldCount, newCount, "created", userId);
    }

    /// <summary>
    /// Publish count decrease KPI update
    /// </summary>
    public static void PublishCountDecrease(this IKpiPublisher publisher, string moduleName,
        string kpiName, int oldCount, int newCount, string? userId = null)
    {
        publisher.PublishUpdate(moduleName, kpiName, oldCount, newCount, "deleted", userId);
    }

    /// <summary>
    /// Publish status change KPI update
    /// </summary>
    public static void PublishStatusChange(this IKpiPublisher publisher, string moduleName,
        string itemType, string oldStatus, string newStatus, string? userId = null)
    {
        publisher.PublishUpdate(moduleName, $"{itemType}_status_changed", oldStatus, newStatus, 
            "updated", userId);
    }
}
