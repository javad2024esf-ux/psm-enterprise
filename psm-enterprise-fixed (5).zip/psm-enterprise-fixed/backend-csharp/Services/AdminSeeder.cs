using PSM.Api.Data;
using PSM.Api.Models;
using ILogger = Serilog.ILogger;

namespace PSM.Api.Services;

/// <summary>
/// Runs once at startup, right after migrations. If the `users` table is empty
/// (fresh database), it creates the single initial Admin account so the
/// installer can hand the operator a working login on first boot — no manual
/// seed script required.
/// </summary>
public class AdminSeeder
{
    private readonly IDbHelper        _db;
    private readonly IPasswordHasher  _hasher;
    private readonly ILogger          _log;

    public AdminSeeder(IDbHelper db, IPasswordHasher hasher, ILogger log)
    {
        _db     = db;
        _hasher = hasher;
        _log    = log.ForContext<AdminSeeder>();
    }

    public async Task RunAsync()
    {
        var userCount = await _db.ExecuteScalarAsync<long>("SELECT COUNT(1) FROM users");
        if (userCount > 0)
        {
            _log.Debug("[Seed] کاربران از قبل وجود دارند — رد شدن از مرحله ساخت Admin.");
            return;
        }

        var username = Env("ADMIN_SEED_USERNAME", "admin");
        var password = Env("ADMIN_SEED_PASSWORD", "Admin@PSM#2026");

        var admin = new User
        {
            Id                 = $"usr_{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}_{Guid.NewGuid().ToString("N")[..8]}",
            Username           = username,
            PasswordHash       = _hasher.Hash(password),
            FullName           = "System Administrator",
            Role               = "Admin",
            Status             = "Active",
            MustChangePassword = true,
            CreatedAt          = DateTime.UtcNow,
        };

        await _db.ExecuteAsync(@"
            INSERT INTO users
                (id, username, password_hash, full_name, email, role, department, unit,
                 status, failed_attempts, mfa_enabled, must_change_password, created_at)
            VALUES
                (@Id, @Username, @PasswordHash, @FullName, @Email, @Role, @Department, @Unit,
                 @Status, @FailedAttempts, @MfaEnabled, @MustChangePassword, @CreatedAt)",
            admin);

        _log.Information("[Seed] ✓ کاربر Admin ایجاد شد");
        _log.Information("─────────────────────────────");
        _log.Information("نام کاربری: {Username}", username);
        _log.Information("رمز عبور:    {Password}", password);
        _log.Information("─────────────────────────────");
        _log.Information("[Seed] لطفاً پس از اولین ورود، رمز عبور را تغییر دهید.");
    }

    private static string Env(string key, string def) =>
        Environment.GetEnvironmentVariable(key) is { Length: > 0 } v ? v : def;
}
