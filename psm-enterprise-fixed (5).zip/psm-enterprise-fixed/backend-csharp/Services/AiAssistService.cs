namespace PSM.Api.Services;

using System.Diagnostics;
using System.Text.Json;
using PSM.Api.DTOs;

public partial interface IAiAssistService
{
    // HAZOP
    Task<SuggestHazopCauseResponseDto> SuggestHazopCauseAsync(SuggestHazopCauseDto request);
    Task<SuggestHazopConsequenceResponseDto> SuggestHazopConsequenceAsync(SuggestHazopConsequenceDto request);
    Task<SuggestHazopSafeguardResponseDto> SuggestHazopSafeguardAsync(SuggestHazopSafeguardDto request);
    Task<SuggestHazopActionResponseDto> SuggestHazopActionAsync(SuggestHazopActionDto request);
    Task<AssessHazopRiskResponseDto> AssessHazopRiskAsync(AssessHazopRiskDto request);

    // LOPA
    Task<SuggestLopaIplResponseDto> SuggestLopaIplAsync(SuggestLopaIplDto request);
    Task<EstimateLopaIplResponseDto> EstimateLopaIplAsync(EstimaLopaLopaDto request);
    Task<RecommendLopaSilResponseDto> RecommendLopaSilAsync(RecommendLopaSilDto request);

    // Generic
    Task<CompleteFieldResponseDto> CompleteFieldAsync(CompleteFieldDto request);

    // Health
    Task<AiAssistHealthDto> GetHealthAsync();
}

public partial class AiAssistService : IAiAssistService
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _configuration;
    private readonly string _aiEndpoint;
    private readonly string _aiApiKey;

    public AiAssistService(HttpClient httpClient, IConfiguration configuration)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));

        _aiEndpoint = _configuration.GetValue<string>("AiAssist:Endpoint") ?? "https://api.anthropic.com";
        _aiApiKey = _configuration.GetValue<string>("AiAssist:ApiKey") ?? "";

        if (!string.IsNullOrEmpty(_aiEndpoint) && !string.IsNullOrEmpty(_aiApiKey))
        {
            _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {_aiApiKey}");
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // HAZOP AI SUGGESTIONS
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<SuggestHazopCauseResponseDto> SuggestHazopCauseAsync(SuggestHazopCauseDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildHazopCausePrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseHazopCauseResponse(response);
    }

    public async Task<SuggestHazopConsequenceResponseDto> SuggestHazopConsequenceAsync(SuggestHazopConsequenceDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildHazopConsequencePrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseHazopConsequenceResponse(response);
    }

    public async Task<SuggestHazopSafeguardResponseDto> SuggestHazopSafeguardAsync(SuggestHazopSafeguardDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildHazopSafeguardPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseHazopSafeguardResponse(response);
    }

    public async Task<SuggestHazopActionResponseDto> SuggestHazopActionAsync(SuggestHazopActionDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildHazopActionPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseHazopActionResponse(response);
    }

    public async Task<AssessHazopRiskResponseDto> AssessHazopRiskAsync(AssessHazopRiskDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildHazopRiskPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseHazopRiskResponse(response);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // LOPA AI SUGGESTIONS
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<SuggestLopaIplResponseDto> SuggestLopaIplAsync(SuggestLopaIplDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildLopaIplPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseLopaIplResponse(response);
    }

    public async Task<EstimateLopaIplResponseDto> EstimateLopaIplAsync(EstimaLopaLopaDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildLopaEstimatePrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseLopaEstimateResponse(response);
    }

    public async Task<RecommendLopaSilResponseDto> RecommendLopaSilAsync(RecommendLopaSilDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildLopaSilPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseLopaSilResponse(response);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // GENERIC FIELD COMPLETION
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<CompleteFieldResponseDto> CompleteFieldAsync(CompleteFieldDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildFieldCompletionPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseFieldCompletionResponse(response);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // HEALTH CHECK
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<AiAssistHealthDto> GetHealthAsync()
    {
        var sw = Stopwatch.StartNew();
        try
        {
            if (string.IsNullOrEmpty(_aiEndpoint) || string.IsNullOrEmpty(_aiApiKey))
            {
                return new AiAssistHealthDto
                {
                    Status = "degraded",
                    Message = "AI API credentials not configured",
                    ResponseTimeMs = sw.ElapsedMilliseconds,
                    ApiConnected = false,
                    Version = "1.0"
                };
            }

            var response = await _httpClient.GetAsync($"{_aiEndpoint}/health");
            sw.Stop();

            return new AiAssistHealthDto
            {
                Status = response.IsSuccessStatusCode ? "healthy" : "degraded",
                Message = response.ReasonPhrase,
                ResponseTimeMs = sw.ElapsedMilliseconds,
                ApiConnected = response.IsSuccessStatusCode,
                Version = "1.0"
            };
        }
        catch (Exception ex)
        {
            sw.Stop();
            return new AiAssistHealthDto
            {
                Status = "unhealthy",
                Message = ex.Message,
                ResponseTimeMs = sw.ElapsedMilliseconds,
                ApiConnected = false,
                Version = "1.0"
            };
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PROMPT BUILDERS
    // ═══════════════════════════════════════════════════════════════════════════

    private string BuildHazopCausePrompt(SuggestHazopCauseDto request)
    {
        return $@"
You are a HAZOP analysis expert. Based on the following context, suggest 3-5 potential causes for the deviation.

Guide Word: {request.GuideWord}
Parameter: {request.Parameter}
Process Description: {request.ProcessDescription}
Existing Causes: {request.ExistingCauses}

Please provide:
1. Three to five novel cause suggestions
2. Brief reasoning for each
3. Confidence score (1-100) for the suggestions

Format your response as JSON:
{{
  ""suggestions"": [""cause1"", ""cause2"", ...],
  ""reasoning"": ""explanation"",
  ""confidenceScore"": 85
}}";
    }

    private string BuildHazopConsequencePrompt(SuggestHazopConsequenceDto request)
    {
        return $@"
You are a process safety expert. Given a cause and process deviation, suggest potential consequences.

Cause: {request.Cause}
Parameter: {request.Parameter}
Process Description: {request.ProcessDescription}
Severity: {request.Severity}

Please provide:
1. Three to five potential consequences
2. Assessment of severity
3. Confidence score (1-100)

Format your response as JSON:
{{
  ""suggestions"": [""consequence1"", ""consequence2"", ...],
  ""severityAssessment"": ""High/Medium/Low"",
  ""confidenceScore"": 80
}}";
    }

    private string BuildHazopSafeguardPrompt(SuggestHazopSafeguardDto request)
    {
        return $@"
You are a process safety control expert. Suggest safeguards to prevent or mitigate the hazard.

Hazard: {request.Hazard}
Consequence: {request.Consequence}
Existing Safeguards: {request.ExistingSafeguards}
Desired Type: {request.SafeguardType}

Please provide:
1. Three to five novel safeguard suggestions
2. Classification by type
3. Confidence score (1-100)

Format your response as JSON:
{{
  ""suggestions"": [""safeguard1"", ""safeguard2"", ...],
  ""safeguardTypes"": [""Engineering"", ""Procedural"", ...],
  ""confidenceScore"": 75
}}";
    }

    private string BuildHazopActionPrompt(SuggestHazopActionDto request)
    {
        return $@"
You are a process improvement specialist. Given residual risk, suggest actions to reduce it.

Residual Risk: {request.ResidualRisk}
Consequence: {request.Consequence}
Recommended Safeguards: {request.RecommendedSafeguards}

Please provide:
1. Three to five actions
2. Priority ranking
3. Suggested timeline
4. Confidence score (1-100)

Format your response as JSON:
{{
  ""actions"": [""action1"", ""action2"", ...],
  ""priorities"": [""High"", ""Medium"", ...],
  ""timeline"": ""weeks/months"",
  ""confidenceScore"": 80
}}";
    }

    private string BuildHazopRiskPrompt(AssessHazopRiskDto request)
    {
        return $@"
You are a risk assessment expert. Assess the risk level based on the provided factors.

Consequence: {request.Consequence}
Likelihood: {request.Likelihood}
Severity: {request.Severity}
Existing Controls: {request.ExistingControls}

Please provide:
1. Risk level (High/Medium/Low)
2. Risk score (1-100)
3. Justification
4. Whether action is required
5. Recommended controls

Format your response as JSON:
{{
  ""riskLevel"": ""High"",
  ""riskScore"": 85,
  ""justification"": ""..."",
  ""requiresAction"": true,
  ""recommendedControls"": [""control1"", ...]
}}";
    }

    private string BuildLopaIplPrompt(SuggestLopaIplDto request)
    {
        return $@"
You are a SIL analysis expert. Suggest Independent Protection Layers (IPLs) for LOPA.

Hazard: {request.Hazard}
Consequence: {request.Consequence}
Initiating Event: {request.InitiatingEvent}
Existing IPLs: {request.ExistingIpls}

Please provide:
1. Three to five IPL suggestions
2. Identify truly independent layers
3. Confidence score (1-100)

Format your response as JSON:
{{
  ""suggestions"": [""ipl1"", ""ipl2"", ...],
  ""independentLayers"": [true, true, ...],
  ""confidenceScore"": 80
}}";
    }

    private string BuildLopaEstimatePrompt(EstimaLopaLopaDto request)
    {
        return $@"
You are a reliability engineer. Estimate PFD for the given IPL.

IPL: {request.Ipl}
Type: {request.IplType}
Maintenance: {request.MaintenanceFrequency}
Testing: {request.TestingFrequency}

Please provide:
1. PFD value
2. PFD range
3. Justification
4. Relevant factors considered

Format your response as JSON:
{{
  ""pfdValue"": 0.05,
  ""pfdRange"": ""0.01-0.1"",
  ""justification"": ""..."",
  ""relevantFactors"": [""factor1"", ...]
}}";
    }

    private string BuildLopaSilPrompt(RecommendLopaSilDto request)
    {
        return $@"
You are a SIL determination expert. Recommend SIL level based on risk parameters.

Initiating Event Frequency: {request.InitiatingEventFrequency}
Consequence Severity: {request.ConsequenceSeverity}
IPL PFD: {request.IplPfd}
Existing IPL Count: {request.ExistingIplCount}

Please provide:
1. Recommended SIL (1, 2, or 3)
2. Justification
3. Required IPL characteristics
4. Risk reduction achieved (%)

Format your response as JSON:
{{
  ""recommendedSil"": 2,
  ""silJustification"": ""..."",
  ""requiredIplCharacteristics"": [""characteristic1"", ...],
  ""riskReductionAchieved"": 95.0
}}";
    }

    private string BuildFieldCompletionPrompt(CompleteFieldDto request)
    {
        return $@"
You are a process safety domain expert for {request.Module} analysis.

Field: {request.FieldName}
Partial Value: {request.PartialValue}
Context: {request.Context}
Additional Data: {JsonSerializer.Serialize(request.ContextData)}

Please complete this field with:
1. Most likely completion
2. Alternative suggestions (2-3)
3. Confidence score (1-100)
4. Reasoning

Format your response as JSON:
{{
  ""completedValue"": ""..."",
  ""alternativeSuggestions"": [""alt1"", ""alt2""],
  ""confidenceScore"": 85,
  ""reasoning"": ""...""
}}";
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // API CALL
    // ═══════════════════════════════════════════════════════════════════════════

    private async Task<string> CallAiApiAsync(string prompt)
    {
        try
        {
            if (string.IsNullOrEmpty(_aiEndpoint) || string.IsNullOrEmpty(_aiApiKey))
            {
                // Return mock response for testing
                return "{\"status\": \"ai_api_not_configured\"}";
            }

            var payload = new
            {
                model = "claude-3-sonnet-20240229",
                messages = new[] { new { role = "user", content = prompt } },
                max_tokens = 1024
            };

            var content = new StringContent(
                JsonSerializer.Serialize(payload),
                Encoding.UTF8,
                "application/json"
            );

            var response = await _httpClient.PostAsync($"{_aiEndpoint}/messages", content);
            var responseBody = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                return $"{{\"error\": \"API call failed: {response.StatusCode}\"}}";
            }

            return responseBody;
        }
        catch (Exception ex)
        {
            return $"{{\"error\": \"{ex.Message}\"}}";
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // RESPONSE PARSERS
    // ═══════════════════════════════════════════════════════════════════════════

    private SuggestHazopCauseResponseDto ParseHazopCauseResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new SuggestHazopCauseResponseDto
            {
                Suggestions = ParseStringArray(root, "suggestions"),
                Reasoning = GetStringValue(root, "reasoning"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new SuggestHazopCauseResponseDto
            {
                Suggestions = new List<string> { "Error parsing response" },
                Reasoning = "Failed to parse AI response",
                ConfidenceScore = 0
            };
        }
    }

    private SuggestHazopConsequenceResponseDto ParseHazopConsequenceResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new SuggestHazopConsequenceResponseDto
            {
                Suggestions = ParseStringArray(root, "suggestions"),
                SeverityAssessment = GetStringValue(root, "severityAssessment"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new SuggestHazopConsequenceResponseDto
            {
                Suggestions = new List<string> { "Error parsing response" },
                SeverityAssessment = "Unknown",
                ConfidenceScore = 0
            };
        }
    }

    private SuggestHazopSafeguardResponseDto ParseHazopSafeguardResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new SuggestHazopSafeguardResponseDto
            {
                Suggestions = ParseStringArray(root, "suggestions"),
                SafeguardTypes = ParseStringArray(root, "safeguardTypes"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new SuggestHazopSafeguardResponseDto
            {
                Suggestions = new List<string> { "Error parsing response" },
                SafeguardTypes = new List<string>(),
                ConfidenceScore = 0
            };
        }
    }

    private SuggestHazopActionResponseDto ParseHazopActionResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new SuggestHazopActionResponseDto
            {
                Actions = ParseStringArray(root, "actions"),
                Priorities = ParseStringArray(root, "priorities"),
                Timeline = GetStringValue(root, "timeline"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new SuggestHazopActionResponseDto
            {
                Actions = new List<string> { "Error parsing response" },
                Priorities = new List<string>(),
                Timeline = "Unknown",
                ConfidenceScore = 0
            };
        }
    }

    private AssessHazopRiskResponseDto ParseHazopRiskResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new AssessHazopRiskResponseDto
            {
                RiskLevel = GetStringValue(root, "riskLevel"),
                RiskScore = GetIntValue(root, "riskScore"),
                Justification = GetStringValue(root, "justification"),
                RequiresAction = GetBoolValue(root, "requiresAction"),
                RecommendedControls = ParseStringArray(root, "recommendedControls")
            };
        }
        catch
        {
            return new AssessHazopRiskResponseDto
            {
                RiskLevel = "Unknown",
                RiskScore = 0,
                Justification = "Error parsing response",
                RequiresAction = false,
                RecommendedControls = new List<string>()
            };
        }
    }

    private SuggestLopaIplResponseDto ParseLopaIplResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new SuggestLopaIplResponseDto
            {
                Suggestions = ParseStringArray(root, "suggestions"),
                IndependentLayers = ParseStringArray(root, "independentLayers"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new SuggestLopaIplResponseDto
            {
                Suggestions = new List<string>(),
                IndependentLayers = new List<string>(),
                ConfidenceScore = 0
            };
        }
    }

    private EstimateLopaIplResponseDto ParseLopaEstimateResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new EstimateLopaIplResponseDto
            {
                PfdValue = GetDoubleValue(root, "pfdValue"),
                PfdRange = GetStringValue(root, "pfdRange"),
                Justification = GetStringValue(root, "justification"),
                RelevantFactors = ParseStringArray(root, "relevantFactors")
            };
        }
        catch
        {
            return new EstimateLopaIplResponseDto
            {
                PfdValue = 0,
                PfdRange = "Unknown",
                Justification = "Error parsing response",
                RelevantFactors = new List<string>()
            };
        }
    }

    private RecommendLopaSilResponseDto ParseLopaSilResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new RecommendLopaSilResponseDto
            {
                RecommendedSil = GetIntValue(root, "recommendedSil"),
                SilJustification = GetStringValue(root, "silJustification"),
                RequiredIplCharacteristics = ParseStringArray(root, "requiredIplCharacteristics"),
                RiskReductionAchieved = GetDoubleValue(root, "riskReductionAchieved")
            };
        }
        catch
        {
            return new RecommendLopaSilResponseDto
            {
                RecommendedSil = 0,
                SilJustification = "Error parsing response",
                RequiredIplCharacteristics = new List<string>(),
                RiskReductionAchieved = 0
            };
        }
    }

    private CompleteFieldResponseDto ParseFieldCompletionResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new CompleteFieldResponseDto
            {
                CompletedValue = GetStringValue(root, "completedValue"),
                AlternativeSuggestions = ParseStringArray(root, "alternativeSuggestions"),
                ConfidenceScore = GetIntValue(root, "confidenceScore"),
                Reasoning = GetStringValue(root, "reasoning")
            };
        }
        catch
        {
            return new CompleteFieldResponseDto
            {
                CompletedValue = "",
                AlternativeSuggestions = new List<string>(),
                ConfidenceScore = 0,
                Reasoning = "Error parsing response"
            };
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // JSON HELPERS
    // ═══════════════════════════════════════════════════════════════════════════

    private List<string> ParseStringArray(JsonElement element, string propertyName)
    {
        var result = new List<string>();
        if (element.TryGetProperty(propertyName, out var prop) && prop.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in prop.EnumerateArray())
            {
                if (item.ValueKind == JsonValueKind.String)
                    result.Add(item.GetString());
            }
        }
        return result;
    }

    private string GetStringValue(JsonElement element, string propertyName)
    {
        if (element.TryGetProperty(propertyName, out var prop) && prop.ValueKind == JsonValueKind.String)
            return prop.GetString();
        return null;
    }

    private int GetIntValue(JsonElement element, string propertyName)
    {
        if (element.TryGetProperty(propertyName, out var prop) && prop.ValueKind == JsonValueKind.Number)
            return prop.GetInt32();
        return 0;
    }

    private double GetDoubleValue(JsonElement element, string propertyName)
    {
        if (element.TryGetProperty(propertyName, out var prop) && prop.ValueKind == JsonValueKind.Number)
            return prop.GetDouble();
        return 0;
    }

    private bool GetBoolValue(JsonElement element, string propertyName)
    {
        if (element.TryGetProperty(propertyName, out var prop) && prop.ValueKind == JsonValueKind.True)
            return true;
        if (prop.ValueKind == JsonValueKind.False)
            return false;
        return false;
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Extended IAiAssistService Interface
// ═══════════════════════════════════════════════════════════════════════════
public partial interface IAiAssistService
{
    // BOWTIE
    Task<SuggestBowTieTopEventResponseDto> SuggestBowTieTopEventAsync(SuggestBowTieTopEventDto request);
    Task<SuggestBowTieThreatsResponseDto> SuggestBowTieThreatsAsync(SuggestBowTieThreatsDto request);
    Task<SuggestBowTieConsequencesResponseDto> SuggestBowTieConsequencesAsync(SuggestBowTieConsequencesDto request);
    Task<SuggestBowTieBarriersResponseDto> SuggestBowTieBarriersAsync(SuggestBowTieBarriersDto request);
    Task<AssessBowTieIntegrityResponseDto> AssessBowTieIntegrityAsync(AssessBowTieIntegrityDto request);

    // RISK ASSESSMENT
    Task<AssessIntegratedRiskResponseDto> AssessIntegratedRiskAsync(AssessIntegratedRiskDto request);
    Task<RecommendRiskControlsResponseDto> RecommendRiskControlsAsync(RecommendRiskControlsDto request);
    Task<AnalyzeRiskTrendsResponseDto> AnalyzeRiskTrendsAsync(AnalyzeRiskTrendsDto request);

    // DOCUMENTS
    Task<AnalyzeDocumentResponseDto> AnalyzeDocumentAsync(AnalyzeDocumentDto request);
    Task<GenerateDocumentRecommendationsResponseDto> GenerateDocumentRecommendationsAsync(GenerateDocumentRecommendationsDto request);
    Task<ExtractDocumentDataResponseDto> ExtractDocumentDataAsync(ExtractDocumentDataDto request);

    // RECOMMENDATIONS
    Task<GenerateHazopRecommendationsResponseDto> GenerateHazopRecommendationsAsync(GenerateHazopRecommendationsDto request);
    Task<GenerateLopaRecommendationsResponseDto> GenerateLopaRecommendationsAsync(GenerateLopaRecommendationsDto request);
    Task<PrioritizeActionsResponseDto> PrioritizeActionsAsync(PrioritizeActionsDto request);

    // CROSS-MODULE
    Task<AnalyzeCrossModuleConsistencyResponseDto> AnalyzeCrossModuleConsistencyAsync(AnalyzeCrossModuleConsistencyDto request);

    // BULK
    Task<BulkAiAnalysisResponseDto> BulkAnalyzeAsync(BulkAiAnalysisDto request);
}

// ═══════════════════════════════════════════════════════════════════════════
// Implementation Method Stubs for AiAssistService
// ═══════════════════════════════════════════════════════════════════════════
public partial class AiAssistService : IAiAssistService
{
    // ═══════════════════════════════════════════════════════════════════════════
    // BOWTIE AI SUGGESTIONS
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<SuggestBowTieTopEventResponseDto> SuggestBowTieTopEventAsync(SuggestBowTieTopEventDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildBowTieTopEventPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseBowTieTopEventResponse(response);
    }

    public async Task<SuggestBowTieThreatsResponseDto> SuggestBowTieThreatsAsync(SuggestBowTieThreatsDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildBowTieThreatsPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseBowTieThreatsResponse(response);
    }

    public async Task<SuggestBowTieConsequencesResponseDto> SuggestBowTieConsequencesAsync(SuggestBowTieConsequencesDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildBowTieConsequencesPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseBowTieConsequencesResponse(response);
    }

    public async Task<SuggestBowTieBarriersResponseDto> SuggestBowTieBarriersAsync(SuggestBowTieBarriersDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildBowTieBarriersPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseBowTieBarriersResponse(response);
    }

    public async Task<AssessBowTieIntegrityResponseDto> AssessBowTieIntegrityAsync(AssessBowTieIntegrityDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildBowTieIntegrityPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseBowTieIntegrityResponse(response);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // RISK ASSESSMENT AI ANALYSIS
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<AssessIntegratedRiskResponseDto> AssessIntegratedRiskAsync(AssessIntegratedRiskDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildIntegratedRiskPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseIntegratedRiskResponse(response);
    }

    public async Task<RecommendRiskControlsResponseDto> RecommendRiskControlsAsync(RecommendRiskControlsDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildRiskControlsPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseRiskControlsResponse(response);
    }

    public async Task<AnalyzeRiskTrendsResponseDto> AnalyzeRiskTrendsAsync(AnalyzeRiskTrendsDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildRiskTrendsPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseRiskTrendsResponse(response);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // DOCUMENT AI ANALYSIS
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<AnalyzeDocumentResponseDto> AnalyzeDocumentAsync(AnalyzeDocumentDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildDocumentAnalysisPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseDocumentAnalysisResponse(response);
    }

    public async Task<GenerateDocumentRecommendationsResponseDto> GenerateDocumentRecommendationsAsync(GenerateDocumentRecommendationsDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildDocumentRecommendationsPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseDocumentRecommendationsResponse(response);
    }

    public async Task<ExtractDocumentDataResponseDto> ExtractDocumentDataAsync(ExtractDocumentDataDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildDocumentExtractionPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseDocumentExtractionResponse(response);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // RECOMMENDATIONS GENERATION
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<GenerateHazopRecommendationsResponseDto> GenerateHazopRecommendationsAsync(GenerateHazopRecommendationsDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildHazopRecommendationsPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseHazopRecommendationsResponse(response);
    }

    public async Task<GenerateLopaRecommendationsResponseDto> GenerateLopaRecommendationsAsync(GenerateLopaRecommendationsDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildLopaRecommendationsPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseLopaRecommendationsResponse(response);
    }

    public async Task<PrioritizeActionsResponseDto> PrioritizeActionsAsync(PrioritizeActionsDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildActionPrioritizationPrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseActionPrioritizationResponse(response);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CROSS-MODULE ANALYSIS
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<AnalyzeCrossModuleConsistencyResponseDto> AnalyzeCrossModuleConsistencyAsync(AnalyzeCrossModuleConsistencyDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var prompt = BuildCrossModulePrompt(request);
        var response = await CallAiApiAsync(prompt);

        return ParseCrossModuleResponse(response);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // BULK ANALYSIS
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<BulkAiAnalysisResponseDto> BulkAnalyzeAsync(BulkAiAnalysisDto request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var results = new Dictionary<int, object>();
        int successCount = 0;
        int failureCount = 0;

        // Process each module ID based on module type
        foreach (var moduleId in request.ModuleIds)
        {
            try
            {
                object result = request.ModuleType switch
                {
                    "HAZOP" => await HandleBulkHazopAnalysisAsync(moduleId, request.AnalysisType),
                    "LOPA" => await HandleBulkLopaAnalysisAsync(moduleId, request.AnalysisType),
                    "BowTie" => await HandleBulkBowTieAnalysisAsync(moduleId, request.AnalysisType),
                    _ => throw new ArgumentException($"Unknown module type: {request.ModuleType}")
                };

                results[moduleId] = result;
                successCount++;
            }
            catch (Exception ex)
            {
                results[moduleId] = new { error = ex.Message };
                failureCount++;
            }
        }

        return new BulkAiAnalysisResponseDto
        {
            Results = results,
            SuccessCount = successCount,
            FailureCount = failureCount
        };
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PROMPT BUILDERS - BOWTIE
    // ═══════════════════════════════════════════════════════════════════════════

    private string BuildBowTieTopEventPrompt(SuggestBowTieTopEventDto request)
    {
        return $@"
You are a process safety expert specializing in BowTie risk analysis.

Suggest the top event for a BowTie analysis given:
- System Description: {request.SystemDescription}
- Process Description: {request.ProcessDescription}
- Historical Incidents: {request.HistoricalIncidents ?? "None provided"}

Provide:
1. 2-3 top event suggestions
2. Severity level for each
3. Confidence score (0-100)

Return as JSON with keys: topEventSuggestions (array), severity, confidenceScore
";
    }

    private string BuildBowTieThreatsPrompt(SuggestBowTieThreatsDto request)
    {
        return $@"
You are a process safety expert specializing in BowTie risk analysis.

Suggest threats that could lead to the top event:
- Top Event: {request.TopEvent}
- System Description: {request.SystemDescription}
- Existing Threats: {request.ExistingThreats ?? "None provided"}

Provide:
1. 3-5 threat suggestions
2. Categorize them (human error, equipment failure, external, etc.)
3. Confidence score for each

Return as JSON with keys: threatSuggestions (array), threatCategories (array), confidenceScore
";
    }

    private string BuildBowTieConsequencesPrompt(SuggestBowTieConsequencesDto request)
    {
        return $@"
You are a process safety expert specializing in BowTie risk analysis.

Suggest consequences of the top event:
- Top Event: {request.TopEvent}
- Severity: {request.Severity}
- Process Context: {request.ProcessContext ?? "Not provided"}

Provide:
1. 2-3 consequence suggestions
2. Overall risk assessment
3. Confidence score

Return as JSON with keys: consequenceSuggestions (array), overallRiskLevel, confidenceScore
";
    }

    private string BuildBowTieBarriersPrompt(SuggestBowTieBarriersDto request)
    {
        return $@"
You are a process safety expert specializing in BowTie risk analysis.

Suggest {request.BarrierPosition} barriers:
- Top Event: {request.TopEvent}
- Threat/Consequence: {request.ThreatOrConsequence ?? "Not specified"}
- Existing Barriers: {request.ExistingBarriers ?? "None"}

Provide:
1. 2-4 barrier suggestions
2. Barrier types: Engineering, Administrative, PPE
3. Confidence score

Return as JSON with keys: barrierSuggestions (array), barrierTypes (array), confidenceScore
";
    }

    private string BuildBowTieIntegrityPrompt(AssessBowTieIntegrityDto request)
    {
        return $@"
You are a process safety expert specializing in BowTie risk analysis.

Assess the integrity of this BowTie analysis:
- Top Event: {request.TopEvent}
- Threats: {string.Join(", ", request.Threats)}
- Prevention Barriers: {string.Join(", ", request.PreventionBarriers)}
- Consequences: {string.Join(", ", request.Consequences)}
- Mitigation Barriers: {string.Join(", ", request.MitigationBarriers)}

Identify:
1. Overall risk assessment
2. Gaps in the analysis
3. Improvement suggestions

Return as JSON with keys: overallRiskAssessment, gapIdentifications (array), improvementSuggestions (array), riskScore
";
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PROMPT BUILDERS - RISK ASSESSMENT
    // ═══════════════════════════════════════════════════════════════════════════

    private string BuildIntegratedRiskPrompt(AssessIntegratedRiskDto request)
    {
        return $@"
You are a process safety expert specializing in integrated risk assessment.

Assess the overall risk given:
- Hazard Description: {request.HazardDescription}
- HAZOP Findings: {request.HazopFindings ?? "Not provided"}
- LOPA Results: {request.LopaResults ?? "Not provided"}
- BowTie Analysis: {request.BowTieAnalysis ?? "Not provided"}
- Existing Controls: {request.ExistingControls ?? "None"}

Provide:
1. Overall risk level (Critical, High, Medium, Low)
2. Risk score (0-100)
3. IPL/SIL needed
4. Control recommendations
5. Monitoring recommendations

Return as JSON with keys: overallRiskLevel, riskScore, iplNeeded, controlRecommendations (array), monitoringRecommendations (array)
";
    }

    private string BuildRiskControlsPrompt(RecommendRiskControlsDto request)
    {
        return $@"
You are a process safety expert specializing in risk control design.

Recommend controls for:
- Risk Level: {request.RiskLevel}
- Hazard Category: {request.HazardCategory ?? "General"}
- Process Description: {request.ProcessDescription ?? "Not provided"}
- Existing Controls: {(request.ExistingControls?.Count > 0 ? string.Join(", ", request.ExistingControls) : "None")}

Categorize recommendations:
1. Engineering controls
2. Administrative controls
3. PPE controls
4. Monitoring measures
5. Implementation priority

Return as JSON with keys: engineeringControls (array), administrativeControls (array), ppeControls (array), monitoringMeasures (array), implementationPriority
";
    }

    private string BuildRiskTrendsPrompt(AnalyzeRiskTrendsDto request)
    {
        return $@"
You are a process safety expert analyzing risk trends.

Analyze historical incident data:
- Time Period: {request.TimeframePeriod ?? "Recent"}
- Incident Count: {request.HistoricalIncidents.Count}

Incidents:
{string.Join("\n", request.HistoricalIncidents.ConvertAll(i => $"- {i.Date:yyyy-MM-dd}: {i.Category} ({i.Severity}) - {i.Description}"))}

Identify:
1. Trends in incident frequency/severity
2. High-risk areas
3. Proactive recommendations

Return as JSON with keys: trendIdentifications (array), highRiskAreas (array), proactiveRecommendations (array), overallTrendAssessment
";
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PROMPT BUILDERS - DOCUMENTS
    // ═══════════════════════════════════════════════════════════════════════════

    private string BuildDocumentAnalysisPrompt(AnalyzeDocumentDto request)
    {
        return $@"
Analyze the following {request.DocumentType} document ({request.AnalysisType} analysis):

Title: {request.DocumentTitle ?? "Not provided"}
Content Preview: {(request.DocumentContent?.Length > 500 ? request.DocumentContent.Substring(0, 500) + "..." : request.DocumentContent ?? "N/A")}

Provide:
1. Summary
2. Key findings
3. Identified risks
4. Compliance gaps
5. Action items

Return as JSON with keys: summary, keyFindings (array), identifiedRisks (array), complianceGaps (array), actionItems (array)
";
    }

    private string BuildDocumentRecommendationsPrompt(GenerateDocumentRecommendationsDto request)
    {
        return $@"
Generate recommendations for {request.DocumentType} document improvement.

Document Context: {request.DocumentContext ?? "Not provided"}

Identified Issues:
{(request.IdentifiedIssues?.Count > 0 ? string.Join("\n", request.IdentifiedIssues) : "None specific")}

Provide recommendations with:
1. Title and description
2. Priority level
3. Implementation timeline

Return as JSON with keys: recommendations (array of {{title, description, priority, timeline}}), implementationStrategy, resourcesNeeded (array)
";
    }

    private string BuildDocumentExtractionPrompt(ExtractDocumentDataDto request)
    {
        return $@"
Extract the following data fields from a {request.DocumentType} document:

Fields to Extract:
{string.Join("\n", request.DataFieldsToExtract.ConvertAll(f => $"- {f}"))}

Document Content: {request.DocumentContent ?? "Not provided"}

For each field, extract the value if found or indicate ""NOT_FOUND"".
Provide confidence score for each extraction.

Return as JSON with keys: extractedData (object with field names as keys), unrecognizedFields (array), extractionConfidence (0-100)
";
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PROMPT BUILDERS - RECOMMENDATIONS
    // ═══════════════════════════════════════════════════════════════════════════

    private string BuildHazopRecommendationsPrompt(GenerateHazopRecommendationsDto request)
    {
        return $@"
Generate detailed action recommendations for HAZOP study {request.HazopStudyId}.

Topics Identified: {request.TopicsIdentified}
Risk Level: {request.RiskLevel}
Existing Actions: {request.ExistingActions ?? "None"}

For each recommendation provide:
1. Title and description
2. Priority (Critical, High, Medium, Low)
3. Suggested owner
4. Timeline
5. Success criteria

Return as JSON with keys: recommendations (array of {{title, description, priority, owner, timeline, successCriteria}}), implementationSequence, resourceRequirements (array)
";
    }

    private string BuildLopaRecommendationsPrompt(GenerateLopaRecommendationsDto request)
    {
        return $@"
Generate technical recommendations to close IPL gaps in LOPA study {request.LopaStudyId}.

- Required SIL: {request.RequiredSil}
- Achieved SIL: {request.AchievedSil}
- IPL Gaps: {request.IplGaps}

For each recommendation:
1. Title and technical description
2. SIL contribution
3. Priority
4. Implementation timeline
5. Estimated cost if available

Return as JSON with keys: recommendations (array of {{title, description, priority, silContribution, timeline, estimatedCost}}), implementationRoadmap, vendorConsiderations (array)
";
    }

    private string BuildActionPrioritizationPrompt(PrioritizeActionsDto request)
    {
        return $@"
Prioritize the following actions considering constraints.

Budget: {request.Budget ?? "Unlimited"}
Time Constraint: {request.TimeConstraint ?? "None"}
Dependencies: {(request.Dependencies?.Count > 0 ? string.Join(", ", request.Dependencies) : "None")}

Actions:
{string.Join("\n", request.Actions.ConvertAll(a => $"- {a.Title} ({a.InitialPriority}) - {a.Description} - Est. {a.EstimatedDays} days"))}

Provide:
1. Sequenced action list with phase assignments
2. Overall implementation strategy
3. Quick wins
4. Long-term investments
5. Dependency analysis

Return as JSON with keys: prioritizedActions (array of {{sequenceNumber, title, phase, dependencies}}), implementationStrategy, quickWins (array), longTermInvestments (array)
";
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PROMPT BUILDERS - CROSS-MODULE
    // ═══════════════════════════════════════════════════════════════════════════

    private string BuildCrossModulePrompt(AnalyzeCrossModuleConsistencyDto request)
    {
        return $@"
Analyze consistency across multiple risk analysis modules.

HAZOP Study ID: {request.HazopStudyId?.ToString() ?? "N/A"}
LOPA Study ID: {request.LopaStudyId?.ToString() ?? "N/A"}
BowTie Study ID: {request.BowTieStudyId?.ToString() ?? "N/A"}
Analysis Scope: {request.AnalysisScope ?? "Full"}

Identify:
1. Consistency issues between modules
2. Data gaps
3. Conflicting findings
4. Recommendation gaps
5. Overall assessment

Return as JSON with keys: consistencyIssues (array), dataGaps (array), conflictingFindings (array), recommendationGaps (array), overallAssessment
";
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // RESPONSE PARSERS - PLACEHOLDER IMPLEMENTATIONS
    // ═══════════════════════════════════════════════════════════════════════════

    private SuggestBowTieTopEventResponseDto ParseBowTieTopEventResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new SuggestBowTieTopEventResponseDto
            {
                TopEventDescription = GetStringValue(root, "topEventDescription"),
                EventFrequencyEstimate = GetStringValue(root, "eventFrequencyEstimate"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new SuggestBowTieTopEventResponseDto
            {
                TopEventDescription = "Error parsing response",
                EventFrequencyEstimate = "Unknown",
                ConfidenceScore = 0
            };
        }
    }

    private SuggestBowTieThreatsResponseDto ParseBowTieThreatsResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new SuggestBowTieThreatsResponseDto
            {
                Threats = ParseStringArray(root, "threats"),
                ThreatCategories = ParseStringArray(root, "threatCategories"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new SuggestBowTieThreatsResponseDto
            {
                Threats = new List<string>(),
                ThreatCategories = new List<string>(),
                ConfidenceScore = 0
            };
        }
    }

    private SuggestBowTieConsequencesResponseDto ParseBowTieConsequencesResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new SuggestBowTieConsequencesResponseDto
            {
                Consequences = ParseStringArray(root, "consequences"),
                SeverityLevels = ParseStringArray(root, "severityLevels"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new SuggestBowTieConsequencesResponseDto
            {
                Consequences = new List<string>(),
                SeverityLevels = new List<string>(),
                ConfidenceScore = 0
            };
        }
    }

    private SuggestBowTieBarriersResponseDto ParseBowTieBarriersResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new SuggestBowTieBarriersResponseDto
            {
                PreventiveBarriers = ParseStringArray(root, "preventiveBarriers"),
                MitigativeBarriers = ParseStringArray(root, "mitigativeBarriers"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new SuggestBowTieBarriersResponseDto
            {
                PreventiveBarriers = new List<string>(),
                MitigativeBarriers = new List<string>(),
                ConfidenceScore = 0
            };
        }
    }

    private AssessBowTieIntegrityResponseDto ParseBowTieIntegrityResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new AssessBowTieIntegrityResponseDto
            {
                IntegrityScore = GetIntValue(root, "integrityScore"),
                BarrierStatus = ParseStringArray(root, "barrierStatus"),
                Recommendations = ParseStringArray(root, "recommendations"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new AssessBowTieIntegrityResponseDto
            {
                IntegrityScore = 0,
                BarrierStatus = new List<string>(),
                Recommendations = new List<string>(),
                ConfidenceScore = 0
            };
        }
    }

    private AssessIntegratedRiskResponseDto ParseIntegratedRiskResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new AssessIntegratedRiskResponseDto
            {
                OverallRiskLevel = GetStringValue(root, "overallRiskLevel"),
                RiskFactors = ParseStringArray(root, "riskFactors"),
                Recommendations = ParseStringArray(root, "recommendations"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new AssessIntegratedRiskResponseDto
            {
                OverallRiskLevel = "Unknown",
                RiskFactors = new List<string>(),
                Recommendations = new List<string>(),
                ConfidenceScore = 0
            };
        }
    }

    private RecommendRiskControlsResponseDto ParseRiskControlsResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new RecommendRiskControlsResponseDto
            {
                Controls = ParseStringArray(root, "controls"),
                ImplementationPriority = ParseStringArray(root, "implementationPriority"),
                ExpectedRiskReduction = GetIntValue(root, "expectedRiskReduction"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new RecommendRiskControlsResponseDto
            {
                Controls = new List<string>(),
                ImplementationPriority = new List<string>(),
                ExpectedRiskReduction = 0,
                ConfidenceScore = 0
            };
        }
    }

    private AnalyzeRiskTrendsResponseDto ParseRiskTrendsResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new AnalyzeRiskTrendsResponseDto
            {
                TrendAnalysis = GetStringValue(root, "trendAnalysis"),
                RiskDirection = GetStringValue(root, "riskDirection"),
                KeyIndicators = ParseStringArray(root, "keyIndicators"),
                Recommendations = ParseStringArray(root, "recommendations"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new AnalyzeRiskTrendsResponseDto
            {
                TrendAnalysis = "Error parsing response",
                RiskDirection = "Unknown",
                KeyIndicators = new List<string>(),
                Recommendations = new List<string>(),
                ConfidenceScore = 0
            };
        }
    }

    private AnalyzeDocumentResponseDto ParseDocumentAnalysisResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new AnalyzeDocumentResponseDto
            {
                Summary = GetStringValue(root, "summary"),
                KeyPoints = ParseStringArray(root, "keyPoints"),
                ComplianceStatus = GetStringValue(root, "complianceStatus"),
                RecommendedActions = ParseStringArray(root, "recommendedActions"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new AnalyzeDocumentResponseDto
            {
                Summary = "Error parsing response",
                KeyPoints = new List<string>(),
                ComplianceStatus = "Unknown",
                RecommendedActions = new List<string>(),
                ConfidenceScore = 0
            };
        }
    }

    private GenerateDocumentRecommendationsResponseDto ParseDocumentRecommendationsResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new GenerateDocumentRecommendationsResponseDto
            {
                Recommendations = ParseStringArray(root, "recommendations"),
                PriorityLevel = GetStringValue(root, "priorityLevel"),
                ImplementationSteps = ParseStringArray(root, "implementationSteps"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new GenerateDocumentRecommendationsResponseDto
            {
                Recommendations = new List<string>(),
                PriorityLevel = "Medium",
                ImplementationSteps = new List<string>(),
                ConfidenceScore = 0
            };
        }
    }

    private ExtractDocumentDataResponseDto ParseDocumentExtractionResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new ExtractDocumentDataResponseDto
            {
                ExtractedData = GetStringValue(root, "extractedData"),
                DataFields = ParseStringArray(root, "dataFields"),
                ExtractionConfidence = GetIntValue(root, "extractionConfidence"),
                RequiresVerification = GetBoolValue(root, "requiresVerification"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new ExtractDocumentDataResponseDto
            {
                ExtractedData = "Error parsing response",
                DataFields = new List<string>(),
                ExtractionConfidence = 0,
                RequiresVerification = true,
                ConfidenceScore = 0
            };
        }
    }

    private GenerateHazopRecommendationsResponseDto ParseHazopRecommendationsResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new GenerateHazopRecommendationsResponseDto
            {
                Recommendations = ParseStringArray(root, "recommendations"),
                ActionItems = ParseStringArray(root, "actionItems"),
                Timeline = GetStringValue(root, "timeline"),
                ResourceRequirements = GetStringValue(root, "resourceRequirements"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new GenerateHazopRecommendationsResponseDto
            {
                Recommendations = new List<string>(),
                ActionItems = new List<string>(),
                Timeline = "To be determined",
                ResourceRequirements = "TBD",
                ConfidenceScore = 0
            };
        }
    }

    private GenerateLopaRecommendationsResponseDto ParseLopaRecommendationsResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new GenerateLopaRecommendationsResponseDto
            {
                Recommendations = ParseStringArray(root, "recommendations"),
                IplEnhancements = ParseStringArray(root, "iplEnhancements"),
                SilImprovements = GetStringValue(root, "silImprovements"),
                ExpectedCostBenefit = GetStringValue(root, "expectedCostBenefit"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new GenerateLopaRecommendationsResponseDto
            {
                Recommendations = new List<string>(),
                IplEnhancements = new List<string>(),
                SilImprovements = "To be evaluated",
                ExpectedCostBenefit = "TBD",
                ConfidenceScore = 0
            };
        }
    }

    private PrioritizeActionsResponseDto ParseActionPrioritizationResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new PrioritizeActionsResponseDto
            {
                PrioritizedActions = ParseStringArray(root, "prioritizedActions"),
                RiskMitigation = GetStringValue(root, "riskMitigation"),
                ImplementationSequence = ParseStringArray(root, "implementationSequence"),
                EstimatedTimeframes = ParseStringArray(root, "estimatedTimeframes"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new PrioritizeActionsResponseDto
            {
                PrioritizedActions = new List<string>(),
                RiskMitigation = "To be evaluated",
                ImplementationSequence = new List<string>(),
                EstimatedTimeframes = new List<string>(),
                ConfidenceScore = 0
            };
        }
    }

    private AnalyzeCrossModuleConsistencyResponseDto ParseCrossModuleResponse(string response)
    {
        try
        {
            var doc = JsonDocument.Parse(response);
            var root = doc.RootElement;

            return new AnalyzeCrossModuleConsistencyResponseDto
            {
                ConsistencyScore = GetIntValue(root, "consistencyScore"),
                InconsistencyAreas = ParseStringArray(root, "inconsistencyAreas"),
                RecommendedAdjustments = ParseStringArray(root, "recommendedAdjustments"),
                RiskImplications = GetStringValue(root, "riskImplications"),
                ConfidenceScore = GetIntValue(root, "confidenceScore")
            };
        }
        catch
        {
            return new AnalyzeCrossModuleConsistencyResponseDto
            {
                ConsistencyScore = 0,
                InconsistencyAreas = new List<string>(),
                RecommendedAdjustments = new List<string>(),
                RiskImplications = "Evaluation required",
                ConfidenceScore = 0
            };
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // BULK ANALYSIS HELPERS
    // ═══════════════════════════════════════════════════════════════════════════

    private async Task<object> HandleBulkHazopAnalysisAsync(int moduleId, string analysisType)
    {
        // Bulk HAZOP analysis placeholder - implementation depends on specific analysis type
        // Future: Fetch HAZOP data from repository and perform analysis based on analysisType
        try
        {
            var result = await Task.FromResult(new { 
                success = true, 
                analysisType,
                message = "Bulk HAZOP analysis initiated",
                timestamp = DateTime.UtcNow 
            });
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in bulk HAZOP analysis");
            return new { success = false, error = "Analysis failed: " + ex.Message };
        }
    }

    private async Task<object> HandleBulkLopaAnalysisAsync(int moduleId, string analysisType)
    {
        // Bulk LOPA analysis placeholder - implementation depends on specific analysis type
        // Future: Fetch LOPA data from repository and perform analysis based on analysisType
        try
        {
            var result = await Task.FromResult(new { 
                success = true, 
                analysisType,
                message = "Bulk LOPA analysis initiated",
                timestamp = DateTime.UtcNow 
            });
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in bulk LOPA analysis");
            return new { success = false, error = "Analysis failed: " + ex.Message };
        }
    }

    private async Task<object> HandleBulkBowTieAnalysisAsync(int moduleId, string analysisType)
    {
        // Bulk BowTie analysis placeholder - implementation depends on specific analysis type
        // Future: Fetch BowTie data from repository and perform analysis based on analysisType
        try
        {
            var result = await Task.FromResult(new { 
                success = true, 
                analysisType,
                message = "Bulk BowTie analysis initiated",
                timestamp = DateTime.UtcNow 
            });
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in bulk BowTie analysis");
            return new { success = false, error = "Analysis failed: " + ex.Message };
        }
    }
}
