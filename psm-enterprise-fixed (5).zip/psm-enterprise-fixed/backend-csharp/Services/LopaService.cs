using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Repositories;
using System.Text.Json;

namespace PSM.Api.Services;

public interface ILopaService
{
    // Studies
    Task<IEnumerable<LopaStudyWithCountsDto>> ListStudiesAsync(string? hazopStudyId);
    Task<LopaStudyDto?> GetStudyAsync(string id);
    Task<LopaStudyDto> CreateStudyAsync(CreateLopaStudyRequest req, string? userId);
    Task<(bool found, LopaStudyDto? study)> UpdateStudyAsync(string id, UpdateLopaStudyRequest req);
    Task<bool> DeleteStudyAsync(string id);

    // Scenarios
    Task<IEnumerable<LopaScenarioDto>> ListScenariosAsync(string studyId);
    Task<LopaScenarioDto?> GetScenarioAsync(string id);
    Task<(bool found, LopaScenarioDto? scenario)> CreateScenarioAsync(string studyId, CreateLopaScenarioRequest req);
    Task<(bool found, LopaScenarioDto? scenario)> UpdateScenarioAsync(string id, UpdateLopaScenarioRequest req);
    Task<bool> DeleteScenarioAsync(string id);

    // IPLs
    Task<IEnumerable<LopaIplDto>> ListIplsAsync(string scenarioId);
    Task<(bool found, LopaIplDto? ipl)> CreateIplAsync(string scenarioId, CreateLopaIplRequest req);
    Task<(bool found, LopaIplDto? ipl)> UpdateIplAsync(string id, UpdateLopaIplRequest req);
    Task<bool> DeleteIplAsync(string id);

    // Dashboard / integration
    Task<LopaDashboardSummaryDto> GetDashboardSummaryAsync();
    Task<IEnumerable<HazopStudyDto>> GetHazopStudiesBriefAsync();
    Task<IEnumerable<HazopDeviationDto>> GetHazopDeviationsAsync(string hazopStudyId);

    Task<bool> CheckPermAsync(string role, PsmAction action);
}

public class LopaService : ILopaService
{
    private readonly ILopaRepository _repo;
    private readonly IPermissionService _perms;
    private readonly IIntegratedRiskService? _intRisk;
    private const string Module = "LOPA";

    // Secondary constructor (backward compat — used when DI doesn't yet have IIntegratedRiskService)
    public LopaService(ILopaRepository repo, IPermissionService perms)
        : this(repo, perms, null) { }

    public LopaService(ILopaRepository repo, IPermissionService perms, IIntegratedRiskService? intRisk)
    {
        _repo    = repo;
        _perms   = perms;
        _intRisk = intRisk;
    }

    public Task<bool> CheckPermAsync(string role, PsmAction action) =>
        _perms.CheckPermissionAsync(role, Module, action);

    // ─── Studies ────────────────────────────────────────────────────────────

    public Task<IEnumerable<LopaStudyWithCountsDto>> ListStudiesAsync(string? hazopStudyId) =>
        _repo.ListStudiesAsync(hazopStudyId);

    public Task<LopaStudyDto?> GetStudyAsync(string id) =>
        _repo.GetStudyAsync(id);

    public async Task<LopaStudyDto> CreateStudyAsync(CreateLopaStudyRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateStudyAsync(
            id,
            req.title ?? "Untitled",
            req.hazop_study_id,
            req.facility,
            req.unit,
            req.lead_engineer,
            req.status ?? "Draft",
            userId,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (await _repo.GetStudyAsync(id))!;
    }

    public async Task<(bool found, LopaStudyDto? study)> UpdateStudyAsync(string id, UpdateLopaStudyRequest req)
    {
        if (!await _repo.StudyExistsAsync(id)) return (false, null);
        await _repo.UpdateStudyAsync(
            id,
            req.title ?? "Untitled",
            req.hazop_study_id,
            req.facility,
            req.unit,
            req.lead_engineer,
            req.status ?? "Draft",
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));
        return (true, await _repo.GetStudyAsync(id));
    }

    public async Task<bool> DeleteStudyAsync(string id)
    {
        if (!await _repo.StudyExistsAsync(id)) return false;
        await _repo.SoftDeleteStudyAsync(id);
        return true;
    }

    // ─── Scenarios ──────────────────────────────────────────────────────────

    public Task<IEnumerable<LopaScenarioDto>> ListScenariosAsync(string studyId) =>
        _repo.ListScenariosAsync(studyId);

    public Task<LopaScenarioDto?> GetScenarioAsync(string id) =>
        _repo.GetScenarioAsync(id);

    public async Task<(bool found, LopaScenarioDto? scenario)> CreateScenarioAsync(
        string studyId, CreateLopaScenarioRequest req)
    {
        if (!await _repo.StudyExistsAsync(studyId)) return (false, null);

        var id = Guid.NewGuid().ToString();
        var freq = ToDouble(req.initiating_frequency, 1e-3);
        var severity = ToInt(req.consequence_severity, 3);
        var targetRisk = ToDouble(req.target_risk, 1e-5);

        await _repo.CreateScenarioAsync(
            id, studyId,
            req.scenario_number == null ? null : (string?)null,   // hazop_deviation_id not in request
            req.scenario_number ?? $"S-{id[..6].ToUpper()}",
            req.initiating_event ?? "Unspecified",
            freq, req.consequence_description,
            severity, targetRisk,
            req.notes,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));

        var scenario = await _repo.GetScenarioAsync(id);
        if (scenario is not null)
            await RecalcScenarioAsync(scenario);

        return (true, await _repo.GetScenarioAsync(id));
    }

    public async Task<(bool found, LopaScenarioDto? scenario)> UpdateScenarioAsync(
        string id, UpdateLopaScenarioRequest req)
    {
        if (!await _repo.ScenarioExistsAsync(id)) return (false, null);

        var freq = ToDouble(req.initiating_frequency, 1e-3);
        var severity = ToInt(req.consequence_severity, 3);
        var targetRisk = ToDouble(req.target_risk, 1e-5);

        await _repo.UpdateScenarioAsync(
            id,
            req.scenario_number ?? "Unspecified",
            req.initiating_event ?? "Unspecified",
            freq, req.consequence_description,
            severity, targetRisk,
            req.notes,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()));

        var scenario = await _repo.GetScenarioRawAsync(id);
        if (scenario is not null)
            await RecalcScenarioAsync(scenario);

        return (true, await _repo.GetScenarioAsync(id));
    }

    public async Task<bool> DeleteScenarioAsync(string id)
    {
        if (!await _repo.ScenarioExistsAsync(id)) return false;
        await _repo.SoftDeleteScenarioAsync(id);
        return true;
    }

    // ─── IPLs ───────────────────────────────────────────────────────────────

    public Task<IEnumerable<LopaIplDto>> ListIplsAsync(string scenarioId) =>
        _repo.ListIplsAsync(scenarioId);

    public async Task<(bool found, LopaIplDto? ipl)> CreateIplAsync(
        string scenarioId, CreateLopaIplRequest req)
    {
        if (!await _repo.ScenarioExistsAsync(scenarioId)) return (false, null);

        var id = Guid.NewGuid().ToString();
        var pfd = ToDouble(req.pfd, 0.1);

        await _repo.CreateIplAsync(
            id, scenarioId,
            req.ipl_name ?? "Unnamed IPL",
            req.ipl_type ?? "Engineering",
            req.description,
            pfd,
            req.is_validated ?? false,
            req.owner,
            req.audit_interval);

        // Recalculate parent scenario after adding IPL
        var scenario = await _repo.GetScenarioRawAsync(scenarioId);
        if (scenario is not null)
            await RecalcScenarioAsync(scenario);

        var ipl = await _repo.GetIplAsync(id);

        // ── AUTO-CREATE RISK BARRIER ──────────────────────────────────────────
        // Every new IPL automatically gets a corresponding Barrier record so that
        // the barrier can be referenced from BowTie diagrams and by Incidents.
        if (_intRisk is not null && ipl is not null)
        {
            try
            {
                await _intRisk.CreateBarrierFromIplAsync(
                    id, ipl,
                    scenarioId,
                    scenario?.hazop_deviation_id,
                    "system");
            }
            catch
            {
                // Auto-barrier creation is non-fatal; IPL is still saved
            }
        }

        return (true, ipl);
    }

    public async Task<(bool found, LopaIplDto? ipl)> UpdateIplAsync(
        string id, UpdateLopaIplRequest req)
    {
        var scenarioId = await _repo.GetIplScenarioIdAsync(id);
        if (scenarioId is null) return (false, null);

        var pfd = ToDouble(req.pfd, 0.1);

        await _repo.UpdateIplAsync(
            id,
            req.ipl_name ?? "Unnamed IPL",
            req.ipl_type ?? "Engineering",
            req.description,
            pfd,
            req.is_validated ?? false,
            req.owner,
            req.audit_interval);

        // Recalculate parent scenario
        var scenario = await _repo.GetScenarioRawAsync(scenarioId);
        if (scenario is not null)
            await RecalcScenarioAsync(scenario);

        return (true, await _repo.GetIplAsync(id));
    }

    public async Task<bool> DeleteIplAsync(string id)
    {
        var scenarioId = await _repo.GetIplScenarioIdAsync(id);
        if (scenarioId is null) return false;

        await _repo.SoftDeleteIplAsync(id);

        // Recalculate parent scenario after removing IPL
        var scenario = await _repo.GetScenarioRawAsync(scenarioId);
        if (scenario is not null)
            await RecalcScenarioAsync(scenario);

        return true;
    }

    // ─── Dashboard / Integration ─────────────────────────────────────────────

    public Task<LopaDashboardSummaryDto> GetDashboardSummaryAsync() =>
        _repo.GetDashboardSummaryAsync();

    public Task<IEnumerable<HazopStudyDto>> GetHazopStudiesBriefAsync() =>
        _repo.GetHazopStudiesBriefAsync();

    public Task<IEnumerable<HazopDeviationDto>> GetHazopDeviationsAsync(string hazopStudyId) =>
        _repo.GetHazopDeviationsAsync(hazopStudyId);

    // ─── SIL calculation (مطابق منطق Node.js) ───────────────────────────────

    /// <summary>
    /// محاسبه مجدد mitigated_frequency، RRF، SIL و gap برای یک سناریو.
    /// دقیقاً منطق Node.js را پیاده می‌کند:
    ///   pfd_non_sis  = product of all non-SIS IPL PFDs
    ///   mitigated    = initiating_frequency × pfd_non_sis
    ///   required_rrf = mitigated / target_risk  (اگر &gt; 1)
    ///   SIL required = band(required_rrf)
    /// </summary>
    private async Task RecalcScenarioAsync(LopaScenarioDto scenario)
    {
        var ipls = (await _repo.ListIplsForCalcAsync(scenario.Id!)).ToList();

        var pfdNonSis = ipls
            .Where(i => !string.Equals(i.IplType, "SIS", StringComparison.OrdinalIgnoreCase))
            .Aggregate(1.0, (acc, i) => acc * i.Pfd);

        var pfdSis = ipls
            .Where(i => string.Equals(i.IplType, "SIS", StringComparison.OrdinalIgnoreCase))
            .Aggregate(1.0, (acc, i) => acc * i.Pfd);

        var mitigated = scenario.InitiatingFrequency * pfdNonSis;
        var riskGap = mitigated - scenario.TargetRisk;
        var riskGapMet = mitigated <= scenario.TargetRisk;

        var requiredRrfSis = riskGapMet ? 1.0
            : (scenario.TargetRisk > 0 ? mitigated / scenario.TargetRisk : double.MaxValue);

        var silRequired = BandSil(requiredRrfSis);

        var achievedRrfSis = pfdSis > 0 ? 1.0 / pfdSis : 0;
        var silAchieved = BandSil(achievedRrfSis);
        var silGapMet = achievedRrfSis >= requiredRrfSis;

        await _repo.UpdateScenarioCalcAsync(
            scenario.Id!,
            mitigated, riskGap, riskGapMet,
            requiredRrfSis, silRequired,
            achievedRrfSis, silAchieved,
            silGapMet, pfdNonSis, pfdSis);
    }

    private static string BandSil(double rrf) => rrf switch
    {
        >= 10000 => "SIL4",
        >= 1000  => "SIL3",
        >= 100   => "SIL2",
        >= 10    => "SIL1",
        _        => "None"
    };

    // ─── Type-coercion helpers ────────────────────────────────────────────────

    private static double ToDouble(object? value, double fallback)
    {
        if (value is null) return fallback;
        if (value is double d) return d;
        if (value is JsonElement je)
        {
            if (je.ValueKind == JsonValueKind.Number && je.TryGetDouble(out var n)) return n;
            if (je.ValueKind == JsonValueKind.String && double.TryParse(je.GetString(), out var s)) return s;
        }
        return double.TryParse(value.ToString(), out var p) ? p : fallback;
    }

    private static int ToInt(object? value, int fallback)
    {
        if (value is null) return fallback;
        if (value is int i) return i;
        if (value is JsonElement je)
        {
            if (je.ValueKind == JsonValueKind.Number && je.TryGetInt32(out var n)) return n;
            if (je.ValueKind == JsonValueKind.String && int.TryParse(je.GetString(), out var s)) return s;
        }
        return int.TryParse(value.ToString(), out var p) ? p : fallback;
    }
}
