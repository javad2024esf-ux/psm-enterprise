using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Repositories;
using System.Text.Json;

namespace PSM.Api.Services;

// ════════════════════════════════════════════════════════════════════════════════════
// INTEGRATED RISK MODEL SERVICE
// ════════════════════════════════════════════════════════════════════════════════════

public class IntegratedRiskModelService : IIntegratedRiskModelService
{
    private readonly IHazopRepository _hazopRepo;
    private readonly ILopaRepository _lopaRepo;
    private readonly IBowTieRepository _bowTieRepo;
    private readonly IBarrierRepository _barrierRepo;
    private readonly ICrossAnalysisRepository _crossAnalysisRepo;
    private readonly IIncidentRepository _incidentRepo;
    private readonly IAuditService _auditService;
    private readonly IPermissionService _permissionService;
    private readonly ILogger<IntegratedRiskModelService> _logger;

    public IntegratedRiskModelService(
        IHazopRepository hazopRepo,
        ILopaRepository lopaRepo,
        IBowTieRepository bowTieRepo,
        IBarrierRepository barrierRepo,
        ICrossAnalysisRepository crossAnalysisRepo,
        IIncidentRepository incidentRepo,
        IAuditService auditService,
        IPermissionService permissionService,
        ILogger<IntegratedRiskModelService> logger)
    {
        _hazopRepo = hazopRepo;
        _lopaRepo = lopaRepo;
        _bowTieRepo = bowTieRepo;
        _barrierRepo = barrierRepo;
        _crossAnalysisRepo = crossAnalysisRepo;
        _incidentRepo = incidentRepo;
        _auditService = auditService;
        _permissionService = permissionService;
        _logger = logger;
    }

    // ════════════════════════════════════════════════════════════════════════════════════
    // HAZOP → LOPA CROSS-CREATION
    // ════════════════════════════════════════════════════════════════════════════════════

    public async Task<CreateLopaFromHazopResultDto> CreateLopaFromHazopAsync(
        CreateLopaFromHazopRequest request, string userId)
    {
        try
        {
            if (string.IsNullOrEmpty(request.hazop_study_id) || 
                string.IsNullOrEmpty(request.hazop_deviation_id))
                throw new ArgumentException("داده‌های HAZOP الزامی هستند", nameof(request));

            // Verify HAZOP exists
            var hazopStudy = await _hazopRepo.GetHazopStudyAsync(request.hazop_study_id);
            if (hazopStudy == null)
                throw new Exception("مطالعه HAZOP یافت نشد");

            var hazopDeviation = await _hazopRepo.GetHazopDeviationAsync(request.hazop_deviation_id);
            if (hazopDeviation == null)
                throw new Exception("انحراف HAZOP یافت نشد");

            // Create LOPA study (if not exists)
            string lopaStudyId;
            var existingLopa = await _lopaRepo.GetLopaStudyByHazopAsync(request.hazop_study_id);
            
            if (existingLopa == null)
            {
                var lopaTitle = request.lopa_title ?? $"LOPA from {hazopStudy.Title}";
                var createLopaReq = new CreateLopaStudyRequest
                {
                    title = lopaTitle,
                    hazop_study_id = request.hazop_study_id,
                    facility = hazopStudy.Facility,
                    unit = hazopStudy.Unit,
                    lead_engineer = hazopStudy.LeadEngineer,
                    status = "Active"
                };

                var newLopa = await _lopaRepo.CreateLopaStudyAsync(
                    Guid.NewGuid().ToString(),
                    createLopaReq.title,
                    request.hazop_study_id,
                    createLopaReq.facility,
                    createLopaReq.unit,
                    createLopaReq.lead_engineer,
                    createLopaReq.status,
                    userId,
                    null);

                lopaStudyId = newLopa.Id!;
            }
            else
            {
                lopaStudyId = existingLopa.Id!;
            }

            // Create LOPA scenario
            var scenarioNumber = request.scenario_number ?? 
                $"S-{DateTime.Now:yyyyMMddHHmmss}";

            var lopaScenario = await _lopaRepo.CreateLopaScenarioAsync(
                Guid.NewGuid().ToString(),
                lopaStudyId,
                request.hazop_deviation_id,
                scenarioNumber,
                request.initiating_event ?? hazopDeviation.Deviation,
                Convert.ToDouble(request.initiating_frequency ?? 1),
                request.consequence_description ?? hazopDeviation.Consequences,
                Convert.ToInt32(request.consequence_severity ?? 3),
                Convert.ToDouble(request.target_risk ?? 1e-4),
                userId,
                JsonSerializer.Serialize(request.data ?? new Dictionary<string, object>()));

            // Create cross-reference mapping
            await _crossAnalysisRepo.LinkHazopToLopaAsync(
                request.hazop_deviation_id,
                lopaScenario.Id!,
                request.hazop_study_id,
                lopaStudyId);

            // Audit log
            await _auditService.LogAuditAsync("LOPA", lopaScenario.Id!, "Create", userId, "HAZOP سناریو تبدیل شد");

            return new CreateLopaFromHazopResultDto
            {
                Study = await _lopaRepo.GetLopaStudyAsync(lopaStudyId),
                Scenario = lopaScenario,
                HazopDeviationId = request.hazop_deviation_id,
                Message = "LOPA با موفقیت از HAZOP ایجاد شد"
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating LOPA from HAZOP");
            throw;
        }
    }

    // ════════════════════════════════════════════════════════════════════════════════════
    // HAZOP → BowTie CROSS-CREATION
    // ════════════════════════════════════════════════════════════════════════════════════

    public async Task<CreateBowTieFromHazopResultDto> CreateBowTieFromHazopAsync(
        CreateBowTieFromHazopRequest request, string userId)
    {
        try
        {
            if (string.IsNullOrEmpty(request.hazop_study_id) || 
                string.IsNullOrEmpty(request.hazop_deviation_id))
                throw new ArgumentException("داده‌های HAZOP الزامی هستند", nameof(request));

            // Verify HAZOP exists
            var hazopDeviation = await _hazopRepo.GetHazopDeviationAsync(request.hazop_deviation_id);
            if (hazopDeviation == null)
                throw new Exception("انحراف HAZOP یافت نشد");

            // Create BowTie diagram
            var diagramTitle = request.bowtie_title ?? 
                $"BowTie - {hazopDeviation.Deviation}";

            var createDiagramDto = new CreateBowTieDiagramDto
            {
                Title = diagramTitle,
                TopEventId = request.top_event ?? hazopDeviation.Deviation,
                TopEventDescription = request.consequence ?? hazopDeviation.Consequences
            };

            var bowTieDiagramId = await _bowTieRepo.CreateBowTieDiagramAsync(createDiagramDto, userId);

            // Create barriers (if provided)
            var barrierIds = new List<string>();

            if (request.preventive_barriers?.Count > 0)
            {
                foreach (var barrier in request.preventive_barriers)
                {
                    try
                    {
                        var barrierId = await _bowTieRepo.CreateBowTieBarrierAsync(
                            new CreateBowTieBarrierDto
                            {
                                DiagramId = bowTieDiagramId,
                                Description = barrier.Value.ToString() ?? "Preventive Barrier",
                                Type = "Preventive"
                            },
                            userId);

                        barrierIds.Add(barrierId);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Failed to create preventive barrier");
                    }
                }
            }

            if (request.mitigative_barriers?.Count > 0)
            {
                foreach (var barrier in request.mitigative_barriers)
                {
                    try
                    {
                        var barrierId = await _bowTieRepo.CreateBowTieBarrierAsync(
                            new CreateBowTieBarrierDto
                            {
                                DiagramId = bowTieDiagramId,
                                Description = barrier.Value.ToString() ?? "Mitigative Barrier",
                                Type = "Mitigative"
                            },
                            userId);

                        barrierIds.Add(barrierId);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Failed to create mitigative barrier");
                    }
                }
            }

            // Create cross-reference
            await _crossAnalysisRepo.LinkHazopToBowTieAsync(
                request.hazop_deviation_id,
                bowTieDiagramId,
                request.hazop_study_id);

            // Audit log
            await _auditService.LogAuditAsync("BowTie", bowTieDiagramId, "Create", userId, 
                "BowTie از HAZOP ایجاد شد");

            return new CreateBowTieFromHazopResultDto
            {
                BowTieDiagramId = bowTieDiagramId,
                HazopDeviationId = request.hazop_deviation_id,
                Message = "BowTie با موفقیت از HAZOP ایجاد شد"
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating BowTie from HAZOP");
            throw;
        }
    }

    // ════════════════════════════════════════════════════════════════════════════════════
    // LOPA IPL → BARRIER AUTO-CREATION
    // ════════════════════════════════════════════════════════════════════════════════════

    public async Task<BarrierDto> CreateBarrierFromLopaIplAsync(
        string lopaIplId, string barrierName, string barrierType, string? description, string userId)
    {
        try
        {
            var ipl = await _lopaRepo.GetLopaIplAsync(lopaIplId);
            if (ipl == null)
                throw new Exception("LOPA IPL یافت نشد");

            // Check if barrier already exists for this IPL
            var existingBarrier = await _barrierRepo.GetBarrierByLopaIplAsync(lopaIplId);
            if (existingBarrier != null)
                return existingBarrier;

            // Create barrier
            var barrier = await _barrierRepo.CreateBarrierAsync(
                Guid.NewGuid().ToString(),
                lopaIplId,
                null, // No BowTie barrier yet
                barrierName,
                barrierType,
                description,
                null,
                null,
                null,
                null,
                null,
                0.9m,
                "Active",
                null,
                null,
                null,
                false,
                "{}"
            );

            // Audit log
            await _auditService.LogAuditAsync("Barrier", barrier.Id!, "Create", userId, 
                "از LOPA IPL ایجاد شد");

            return barrier;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating barrier from LOPA IPL");
            throw;
        }
    }

    // ════════════════════════════════════════════════════════════════════════════════════
    // BARRIER STATUS CASCADE UPDATES
    // ════════════════════════════════════════════════════════════════════════════════════

    public async Task<BarrierFailureImpactDto> HandleBarrierFailureAsync(
        string barrierId, string reason, string userId)
    {
        try
        {
            var barrier = await _barrierRepo.GetBarrierAsync(barrierId);
            if (barrier == null)
                throw new Exception("مانع یافت نشد");

            // Update barrier status
            var updateReq = new UpdateBarrierStatusRequest
            {
                new_status = "Failed",
                reason = reason
            };

            await _barrierRepo.UpdateBarrierStatusAsync(barrierId, updateReq, userId);

            // Get cascade impact
            var impactAnalysis = await _barrierRepo.GetBarrierImpactAnalysisAsync(barrierId);

            var affectedLopaIpls = new List<string>();
            var affectedBowTieBarriers = new List<string>();
            var affectedHazopDeviations = new List<string>();

            foreach (var item in impactAnalysis)
            {
                if (item.AnalysisType == "LOPA")
                    affectedLopaIpls.Add(item.AnalysisId!);
                else if (item.AnalysisType == "BowTie")
                    affectedBowTieBarriers.Add(item.AnalysisId!);
                else if (item.AnalysisType == "HAZOP")
                    affectedHazopDeviations.Add(item.AnalysisId!);
            }

            // Audit cascade
            await _auditService.LogAuditAsync("Barrier", barrierId, "FailureCascade", userId,
                $"مانع ناموفق: {affectedLopaIpls.Count} LOPA، {affectedBowTieBarriers.Count} BowTie، {affectedHazopDeviations.Count} HAZOP");

            return new BarrierFailureImpactDto
            {
                Barrier = barrier,
                AffectedLopaIpls = affectedLopaIpls,
                AffectedBowTieBarriers = affectedBowTieBarriers,
                AffectedHazopDeviations = affectedHazopDeviations,
                TotalAffectedAnalyses = affectedLopaIpls.Count + affectedBowTieBarriers.Count + affectedHazopDeviations.Count,
                Message = "وضعیت مانع با موفقیت به‌روزرسانی شد و کسکیدات اعمال شد"
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error handling barrier failure");
            throw;
        }
    }

    // ════════════════════════════════════════════════════════════════════════════════════
    // INCIDENT IMPACT ANALYSIS — Show affected HAZOP/LOPA/BowTie
    // ════════════════════════════════════════════════════════════════════════════════════

    public async Task<IncidentDetailedAnalysisDto> GetIncidentImpactAnalysisAsync(string incidentId)
    {
        try
        {
            var incident = await _incidentRepo.GetIncidentAsync(incidentId);
            if (incident == null)
                throw new Exception("حادثه یافت نشد");

            // Get linked barriers
            var barriers = await _incidentRepo.GetIncidentBarriersAsync(incidentId);
            var barrierList = barriers.ToList();

            // Get affected HAZOP scenarios
            var hazopMappings = await _crossAnalysisRepo.GetIncidentHazopMappingsAsync(incidentId);
            var hazopDeviations = new List<HazopDeviationDto>();
            foreach (var mapping in hazopMappings)
            {
                var deviation = await _hazopRepo.GetHazopDeviationAsync(mapping.HazopDeviationId!);
                if (deviation != null)
                    hazopDeviations.Add(MapToHazopDeviationDto(deviation));
            }

            // Get affected LOPA scenarios
            var lopaMappings = await _crossAnalysisRepo.GetIncidentLopaMappingsAsync(incidentId);
            var lopaScenarios = new List<LopaScenarioDto>();
            foreach (var mapping in lopaMappings)
            {
                var scenario = await _lopaRepo.GetLopaScenarioAsync(mapping.LopaScenarioId!);
                if (scenario != null)
                    lopaScenarios.Add(scenario);
            }

            // Get affected BowTie diagrams
            var bowTieMappings = await _crossAnalysisRepo.GetIncidentBowTieMappingsAsync(incidentId);
            var bowTieDiagrams = new List<BowTieDiagramDetailDto>();
            foreach (var mapping in bowTieMappings)
            {
                var diagram = await _bowTieRepo.GetBowTieDiagramAsync(mapping.BowTieDiagramId!);
                if (diagram != null)
                    bowTieDiagrams.Add(diagram);
            }

            var barrierDtos = new List<BarrierDto>();
            foreach (var barrier in barrierList)
            {
                var barrierDto = await _barrierRepo.GetBarrierAsync(barrier.BarrierId!);
                if (barrierDto != null)
                    barrierDtos.Add(barrierDto);
            }

            // Map DetailDto to base Dto for the response
            var bowTieDiagramsForResponse = bowTieDiagrams.Select(d => new BowTieDiagramDto
            {
                Id = d.Id,
                Title = d.Title,
                Description = d.Description,
                HazopStudyId = d.HazopStudyId,
                LopaStudyId = d.LopaStudyId,
                TopEventId = d.TopEventId,
                TopEventDescription = d.TopEventDescription,
                CreatedAt = d.CreatedAt,
                UpdatedAt = d.UpdatedAt,
                CreatedBy = d.CreatedBy
            }).ToList();

            return new IncidentDetailedAnalysisDto
            {
                Incident = incident,
                AffectedBarriers = barrierDtos,
                AffectedHazopDeviations = hazopDeviations,
                AffectedLopaScenarios = lopaScenarios,
                AffectedBowTieDiagrams = bowTieDiagramsForResponse,
                TotalBarriersFailed = barrierDtos.Count(b => b.Status == "Failed"),
                TotalAnalysisTypesAffected = (hazopDeviations.Count > 0 ? 1 : 0) + 
                                           (lopaScenarios.Count > 0 ? 1 : 0) + 
                                           (bowTieDiagrams.Count > 0 ? 1 : 0)
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting incident impact analysis");
            throw;
        }
    }

    // ════════════════════════════════════════════════════════════════════════════════════
    // GET BARRIER IMPACT ACROSS ALL ANALYSES
    // ════════════════════════════════════════════════════════════════════════════════════

    public async Task<BarrierFailureImpactDto> GetBarrierImpactAsync(string barrierId)
    {
        try
        {
            var barrier = await _barrierRepo.GetBarrierAsync(barrierId);
            if (barrier == null)
                throw new Exception("مانع یافت نشد");

            var impactAnalysis = await _barrierRepo.GetBarrierImpactAnalysisAsync(barrierId);
            var results = impactAnalysis?.ToList() ?? new List<BarrierImpactAnalysisDto>();

            var affectedLopaIpls = new List<string>();
            var affectedBowTieBarriers = new List<string>();
            var affectedHazopDeviations = new List<string>();

            foreach (var item in results)
            {
                if (item.AnalysisType == "LOPA")
                    affectedLopaIpls.Add(item.AnalysisId!);
                else if (item.AnalysisType == "BowTie")
                    affectedBowTieBarriers.Add(item.AnalysisId!);
                else if (item.AnalysisType == "HAZOP")
                    affectedHazopDeviations.Add(item.AnalysisId!);
            }

            return new BarrierFailureImpactDto
            {
                Barrier = barrier,
                AffectedLopaIpls = affectedLopaIpls,
                AffectedBowTieBarriers = affectedBowTieBarriers,
                AffectedHazopDeviations = affectedHazopDeviations,
                TotalAffectedAnalyses = results.Count()
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting barrier impact");
            throw;
        }
    }

    // ════════════════════════════════════════════════════════════════════════════════════
    // LINK INCIDENT TO BARRIERS/HAZOP/LOPA/BowTie
    // ════════════════════════════════════════════════════════════════════════════════════

    public async Task<IncidentBarrierMappingDto> LinkIncidentToBarrierAsync(
        string incidentId, string barrierId, string? failureType, string? evidence, decimal? contribution, string userId)
    {
        try
        {
            var incident = await _incidentRepo.GetIncidentAsync(incidentId);
            if (incident == null)
                throw new Exception("حادثه یافت نشد");

            var barrier = await _barrierRepo.GetBarrierAsync(barrierId);
            if (barrier == null)
                throw new Exception("مانع یافت نشد");

            var mapping = await _incidentRepo.LinkBarrierAsync(
                Guid.NewGuid().ToString(),
                incidentId,
                barrierId,
                failureType,
                evidence,
                contribution ?? 0.5m);

            // Audit
            await _auditService.LogAuditAsync("Incident", incidentId, "LinkBarrier", userId,
                $"مانع {barrier.BarrierName} مرتبط کننید");

            return MapToIncidentBarrierMappingDto(mapping);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error linking incident to barrier");
            throw;
        }
    }

    public async Task<IncidentHazopMappingDto> LinkIncidentToHazopAsync(
        string incidentId, string hazopDeviationId, string hazopStudyId, decimal? relevanceScore, string userId)
    {
        try
        {
            var mapping = await _crossAnalysisRepo.LinkIncidentToHazopAsync(
                Guid.NewGuid().ToString(),
                incidentId,
                hazopDeviationId,
                hazopStudyId,
                relevanceScore ?? 0.8m);

            await _auditService.LogAuditAsync("Incident", incidentId, "LinkHazop", userId,
                "انحراف HAZOP مرتبط کننید");

            return mapping;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error linking incident to HAZOP");
            throw;
        }
    }

    public async Task<IncidentLopaMappingDto> LinkIncidentToLopaAsync(
        string incidentId, string lopaScenarioId, string lopaStudyId, int? iplFailureCount, decimal? relevanceScore, string userId)
    {
        try
        {
            var mapping = await _crossAnalysisRepo.LinkIncidentToLopaAsync(
                Guid.NewGuid().ToString(),
                incidentId,
                lopaScenarioId,
                lopaStudyId,
                iplFailureCount ?? 0,
                relevanceScore ?? 0.8m);

            await _auditService.LogAuditAsync("Incident", incidentId, "LinkLopa", userId,
                "سناریو LOPA مرتبط کننید");

            return mapping;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error linking incident to LOPA");
            throw;
        }
    }

    public async Task<IncidentBowTieMappingDto> LinkIncidentToBowTieAsync(
        string incidentId, string bowTieDiagramId, bool? topEventOccurred, int? barriersFailed, decimal? relevanceScore, string userId)
    {
        try
        {
            var mapping = await _crossAnalysisRepo.LinkIncidentToBowTieAsync(
                Guid.NewGuid().ToString(),
                incidentId,
                bowTieDiagramId,
                topEventOccurred ?? true,
                barriersFailed ?? 0,
                relevanceScore ?? 0.8m);

            await _auditService.LogAuditAsync("Incident", incidentId, "LinkBowTie", userId,
                "نمودار BowTie مرتبط کننید");

            return mapping;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error linking incident to BowTie");
            throw;
        }
    }

    // ════════════════════════════════════════════════════════════════════════════════════
    // BATCH OPERATIONS
    // ════════════════════════════════════════════════════════════════════════════════════

    public async Task<BatchOperationResultDto> BatchLinkBarriersToIncidentAsync(
        string incidentId, List<LinkIncidentToBarrierRequest> barriers, string userId)
    {
        var successIds = new List<string>();
        var errors = new List<string>();
        int successCount = 0, failureCount = 0;

        foreach (var barrier in barriers)
        {
            try
            {
                if (string.IsNullOrEmpty(barrier.barrier_id))
                {
                    errors.Add("شناسه مانع الزامی است");
                    failureCount++;
                    continue;
                }

                var mapping = await LinkIncidentToBarrierAsync(
                    incidentId,
                    barrier.barrier_id,
                    barrier.barrier_failure_type,
                    barrier.failure_evidence,
                    barrier.contribution_to_incident,
                    userId);

                successIds.Add(mapping.BarrierId!);
                successCount++;
            }
            catch (Exception ex)
            {
                errors.Add($"مانع {barrier.barrier_id}: {ex.Message}");
                failureCount++;
            }
        }

        return new BatchOperationResultDto
        {
            SuccessCount = successCount,
            FailureCount = failureCount,
            SuccessIds = successIds,
            ErrorMessages = errors,
            Message = $"{successCount} موفق، {failureCount} ناموفق"
        };
    }

    // ════════════════════════════════════════════════════════════════════════════════════
    // DASHBOARD & ANALYTICS
    // ════════════════════════════════════════════════════════════════════════════════════

    public async Task<IntegratedRiskDashboardDto> GetDashboardSummaryAsync()
    {
        try
        {
            var hazopCount = await _hazopRepo.GetHazopStudyCountAsync();
            var lopaCount = await _lopaRepo.GetLopaStudyCountAsync();
            var bowTieCount = await _bowTieRepo.GetBowTieDiagramCountAsync();
            var barrierCount = await _barrierRepo.GetBarrierCountAsync();
            var incidentCount = await _incidentRepo.GetIncidentCountAsync();

            var barrierStatus = await _barrierRepo.GetBarrierStatusDistributionAsync();
            var barrierTypes = await _barrierRepo.GetBarrierTypeDistributionAsync();
            var incidentTypes = await _incidentRepo.GetIncidentTypeDistributionAsync();

            var criticalBarriers = await _barrierRepo.GetCriticalBarrierCountAsync();
            var openIncidents = await _incidentRepo.GetOpenIncidentsCountAsync();
            var failedBarriers = barrierStatus.GetValueOrDefault("Failed", 0);
            var degradedBarriers = barrierStatus.GetValueOrDefault("Degraded", 0);
            var activeBarriers = barrierStatus.GetValueOrDefault("Active", 0);

            return new IntegratedRiskDashboardDto
            {
                TotalHazopStudies = hazopCount,
                TotalLopaStudies = lopaCount,
                TotalBowTieDiagrams = bowTieCount,
                TotalBarriers = barrierCount,
                TotalIncidents = incidentCount,
                CriticalBarriers = criticalBarriers,
                FailedBarriers = failedBarriers,
                DegradedBarriers = degradedBarriers,
                ActiveBarriers = activeBarriers,
                OpenIncidents = openIncidents,
                HighSeverityIncidents = await _incidentRepo.GetHighSeverityIncidentsCountAsync(),
                IncidentsWithBarrierFailures = await _incidentRepo.GetIncidentsWithBarrierFailuresCountAsync(),
                BarrierTypeDistribution = barrierTypes,
                IncidentTypeDistribution = incidentTypes,
                BarrierStatusDistribution = barrierStatus,
                LastUpdated = DateTime.UtcNow
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting dashboard summary");
            throw;
        }
    }

    // ════════════════════════════════════════════════════════════════════════════════════
    // HELPER MAPPERS
    // ════════════════════════════════════════════════════════════════════════════════════

    private HazopDeviationDto MapToHazopDeviationDto(dynamic deviation)
    {
        return new HazopDeviationDto
        {
            Id = deviation.Id,
            StudyId = deviation.StudyId,
            NodeId = deviation.NodeId,
            GuideWord = deviation.GuideWord,
            Parameter = deviation.Parameter,
            Deviation = deviation.Deviation,
            Causes = deviation.Causes,
            Consequences = deviation.Consequences,
            ExistingSafeguards = deviation.ExistingSafeguards,
            Recommendations = deviation.Recommendations,
            Severity = deviation.Severity ?? 0,
            Likelihood = deviation.Likelihood ?? 0,
            RiskScore = (deviation.Severity ?? 0) * (deviation.Likelihood ?? 0),
            RiskLevel = deviation.RiskLevel,
            Status = deviation.Status,
            IncidentReference = deviation.IncidentReference,
            LinkedIncidents = deviation.LinkedIncidents ?? 0,
            CreatedAt = deviation.CreatedAt,
            UpdatedAt = deviation.UpdatedAt
        };
    }

    private IncidentBarrierMappingDto MapToIncidentBarrierMappingDto(dynamic mapping)
    {
        return new IncidentBarrierMappingDto
        {
            Id = mapping.Id,
            IncidentId = mapping.IncidentId,
            BarrierId = mapping.BarrierId,
            BarrierFailureType = mapping.BarrierFailureType,
            FailureEvidence = mapping.FailureEvidence,
            ContributionToIncident = mapping.ContributionToIncident,
            CreatedAt = mapping.CreatedAt
        };
    }
}

// ════════════════════════════════════════════════════════════════════════════════════
// SERVICE INTERFACE
// ════════════════════════════════════════════════════════════════════════════════════

public interface IIntegratedRiskModelService
{
    // HAZOP → LOPA/BowTie
    Task<CreateLopaFromHazopResultDto> CreateLopaFromHazopAsync(
        CreateLopaFromHazopRequest request, string userId);
    Task<CreateBowTieFromHazopResultDto> CreateBowTieFromHazopAsync(
        CreateBowTieFromHazopRequest request, string userId);

    // LOPA IPL → Barrier
    Task<BarrierDto> CreateBarrierFromLopaIplAsync(
        string lopaIplId, string barrierName, string barrierType, string? description, string userId);

    // Barrier cascade
    Task<BarrierFailureImpactDto> HandleBarrierFailureAsync(
        string barrierId, string reason, string userId);

    // Incident impact
    Task<IncidentDetailedAnalysisDto> GetIncidentImpactAnalysisAsync(string incidentId);
    Task<BarrierFailureImpactDto> GetBarrierImpactAsync(string barrierId);

    // Linking
    Task<IncidentBarrierMappingDto> LinkIncidentToBarrierAsync(
        string incidentId, string barrierId, string? failureType, string? evidence, decimal? contribution, string userId);
    Task<IncidentHazopMappingDto> LinkIncidentToHazopAsync(
        string incidentId, string hazopDeviationId, string hazopStudyId, decimal? relevanceScore, string userId);
    Task<IncidentLopaMappingDto> LinkIncidentToLopaAsync(
        string incidentId, string lopaScenarioId, string lopaStudyId, int? iplFailureCount, decimal? relevanceScore, string userId);
    Task<IncidentBowTieMappingDto> LinkIncidentToBowTieAsync(
        string incidentId, string bowTieDiagramId, bool? topEventOccurred, int? barriersFailed, decimal? relevanceScore, string userId);

    // Batch
    Task<BatchOperationResultDto> BatchLinkBarriersToIncidentAsync(
        string incidentId, List<LinkIncidentToBarrierRequest> barriers, string userId);

    // Dashboard
    Task<IntegratedRiskDashboardDto> GetDashboardSummaryAsync();
}
