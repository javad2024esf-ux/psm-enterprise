using System.Text.Json;
using System.Text.Json.Serialization;
using PSM.Api.Models;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

/// <summary>
/// Builder سیال برای ساختن AuditEntry — هر callsite فقط فیلدهای مرتبط را ست می‌کند.
/// </summary>
public sealed class AuditBuilder
{
    private readonly AuditEntry _entry = new()
    {
        EventId   = $"aud_{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}_{Guid.NewGuid():N}"[..32],
        Outcome   = "SUCCESS",
        Severity  = AuditSeverity.Info,
        CreatedAt = DateTime.UtcNow,
    };

    public AuditBuilder Action(string action)            { _entry.Action       = action;      return this; }
    public AuditBuilder Severity(string severity)        { _entry.Severity     = severity;    return this; }
    public AuditBuilder User(string? id, string? name = null, string? fullName = null, string? role = null)
    {
        _entry.UserId       = id;
        _entry.Username     = name;
        _entry.UserFullName = fullName;
        _entry.UserRole     = role;
        return this;
    }
    public AuditBuilder Ip(string? ip)                   { _entry.IpAddress    = ip;          return this; }
    public AuditBuilder Agent(string? ua)                { _entry.UserAgent    = ua;          return this; }
    public AuditBuilder Module(string? module)           { _entry.Module       = module;      return this; }
    public AuditBuilder Record(string? id, string? title = null)
    {
        _entry.RecordId    = id;
        _entry.RecordTitle = title;
        return this;
    }
    public AuditBuilder Outcome(string outcome, string? reason = null)
    {
        _entry.Outcome       = outcome;
        _entry.FailureReason = reason;
        return this;
    }

    /// <summary>
    /// ثبت مقادیر قبل و بعد و محاسبه خودکار diff فیلدها.
    /// هر دو پارامتر باید از نوع مشابه یا دارای کلیدهای string باشند.
    /// </summary>
    public AuditBuilder Diff<T>(T? oldValue, T? newValue) where T : class
    {
        _entry.OldValues = oldValue is null ? null
            : JsonDocument.Parse(JsonSerializer.Serialize(oldValue, _jsonOpts));
        _entry.NewValues = newValue is null ? null
            : JsonDocument.Parse(JsonSerializer.Serialize(newValue, _jsonOpts));

        if (oldValue is not null && newValue is not null)
            _entry.ChangedFields = ComputeDiff(oldValue, newValue);

        return this;
    }

    public AuditBuilder Meta(object? meta)
    {
        if (meta is not null)
            _entry.Metadata = JsonDocument.Parse(JsonSerializer.Serialize(meta, _jsonOpts));
        return this;
    }

    public AuditEntry Build() => _entry;

    // ── Diff engine ──────────────────────────────────────────────────────────
    private static readonly JsonSerializerOptions _jsonOpts = new()
    {
        PropertyNamingPolicy        = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition      = JsonIgnoreCondition.WhenWritingNull,
        Converters                  = { new JsonStringEnumConverter() },
    };

    private static JsonDocument ComputeDiff<T>(T oldObj, T newObj)
    {
        var oldDict = Flatten(JsonDocument.Parse(JsonSerializer.Serialize(oldObj, _jsonOpts)));
        var newDict = Flatten(JsonDocument.Parse(JsonSerializer.Serialize(newObj, _jsonOpts)));

        var changes = new List<object>();
        foreach (var key in oldDict.Keys.Union(newDict.Keys))
        {
            var oldVal = oldDict.GetValueOrDefault(key);
            var newVal = newDict.GetValueOrDefault(key);
            if (oldVal != newVal)
                changes.Add(new { field = key, oldValue = oldVal, newValue = newVal });
        }

        return JsonDocument.Parse(JsonSerializer.Serialize(changes, _jsonOpts));
    }

    /// <summary>فشرده‌سازی JSON تودرتو به map تخت key→string برای مقایسه.</summary>
    private static Dictionary<string, string?> Flatten(JsonDocument doc, string prefix = "")
    {
        var result = new Dictionary<string, string?>();
        foreach (var prop in doc.RootElement.EnumerateObject())
        {
            var key = prefix == "" ? prop.Name : $"{prefix}.{prop.Name}";
            if (prop.Value.ValueKind == JsonValueKind.Object)
                foreach (var kv in Flatten(JsonDocument.Parse(prop.Value.GetRawText()), key))
                    result[kv.Key] = kv.Value;
            else
                result[key] = prop.Value.ValueKind == JsonValueKind.Null ? null : prop.Value.ToString();
        }
        return result;
    }
}

public interface IAuditService
{
    /// <summary>ثبت ساده — برای رویدادهای بدون diff (login, logout, ...).</summary>
    Task WriteAsync(string? userId, string action, string? module = null,
                    string? recordId = null, string? details = null, string? ip = null);

    /// <summary>ثبت کامل با Builder — برای عملیات با diff.</summary>
    Task WriteEntryAsync(AuditEntry entry);

    /// <summary>کمک‌کننده: Builder آماده با context درخواست HTTP.</summary>
    AuditBuilder ForRequest(Microsoft.AspNetCore.Http.HttpContext ctx);

    Task<AuditPage> QueryAsync(AuditQuery q);

    /// <summary>Alias for WriteAsync with named params used in some controllers.</summary>
    Task LogAsync(string module, string action, string details, string? userId = null, string? ip = null);

    /// <summary>Alias for WriteAsync used in integrated risk services.</summary>
    Task LogAuditAsync(string module, string recordId, string action, string userId, string details);

    /// <summary>Log using AuditLogEntry object.</summary>
    Task LogAsync(AuditLogEntry entry);
}

/// <summary>Simple audit log entry DTO used by relationship services.</summary>
public class AuditLogEntry
{
    public string? UserId { get; set; }
    public string? Action { get; set; }
    public string? Module { get; set; }
    public string? Description { get; set; }
    public string? RecordId { get; set; }
}

public class AuditService : IAuditService
{
    private readonly IAuditRepository    _repo;
    private readonly INotificationService _notify;

    public AuditService(IAuditRepository repo, INotificationService notify)
    {
        _repo   = repo;
        _notify = notify;
    }

    // ── Legacy shim ──────────────────────────────────────────────────────────
    public async Task WriteAsync(string? userId, string action, string? module = null,
                           string? recordId = null, string? details = null, string? ip = null)
    {
        var entry = new AuditBuilder()
            .Action(action)
            .User(userId)
            .Ip(ip)
            .Module(module)
            .Record(recordId)
            .Meta(details is null ? null : new { note = details })
            .Build();
        await _repo.CreateAsync(entry);

        // Fire notification for high-severity audit events (non-fatal)
        _ = _notify.OnAuditEventAsync(action, module, recordId, recipientUserId: null);
    }

    public Task WriteEntryAsync(AuditEntry entry) => _repo.CreateAsync(entry);

    public Task LogAsync(string module, string action, string details, string? userId = null, string? ip = null)
        => WriteAsync(userId, action, module, null, details, ip);

    public Task LogAuditAsync(string module, string recordId, string action, string userId, string details)
        => WriteAsync(userId, action, module, recordId, details);

    public Task LogAsync(AuditLogEntry entry)
        => WriteAsync(entry.UserId, entry.Action ?? "", entry.Module, entry.RecordId, entry.Description);

    public AuditBuilder ForRequest(Microsoft.AspNetCore.Http.HttpContext ctx)
    {
        var ip = ctx.Connection.RemoteIpAddress?.ToString()
               ?? ctx.Request.Headers["X-Forwarded-For"].FirstOrDefault();
        var ua = ctx.Request.Headers["User-Agent"].FirstOrDefault();
        return new AuditBuilder().Ip(ip).Agent(ua);
    }

    public Task<AuditPage> QueryAsync(AuditQuery q) => _repo.QueryAsync(q);
}

/// <summary>پارامترهای جستجو برای GET /api/audit.</summary>
public sealed class AuditQuery
{
    public string?   UserId    { get; set; }
    public string?   Module    { get; set; }
    public string?   Action    { get; set; }
    public string?   Severity  { get; set; }
    public string?   RecordId  { get; set; }
    public string?   Outcome   { get; set; }
    public DateTime? From      { get; set; }
    public DateTime? To        { get; set; }
    public string?   Search    { get; set; }   // جستجو در username / record_title / ip
    public int       Limit     { get; set; } = 100;
    public int       Offset    { get; set; } = 0;
}
