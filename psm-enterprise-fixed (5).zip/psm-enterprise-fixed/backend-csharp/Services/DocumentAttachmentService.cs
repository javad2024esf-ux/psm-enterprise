using PSM.Api.DTOs;
using PSM.Api.Authorization;
using PSM.Api.Configuration;
using PSM.Api.Models;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

/// <summary>
/// Enhanced interface for document attachment and versioning operations.
/// Provides methods for managing attachments and document versions across all modules.
/// </summary>
public interface IDocumentAttachmentService
{
    // ─── Permissions ──────────────────────────────────────────────────────────
    Task<bool> CheckPermAsync(string role, PsmAction action);

    // ─── Attachments ──────────────────────────────────────────────────────────
    /// <summary>Attach a document to a module record.</summary>
    Task<DocumentAttachmentDto> AttachDocumentAsync(
        AttachDocumentRequest request, string userId);

    /// <summary>Detach a document from a module record.</summary>
    Task<bool> DetachDocumentAsync(string attachmentId, string userId);

    /// <summary>Get all attachments for a module record.</summary>
    Task<List<DocumentAttachmentDto>> GetAttachmentsAsync(string module, string recordId);

    /// <summary>Get all attachments for a document.</summary>
    Task<List<DocumentAttachmentDto>> GetDocumentAttachmentsAsync(string documentId);

    /// <summary>Reorder attachments for a record.</summary>
    Task<bool> ReorderAttachmentsAsync(
        string module, string recordId, Dictionary<string, int> sortOrders, string userId);

    // ─── Versions ─────────────────────────────────────────────────────────────
    /// <summary>Upload a new version of a document.</summary>
    Task<DocumentVersionDto> UploadVersionAsync(
        string documentId, IFormFile file, UploadDocumentVersionRequest request, string userId);

    /// <summary>Get all versions of a document.</summary>
    Task<List<DocumentVersionDto>> GetVersionsAsync(string documentId);

    /// <summary>Get a specific version.</summary>
    Task<DocumentVersionDto?> GetVersionAsync(string versionId);

    /// <summary>Restore a document to a previous version.</summary>
    Task<bool> RestoreVersionAsync(string documentId, int versionNumber, string userId);

    // ─── Previews ─────────────────────────────────────────────────────────────
    /// <summary>Get preview metadata for a document.</summary>
    Task<DocumentPreviewDto?> GetPreviewAsync(string documentId, string? previewType = null);

    /// <summary>Generate and save preview metadata.</summary>
    Task<DocumentPreviewDto> GeneratePreviewAsync(
        string documentId, string previewType, string? thumbnailPath = null, int? pageCount = null);

    // ─── Access Tracking ──────────────────────────────────────────────────────
    /// <summary>Log document access activity.</summary>
    Task LogAccessAsync(string documentId, string? userId, string actionType, 
        string? ipAddress = null, string? userAgent = null);

    /// <summary>Get access history for a document.</summary>
    Task<List<DocumentAccessLogDto>> GetAccessHistoryAsync(string documentId, int limit = 100);

    // ─── Module Summaries ──────────────────────────────────────────────────────
    /// <summary>Get complete document summary for a module record.</summary>
    Task<ModuleDocumentSummaryDto> GetModuleDocumentSummaryAsync(string module, string recordId);

    /// <summary>Get documents with all attachments and versions for a module record.</summary>
    Task<List<DocumentWithAttachmentsDto>> GetCompleteDocumentDataAsync(
        string module, string recordId);
}

/// <summary>
/// Implementation of document attachment and versioning service.
/// </summary>
public class DocumentAttachmentService : IDocumentAttachmentService
{
    private readonly IDocumentAttachmentRepository _attachmentRepo;
    private readonly IDocumentRepository _docRepo;
    private readonly IPermissionService _perms;
    private readonly IAuditService _audit;
    private readonly AppConfig _config;
    private readonly ILogger<DocumentAttachmentService> _log;

    private const string Module = "Documents";
    private const long MaxFileSizeBytes = 100L * 1024 * 1024; // 100 MB

    private static readonly HashSet<string> AllowedMime = new(StringComparer.OrdinalIgnoreCase)
    {
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-powerpoint",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "text/plain",
        "text/csv",
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp",
        "image/svg+xml",
        "application/zip",
        "application/x-zip-compressed",
    };

    public DocumentAttachmentService(
        IDocumentAttachmentRepository attachmentRepo,
        IDocumentRepository docRepo,
        IPermissionService perms,
        IAuditService audit,
        AppConfig config,
        ILogger<DocumentAttachmentService> log)
    {
        _attachmentRepo = attachmentRepo;
        _docRepo = docRepo;
        _perms = perms;
        _audit = audit;
        _config = config;
        _log = log;
    }

    // ─── RBAC ─────────────────────────────────────────────────────────────────
    public Task<bool> CheckPermAsync(string role, PsmAction action) =>
        _perms.CheckPermissionAsync(role, Module, action);

    // ═══════════════════════════════════════════════════════════════════════════
    // Attachments
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<DocumentAttachmentDto> AttachDocumentAsync(
        AttachDocumentRequest request, string userId)
    {
        // Validate document exists
        var doc = await _docRepo.GetByIdAsync(request.DocumentId);
        if (doc == null)
            throw new ArgumentException($"Document '{request.DocumentId}' not found.");

        // Create attachment
        var attachment = await _attachmentRepo.CreateAttachmentAsync(request);
        // Structured audit log applied
        _log.LogInformation(
            "Document {DocumentId} attached to {Module}/{RecordId} by {UserId}",
            request.DocumentId, request.Module, request.RecordId, userId);

        return attachment;
    }

    public async Task<bool> DetachDocumentAsync(string attachmentId, string userId)
    {
        var attachment = await _attachmentRepo.GetAttachmentAsync(attachmentId);
        if (attachment == null)
            return false;

        var success = await _attachmentRepo.DetachDocumentAsync(attachmentId);

        if (success)
        {
            _log.LogInformation(
                "Document {DocumentId} detached from {Module}/{RecordId} by {UserId}",
                attachment.DocumentId, attachment.Module, attachment.RecordId, userId);
        }

        return success;
    }

    public async Task<List<DocumentAttachmentDto>> GetAttachmentsAsync(string module, string recordId)
    {
        return await _attachmentRepo.GetAttachmentsByModuleRecordAsync(module, recordId);
    }

    public async Task<List<DocumentAttachmentDto>> GetDocumentAttachmentsAsync(string documentId)
    {
        return await _attachmentRepo.GetAttachmentsByDocumentAsync(documentId);
    }

    public async Task<bool> ReorderAttachmentsAsync(
        string module, string recordId, Dictionary<string, int> sortOrders, string userId)
    {
        var success = await _attachmentRepo.ReorderAttachmentsAsync(recordId, module, sortOrders);

        if (success)
        {
        }

        return success;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Versions
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<DocumentVersionDto> UploadVersionAsync(
        string documentId, IFormFile file, UploadDocumentVersionRequest request, string userId)
    {
        // Validate document
        var doc = await _docRepo.GetByIdAsync(documentId);
        if (doc == null)
            throw new ArgumentException($"Document '{documentId}' not found.");

        // Validate file
        if (file.Length == 0)
            throw new ArgumentException("File is empty.");
        if (file.Length > MaxFileSizeBytes)
            throw new ArgumentException($"File exceeds maximum size of 100 MB.");
        if (!AllowedMime.Contains(file.ContentType))
            throw new ArgumentException($"File type '{file.ContentType}' is not allowed.");

        // Save file
        var fileName = Path.GetFileName(file.FileName);
        var filePath = Path.Combine(_config.DataDir, "documents", $"{documentId}_v{await _attachmentRepo.GetLatestVersionNumberAsync(documentId) + 1}_{fileName}");
        
        Directory.CreateDirectory(Path.GetDirectoryName(filePath)!);
        await using (var stream = new FileStream(filePath, FileMode.Create))
        {
            await file.CopyToAsync(stream);
        }

        // Create version record
        var version = await _attachmentRepo.CreateVersionAsync(documentId, request);

        // Audit log
        return version;
    }

    public async Task<List<DocumentVersionDto>> GetVersionsAsync(string documentId)
    {
        return await _attachmentRepo.GetVersionsByDocumentAsync(documentId);
    }

    public async Task<DocumentVersionDto?> GetVersionAsync(string versionId)
    {
        return await _attachmentRepo.GetVersionAsync(versionId);
    }

    public async Task<bool> RestoreVersionAsync(string documentId, int versionNumber, string userId)
    {
        var version = (await _attachmentRepo.GetVersionsByDocumentAsync(documentId))
            .FirstOrDefault(v => v.VersionNumber == versionNumber);

        if (version == null)
            return false;

        var success = await _attachmentRepo.RestoreVersionAsync(documentId, versionNumber);

        if (success)
        {
            _log.LogInformation(
                "Document {DocumentId} restored to version {VersionNumber} by {UserId}",
                documentId, versionNumber, userId);
        }

        return success;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Previews
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<DocumentPreviewDto?> GetPreviewAsync(string documentId, string? previewType = null)
    {
        return await _attachmentRepo.GetPreviewAsync(documentId, previewType);
    }

    public async Task<DocumentPreviewDto> GeneratePreviewAsync(
        string documentId, string previewType, string? thumbnailPath = null, int? pageCount = null)
    {
        var preview = new DocumentPreviewDto
        {
            Id = Guid.NewGuid().ToString(),
            DocumentId = documentId,
            PreviewType = previewType,
            ThumbnailPath = thumbnailPath,
            PageCount = pageCount,
            GeneratedAt = DateTime.UtcNow,
            ExpiresAt = DateTime.UtcNow.AddDays(30),
        };

        return await _attachmentRepo.SavePreviewAsync(preview);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Access Tracking
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task LogAccessAsync(string documentId, string? userId, string actionType,
        string? ipAddress = null, string? userAgent = null)
    {
        var log = new DocumentAccessLogDto
        {
            Id = Guid.NewGuid().ToString(),
            DocumentId = documentId,
            UserId = userId,
            ActionType = actionType,
            IpAddress = ipAddress,
            UserAgent = userAgent,
        };

        await _attachmentRepo.LogAccessAsync(log);
    }

    public async Task<List<DocumentAccessLogDto>> GetAccessHistoryAsync(string documentId, int limit = 100)
    {
        return await _attachmentRepo.GetAccessLogAsync(documentId, limit);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Module Summaries
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<ModuleDocumentSummaryDto> GetModuleDocumentSummaryAsync(string module, string recordId)
    {
        return await _attachmentRepo.GetModuleDocumentSummaryAsync(module, recordId);
    }

    public async Task<List<DocumentWithAttachmentsDto>> GetCompleteDocumentDataAsync(
        string module, string recordId)
    {
        return await _attachmentRepo.GetDocumentsWithAttachmentsAsync(module, recordId);
    }
}
