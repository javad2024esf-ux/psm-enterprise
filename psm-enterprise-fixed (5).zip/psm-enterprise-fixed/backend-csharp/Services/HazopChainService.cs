using PSM.Api.DTOs;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

// ════════════════════════════════════════════════════════════════════════════
// Interface
// ════════════════════════════════════════════════════════════════════════════
public interface IHazopChainService
{
    // Causes
    Task<IEnumerable<HazopCauseDto>>          ListCausesAsync(string deviationId);
    Task<HazopCauseDto>                       CreateCauseAsync(CreateHazopCauseRequest req, string? userId);
    Task<HazopCauseDto?>                      UpdateCauseAsync(string id, UpdateHazopCauseRequest req, string? userId);
    Task<bool>                                DeleteCauseAsync(string id, string? userId);

    // Consequences
    Task<IEnumerable<HazopConsequenceDto>>    ListConsequencesAsync(string deviationId);
    Task<HazopConsequenceDto>                 CreateConsequenceAsync(CreateHazopConsequenceRequest req, string? userId);
    Task<HazopConsequenceDto?>                UpdateConsequenceAsync(string id, UpdateHazopConsequenceRequest req, string? userId);
    Task<bool>                                DeleteConsequenceAsync(string id, string? userId);

    // Safeguards
    Task<IEnumerable<HazopSafeguardDto>>      ListSafeguardsAsync(string deviationId);
    Task<HazopSafeguardDto>                   CreateSafeguardAsync(CreateHazopSafeguardRequest req, string? userId);
    Task<HazopSafeguardDto?>                  UpdateSafeguardAsync(string id, UpdateHazopSafeguardRequest req, string? userId);
    Task<bool>                                DeleteSafeguardAsync(string id, string? userId);

    // Recommendations
    Task<IEnumerable<HazopRecommendationDto>> ListRecommendationsAsync(string studyId);
    Task<IEnumerable<HazopRecommendationDto>> ListRecommendationsByDeviationAsync(string deviationId);
    Task<HazopRecommendationDto>              CreateRecommendationAsync(CreateHazopRecommendationRequest req, string? userId);
    Task<HazopRecommendationDto?>             UpdateRecommendationAsync(string id, UpdateHazopRecommendationRequest req, string? userId);
    Task<bool>                                DeleteRecommendationAsync(string id, string? userId);

    // Actions
    Task<IEnumerable<HazopActionDto>>         ListActionsAsync(string studyId);
    Task<HazopActionDto>                      CreateActionFromRecommendationAsync(string recommendationId,
                                                  string? responsible, DateTime? dueDate, string? userId);
    Task<HazopActionDto?>                     UpdateActionStatusAsync(string id, string status,
                                                  DateTime? completedDate, string? verifiedBy,
                                                  string? verificationNote, string? userId);
    Task<bool>                                DeleteActionAsync(string id, string? userId);

    // Workflow
    Task<HazopWorkflowInstanceDto>            StartWorkflowAsync(StartHazopWorkflowRequest req, string? userId);
    Task<HazopWorkflowInstanceDto?>           TransitionWorkflowAsync(HazopWorkflowTransitionRequest req,
                                                  string actorId, string actorName);
    Task<HazopWorkflowInstanceDto?>           GetWorkflowAsync(string entityType, string entityId);
    Task<IEnumerable<HazopWorkflowInstanceDto>> ListPendingWorkflowsAsync(string? userId);

    // Full Chain
    Task<HazopDeviationFullChainDto?>         GetDeviationFullChainAsync(string deviationId);
    Task<HazopChainAnalyticsDto>              GetChainAnalyticsAsync(string? studyId = null);
}

// ════════════════════════════════════════════════════════════════════════════
// Implementation
// ════════════════════════════════════════════════════════════════════════════
public class HazopChainService : IHazopChainService
{
    private readonly IHazopChainRepository      _repo;
    private readonly INotificationService       _notif;
    private readonly ILogger<HazopChainService> _log;

    // تعریف گذارهای مجاز Workflow برای HAZOP
    private static readonly Dictionary<string, (string ToState, string[] AllowedRoles)[]> WorkflowTransitions = new()
    {
        ["submit"]       = [("Under Review",    ["Engineer", "Admin"])],
        ["approve"]      = [("Approved",        ["Manager", "Admin"])],
        ["reject"]       = [("Draft",           ["Manager", "Admin"])],
        ["raise_action"] = [("Action Required", ["Engineer", "Manager", "Admin"])],
        ["close"]        = [("Closed",          ["Manager", "Admin"])],
        ["archive"]      = [("Archived",        ["Admin"])],
    };

    public HazopChainService(
        IHazopChainRepository      repo,
        INotificationService       notif,
        ILogger<HazopChainService> log)
    {
        _repo  = repo;
        _notif = notif;
        _log   = log;
    }

    // ─── Causes ─────────────────────────────────────────────────────────────
    public Task<IEnumerable<HazopCauseDto>> ListCausesAsync(string deviationId) =>
        _repo.ListCausesAsync(deviationId);

    public async Task<HazopCauseDto> CreateCauseAsync(CreateHazopCauseRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateCauseAsync(id, req.deviation_id, null, req.description,
            req.cause_type ?? "Process", req.likelihood ?? 3,
            req.initiating_event, req.frequency_basis, userId);

        await AuditAsync(null, "cause", id, "CREATE", userId, null, null, req);
        return (await _repo.GetCauseAsync(id))!;
    }

    public async Task<HazopCauseDto?> UpdateCauseAsync(string id, UpdateHazopCauseRequest req, string? userId)
    {
        var old = await _repo.GetCauseAsync(id);
        if (old is null) return null;
        await _repo.UpdateCauseAsync(id, req.description, req.cause_type ?? "Process",
            req.likelihood ?? 3, req.initiating_event, req.frequency_basis);
        await AuditAsync(null, "cause", id, "UPDATE", userId, old, req);
        return await _repo.GetCauseAsync(id);
    }

    public async Task<bool> DeleteCauseAsync(string id, string? userId)
    {
        var old = await _repo.GetCauseAsync(id);
        if (old is null) return false;
        await _repo.DeleteCauseAsync(id);
        await AuditAsync(null, "cause", id, "DELETE", userId, old, null);
        return true;
    }

    // ─── Consequences ────────────────────────────────────────────────────────
    public Task<IEnumerable<HazopConsequenceDto>> ListConsequencesAsync(string deviationId) =>
        _repo.ListConsequencesAsync(deviationId);

    public async Task<HazopConsequenceDto> CreateConsequenceAsync(CreateHazopConsequenceRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateConsequenceAsync(id, req.deviation_id, null, req.description,
            req.consequence_category ?? "Safety", req.severity ?? 3,
            req.affected_population, req.credible ?? true, userId);
        await AuditAsync(null, "consequence", id, "CREATE", userId, null, req);
        return (await _repo.GetConsequenceAsync(id))!;
    }

    public async Task<HazopConsequenceDto?> UpdateConsequenceAsync(string id, UpdateHazopConsequenceRequest req, string? userId)
    {
        var old = await _repo.GetConsequenceAsync(id);
        if (old is null) return null;
        await _repo.UpdateConsequenceAsync(id, req.description, req.consequence_category ?? "Safety",
            req.severity ?? 3, req.affected_population, req.credible ?? true);
        await AuditAsync(null, "consequence", id, "UPDATE", userId, old, req);
        return await _repo.GetConsequenceAsync(id);
    }

    public async Task<bool> DeleteConsequenceAsync(string id, string? userId)
    {
        var old = await _repo.GetConsequenceAsync(id);
        if (old is null) return false;
        await _repo.DeleteConsequenceAsync(id);
        await AuditAsync(null, "consequence", id, "DELETE", userId, old, null);
        return true;
    }

    // ─── Safeguards ──────────────────────────────────────────────────────────
    public Task<IEnumerable<HazopSafeguardDto>> ListSafeguardsAsync(string deviationId) =>
        _repo.ListSafeguardsAsync(deviationId);

    public async Task<HazopSafeguardDto> CreateSafeguardAsync(CreateHazopSafeguardRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateSafeguardAsync(id, req.deviation_id, null, req.description,
            req.safeguard_type ?? "Prevention", req.ipl_credited ?? false,
            req.pfd, req.tag_number, req.status ?? "Active", userId);
        await AuditAsync(null, "safeguard", id, "CREATE", userId, null, req);
        return (await _repo.GetSafeguardAsync(id))!;
    }

    public async Task<HazopSafeguardDto?> UpdateSafeguardAsync(string id, UpdateHazopSafeguardRequest req, string? userId)
    {
        var old = await _repo.GetSafeguardAsync(id);
        if (old is null) return null;
        await _repo.UpdateSafeguardAsync(id, req.description, req.safeguard_type ?? "Prevention",
            req.ipl_credited ?? false, req.pfd, req.tag_number, req.status ?? "Active");
        await AuditAsync(null, "safeguard", id, "UPDATE", userId, old, req);
        return await _repo.GetSafeguardAsync(id);
    }

    public async Task<bool> DeleteSafeguardAsync(string id, string? userId)
    {
        var old = await _repo.GetSafeguardAsync(id);
        if (old is null) return false;
        await _repo.DeleteSafeguardAsync(id);
        await AuditAsync(null, "safeguard", id, "DELETE", userId, old, null);
        return true;
    }

    // ─── Recommendations ─────────────────────────────────────────────────────
    public Task<IEnumerable<HazopRecommendationDto>> ListRecommendationsAsync(string studyId) =>
        _repo.ListRecommendationsAsync(studyId);

    public Task<IEnumerable<HazopRecommendationDto>> ListRecommendationsByDeviationAsync(string deviationId) =>
        _repo.ListRecommendationsByDeviationAsync(deviationId);

    public async Task<HazopRecommendationDto> CreateRecommendationAsync(CreateHazopRecommendationRequest req, string? userId)
    {
        var id = Guid.NewGuid().ToString();
        await _repo.CreateRecommendationAsync(id, req.study_id, req.deviation_id, req.node_id,
            req.recommendation_text, req.owner, req.priority ?? "Medium", req.due_date, req.remarks, userId);

        // اعلان به مسئول
        if (!string.IsNullOrEmpty(req.owner))
        {
            await _notif.PushAsync(new CreateNotificationRequest
            {
                UserId   = req.owner,
                Title    = "توصیه HAZOP جدید برای شما ثبت شد",
                Message = $"توصیه: {req.recommendation_text.Substring(0, Math.Min(80, req.recommendation_text.Length))}...",
                Type     = req.priority ?? "Medium",
                RecordId = id,
                Module   = "HAZOP",
            });
        }

        await AuditAsync(req.study_id, "recommendation", id, "CREATE", userId, null, req);
        return (await _repo.GetRecommendationAsync(id))!;
    }

    public async Task<HazopRecommendationDto?> UpdateRecommendationAsync(string id, UpdateHazopRecommendationRequest req, string? userId)
    {
        var old = await _repo.GetRecommendationAsync(id);
        if (old is null) return null;

        await _repo.UpdateRecommendationAsync(id, req.recommendation_text, req.owner,
            req.priority ?? "Medium", req.due_date, req.status ?? "Open",
            req.approval_status ?? "Not Submitted", req.approver,
            req.closure_evidence, req.closure_date, req.remarks);

        // اعلان تغییر وضعیت
        if (old.Status != req.status && !string.IsNullOrEmpty(req.owner))
        {
            await _notif.PushAsync(new CreateNotificationRequest
            {
                UserId   = req.owner,
                Title    = $"وضعیت توصیه تغییر کرد: {req.status}",
                Message = req.recommendation_text,
                Type     = "HAZOP_RECOMMENDATION_STATUS",
                RecordId = id,
                Module   = "HAZOP",
            });
        }

        await AuditAsync(req.study_id, "recommendation", id, "STATUS_CHANGE", userId, old, req);
        return await _repo.GetRecommendationAsync(id);
    }

    public async Task<bool> DeleteRecommendationAsync(string id, string? userId)
    {
        var old = await _repo.GetRecommendationAsync(id);
        if (old is null) return false;
        await _repo.DeleteRecommendationAsync(id);
        await AuditAsync(old.StudyId, "recommendation", id, "DELETE", userId, old, null);
        return true;
    }

    // ─── Actions ─────────────────────────────────────────────────────────────
    public Task<IEnumerable<HazopActionDto>> ListActionsAsync(string studyId) =>
        _repo.ListActionsAsync(studyId);

    public async Task<HazopActionDto> CreateActionFromRecommendationAsync(
        string recommendationId, string? responsible, DateTime? dueDate, string? userId)
    {
        var rec = await _repo.GetRecommendationAsync(recommendationId)
                  ?? throw new KeyNotFoundException("توصیه یافت نشد");

        var actionId = Guid.NewGuid().ToString();
        await _repo.CreateActionAsync(
            actionId, rec.StudyId!, rec.DeviationId!, recommendationId, null,
            $"اقدام از توصیه HAZOP: {rec.RecommendationText?.Substring(0, Math.Min(50, rec.RecommendationText?.Length ?? 0))}",
            rec.RecommendationText ?? "",
            responsible ?? rec.Owner,
            dueDate ?? rec.DueDate,
            rec.Priority ?? "High",
            userId);

        // لینک توصیه به اقدام
        await _repo.LinkRecommendationToActionAsync(recommendationId, actionId);

        // آپدیت وضعیت توصیه
        await _repo.UpdateRecommendationAsync(recommendationId, rec.RecommendationText!, rec.Owner,
            rec.Priority ?? "High", rec.DueDate, "In Progress", rec.ApprovalStatus ?? "Not Submitted",
            rec.Approver, rec.ClosureEvidence, rec.ClosureDate, rec.Remarks);

        // اعلان
        if (!string.IsNullOrEmpty(responsible))
        {
            await _notif.PushAsync(new CreateNotificationRequest
            {
                UserId   = responsible,
                Title    = "اقدام جدید HAZOP به شما واگذار شد",
                Message = $"اقدام مرتبط با توصیه HAZOP ایجاد شد. مهلت: {dueDate?.ToString("yyyy/MM/dd") ?? "نامشخص"}",
                Type = rec.Priority ?? "High",
                RecordId = actionId,
                Module   = "HAZOP",
            });
        }

        await AuditAsync(rec.StudyId, "action", actionId, "CREATE", userId, null, new { recommendationId, responsible, dueDate });
        return (await _repo.GetActionAsync(actionId))!;
    }

    public async Task<HazopActionDto?> UpdateActionStatusAsync(string id, string status,
        DateTime? completedDate, string? verifiedBy, string? verificationNote, string? userId)
    {
        var old = await _repo.GetActionAsync(id);
        if (old is null) return null;

        await _repo.UpdateActionStatusAsync(id, status, completedDate, verifiedBy, verificationNote);

        // اگر اقدام بسته شد — توصیه را هم ببند
        if (status == "Closed" && !string.IsNullOrEmpty(old.RecommendationId))
        {
            var rec = await _repo.GetRecommendationAsync(old.RecommendationId!);
            if (rec is not null)
            {
                await _repo.UpdateRecommendationAsync(rec.Id!, rec.RecommendationText!, rec.Owner,
                    rec.Priority ?? "High", rec.DueDate, "Closed", "Approved",
                    verifiedBy, verificationNote, completedDate, "بسته شد از طریق اقدام");
            }
        }

        await AuditAsync(old.StudyId, "action", id, "STATUS_CHANGE", userId,
            new { old.Status }, new { status, completedDate, verifiedBy });
        return await _repo.GetActionAsync(id);
    }

    public async Task<bool> DeleteActionAsync(string id, string? userId)
    {
        var old = await _repo.GetActionAsync(id);
        if (old is null) return false;
        await _repo.DeleteActionAsync(id);
        await AuditAsync(old.StudyId, "action", id, "DELETE", userId, old, null);
        return true;
    }

    // ─── Workflow ────────────────────────────────────────────────────────────
    public async Task<HazopWorkflowInstanceDto> StartWorkflowAsync(StartHazopWorkflowRequest req, string? userId)
    {
        var instanceId = Guid.NewGuid().ToString();
        DateTime? due = req.due_date is not null ? DateTime.TryParse(req.due_date, out var d) ? d : null : null;

        var inst = await _repo.StartWorkflowAsync(instanceId, req.entity_type, req.entity_id,
            null, req.assigned_to, null, req.priority, due, userId);

        await _notif.OnWorkflowStartedAsync(req.entity_id, "HAZOP", req.assigned_to, userId ?? "System");
        await AuditAsync(null, "workflow", req.entity_id, "WORKFLOW_START", userId, null, new { state = "Draft" });
        return inst;
    }

    public async Task<HazopWorkflowInstanceDto?> TransitionWorkflowAsync(
        HazopWorkflowTransitionRequest req, string actorId, string actorName)
    {
        // پیدا کردن state بعدی
        if (!WorkflowTransitions.TryGetValue(req.action, out var transitions) || transitions.Length == 0)
            throw new ArgumentException($"اقدام ناشناخته یا بدون حالت انتقال: {req.action}");

        var toState = transitions[0].ToState;
        var inst = await _repo.TransitionWorkflowAsync("deviation", req.entity_id,
            req.action, toState, actorId, actorName, req.comment);

        if (inst is not null)
        {
            await _notif.OnWorkflowTransitionAsync(req.entity_id, inst.PreviousState ?? "Draft",
                toState, req.action, "HAZOP", inst.AssignedTo, actorName);
            await AuditAsync(null, "workflow", req.entity_id, "WORKFLOW_TRANSITION", actorId,
                new { from = inst.PreviousState }, new { to = toState, req.action });
        }
        return inst;
    }

    public Task<HazopWorkflowInstanceDto?> GetWorkflowAsync(string entityType, string entityId) =>
        _repo.GetWorkflowInstanceAsync(entityType, entityId);

    public Task<IEnumerable<HazopWorkflowInstanceDto>> ListPendingWorkflowsAsync(string? userId) =>
        _repo.ListPendingWorkflowsAsync(userId);

    // ─── Full Chain ───────────────────────────────────────────────────────────
    public Task<HazopDeviationFullChainDto?> GetDeviationFullChainAsync(string deviationId) =>
        _repo.GetDeviationFullChainAsync(deviationId);

    public Task<HazopChainAnalyticsDto> GetChainAnalyticsAsync(string? studyId = null) =>
        _repo.GetChainAnalyticsAsync(studyId);

    // ─── Private Helpers ─────────────────────────────────────────────────────
    private Task AuditAsync(string? studyId, string entityType, string entityId,
        string action, string? actorId, object? oldValues, object? newValues, object? extra = null) =>
        _repo.LogAuditAsync(
            Guid.NewGuid().ToString(), studyId, entityType, entityId,
            action, actorId, actorId, oldValues, newValues ?? extra, null);
}
