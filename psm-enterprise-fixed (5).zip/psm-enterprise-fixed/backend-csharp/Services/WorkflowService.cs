using System.Text.Json;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

// ════════════════════════════════════════════════════════════════════════════
// IWorkflowService
// ════════════════════════════════════════════════════════════════════════════
public interface IWorkflowService
{
    // ── Definitions ─────────────────────────────────────────────────────────
    Task<IEnumerable<WorkflowDefinitionDto>> ListDefinitionsAsync();
    Task<WorkflowDefinitionDetailDto?> GetDefinitionForModuleAsync(string module);

    // ── Instance lifecycle ───────────────────────────────────────────────────
    Task<WorkflowInstanceDetailDto> StartWorkflowAsync(StartWorkflowRequest req, string userId);
    Task<WorkflowInstanceDetailDto?> GetInstanceDetailAsync(string recordId, string userRole);
    Task<WorkflowInstanceDetailDto> DoTransitionAsync(TransitionRequest req, string userId, string userRole);
    Task DeleteInstanceAsync(string recordId, string userId);

    // ── History ──────────────────────────────────────────────────────────────
    Task<IEnumerable<WorkflowHistoryDto>> GetHistoryAsync(string recordId);

    // ── Dashboard / analytics ────────────────────────────────────────────────
    Task<WorkflowDashboardDto> GetDashboardAsync(string userId, string userRole);
    Task<WorkflowAnalyticsDto> GetAnalyticsAsync();

    // ── RBAC helper ──────────────────────────────────────────────────────────
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

// ════════════════════════════════════════════════════════════════════════════
// WorkflowService
// ════════════════════════════════════════════════════════════════════════════
public class WorkflowService : IWorkflowService
{
    private readonly IWorkflowRepository _repo;
    private readonly IPermissionService  _perms;
    private readonly IAuditService       _audit;
    private readonly ILogger<WorkflowService> _log;
    private readonly INotificationService _notify;

    private const string Module = "Workflow";

    public WorkflowService(
        IWorkflowRepository repo,
        IPermissionService  perms,
        IAuditService       audit,
        INotificationService notify,
        ILogger<WorkflowService> log)
    {
        _repo   = repo;
        _perms  = perms;
        _audit  = audit;
        _notify = notify;
        _log    = log;
    }

    // ── RBAC ─────────────────────────────────────────────────────────────────
    public Task<bool> CheckPermAsync(string role, PsmAction action) =>
        _perms.CheckPermissionAsync(role, Module, action);

    // ── Definitions ──────────────────────────────────────────────────────────
    public Task<IEnumerable<WorkflowDefinitionDto>> ListDefinitionsAsync() =>
        _repo.ListDefinitionsAsync();

    public async Task<WorkflowDefinitionDetailDto?> GetDefinitionForModuleAsync(string module)
    {
        var def = await _repo.GetActiveDefinitionByModuleAsync(module);
        if (def is null) return null;

        var states      = await _repo.GetStatesAsync(def.Id);
        var transitions = await _repo.GetTransitionsAsync(def.Id);

        return new WorkflowDefinitionDetailDto
        {
            Id          = def.Id,
            Name        = def.Name,
            Module      = def.Module,
            Version     = def.Version,
            Config      = def.Config,
            IsActive    = def.IsActive,
            CreatedBy   = def.CreatedBy,
            CreatedAt   = def.CreatedAt,
            UpdatedAt   = def.UpdatedAt,
            States      = states.ToList(),
            Transitions = transitions.ToList(),
        };
    }

    // ── Instance: Start ──────────────────────────────────────────────────────
    public async Task<WorkflowInstanceDetailDto> StartWorkflowAsync(StartWorkflowRequest req, string userId)
    {
        if (string.IsNullOrWhiteSpace(req.recordId))
            throw new ArgumentException("recordId is required.");
        if (string.IsNullOrWhiteSpace(req.collection))
            throw new ArgumentException("collection is required.");

        // Guard: record must exist
        if (!await _repo.RecordExistsAsync(req.recordId))
            throw new KeyNotFoundException($"Record '{req.recordId}' not found.");

        // Guard: no duplicate instance
        var existing = await _repo.GetInstanceByRecordIdAsync(req.recordId);
        if (existing is not null)
            throw new InvalidOperationException($"Workflow already active for record '{req.recordId}'.");

        // Resolve definition
        var def = await _repo.GetActiveDefinitionByModuleAsync(req.collection)
               ?? throw new InvalidOperationException($"No active workflow definition for module '{req.collection}'.");

        if (!await _repo.StatesExistAsync(def.Id))
            throw new InvalidOperationException($"Workflow definition '{def.Id}' has no states configured.");

        var states = (await _repo.GetStatesAsync(def.Id)).ToList();
        var initial = states.FirstOrDefault(s => s.IsInitial)
                   ?? throw new InvalidOperationException("Workflow has no initial state.");

        // Compute due date from SLA
        DateTime? dueAt = initial.SlaHours.HasValue
            ? DateTime.UtcNow.AddHours(initial.SlaHours.Value)
            : null;

        var escalationPolicy = req.priority?.ToLower() == "critical" ? "Critical" : "Standard";

        var instanceId = $"wfi_{Guid.NewGuid():N}";

        string? createdInstanceId = null;

        await _repo.WithTransactionAsync(async (conn, tx) =>
        {
            createdInstanceId = await _repo.CreateInstanceAsync(
                conn, tx, instanceId, req.recordId, def.Id, req.collection,
                initial.Name, dueAt, escalationPolicy, userId);

            await _repo.InsertHistoryAsync(
                conn, tx,
                $"wfh_{Guid.NewGuid():N}",
                instanceId,
                "START",
                null, initial.Name,
                "Workflow started",
                userId);

            await _repo.SyncRecordStatusAsync(conn, tx, req.recordId, initial.Name, userId);

            // Pending approval for the initial state's required role
            if (!string.IsNullOrEmpty(initial.RequiredRole))
            {
                await _repo.InsertPendingApprovalAsync(
                    conn, tx,
                    $"wfpa_{Guid.NewGuid():N}",
                    instanceId,
                    initial.RequiredRole,
                    dueAt,
                    0);
            }

            await _repo.InsertAuditTrailAsync(
                conn, tx,
                $"wfat_{Guid.NewGuid():N}",
                instanceId,
                "WORKFLOW_STARTED",
                null,
                JsonSerializer.Serialize(new { state = initial.Name, record = req.recordId }),
                userId,
                null);
        });

        await _audit.WriteAsync(userId, "WORKFLOW_STARTED", Module, req.recordId,
            $"Started workflow '{def.Name}' for record '{req.recordId}'");

        await _notify.OnWorkflowStartedAsync(
            req.recordId, req.collection, recipientUserId: null, actorName: userId);

        return await BuildDetailDtoAsync(instanceId, null)
            ?? throw new InvalidOperationException("Failed to retrieve newly created workflow instance.");
    }

    // ── Instance: Get detail ─────────────────────────────────────────────────
    public async Task<WorkflowInstanceDetailDto?> GetInstanceDetailAsync(string recordId, string userRole)
    {
        var inst = await _repo.GetInstanceByRecordIdAsync(recordId);
        if (inst is null) return null;

        return await BuildDetailDtoAsync(inst.Id, userRole);
    }

    // ── Instance: Transition ─────────────────────────────────────────────────
    public async Task<WorkflowInstanceDetailDto> DoTransitionAsync(
        TransitionRequest req, string userId, string userRole)
    {
        if (string.IsNullOrWhiteSpace(req.recordId))
            throw new ArgumentException("recordId is required.");
        if (string.IsNullOrWhiteSpace(req.action))
            throw new ArgumentException("action is required.");

        var inst = await _repo.GetInstanceByRecordIdAsync(req.recordId)
            ?? throw new KeyNotFoundException($"No active workflow for record '{req.recordId}'.");

        if (inst.CompletedAt.HasValue)
            throw new InvalidOperationException("Workflow is already completed.");

        // Resolve transition
        var transition = await _repo.FindTransitionAsync(inst.WorkflowId, inst.CurrentState, req.action)
            ?? throw new InvalidOperationException(
                $"Action '{req.action}' is not valid from state '{inst.CurrentState}'.");

        // RBAC: check required role on transition
        if (!string.IsNullOrEmpty(transition.RequiredRole)
            && userRole != "Admin"
            && userRole != transition.RequiredRole)
        {
            throw new UnauthorizedAccessException(
                $"Action '{req.action}' requires role '{transition.RequiredRole}'.");
        }

        var toState = await _repo.GetStateAsync(inst.WorkflowId, transition.ToState)
            ?? throw new InvalidOperationException($"Target state '{transition.ToState}' not found.");

        DateTime? newDueAt     = toState.SlaHours.HasValue ? DateTime.UtcNow.AddHours(toState.SlaHours.Value) : null;
        DateTime? completedAt  = toState.IsFinal ? DateTime.UtcNow : null;

        var fromState = inst.CurrentState;

        await _repo.WithTransactionAsync(async (conn, tx) =>
        {
            // Resolve existing approvals & SLA breaches
            await _repo.ResolveOpenApprovalsAsync(conn, tx, inst.Id, "approved", req.comment);
            await _repo.ResolveOpenBreachesAsync(conn, tx, inst.Id);

            // Advance instance
            await _repo.UpdateInstanceStateAsync(conn, tx, inst.Id, toState.Name, newDueAt, completedAt);

            if (toState.IsFinal)
                await _repo.MarkInstanceCompletedAsync(conn, tx, inst.Id);

            // History entry
            await _repo.InsertHistoryAsync(
                conn, tx,
                $"wfh_{Guid.NewGuid():N}",
                inst.Id,
                req.action,
                fromState, toState.Name,
                req.comment ?? string.Empty,
                userId);

            // New pending approval for the target state
            if (!string.IsNullOrEmpty(toState.RequiredRole) && !toState.IsFinal)
            {
                await _repo.InsertPendingApprovalAsync(
                    conn, tx,
                    $"wfpa_{Guid.NewGuid():N}",
                    inst.Id,
                    toState.RequiredRole,
                    newDueAt,
                    0);
            }

            // Sync record status
            await _repo.SyncRecordStatusAsync(conn, tx, req.recordId, toState.Name, userId);

            // Domain audit trail
            await _repo.InsertAuditTrailAsync(
                conn, tx,
                $"wfat_{Guid.NewGuid():N}",
                inst.Id,
                "STATE_TRANSITION",
                JsonSerializer.Serialize(new { state = fromState }),
                JsonSerializer.Serialize(new { state = toState.Name, action = req.action }),
                userId,
                req.comment);
        });

        await _audit.WriteAsync(userId, "WORKFLOW_TRANSITION", Module, req.recordId,
            $"Transition '{req.action}': {fromState} → {toState.Name}");

        // Notify relevant parties about the state change (non-fatal)
        _ = _notify.OnWorkflowTransitionAsync(
            req.recordId, fromState, toState.Name, req.action,
            inst.Collection ?? Module, recipientUserId: null, actorName: userId);

        return await BuildDetailDtoAsync(inst.Id, userRole)
            ?? throw new InvalidOperationException("Failed to retrieve updated workflow instance.");
    }

    // ── Delete instance ──────────────────────────────────────────────────────
    public async Task DeleteInstanceAsync(string recordId, string userId)
    {
        var inst = await _repo.GetInstanceByRecordIdAsync(recordId)
            ?? throw new KeyNotFoundException($"No workflow instance for record '{recordId}'.");

        await _repo.WithTransactionAsync(async (conn, tx) =>
        {
            await _repo.InsertAuditTrailAsync(
                conn, tx,
                $"wfat_{Guid.NewGuid():N}",
                inst.Id,
                "WORKFLOW_DELETED",
                JsonSerializer.Serialize(new { state = inst.CurrentState }),
                null,
                userId,
                "Instance deleted by user");
        });

        await _audit.WriteAsync(userId, "WORKFLOW_DELETED", Module, recordId,
            $"Deleted workflow instance '{inst.Id}'");
    }

    // ── History ──────────────────────────────────────────────────────────────
    public async Task<IEnumerable<WorkflowHistoryDto>> GetHistoryAsync(string recordId)
    {
        var inst = await _repo.GetInstanceByRecordIdAsync(recordId);
        if (inst is null) return Enumerable.Empty<WorkflowHistoryDto>();
        return await _repo.GetHistoryAsync(inst.Id);
    }

    // ── Dashboard ─────────────────────────────────────────────────────────────
    public async Task<WorkflowDashboardDto> GetDashboardAsync(string userId, string userRole)
    {
        var summary = await _repo.GetDashboardSummaryAsync();

        // My pending approvals: filter by the user's role
        var myApprovals = await _repo.GetPendingForRoleAsync(userRole, userId);
        summary.MyPendingApprovals = myApprovals.ToList();

        var overdueInst = await _repo.GetOverdueInstancesAsync(10);
        summary.OverdueInstances = overdueInst.ToList();

        var escalations = await _repo.GetRecentEscalationsAsync(5);
        summary.RecentEscalations = escalations.ToList();

        return summary;
    }

    // ── Analytics ────────────────────────────────────────────────────────────
    public async Task<WorkflowAnalyticsDto> GetAnalyticsAsync()
    {
        var summary    = await _repo.GetDashboardSummaryAsync();
        var byModule   = await _repo.GetModuleStatsAsync();
        var escalations = await _repo.GetRecentEscalationsAsync(10);
        var overdue     = await _repo.GetOverdueInstancesAsync(20);

        return new WorkflowAnalyticsDto
        {
            ActiveWorkflows              = summary.ActiveWorkflows,
            OverdueWorkflows             = summary.OverdueWorkflows,
            ActiveSlaBreaches            = summary.ActiveSlaBreaches,
            PendingApprovals             = summary.PendingApprovals,
            UnacknowledgedEscalations    = summary.UnacknowledgedEscalations,
            AvgCompletionHours           = summary.AvgCompletionHours,
            SlaCompliancePercentage      = summary.SlaCompliancePercentage,
            MyPendingApprovals           = new List<PendingApprovalDto>(),
            OverdueInstances             = overdue.ToList(),
            RecentEscalations            = escalations.ToList(),
            ByModule                     = byModule.ToList(),
        };
    }

    // ════════════════════════════════════════════════════════════════════════
    // Private helpers
    // ════════════════════════════════════════════════════════════════════════

    private async Task<WorkflowInstanceDetailDto?> BuildDetailDtoAsync(string instanceId, string? userRole)
    {
        var inst = await _repo.GetInstanceByIdAsync(instanceId);
        if (inst is null) return null;

        var states      = await _repo.GetStatesAsync(inst.WorkflowId);
        var transitions = await _repo.GetTransitionsAsync(inst.WorkflowId);
        var statesList  = states.ToList();

        var currentStateDef = statesList.FirstOrDefault(s => s.Name == inst.CurrentState);

        // Available actions = transitions from current state, filtered by role
        var available = transitions
            .Where(t => t.FromState == inst.CurrentState)
            .Where(t => string.IsNullOrEmpty(t.RequiredRole)
                     || userRole == "Admin"
                     || userRole == t.RequiredRole)
            .ToList();

        var pendingApprovals = await _repo.GetPendingForRoleAsync(userRole ?? "", null);

        bool isOverdue         = inst.DueAt.HasValue && DateTime.UtcNow > inst.DueAt.Value && !inst.CompletedAt.HasValue;
        double? hoursRemaining = inst.DueAt.HasValue && !inst.CompletedAt.HasValue
            ? (inst.DueAt.Value - DateTime.UtcNow).TotalHours
            : null;

        return new WorkflowInstanceDetailDto
        {
            Id               = inst.Id,
            RecordId         = inst.RecordId,
            WorkflowId       = inst.WorkflowId,
            Collection       = inst.Collection,
            CurrentState     = inst.CurrentState,
            DueAt            = inst.DueAt,
            CompletedAt      = inst.CompletedAt,
            EscalationPolicy = inst.EscalationPolicy,
            CreatedBy        = inst.CreatedBy,
            CreatedAt        = inst.CreatedAt,
            UpdatedAt        = inst.UpdatedAt,
            StateLabel       = currentStateDef?.Label,
            IsFinal          = currentStateDef?.IsFinal ?? false,
            IsOverdue        = isOverdue,
            HoursRemaining   = hoursRemaining,
            AvailableActions = available,
            PendingApprovals = pendingApprovals
                .Where(p => p.InstanceId == inst.Id)
                .ToList(),
        };
    }
}
