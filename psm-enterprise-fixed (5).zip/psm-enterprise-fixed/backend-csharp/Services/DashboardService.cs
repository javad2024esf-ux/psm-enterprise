using PSM.Api.DTOs;
using PSM.Api.Repositories;
using System.Collections.Concurrent;

namespace PSM.Api.Services;

/// <summary>
/// Service for managing Dashboard KPI aggregation and real-time updates
/// </summary>
public interface IDashboardService
{
    /// <summary>Get all KPIs for the dashboard</summary>
    Task<DashboardKpisDto> GetAllKpisAsync();

    /// <summary>Get specific module KPIs</summary>
    Task<HazopKpisDto> GetHazopKpisAsync();
    Task<LopaKpisDto> GetLopaKpisAsync();
    Task<IncidentKpisDto> GetIncidentKpisAsync();
    Task<PermitKpisDto> GetPermitKpisAsync();
    Task<WorkflowKpisDto> GetWorkflowKpisAsync();
    Task<ActionRegisterKpisDto> GetActionRegisterKpisAsync();
    Task<AuditKpisDto> GetAuditKpisAsync();

    /// <summary>Publish KPI update event for real-time notifications</summary>
    void PublishKpiUpdate(KpiUpdateEventDto updateEvent);

    /// <summary>Subscribe to KPI updates</summary>
    void SubscribeToUpdates(Action<KpiUpdateEventDto> onUpdate);

    /// <summary>Get recent KPI updates (for real-time dashboard)</summary>
    IEnumerable<KpiUpdateEventDto> GetRecentUpdates(int limitMinutes = 5);

    /// <summary>Clear cached KPI data</summary>
    Task InvalidateCacheAsync();

    /// <summary>Get cache statistics</summary>
    KpiCacheStatsDto GetCacheStats();
}

/// <summary>
/// Cache statistics for monitoring
/// </summary>
public class KpiCacheStatsDto
{
    public DateTime CacheCreatedAt { get; set; }
    public int MinutesSinceCacheCreation { get; set; }
    public int UpdateEventCount { get; set; }
    public int SubscriberCount { get; set; }
}

public class DashboardService : IDashboardService
{
    private readonly IDashboardRepository _repository;
    private DashboardKpisDto? _cachedKpis;
    private DateTime _cacheTimestamp;
    private readonly TimeSpan _cacheDuration = TimeSpan.FromMinutes(2);
    
    private readonly ConcurrentBag<KpiUpdateEventDto> _recentUpdates = new();
    private readonly ConcurrentBag<Action<KpiUpdateEventDto>> _subscribers = new();
    private const int MaxRecentUpdates = 1000;

    public DashboardService(IDashboardRepository repository)
    {
        _repository = repository;
    }

    public async Task<DashboardKpisDto> GetAllKpisAsync()
    {
        // Check cache validity
        if (_cachedKpis != null && DateTime.UtcNow - _cacheTimestamp < _cacheDuration)
        {
            return _cachedKpis;
        }

        // Fetch fresh KPIs
        _cachedKpis = await _repository.GetAllKpisAsync();
        _cacheTimestamp = DateTime.UtcNow;
        return _cachedKpis;
    }

    public async Task<HazopKpisDto> GetHazopKpisAsync()
    {
        var kpis = await GetAllKpisAsync();
        return kpis.HazopKpis;
    }

    public async Task<LopaKpisDto> GetLopaKpisAsync()
    {
        var kpis = await GetAllKpisAsync();
        return kpis.LopaKpis;
    }

    public async Task<IncidentKpisDto> GetIncidentKpisAsync()
    {
        var kpis = await GetAllKpisAsync();
        return kpis.IncidentKpis;
    }

    public async Task<PermitKpisDto> GetPermitKpisAsync()
    {
        var kpis = await GetAllKpisAsync();
        return kpis.PermitKpis;
    }

    public async Task<WorkflowKpisDto> GetWorkflowKpisAsync()
    {
        var kpis = await GetAllKpisAsync();
        return kpis.WorkflowKpis;
    }

    public async Task<ActionRegisterKpisDto> GetActionRegisterKpisAsync()
    {
        var kpis = await GetAllKpisAsync();
        return kpis.ActionRegisterKpis;
    }

    public async Task<AuditKpisDto> GetAuditKpisAsync()
    {
        var kpis = await GetAllKpisAsync();
        return kpis.AuditKpis;
    }

    public void PublishKpiUpdate(KpiUpdateEventDto updateEvent)
    {
        // Add to recent updates
        _recentUpdates.Add(updateEvent);

        // Keep collection size manageable
        if (_recentUpdates.Count > MaxRecentUpdates)
        {
            var oldestToRemove = _recentUpdates
                .OrderBy(u => u.Timestamp)
                .FirstOrDefault();
            if (oldestToRemove != null)
                _recentUpdates.TryTake(out oldestToRemove);
        }

        // Notify all subscribers
        foreach (var subscriber in _subscribers)
        {
            try
            {
                subscriber.Invoke(updateEvent);
            }
            catch (Exception ex)
            {
                // Log but don't fail - subscriber issues shouldn't break the system
                Console.WriteLine($"KPI subscriber error: {ex.Message}");
            }
        }

        // Invalidate cache on updates
        _cachedKpis = null;
        _cacheTimestamp = DateTime.MinValue;
    }

    public void SubscribeToUpdates(Action<KpiUpdateEventDto> onUpdate)
    {
        _subscribers.Add(onUpdate);
    }

    public IEnumerable<KpiUpdateEventDto> GetRecentUpdates(int limitMinutes = 5)
    {
        var cutoffTime = DateTime.UtcNow.AddMinutes(-limitMinutes);
        return _recentUpdates
            .Where(u => u.Timestamp >= cutoffTime)
            .OrderByDescending(u => u.Timestamp);
    }

    public async Task InvalidateCacheAsync()
    {
        _cachedKpis = null;
        _cacheTimestamp = DateTime.MinValue;
        await Task.CompletedTask;
    }

    public KpiCacheStatsDto GetCacheStats()
    {
        return new KpiCacheStatsDto
        {
            CacheCreatedAt = _cacheTimestamp,
            MinutesSinceCacheCreation = (int)(DateTime.UtcNow - _cacheTimestamp).TotalMinutes,
            UpdateEventCount = _recentUpdates.Count,
            SubscriberCount = _subscribers.Count
        };
    }
}
