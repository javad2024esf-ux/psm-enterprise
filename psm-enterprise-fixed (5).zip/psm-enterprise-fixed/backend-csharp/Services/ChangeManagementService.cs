using PSM.Api.DTOs;
using PSM.Api.Repositories;

namespace PSM.Api.Services;
public interface IChangeManagementService
{
    Task<string> CreateChangeRequestAsync(CreateChangeRequestDto dto, string userId);
    Task<ChangeRequestDto> GetChangeRequestAsync(string changeId);
    Task<List<ChangeRequestDto>> GetChangeRequestsAsync(ChangeRequestFilterDto filter);
    Task AdvanceWorkflowStageAsync(string changeId, string nextStage, string userId, string comment);
    Task ReturnWorkflowStageAsync(string changeId, string previousStage, string userId, string reason);
    Task AddStageActionAsync(CreateStageActionDto dto);
    Task CompleteStageActionAsync(string actionId, string completedBy, string notes);
    Task LinkHazopAsync(string changeId, string hazopId, string userId);
    Task LinkLopaAsync(string changeId, string lopaId, string userId);
    Task AddTrainingRecordAsync(CreateTrainingRecordDto dto);
    Task CompleteTrainingAsync(string trainingId, string certificateUrl, string notes);
    Task AddPssrItemAsync(string changeId, string item, string category);
    Task VerifyPssrItemAsync(string itemId, string verifiedBy, string notes);
    Task<StartupGateStatusDto> EvaluateStartupReadinessAsync(string changeId);
    Task<bool> CanApproveStartupAsync(string changeId);
    Task ApproveStartupAsync(string changeId, string approvedBy, string comment);
    Task RejectStartupAsync(string changeId, string reason);
    Task<ChangeDashboardMetricsDto> GetDashboardAsync();
    Task<List<WorkflowAuditDto>> GetAuditTrailAsync(string changeId);
    Task<List<ChangeNotificationDto>> GetUserNotificationsAsync(string userId);
}

public class ChangeManagementService : IChangeManagementService
{
    private readonly IChangeManagementRepository _repository;
    private readonly IAuditService _auditService;
    private readonly INotificationService _notificationService;
    private readonly IWorkflowRepository _workflowRepository;

    public ChangeManagementService(
        IChangeManagementRepository repository,
        IAuditService auditService,
        INotificationService notificationService,
        IWorkflowRepository workflowRepository)
    {
        _repository = repository;
        _auditService = auditService;
        _notificationService = notificationService;
        _workflowRepository = workflowRepository;
    }

    public async Task<string> CreateChangeRequestAsync(CreateChangeRequestDto dto, string userId)
    {
        var changeId = await _repository.CreateChangeRequestAsync(dto, userId);

        // Log audit trail
        await _auditService.LogAsync(new AuditLogEntry
        {
            Action = "CREATE_CHANGE",
            Module = "ChangeManagement",
            RecordId = changeId,
            Description = $"Change request created: {dto.Title}",
            UserId = userId
        });

        // Send notification
        await _notificationService.SendAsync(new NotificationDto
        {
            Type = "ChangeCreated",
            Title = "Change Request Created",
            Message = $"New {dto.ChangeType} change: {dto.Title}",
            Recipients = new[] { "role:ChangeManager" }
        });

        return changeId;
    }

    public async Task<ChangeRequestDto> GetChangeRequestAsync(string changeId)
    {
        var change = await _repository.GetChangeRequestAsync(changeId);
        if (change != null)
        {
            // Enrich with gate status
            var gateStatus = await _repository.GetStartupGateStatusAsync(changeId);
            // Add gate status to change metadata as needed
        }
        return change;
    }

    public async Task<List<ChangeRequestDto>> GetChangeRequestsAsync(ChangeRequestFilterDto filter)
    {
        return await _repository.GetChangeRequestsAsync(filter);
    }

    public async Task AdvanceWorkflowStageAsync(string changeId, string nextStage, string userId, string comment)
    {
        var change = await _repository.GetChangeRequestAsync(changeId);
        if (change == null)
            throw new Exception("Change request not found");

        var currentStage = change.CurrentStage;
        var stages = new[] { "PSI_Change", "MOC", "HAZOP_Review", "LOPA_Review", "Procedure_Update", "Training", "PSSR", "Startup_Approval" };

        // Validate transition
        var currentIndex = Array.IndexOf(stages, currentStage);
        var nextIndex = Array.IndexOf(stages, nextStage);

        if (nextIndex != currentIndex + 1)
            throw new Exception("Invalid workflow transition");

        // Get stage and update
        var workflowStage = change.Stages.FirstOrDefault(s => s.StageName == currentStage);
        if (workflowStage == null)
            throw new Exception("Workflow stage not found");

        // Mark current stage as completed
        var updateDto = new UpdateWorkflowStageDto
        {
            StageStatus = "Completed",
            Notes = comment
        };
        await _repository.UpdateWorkflowStageAsync(workflowStage.Id, updateDto);

        // Start next stage
        var nextStageObj = change.Stages.FirstOrDefault(s => s.StageName == nextStage);
        if (nextStageObj != null)
        {
            var startDto = new UpdateWorkflowStageDto
            {
                StageStatus = "In_Progress"
            };
            await _repository.UpdateWorkflowStageAsync(nextStageObj.Id, startDto);
        }

        // Record audit
        await _repository.RecordAuditLogAsync(changeId, "advance_stage", currentStage, nextStage, userId, comment);

        // Notify stakeholders
        await _notificationService.SendAsync(new NotificationDto
        {
            Type = "StageAdvanced",
            Title = "Workflow Stage Advanced",
            Message = $"Change moved from {currentStage} to {nextStage}",
            Recipients = new[] { "role:ChangeTeam" }
        });
    }

    public async Task ReturnWorkflowStageAsync(string changeId, string previousStage, string userId, string reason)
    {
        var change = await _repository.GetChangeRequestAsync(changeId);
        if (change == null)
            throw new Exception("Change request not found");

        var currentStage = change.CurrentStage;

        // Mark current stage as failed
        var workflowStage = change.Stages.FirstOrDefault(s => s.StageName == currentStage);
        if (workflowStage != null)
        {
            var updateDto = new UpdateWorkflowStageDto
            {
                StageStatus = "Failed",
                Notes = reason
            };
            await _repository.UpdateWorkflowStageAsync(workflowStage.Id, updateDto);
        }

        // Reset previous stage
        var prevStageObj = change.Stages.FirstOrDefault(s => s.StageName == previousStage);
        if (prevStageObj != null)
        {
            var resetDto = new UpdateWorkflowStageDto
            {
                StageStatus = "In_Progress"
            };
            await _repository.UpdateWorkflowStageAsync(prevStageObj.Id, resetDto);
        }

        // Record audit
        await _repository.RecordAuditLogAsync(changeId, "return_stage", currentStage, previousStage, userId, reason);
    }

    public async Task AddStageActionAsync(CreateStageActionDto dto)
    {
        await _repository.CreateStageActionAsync(dto);
    }

    public async Task CompleteStageActionAsync(string actionId, string completedBy, string notes)
    {
        await _repository.CompleteActionAsync(actionId, notes, completedBy);
    }

    public async Task LinkHazopAsync(string changeId, string hazopId, string userId)
    {
        await _repository.LinkHazopAsync(changeId, hazopId, userId);

        await _auditService.LogAsync(new AuditLogEntry
        {
            Action = "LINK_HAZOP",
            Module = "ChangeManagement",
            RecordId = changeId,
            Description = $"HAZOP {hazopId} linked to change",
            UserId = userId
        });
    }

    public async Task LinkLopaAsync(string changeId, string lopaId, string userId)
    {
        await _repository.LinkLopaAsync(changeId, lopaId, userId);

        await _auditService.LogAsync(new AuditLogEntry
        {
            Action = "LINK_LOPA",
            Module = "ChangeManagement",
            RecordId = changeId,
            Description = $"LOPA {lopaId} linked to change",
            UserId = userId
        });
    }

    public async Task AddTrainingRecordAsync(CreateTrainingRecordDto dto)
    {
        await _repository.CreateTrainingRecordAsync(dto);

        await _notificationService.SendAsync(new NotificationDto
        {
            Type = "TrainingAssigned",
            Title = "Training Required",
            Message = "You have been assigned training for a change implementation",
            Recipients = new[] { dto.UserId }
        });
    }

    public async Task CompleteTrainingAsync(string trainingId, string certificateUrl, string notes)
    {
        await _repository.CompleteTrainingAsync(trainingId, certificateUrl, notes);
    }

    public async Task AddPssrItemAsync(string changeId, string item, string category)
    {
        await _repository.CreatePssrChecklistAsync(changeId, item, category);
    }

    public async Task VerifyPssrItemAsync(string itemId, string verifiedBy, string notes)
    {
        await _repository.VerifyPssrItemAsync(itemId, verifiedBy, notes);
    }

    /// <summary>
    /// CRITICAL: Evaluates startup readiness based on all gates
    /// </summary>
    public async Task<StartupGateStatusDto> EvaluateStartupReadinessAsync(string changeId)
    {
        // Get or create gate status
        var gateStatus = await _repository.GetStartupGateStatusAsync(changeId);
        if (gateStatus == null)
        {
            // Initialize gate
            var gateId = Guid.NewGuid().ToString();
            // Will be created on first check
        }

        // Check all conditions
        var trainingComplete = await _repository.CheckTrainingCompleteAsync(changeId);
        var pssrComplete = await _repository.CheckPssrCompleteAsync(changeId);
        var hazopClosed = await _repository.CheckHazopActionsClosedAsync(changeId);
        var lopaClosed = await _repository.CheckLopaActionsClosedAsync(changeId);

        // Update gate status
        var updates = new Dictionary<string, object>
        {
            { "training_complete", trainingComplete },
            { "pssr_complete", pssrComplete },
            { "hazop_actions_closed", hazopClosed },
            { "lopa_actions_closed", lopaClosed },
            { "checked_at", DateTime.UtcNow }
        };

        if (gateStatus != null)
        {
            // Update existing gate - would need update method on repository
            // For now, re-fetch
            gateStatus = await _repository.GetStartupGateStatusAsync(changeId);
        }

        // Rebuild blocking issues
        gateStatus.BlockingIssues.Clear();
        if (!trainingComplete)
            gateStatus.BlockingIssues.Add("Training is not complete");
        if (!pssrComplete)
            gateStatus.BlockingIssues.Add("PSSR is not complete");
        if (!hazopClosed)
            gateStatus.BlockingIssues.Add("HAZOP actions are still open");
        if (!lopaClosed)
            gateStatus.BlockingIssues.Add("LOPA actions are still open");

        return gateStatus;
    }

    /// <summary>
    /// CRITICAL: Validates if startup can be approved
    /// Returns false if ANY of the required conditions are not met
    /// </summary>
    public async Task<bool> CanApproveStartupAsync(string changeId)
    {
        // Training must be complete
        var trainingComplete = await _repository.CheckTrainingCompleteAsync(changeId);
        if (!trainingComplete)
            return false;

        // PSSR must be complete
        var pssrComplete = await _repository.CheckPssrCompleteAsync(changeId);
        if (!pssrComplete)
            return false;

        // All HAZOP actions must be closed
        var hazopActionsClosed = await _repository.CheckHazopActionsClosedAsync(changeId);
        if (!hazopActionsClosed)
            return false;

        // All LOPA actions must be closed
        var lopaActionsClosed = await _repository.CheckLopaActionsClosedAsync(changeId);
        if (!lopaActionsClosed)
            return false;

        return true;
    }

    /// <summary>
    /// CRITICAL: Approve startup only if all gates are satisfied
    /// </summary>
    public async Task ApproveStartupAsync(string changeId, string approvedBy, string comment)
    {
        // Validate that startup can be approved
        if (!await CanApproveStartupAsync(changeId))
        {
            // Get details for error message
            var gateStatus = await EvaluateStartupReadinessAsync(changeId);
            var issues = string.Join(", ", gateStatus.BlockingIssues);
            throw new Exception($"Cannot approve startup. Blocking issues: {issues}");
        }

        // Approve
        await _repository.ApproveStartupAsync(changeId, approvedBy, comment);

        // Log audit
        await _auditService.LogAsync(new AuditLogEntry
        {
            Action = "STARTUP_APPROVED",
            Module = "ChangeManagement",
            RecordId = changeId,
            Description = "Startup approved after all gates satisfied",
            UserId = approvedBy
        });

        // Notify stakeholders
        await _notificationService.SendAsync(new NotificationDto
        {
            Type = "StartupApproved",
            Title = "Startup Approved",
            Message = $"Change startup has been approved",
            Recipients = new[] { "role:Operations", "role:Management" }
        });
    }

    public async Task RejectStartupAsync(string changeId, string reason)
    {
        await _repository.RejectStartupAsync(changeId, reason);

        await _auditService.LogAsync(new AuditLogEntry
        {
            Action = "STARTUP_REJECTED",
            Module = "ChangeManagement",
            RecordId = changeId,
            Description = reason
        });
    }

    public async Task<ChangeDashboardMetricsDto> GetDashboardAsync()
    {
        return await _repository.GetDashboardMetricsAsync();
    }

    public async Task<List<WorkflowAuditDto>> GetAuditTrailAsync(string changeId)
    {
        return await _repository.GetAuditHistoryAsync(changeId);
    }

    public async Task<List<ChangeNotificationDto>> GetUserNotificationsAsync(string userId)
    {
        return await _repository.GetNotificationsAsync(userId, unreadOnly: false);
    }
}
