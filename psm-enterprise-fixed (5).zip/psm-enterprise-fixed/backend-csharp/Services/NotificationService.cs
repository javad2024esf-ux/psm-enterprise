using PSM.Api.DTOs;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

// ════════════════════════════════════════════════════════════════════════════
// Interface
// ════════════════════════════════════════════════════════════════════════════
public interface INotificationService
{
    // ── Query ─────────────────────────────────────────────────────────────────
    Task<NotificationPageDto> ListAsync(string userId, bool unreadOnly, int page, int limit);
    Task<long>                UnreadCountAsync(string userId);

    // ── Mutations ─────────────────────────────────────────────────────────────
    Task<bool> MarkReadAsync(string notificationId, string userId);
    Task<int>  MarkAllReadAsync(string userId);
    Task<bool> DeleteAsync(string notificationId, string userId);

    // ── Event hooks (called by WorkflowService, PermitService, AuditService) ──

    /// <summary>General-purpose push — lowest common denominator.</summary>
    Task PushAsync(CreateNotificationRequest req);

    /// <summary>Send notification using NotificationDto (used by ChangeManagementService).</summary>
    Task SendAsync(NotificationDto dto);

    /// <summary>Workflow state-transition notification.</summary>
    Task OnWorkflowTransitionAsync(
        string  recordId,
        string  fromState,
        string  toState,
        string  action,
        string  module,
        string? recipientUserId,
        string  actorName);

    /// <summary>Workflow started notification.</summary>
    Task OnWorkflowStartedAsync(
        string  recordId,
        string  module,
        string? recipientUserId,
        string  actorName);

    /// <summary>Permit lifecycle notification.</summary>
    Task OnPermitEventAsync(
        string  permitId,
        string  eventType,    // CREATED | APPROVED | CLOSED | DELETED
        string  jobTitle,
        string  permitType,
        string? recipientUserId,
        string  actorName);

    /// <summary>Audit-triggered notification (HIGH severity events).</summary>
    Task OnAuditEventAsync(
        string  action,
        string? module,
        string? recordId,
        string? recipientUserId);
}

// ════════════════════════════════════════════════════════════════════════════
// Implementation
// ════════════════════════════════════════════════════════════════════════════
public class NotificationService : INotificationService
{
    private readonly INotificationRepository _repo;
    private readonly ILogger<NotificationService> _log;

    public NotificationService(
        INotificationRepository repo,
        ILogger<NotificationService> log)
    {
        _repo = repo;
        _log  = log;
    }

    // ── List ─────────────────────────────────────────────────────────────────
    public async Task<NotificationPageDto> ListAsync(
        string userId, bool unreadOnly, int page, int limit)
    {
        limit  = Math.Clamp(limit, 1, 100);
        page   = Math.Max(page, 1);
        int offset = (page - 1) * limit;

        var (rows, total, unread) = await _repo.ListAsync(userId, unreadOnly, limit, offset);

        return new NotificationPageDto
        {
            Data        = rows.ToList(),
            Total       = (int)total,
            UnreadCount = (int)unread,
            Page        = page,
            Limit       = limit,
        };
    }

    public Task<long> UnreadCountAsync(string userId) => _repo.UnreadCountAsync(userId);

    // ── Mutations ─────────────────────────────────────────────────────────────
    public Task<bool> MarkReadAsync(string notificationId, string userId) =>
        _repo.MarkReadAsync(notificationId, userId);

    public Task<int> MarkAllReadAsync(string userId) =>
        _repo.MarkAllReadAsync(userId);

    public Task<bool> DeleteAsync(string notificationId, string userId) =>
        _repo.DeleteAsync(notificationId, userId);

    // ── General push ─────────────────────────────────────────────────────────
    public async Task PushAsync(CreateNotificationRequest req)
    {
        try
        {
            await _repo.CreateAsync(req);
        }
        catch (Exception ex)
        {
            // Notifications must never break the main flow
            _log.LogWarning(ex, "Non-fatal: failed to persist notification '{Title}'", req.Title);
        }
    }

    public Task SendAsync(NotificationDto dto) =>
        PushAsync(new CreateNotificationRequest
        {
            UserId   = dto.Recipients != null && dto.Recipients.Length > 0 ? dto.Recipients[0] : dto.UserId,
            Type     = dto.Type ?? "info",
            Title    = dto.Title ?? "",
            Message  = dto.Message ?? "",
            Module   = dto.Module,
            RecordId = dto.RecordId,
        });

    // ── Workflow events ───────────────────────────────────────────────────────
    public Task OnWorkflowStartedAsync(
        string  recordId,
        string  module,
        string? recipientUserId,
        string  actorName) =>
        PushAsync(new CreateNotificationRequest
        {
            UserId   = recipientUserId,
            Type     = "info",
            Title    = $"گردش‌کار جدید — {module}",
            Message  = $"{actorName} یک گردش‌کار جدید برای '{recordId}' در ماژول {module} آغاز کرد.",
            Module   = module,
            RecordId = recordId,
        });

    public Task OnWorkflowTransitionAsync(
        string  recordId,
        string  fromState,
        string  toState,
        string  action,
        string  module,
        string? recipientUserId,
        string  actorName)
    {
        // Determine notification type based on action semantics
        var (type, title) = action.ToLowerInvariant() switch
        {
            "approve" or "approved"
                => ("approval", $"تصویب شد — {module}"),
            "reject" or "rejected"
                => ("warning", $"رد شد — {module}"),
            "close"  or "closed"
                => ("success", $"بسته شد — {module}"),
            "escalate" or "escalated"
                => ("warning", $"تشدید شد — {module}"),
            _   => ("info",    $"انتقال وضعیت — {module}"),
        };

        return PushAsync(new CreateNotificationRequest
        {
            UserId   = recipientUserId,
            Type     = type,
            Title    = title,
            Message  = $"{actorName} اقدام '{action}' را انجام داد: {fromState} → {toState} (رکورد: {recordId}).",
            Module   = module,
            RecordId = recordId,
        });
    }

    // ── Permit events ─────────────────────────────────────────────────────────
    public Task OnPermitEventAsync(
        string  permitId,
        string  eventType,
        string  jobTitle,
        string  permitType,
        string? recipientUserId,
        string  actorName)
    {
        var (type, title, message) = eventType.ToUpperInvariant() switch
        {
            "CREATED" => (
                "info",
                $"مجوز کاری جدید — {permitType}",
                $"مجوز '{jobTitle}' ({permitType}) توسط {actorName} ثبت شد و در انتظار بررسی است."),

            "APPROVED" => (
                "approval",
                $"مجوز تأیید شد — {permitType}",
                $"مجوز '{jobTitle}' توسط {actorName} تأیید شد."),

            "CLOSED" => (
                "success",
                $"مجوز بسته شد — {permitType}",
                $"مجوز '{jobTitle}' توسط {actorName} بسته شد."),

            "DELETED" => (
                "warning",
                $"مجوز حذف شد — {permitType}",
                $"مجوز '{jobTitle}' توسط {actorName} حذف شد."),

            "ESCALATED" => (
                "warning",
                $"مجوز تشدید شد — {permitType}",
                $"مجوز '{jobTitle}' به دلیل تجاوز از SLA تشدید شد."),

            _ => (
                "info",
                $"به‌روزرسانی مجوز — {permitType}",
                $"مجوز '{jobTitle}' توسط {actorName} به‌روز شد ({eventType})."),
        };

        return PushAsync(new CreateNotificationRequest
        {
            UserId   = recipientUserId,
            Type     = type,
            Title    = title,
            Message  = message,
            Module   = "WORK_PERMIT",
            RecordId = permitId,
        });
    }

    // ── Audit-triggered notifications ─────────────────────────────────────────
    // Only HIGH-severity audit events (security, deletions, approvals) generate notifications.
    private static readonly HashSet<string> _auditNotifyActions = new(StringComparer.OrdinalIgnoreCase)
    {
        "DELETE_PERMIT", "APPROVE_PERMIT", "CLOSE_PERMIT",
        "WORKFLOW_TRANSITION", "WORKFLOW_DELETED",
        "LOGIN_FAILED", "UNAUTHORIZED_ACCESS",
        "APPROVE_PSSR", "CLOSE_INCIDENT", "APPROVE_MOC",
    };

    public Task OnAuditEventAsync(
        string  action,
        string? module,
        string? recordId,
        string? recipientUserId)
    {
        if (!_auditNotifyActions.Contains(action))
            return Task.CompletedTask;

        return PushAsync(new CreateNotificationRequest
        {
            UserId   = recipientUserId,
            Type     = action.Contains("FAIL", StringComparison.OrdinalIgnoreCase)
                       || action.Contains("DELETE", StringComparison.OrdinalIgnoreCase)
                       || action.Contains("UNAUTHORIZED", StringComparison.OrdinalIgnoreCase)
                       ? "warning" : "info",
            Title    = $"رویداد سیستمی — {action}",
            Message  = $"اقدام '{action}' در ماژول '{module}' برای رکورد '{recordId}' ثبت شد.",
            Module   = module,
            RecordId = recordId,
        });
    }
}
