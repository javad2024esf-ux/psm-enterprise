using PSM.Api.Data;
using PSM.Api.DTOs;
using PSM.Api.Models;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

/// <summary>
/// Service for managing PSM relationships and cross-module integration.
/// Orchestrates relationship creation, querying, and impact analysis.
/// </summary>
public interface IPsmRelationshipService
{
    // Relationship Lifecycle
    Task<string> CreateRelationshipAsync(CreateRelationshipDto dto, string userId);
    Task UpdateRelationshipAsync(string id, UpdateRelationshipDto dto, string userId);
    Task DeleteRelationshipAsync(string id, string userId);
    Task<PsmRelationshipDto?> GetRelationshipAsync(string id);

    // Querying and Graph Analysis
    Task<RelationshipQueryDto> GetRelationshipGraphAsync(string entityId, string entityType, int maxDepth = 3);
    Task<List<PsmRelationshipDto>> GetEntityRelationshipsAsync(string entityId, string entityType);
    Task<List<PsmRelationshipDto>> GetRelationshipsByTypeAsync(string relationshipType);

    // Bulk Operations
    Task<BulkCreateRelationshipsResultDto> BulkCreateRelationshipsAsync(
        List<CreateRelationshipDto> dtos, string userId, string? batchDescription = null);

    // Analytics and Reporting
    Task<RelationshipStatisticsDto> GetStatisticsAsync();
    Task<ImpactAnalysisResultDto> AnalyzeImpactAsync(string entityId, string entityType);
    Task<EntityComplianceCheckDto> CheckComplianceAsync(string entityId, string entityType);
    Task<List<IntegrationHealthDto>> GetIntegrationHealthAsync();
    Task<CrossModuleFlowDto> GetCrossModuleFlowAsync(string sourceModule, string targetModule);

    // Auto-linking
    Task<int> AutoLinkRelatedEntitiesAsync(string entityId, string entityType, string userId);

    // Validation
    Task<RelationshipValidationResultDto> ValidateRelationshipAsync(CreateRelationshipDto dto);
}

public class PsmRelationshipService : IPsmRelationshipService
{
    private readonly IPsmRelationshipRepository _relationshipRepo;
    private readonly IAuditService _auditService;
    private readonly IDbHelper _db;

    public PsmRelationshipService(
        IPsmRelationshipRepository relationshipRepo,
        IAuditService auditService,
        IDbHelper db)
    {
        _relationshipRepo = relationshipRepo;
        _auditService = auditService;
        _db = db;
    }

    public async Task<string> CreateRelationshipAsync(CreateRelationshipDto dto, string userId)
    {
        // Validate relationship
        var validation = await ValidateRelationshipAsync(dto);
        if (!validation.IsValid)
            throw new InvalidOperationException($"Relationship validation failed: {string.Join(", ", validation.ValidationErrors ?? [])}");

        // Create relationship
        var id = await _relationshipRepo.CreateRelationshipAsync(dto, userId);

        // Audit log
        await _auditService.LogAsync(new AuditLogEntry
        {
            UserId = userId,
            Action = "CREATE_RELATIONSHIP",
            Module = "RelationshipEngine",
            Description = $"Created relationship {dto.RelationshipType} from {dto.SourceEntityType}:{dto.SourceEntityId} to {dto.TargetEntityType}:{dto.TargetEntityId}",
            RecordId = id
        });

        return id;
    }

    public async Task UpdateRelationshipAsync(string id, UpdateRelationshipDto dto, string userId)
    {
        var existing = await GetRelationshipAsync(id);
        if (existing == null)
            throw new InvalidOperationException($"Relationship {id} not found");

        await _relationshipRepo.UpdateRelationshipAsync(id, dto, userId);

        await _auditService.LogAsync(new AuditLogEntry
        {
            UserId = userId,
            Action = "UPDATE_RELATIONSHIP",
            Module = "RelationshipEngine",
            Description = $"Updated relationship {id}",
            RecordId = id
        });
    }

    public async Task DeleteRelationshipAsync(string id, string userId)
    {
        var existing = await GetRelationshipAsync(id);
        if (existing == null)
            throw new InvalidOperationException($"Relationship {id} not found");

        await _relationshipRepo.DeleteRelationshipAsync(id, userId);

        await _auditService.LogAsync(new AuditLogEntry
        {
            UserId = userId,
            Action = "DELETE_RELATIONSHIP",
            Module = "RelationshipEngine",
            Description = $"Deleted relationship {id}",
            RecordId = id
        });
    }

    public Task<PsmRelationshipDto?> GetRelationshipAsync(string id) =>
        _relationshipRepo.GetRelationshipAsync(id);

    public Task<RelationshipQueryDto> GetRelationshipGraphAsync(string entityId, string entityType, int maxDepth = 3) =>
        _relationshipRepo.GetRelationshipGraphAsync(entityId, entityType, maxDepth);

    public async Task<List<PsmRelationshipDto>> GetEntityRelationshipsAsync(string entityId, string entityType)
    {
        var outbound = await _relationshipRepo.GetOutboundRelationshipsAsync(entityId, entityType);
        var inbound = await _relationshipRepo.GetInboundRelationshipsAsync(entityId, entityType);
        return outbound.Concat(inbound).ToList();
    }

    public async Task<List<PsmRelationshipDto>> GetRelationshipsByTypeAsync(string relationshipType) =>
        (await _relationshipRepo.GetRelationshipsByTypeAsync(relationshipType)).ToList();

    public async Task<BulkCreateRelationshipsResultDto> BulkCreateRelationshipsAsync(
        List<CreateRelationshipDto> dtos, string userId, string? batchDescription = null)
    {
        var result = await _relationshipRepo.BulkCreateRelationshipsAsync(dtos, userId, batchDescription);

        await _auditService.LogAsync(new AuditLogEntry
        {
            UserId = userId,
            Action = "BULK_CREATE_RELATIONSHIPS",
            Module = "RelationshipEngine",
            Description = $"Bulk created {result.SuccessCount} relationships ({batchDescription})",
            RecordId = null
        });

        return result;
    }

    public Task<RelationshipStatisticsDto> GetStatisticsAsync() =>
        _relationshipRepo.GetRelationshipStatisticsAsync();

    public async Task<ImpactAnalysisResultDto> AnalyzeImpactAsync(string entityId, string entityType)
    {
        var directImpact = await _relationshipRepo.AnalyzeImpactAsync(entityId, entityType);

        // Enhance with indirect impacts
        var allDirectlyImpacted = new List<string> { entityId };
        var indirectlyImpacted = new List<ImpactedItemDto>();

        foreach (var item in directImpact.DirectlyImpacted)
        {
            if (!allDirectlyImpacted.Contains(item.EntityId))
            {
                allDirectlyImpacted.Add(item.EntityId);
                var secondaryImpact = await _relationshipRepo.AnalyzeImpactAsync(item.EntityId, item.EntityType);
                foreach (var secondary in secondaryImpact.DirectlyImpacted)
                {
                    if (!allDirectlyImpacted.Contains(secondary.EntityId))
                    {
                        var modified = secondary with { HopsFromRoot = 2 };
                        indirectlyImpacted.Add(modified);
                    }
                }
            }
        }

        return directImpact with
        {
            IndirectlyImpacted = indirectlyImpacted,
            TotalImpactedRecords = directImpact.DirectlyImpacted.Count + indirectlyImpacted.Count
        };
    }

    public Task<EntityComplianceCheckDto> CheckComplianceAsync(string entityId, string entityType) =>
        _relationshipRepo.CheckEntityComplianceAsync(entityId, entityType);

    public Task<List<IntegrationHealthDto>> GetIntegrationHealthAsync() =>
        _relationshipRepo.GetIntegrationHealthAsync();

    public Task<CrossModuleFlowDto> GetCrossModuleFlowAsync(string sourceModule, string targetModule) =>
        _relationshipRepo.GetCrossModuleFlowAsync(sourceModule, targetModule);

    public Task<int> AutoLinkRelatedEntitiesAsync(string entityId, string entityType, string userId)
    {
        var autoLinked = 0;

        // Implement auto-linking logic based on entity type and existing relationships
        // Example: If creating a Hazard, auto-link to related Scenarios
        // This would be customized based on your business rules

        return Task.FromResult(autoLinked);
    }

    public Task<RelationshipValidationResultDto> ValidateRelationshipAsync(CreateRelationshipDto dto)
    {
        var errors = new List<string>();
        var warnings = new List<string>();

        // Validate entity types exist and IDs are valid
        if (string.IsNullOrEmpty(dto.SourceEntityType))
            errors.Add("Source entity type is required");

        if (string.IsNullOrEmpty(dto.SourceEntityId))
            errors.Add("Source entity ID is required");

        if (string.IsNullOrEmpty(dto.TargetEntityType))
            errors.Add("Target entity type is required");

        if (string.IsNullOrEmpty(dto.TargetEntityId))
            errors.Add("Target entity ID is required");

        // Prevent self-relationships (usually not desired)
        if (dto.SourceEntityId == dto.TargetEntityId && dto.SourceEntityType == dto.TargetEntityType)
            warnings.Add("Self-relationship detected");

        // Check if relationship already exists
        // This would need implementation based on your schema

        // Validate relationship type matches entity types
        var isValidMapping = ValidateRelationshipTypeMapping(
            dto.RelationshipType,
            dto.SourceEntityType,
            dto.TargetEntityType);

        if (!isValidMapping)
            errors.Add($"Invalid relationship mapping: {dto.RelationshipType} doesn't support {dto.SourceEntityType}->{dto.TargetEntityType}");

        return Task.FromResult(new RelationshipValidationResultDto(
            errors.Count == 0,
            errors.Count > 0 ? errors : null,
            warnings.Count > 0 ? warnings : null));
    }

    private bool ValidateRelationshipTypeMapping(string relationshipType, string sourceType, string targetType)
    {
        // This implements business logic to validate relationship types
        // Example mappings:
        var validMappings = new Dictionary<string, (string Source, string Target)[]>
        {
            ["PsiToHazop"] = new[] { ("PSI", "Hazard"), ("PSI", "Scenario") },
            ["HazopToLopa"] = new[] { ("Hazard", "Scenario"), ("Scenario", "Barrier") },
            ["LopaToBarrier"] = new[] { ("Scenario", "Barrier") },
            ["HazardToScenario"] = new[] { ("Hazard", "Scenario") },
            ["ScenarioToBarrier"] = new[] { ("Scenario", "Barrier") },
            ["ActionItemToHazard"] = new[] { ("ActionItem", "Hazard"), ("ActionItem", "Scenario") },
            // Add more mappings as needed
        };

        if (!validMappings.ContainsKey(relationshipType))
            return true; // Allow unmapped types (be permissive)

        var mapping = validMappings[relationshipType];
        return mapping.Any(m => m.Source == sourceType && m.Target == targetType);
    }
}

/// <summary>
/// Service for domain entity operations.
/// Handles creation, update, and management of core PSM entities.
/// </summary>
public interface IPsmDomainEntityService
{
    Task<string> CreateAssetAsync(CreateAssetDto dto, string userId);
    Task<AssetDto?> GetAssetAsync(string id);
    Task<List<AssetDto>> ListAssetsAsync(string? unit = null);

    Task<string> CreateProcessUnitAsync(ProcessUnitDto dto, string userId);
    Task<ProcessUnitDto?> GetProcessUnitAsync(string id);
    Task<List<ProcessUnitDto>> ListProcessUnitsAsync();

    Task<string> CreateHazardAsync(HazardDto dto, string userId);
    Task<HazardDto?> GetHazardAsync(string id);
    Task<List<HazardDto>> ListHazardsAsync(string? processUnitId = null);

    Task<string> CreateActionItemAsync(ActionItemDto dto, string userId);
    Task<ActionItemDto?> GetActionItemAsync(string id);
    Task UpdateActionItemAsync(string id, ActionItemDto dto, string userId);
    Task<List<ActionItemDto>> ListActionItemsAsync(string? sourceModule = null, string? status = null);
}

public class PsmDomainEntityService : IPsmDomainEntityService
{
    private readonly IPsmDomainEntityRepository _entityRepo;
    private readonly IAuditService _auditService;

    public PsmDomainEntityService(
        IPsmDomainEntityRepository entityRepo,
        IAuditService auditService)
    {
        _entityRepo = entityRepo;
        _auditService = auditService;
    }

    public async Task<string> CreateAssetAsync(CreateAssetDto dto, string userId)
    {
        var id = await _entityRepo.CreateAssetAsync(dto, userId);

        await _auditService.LogAsync(new AuditLogEntry
        {
            UserId = userId,
            Action = "CREATE_ASSET",
            Module = "RelationshipEngine",
            Description = $"Created asset {dto.Name}",
            RecordId = id
        });

        return id;
    }

    public Task<AssetDto?> GetAssetAsync(string id) =>
        _entityRepo.GetAssetAsync(id);

    public async Task<List<AssetDto>> ListAssetsAsync(string? unit = null) =>
        (await _entityRepo.ListAssetsAsync(unit)).ToList();

    public async Task<string> CreateProcessUnitAsync(ProcessUnitDto dto, string userId)
    {
        var id = await _entityRepo.CreateProcessUnitAsync(dto, userId);

        await _auditService.LogAsync(new AuditLogEntry
        {
            UserId = userId,
            Action = "CREATE_PROCESS_UNIT",
            Module = "RelationshipEngine",
            Description = $"Created process unit {dto.Name}",
            RecordId = id
        });

        return id;
    }

    public Task<ProcessUnitDto?> GetProcessUnitAsync(string id) =>
        _entityRepo.GetProcessUnitAsync(id);

    public async Task<List<ProcessUnitDto>> ListProcessUnitsAsync() =>
        (await _entityRepo.ListProcessUnitsAsync()).ToList();

    public async Task<string> CreateHazardAsync(HazardDto dto, string userId)
    {
        var id = await _entityRepo.CreateHazardAsync(dto, userId);

        await _auditService.LogAsync(new AuditLogEntry
        {
            UserId = userId,
            Action = "CREATE_HAZARD",
            Module = "RelationshipEngine",
            Description = $"Created hazard {dto.Name} in category {dto.HazardCategory}",
            RecordId = id
        });

        return id;
    }

    public Task<HazardDto?> GetHazardAsync(string id) =>
        _entityRepo.GetHazardAsync(id);

    public async Task<List<HazardDto>> ListHazardsAsync(string? processUnitId = null) =>
        (await _entityRepo.ListHazardsAsync(processUnitId)).ToList();

    public async Task<string> CreateActionItemAsync(ActionItemDto dto, string userId)
    {
        var id = await _entityRepo.CreateActionItemAsync(dto, userId);

        await _auditService.LogAsync(new AuditLogEntry
        {
            UserId = userId,
            Action = "CREATE_ACTION_ITEM",
            Module = "RelationshipEngine",
            Description = $"Created action item {dto.Title} ({dto.Priority} priority, due {dto.DueDate:yyyy-MM-dd})",
            RecordId = id
        });

        return id;
    }

    public Task<ActionItemDto?> GetActionItemAsync(string id) =>
        _entityRepo.GetActionItemAsync(id);

    public async Task UpdateActionItemAsync(string id, ActionItemDto dto, string userId)
    {
        var updated = await _entityRepo.UpdateActionItemAsync(id, dto);
        if (!updated)
            throw new InvalidOperationException($"Action item {id} not found");

        await _auditService.LogAsync(new AuditLogEntry
        {
            UserId = userId,
            Action = "UPDATE_ACTION_ITEM",
            Module = "RelationshipEngine",
            Description = $"Updated action item {id}",
            RecordId = id
        });
    }

    public async Task<List<ActionItemDto>> ListActionItemsAsync(string? sourceModule = null, string? status = null) =>
        (await _entityRepo.ListActionItemsAsync(sourceModule, status)).ToList();
}

/// <summary>
/// Service for cross-module integration orchestration.
/// Automatically links related entities across modules.
/// </summary>
public interface ICrossModuleIntegrationService
{
    Task<int> LinkHazopToLopaAsync(string hazopId, string lopaId, string userId);
    Task<int> LinkHazopToBowTieAsync(string hazopId, string bowTieId, string userId);
    Task<int> LinkIncidentToBowTieAsync(string incidentId, string bowTieId, string userId);
    Task<int> LinkAuditToActionsAsync(string auditId, List<string> actionIds, string userId);
    Task<int> LinkMocToPSSRAsync(string mocId, string pssrId, string userId);
    Task<int> SyncActionItemsAsync(string sourceId, string sourceModule, string userId);
}

public class CrossModuleIntegrationService : ICrossModuleIntegrationService
{
    private readonly IPsmRelationshipService _relationshipService;
    private readonly IAuditService _auditService;

    public CrossModuleIntegrationService(
        IPsmRelationshipService relationshipService,
        IAuditService auditService)
    {
        _relationshipService = relationshipService;
        _auditService = auditService;
    }

    public async Task<int> LinkHazopToLopaAsync(string hazopId, string lopaId, string userId)
    {
        var dto = new CreateRelationshipDto(
            "HazopToLopa",
            "Hazard",
            hazopId,
            "Scenario",
            lopaId);

        await _relationshipService.CreateRelationshipAsync(dto, userId);
        return 1;
    }

    public async Task<int> LinkHazopToBowTieAsync(string hazopId, string bowTieId, string userId)
    {
        var dto = new CreateRelationshipDto(
            "HazopToBowTie",
            "Hazard",
            hazopId,
            "Barrier",
            bowTieId);

        await _relationshipService.CreateRelationshipAsync(dto, userId);
        return 1;
    }

    public async Task<int> LinkIncidentToBowTieAsync(string incidentId, string bowTieId, string userId)
    {
        var dto = new CreateRelationshipDto(
            "IncidentToBowTie",
            "Incident",
            incidentId,
            "Barrier",
            bowTieId);

        await _relationshipService.CreateRelationshipAsync(dto, userId);
        return 1;
    }

    public async Task<int> LinkAuditToActionsAsync(string auditId, List<string> actionIds, string userId)
    {
        var count = 0;
        foreach (var actionId in actionIds)
        {
            var dto = new CreateRelationshipDto(
                "AuditToActionItems",
                "Audit",
                auditId,
                "ActionItem",
                actionId);

            await _relationshipService.CreateRelationshipAsync(dto, userId);
            count++;
        }

        await _auditService.LogAsync(new AuditLogEntry
        {
            UserId = userId,
            Action = "LINK_AUDIT_TO_ACTIONS",
            Module = "RelationshipEngine",
            Description = $"Linked {count} action items to audit {auditId}",
            RecordId = auditId
        });

        return count;
    }

    public async Task<int> LinkMocToPSSRAsync(string mocId, string pssrId, string userId)
    {
        var dto = new CreateRelationshipDto(
            "MocToPSSR",
            "ChangeRequest",
            mocId,
            "Barrier",
            pssrId);

        await _relationshipService.CreateRelationshipAsync(dto, userId);
        return 1;
    }

    public async Task<int> SyncActionItemsAsync(string sourceId, string sourceModule, string userId)
    {
        // Sync action items from a source module (e.g., HAZOP findings -> Action Items)
        var count = 0;

        // Implementation would fetch source findings and create corresponding action items

        await _auditService.LogAsync(new AuditLogEntry
        {
            UserId = userId,
            Action = "SYNC_ACTION_ITEMS",
            Module = "RelationshipEngine",
            Description = $"Synced {count} action items from {sourceModule}",
            RecordId = sourceId
        });

        return count;
    }
}
