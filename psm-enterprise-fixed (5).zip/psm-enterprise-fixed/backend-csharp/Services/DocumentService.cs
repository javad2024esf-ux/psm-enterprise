using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Configuration;
using PSM.Api.Models;
using PSM.Api.Repositories;

namespace PSM.Api.Services;

// ════════════════════════════════════════════════════════════════════════════
// Interface
// ════════════════════════════════════════════════════════════════════════════
public interface IDocumentService
{
    Task<bool> CheckPermAsync(string role, PsmAction action);

    Task<DocumentListResponse> ListAsync(
        string? module, string? tag, int page, int limit);

    Task<DocumentDto?> GetAsync(string id);

    /// <summary>
    /// Persists the file to disk under DataDir/documents/ and inserts a row
    /// in the documents table. Returns the new document DTO.
    /// </summary>
    Task<DocumentDto> UploadAsync(
        IFormFile    file,
        string?      module,
        string[]?    tags,
        string       userId);

    /// <summary>
    /// Removes both the DB row and the physical file.
    /// Returns false when the document does not exist.
    /// </summary>
    Task<bool> DeleteAsync(string id, string userId);

    /// <summary>
    /// Resolves the absolute filesystem path for streaming a download.
    /// Returns null when the document or its physical file is missing.
    /// </summary>
    Task<(string AbsolutePath, string MimeType, string FileName)?> ResolveDownloadAsync(string id);
}

// ════════════════════════════════════════════════════════════════════════════
// Implementation
// ════════════════════════════════════════════════════════════════════════════
public class DocumentService : IDocumentService
{
    private readonly IDocumentRepository   _repo;
    private readonly IPermissionService    _perms;
    private readonly IAuditService         _audit;
    private readonly AppConfig             _config;
    private readonly ILogger<DocumentService> _log;

    private const string Module = "Documents";

    // Allowed MIME types — extend as needed
    private static readonly HashSet<string> AllowedMime = new(StringComparer.OrdinalIgnoreCase)
    {
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-powerpoint",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "text/plain",
        "text/csv",
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp",
        "image/svg+xml",
        "application/zip",
        "application/x-zip-compressed",
    };

    private const long MaxFileSizeBytes = 100L * 1024 * 1024; // 100 MB (matches nginx)

    public DocumentService(
        IDocumentRepository      repo,
        IPermissionService       perms,
        IAuditService            audit,
        AppConfig                config,
        ILogger<DocumentService> log)
    {
        _repo   = repo;
        _perms  = perms;
        _audit  = audit;
        _config = config;
        _log    = log;
    }

    // ── RBAC ─────────────────────────────────────────────────────────────────
    public Task<bool> CheckPermAsync(string role, PsmAction action) =>
        _perms.CheckPermissionAsync(role, Module, action);

    // ── List ─────────────────────────────────────────────────────────────────
    public async Task<DocumentListResponse> ListAsync(
        string? module, string? tag, int page, int limit)
    {
        limit  = Math.Clamp(limit, 1, 100);
        page   = Math.Max(page, 1);
        int offset = (page - 1) * limit;

        var (rows, total) = await _repo.ListAsync(module, tag, limit, offset);

        return new DocumentListResponse
        {
            Data  = rows.ToList(),
            Total = (int)total,
            Page  = page,
            Limit = limit,
        };
    }

    // ── Get ───────────────────────────────────────────────────────────────────
    public Task<DocumentDto?> GetAsync(string id) => _repo.GetByIdAsync(id);

    // ── Upload ────────────────────────────────────────────────────────────────
    public async Task<DocumentDto> UploadAsync(
        IFormFile file, string? module, string[]? tags, string userId)
    {
        // --- Validation ---
        if (file.Length == 0)
            throw new ArgumentException("File is empty.");

        if (file.Length > MaxFileSizeBytes)
            throw new ArgumentException(
                $"File exceeds maximum allowed size of {MaxFileSizeBytes / 1024 / 1024} MB.");

        var mime = ResolveMime(file);
        if (!AllowedMime.Contains(mime))
            throw new ArgumentException($"File type '{mime}' is not permitted.");

        // --- Storage path ---
        var docsDir = Path.Combine(_config.DataDir, "documents");
        Directory.CreateDirectory(docsDir);

        var ext      = Path.GetExtension(file.FileName);
        var safeId   = $"doc_{Guid.NewGuid():N}";
        var fileName = $"{safeId}{ext}";
        var absPath  = Path.Combine(docsDir, fileName);
        // Relative path stored in DB (DataDir-relative) so it survives container restarts
        var relPath  = Path.Combine("documents", fileName);

        // --- Write file ---
        await using (var stream = new FileStream(absPath, FileMode.Create, FileAccess.Write, FileShare.None))
            await file.CopyToAsync(stream);

        // --- DB row ---
        try
        {
            await _repo.CreateAsync(
                safeId,
                SanitizeFileName(file.FileName),
                module,
                tags,
                relPath,
                file.Length,
                mime,
                userId);
        }
        catch
        {
            // Clean up orphaned file if DB insert fails
            TryDeletePhysical(absPath);
            throw;
        }

        await _audit.WriteAsync(userId, "UPLOAD_DOCUMENT", Module, safeId,
            $"Uploaded '{file.FileName}' ({file.Length} bytes, {mime})");

        return (await _repo.GetByIdAsync(safeId))!;
    }

    // ── Delete ────────────────────────────────────────────────────────────────
    public async Task<bool> DeleteAsync(string id, string userId)
    {
        var storedPath = await _repo.DeleteAsync(id);
        if (storedPath is null) return false;

        // Remove physical file (best-effort; log but don't throw)
        var absPath = ResolveAbsolute(storedPath);
        TryDeletePhysical(absPath);

        await _audit.WriteAsync(userId, "DELETE_DOCUMENT", Module, id,
            $"Deleted document, stored path: {storedPath}");

        return true;
    }

    // ── Download resolution ───────────────────────────────────────────────────
    public async Task<(string AbsolutePath, string MimeType, string FileName)?> ResolveDownloadAsync(string id)
    {
        var doc = await _repo.GetByIdAsync(id);
        if (doc is null || doc.FilePath is null) return null;

        var abs = ResolveAbsolute(doc.FilePath);
        if (!File.Exists(abs)) return null;

        return (abs, doc.MimeType ?? "application/octet-stream", doc.Name);
    }

    // ════════════════════════════════════════════════════════════════════════
    // Private helpers
    // ════════════════════════════════════════════════════════════════════════

    /// <summary>Convert a DataDir-relative path back to an absolute filesystem path.</summary>
    private string ResolveAbsolute(string storedPath)
    {
        // Stored path may already be absolute (legacy/demo seed rows like /demo/docs/…)
        if (Path.IsPathRooted(storedPath)) return storedPath;
        return Path.Combine(_config.DataDir, storedPath);
    }

    private void TryDeletePhysical(string absPath)
    {
        try
        {
            if (File.Exists(absPath))
                File.Delete(absPath);
        }
        catch (Exception ex)
        {
            _log.LogWarning(ex, "Could not delete physical file at '{Path}'", absPath);
        }
    }

    /// <summary>
    /// Determine MIME: trust Content-Type header if valid, otherwise sniff extension.
    /// </summary>
    private static string ResolveMime(IFormFile file)
    {
        var ct = file.ContentType?.Trim().Split(';')[0].Trim();
        if (!string.IsNullOrEmpty(ct) && ct != "application/octet-stream")
            return ct;

        return Path.GetExtension(file.FileName).ToLowerInvariant() switch
        {
            ".pdf"  => "application/pdf",
            ".doc"  => "application/msword",
            ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".xls"  => "application/vnd.ms-excel",
            ".xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".ppt"  => "application/vnd.ms-powerpoint",
            ".pptx" => "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            ".txt"  => "text/plain",
            ".csv"  => "text/csv",
            ".jpg" or ".jpeg" => "image/jpeg",
            ".png"  => "image/png",
            ".gif"  => "image/gif",
            ".webp" => "image/webp",
            ".svg"  => "image/svg+xml",
            ".zip"  => "application/zip",
            _       => "application/octet-stream",
        };
    }

    /// <summary>Strip path separators so the stored name is safe.</summary>
    private static string SanitizeFileName(string raw) =>
        Path.GetFileName(raw.Replace('\\', '/')) is { Length: > 0 } s ? s : "unnamed";
}
