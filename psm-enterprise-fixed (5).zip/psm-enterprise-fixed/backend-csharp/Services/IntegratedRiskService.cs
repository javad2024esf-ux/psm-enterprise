using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Repositories;
using System.Text.Json;

namespace PSM.Api.Services;

// ════════════════════════════════════════════════════════════════════════════════════
// BARRIER SERVICE INTERFACE
// ════════════════════════════════════════════════════════════════════════════════════

public interface IBarrierService
{
    // CRUD
    Task<BarrierDto> CreateBarrierAsync(CreateBarrierRequest req);
    Task<BarrierDto?> GetBarrierAsync(string id);
    Task<BarrierDto?> GetBarrierByLopaIplAsync(string lopaIplId);
    Task<IEnumerable<BarrierDto>> ListBarriersAsync(string? statusFilter = null);
    Task<IEnumerable<BarrierWithRelatedAnalysisDto>> ListBarriersWithAnalysisAsync();
    Task UpdateBarrierAsync(string id, UpdateBarrierRequest req);
    
    // Status management with cascade
    Task<(bool success, string message)> UpdateBarrierStatusAsync(string id, UpdateBarrierStatusRequest req, string userId);
    
    // History
    Task<IEnumerable<BarrierStatusHistoryDto>> GetBarrierStatusHistoryAsync(string barrierId);
    
    // Analytics
    Task<Dictionary<string, int>> GetBarrierStatusDistributionAsync();
    Task<int> GetCriticalBarrierCountAsync();
    
    // Permissions
    Task<bool> CheckPermAsync(string role, PsmAction action);
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT SERVICE INTERFACE
// ════════════════════════════════════════════════════════════════════════════════════

public interface IIncidentService
{
    // CRUD
    Task<IncidentDto> CreateIncidentAsync(CreateIncidentRequest req);
    Task<IncidentDto?> GetIncidentAsync(string id);
    Task<IEnumerable<IncidentDto>> ListIncidentsAsync(string? statusFilter = null, int page = 1);
    Task UpdateIncidentAsync(string id, UpdateIncidentRequest req);
    Task<bool> CloseIncidentAsync(string id, CloseIncidentRequest req);
    
    // Barrier linking
    Task<IncidentBarrierDto> LinkBarrierAsync(CreateIncidentBarrierRequest req);
    Task<IEnumerable<IncidentBarrierDto>> GetIncidentBarriersAsync(string incidentId);
    
    // Analysis linking
    Task<IncidentHazopMappingDto> LinkHazopAsync(CreateIncidentHazopMappingRequest req);
    Task<IncidentLopaMappingDto> LinkLopaAsync(CreateIncidentLopaMappingRequest req);
    Task<IncidentBowTieMappingDto> LinkBowTieAsync(CreateIncidentBowTieMappingRequest req);
    
    // Analytics
    Task<Dictionary<string, int>> GetIncidentTypeDistributionAsync();
    Task<int> GetOpenIncidentsCountAsync();

    /// <summary>
    /// Creates action register items from all recommendations in an Incident.
    /// Creates separate actions for: Immediate, Corrective, and Preventive recommendations.
    /// Each action is automatically linked to the incident via Source=Incident, SourceId=incidentId.
    /// Triggers Workflow and Audit for each action created.
    /// </summary>
    /// <param name="incidentId">The incident ID</param>
    /// <param name="userId">User creating the actions (for audit trail)</param>
    /// <returns>List of created ActionRegisterDto items</returns>
    /// <exception cref="KeyNotFoundException">If incident not found</exception>
    Task<IEnumerable<ActionRegisterDto>> CreateActionsFromRecommendationsAsync(
        string incidentId, string userId);
}

// ════════════════════════════════════════════════════════════════════════════════════
// INTEGRATED RISK SERVICE INTERFACE
// ════════════════════════════════════════════════════════════════════════════════════

public interface IIntegratedRiskService
{
    // When LOPA IPL is created, create Barrier record automatically (called from LopaService
    // right after a new IPL is persisted).
    Task<BarrierDto> CreateBarrierFromLopaIplAsync(string lopaIplId, string barrierName,
        string barrierType, string? description);

    /// <summary>
    /// Auto-creates a unified risk Barrier from a freshly created LOPA IPL. Derives the barrier
    /// name/type from the IPL itself, and — if the parent LOPA scenario is already linked to a
    /// BowTie diagram — also creates a matching BowTie barrier and cross-links the two records so
    /// that a later barrier-status change cascades to both the LOPA IPL and the BowTie diagram.
    /// </summary>
    Task<BarrierDto> CreateBarrierFromIplAsync(string lopaIplId, LopaIplDto ipl,
        string scenarioId, string? hazopDeviationId, string changedBy);

    // When HAZOP scenario (deviation) created, allow LOPA/BowTie creation directly from it.
    Task<CreateLopaFromHazopResultDto> CreateLopaFromHazopAsync(CreateLopaFromHazopRequest req);
    Task<CreateBowTieFromHazopResultDto> CreateBowTieFromHazopAsync(CreateBowTieFromHazopRequest req);

    // When barrier fails, cascade updates
    Task<BarrierFailureImpactDto> HandleBarrierFailureAsync(string barrierId, string reason,
        string userId);

    // When incident references barrier, show affected analyses
    Task<IncidentDetailedAnalysisDto> GetIncidentImpactAnalysisAsync(string incidentId);

    // Cross-analysis queries
    Task<BarrierFailureImpactDto> GetBarrierImpactAsync(string barrierId);
    Task<IEnumerable<IncidentDto>> FindRelatedIncidentsAsync(string? hazopId = null,
        string? lopaId = null, string? bowTieId = null);

    // Batch operations
    Task<BatchOperationResultDto> BatchLinkBarriersToIncidentAsync(
        BatchCreateIncidentBarriersRequest req);
    Task<BatchOperationResultDto> BatchUpdateBarrierStatusAsync(
        BatchUpdateBarrierStatusRequest req, string userId);
}

// ════════════════════════════════════════════════════════════════════════════════════
// BARRIER SERVICE IMPLEMENTATION
// ════════════════════════════════════════════════════════════════════════════════════

public class BarrierService : IBarrierService
{
    private readonly IBarrierRepository _barrierRepo;
    private readonly IPermissionService _perms;
    private const string Module = "BARRIERS";

    public BarrierService(IBarrierRepository barrierRepo, IPermissionService perms)
    {
        _barrierRepo = barrierRepo;
        _perms = perms;
    }

    public async Task<BarrierDto> CreateBarrierAsync(CreateBarrierRequest req)
    {
        var id = Guid.NewGuid().ToString();
        return await _barrierRepo.CreateBarrierAsync(
            id, req.lopa_ipl_id!, req.bowtie_barrier_id, req.barrier_name ?? "Untitled",
            req.barrier_type ?? "Engineering", req.description, req.owner_discipline,
            req.owner_contact, req.maintenance_frequency, req.last_tested, req.next_test_due,
            req.effectiveness_rating ?? 0.9m, req.status ?? "Active", req.failure_mode,
            req.documentation_ref, req.sil_level, req.critical_flag ?? false,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>())
        );
    }

    public Task<BarrierDto?> GetBarrierAsync(string id) =>
        _barrierRepo.GetBarrierAsync(id);

    public Task<BarrierDto?> GetBarrierByLopaIplAsync(string lopaIplId) =>
        _barrierRepo.GetBarrierByLopaIplAsync(lopaIplId);

    public Task<IEnumerable<BarrierDto>> ListBarriersAsync(string? statusFilter = null) =>
        _barrierRepo.ListBarriersAsync(statusFilter);

    public Task<IEnumerable<BarrierWithRelatedAnalysisDto>> ListBarriersWithAnalysisAsync() =>
        _barrierRepo.ListBarriersWithAnalysisAsync();

    public async Task UpdateBarrierAsync(string id, UpdateBarrierRequest req)
    {
        await _barrierRepo.UpdateBarrierAsync(
            id, req.barrier_name, req.barrier_type, req.description,
            req.owner_discipline, req.owner_contact, req.maintenance_frequency,
            req.last_tested, req.next_test_due, req.effectiveness_rating,
            req.documentation_ref, req.sil_level, req.critical_flag,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>()), null
        );
    }

    public async Task<(bool success, string message)> UpdateBarrierStatusAsync(
        string id, UpdateBarrierStatusRequest req, string userId)
    {
        // Use cascade update to update BowTie and LOPA statuses
        return await _barrierRepo.UpdateBarrierStatusCascadeAsync(
            id, req.new_status ?? "Active", req.reason, req.incident_id, userId
        );
    }

    public Task<IEnumerable<BarrierStatusHistoryDto>> GetBarrierStatusHistoryAsync(string barrierId) =>
        _barrierRepo.GetBarrierStatusHistoryAsync(barrierId);

    public Task<Dictionary<string, int>> GetBarrierStatusDistributionAsync() =>
        _barrierRepo.GetBarrierStatusDistributionAsync();

    public Task<int> GetCriticalBarrierCountAsync() =>
        _barrierRepo.GetCriticalBarrierCountAsync();

    public Task<bool> CheckPermAsync(string role, PsmAction action) =>
        _perms.CheckPermissionAsync(role, Module, action);
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT SERVICE IMPLEMENTATION
// ════════════════════════════════════════════════════════════════════════════════════

public class IncidentService : IIncidentService
{
    private readonly IIncidentRepository _incidentRepo;
    private readonly IIncidentBarrierRepository _incidentBarrierRepo;
    private readonly IIncidentHazopRepository _incidentHazopRepo;
    private readonly IIncidentLopaRepository _incidentLopaRepo;
    private readonly IIncidentBowTieRepository _incidentBowTieRepo;
    private readonly IActionRegisterService _actionRegisterService;
    private readonly IPermissionService _perms;
    private const string Module = "Incident";

    public IncidentService(
        IIncidentRepository incidentRepo,
        IIncidentBarrierRepository incidentBarrierRepo,
        IIncidentHazopRepository incidentHazopRepo,
        IIncidentLopaRepository incidentLopaRepo,
        IIncidentBowTieRepository incidentBowTieRepo,
        IActionRegisterService actionRegisterService,
        IPermissionService perms)
    {
        _incidentRepo = incidentRepo;
        _incidentBarrierRepo = incidentBarrierRepo;
        _incidentHazopRepo = incidentHazopRepo;
        _incidentLopaRepo = incidentLopaRepo;
        _incidentBowTieRepo = incidentBowTieRepo;
        _actionRegisterService = actionRegisterService;
        _perms = perms;
    }

    public async Task<IncidentDto> CreateIncidentAsync(CreateIncidentRequest req)
    {
        var id = Guid.NewGuid().ToString();
        return await _incidentRepo.CreateIncidentAsync(
            id, req.incident_number ?? $"INC-{DateTime.UtcNow:yyyyMMdd-HHmmss}",
            req.title ?? "Untitled", req.description, req.facility, req.unit,
            req.date_occurred ?? DateTime.UtcNow, req.reporter_name, req.reporter_contact,
            req.incident_type ?? "Other", req.severity_actual ?? 3, req.root_cause,
            req.immediate_actions, req.corrective_actions, req.preventive_actions,
            req.status ?? "Reported", req.investigation_lead, req.lessons_learned,
            req.shared_with_industry ?? false,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>())
        );
    }

    public Task<IncidentDto?> GetIncidentAsync(string id) =>
        _incidentRepo.GetIncidentAsync(id);

    public Task<IEnumerable<IncidentDto>> ListIncidentsAsync(string? statusFilter = null, int page = 1) =>
        _incidentRepo.ListIncidentsAsync(statusFilter: statusFilter, pageNumber: page);

    public async Task UpdateIncidentAsync(string id, UpdateIncidentRequest req)
    {
        await _incidentRepo.UpdateIncidentAsync(
            id, req.title, req.description, req.facility, req.unit, req.root_cause,
            req.immediate_actions, req.corrective_actions, req.preventive_actions,
            req.status, req.investigation_lead, req.lessons_learned, req.shared_with_industry,
            JsonSerializer.Serialize(req.data ?? new Dictionary<string, object>())
        );
    }

    public async Task<bool> CloseIncidentAsync(string id, CloseIncidentRequest req) =>
        await _incidentRepo.CloseIncidentAsync(id, req.lessons_learned);

    public async Task<IncidentBarrierDto> LinkBarrierAsync(CreateIncidentBarrierRequest req)
    {
        return await _incidentBarrierRepo.CreateIncidentBarrierAsync(
            Guid.NewGuid().ToString(), req.incident_id!, req.barrier_id!,
            req.barrier_failure_type, req.failure_evidence, req.contribution_to_incident
        );
    }

    public Task<IEnumerable<IncidentBarrierDto>> GetIncidentBarriersAsync(string incidentId) =>
        _incidentBarrierRepo.GetIncidentBarriersAsync(incidentId);

    public async Task<IncidentHazopMappingDto> LinkHazopAsync(CreateIncidentHazopMappingRequest req)
    {
        return await _incidentHazopRepo.CreateMappingAsync(
            Guid.NewGuid().ToString(), req.incident_id!, req.hazop_deviation_id!,
            req.hazop_study_id!, req.relevance_score ?? 0.8m, req.notes
        );
    }

    public async Task<IncidentLopaMappingDto> LinkLopaAsync(CreateIncidentLopaMappingRequest req)
    {
        return await _incidentLopaRepo.CreateMappingAsync(
            Guid.NewGuid().ToString(), req.incident_id!, req.lopa_scenario_id!,
            req.lopa_study_id!, req.relevance_score ?? 0.8m, req.ipl_failure_count, req.notes
        );
    }

    public async Task<IncidentBowTieMappingDto> LinkBowTieAsync(CreateIncidentBowTieMappingRequest req)
    {
        return await _incidentBowTieRepo.CreateMappingAsync(
            Guid.NewGuid().ToString(), req.incident_id!, req.bowtie_diagram_id!,
            req.top_event_occurred ?? true, req.barriers_failed, req.relevance_score ?? 0.8m, req.notes
        );
    }

    public Task<Dictionary<string, int>> GetIncidentTypeDistributionAsync() =>
        _incidentRepo.GetIncidentTypeDistributionAsync();

    public Task<int> GetOpenIncidentsCountAsync() =>
        _incidentRepo.GetOpenIncidentsAsync();

    public async Task<IEnumerable<ActionRegisterDto>> CreateActionsFromRecommendationsAsync(
        string incidentId, string userId)
    {
        // Fetch the incident
        var incident = await _incidentRepo.GetIncidentAsync(incidentId)
            ?? throw new KeyNotFoundException($"حادثه '{incidentId}' یافت نشد");

        var createdActions = new List<ActionRegisterDto>();

        // Helper function to create action if recommendation exists
        async Task TryCreateAction(string recommendationType, string? recommendationText)
        {
            if (string.IsNullOrWhiteSpace(recommendationText))
                return;

            var req = new CreateActionFromIncidentRequest
            {
                IncidentId = incidentId,
                RecommendationType = recommendationType,
                RecommendationText = recommendationText.Trim(),
                Priority = "High",
                Responsible = incident.InvestigationLead,
                DueDate = DateTime.UtcNow.AddDays(30)
            };

            var action = await _actionRegisterService.CreateFromIncidentRecommendationAsync(req, userId);
            createdActions.Add(action);
        }

        // Create actions from each recommendation type
        await TryCreateAction("immediate", incident.ImmediateActions);
        await TryCreateAction("corrective", incident.CorrectiveActions);
        await TryCreateAction("preventive", incident.PreventiveActions);

        return createdActions;
    }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INTEGRATED RISK SERVICE IMPLEMENTATION
// ════════════════════════════════════════════════════════════════════════════════════

public class IntegratedRiskService : IIntegratedRiskService
{
    private readonly IBarrierService _barrierService;
    private readonly IIncidentService _incidentService;
    private readonly ICrossAnalysisRepository _crossAnalysisRepo;
    private readonly IBarrierRepository _barrierRepo;
    private readonly IIncidentRepository _incidentRepo;
    private readonly ILopaRepository _lopaRepo;
    private readonly IHazopRepository _hazopRepo;
    private readonly IBowTieService _bowTieService;

    public IntegratedRiskService(
        IBarrierService barrierService,
        IIncidentService incidentService,
        ICrossAnalysisRepository crossAnalysisRepo,
        IBarrierRepository barrierRepo,
        IIncidentRepository incidentRepo,
        ILopaRepository lopaRepo,
        IHazopRepository hazopRepo,
        IBowTieService bowTieService)
    {
        _barrierService = barrierService;
        _incidentService = incidentService;
        _crossAnalysisRepo = crossAnalysisRepo;
        _barrierRepo = barrierRepo;
        _incidentRepo = incidentRepo;
        _lopaRepo = lopaRepo;
        _hazopRepo = hazopRepo;
        _bowTieService = bowTieService;
    }

    public async Task<BarrierDto> CreateBarrierFromLopaIplAsync(string lopaIplId, string barrierName,
        string barrierType, string? description)
    {
        return await _barrierService.CreateBarrierAsync(new CreateBarrierRequest
        {
            lopa_ipl_id = lopaIplId,
            barrier_name = barrierName,
            barrier_type = barrierType,
            description = description,
            status = "Active",
            effectiveness_rating = 0.9m
        });
    }

    /// <summary>Maps a free-text LOPA IPL type to the constrained barrier_type CHECK list
    /// ('Engineering','Administrative','Procedural','SIS','Detection').</summary>
    private static string MapIplTypeToBarrierType(string? iplType)
    {
        var normalized = (iplType ?? "").Trim().ToUpperInvariant();
        return normalized switch
        {
            "ENGINEERING"                                   => "Engineering",
            "ADMINISTRATIVE"                                => "Administrative",
            "PROCEDURAL" or "PROCEDURE"                     => "Procedural",
            "SIS" or "SIF"                                  => "SIS",
            "DETECTION" or "ALARM" or "BPCS"                => "Detection",
            "RELIEF" or "PSV" or "PRV" or "MECHANICAL"      => "Engineering",
            "OPERATOR RESPONSE" or "MANUAL"                 => "Procedural",
            _                                                => "Engineering"
        };
    }

    public async Task<BarrierDto> CreateBarrierFromIplAsync(string lopaIplId, LopaIplDto ipl,
        string scenarioId, string? hazopDeviationId, string changedBy)
    {
        // Don't create a duplicate barrier if one already exists for this IPL
        // (UNIQUE constraint on barriers.lopa_ipl_id would otherwise throw).
        var existing = await _barrierRepo.GetBarrierByLopaIplAsync(lopaIplId);
        if (existing is not null) return existing;

        string? bowTieBarrierId = null;

        // If the parent LOPA scenario is already linked to a BowTie diagram, also create a
        // matching BowTie barrier so that a future barrier-status change cascades into the
        // diagram too (see UpdateBarrierStatusCascadeAsync / update_barrier_status_cascade()).
        try
        {
            var linkedDiagramId = await _lopaRepo.GetScenarioBowTieDiagramIdAsync(scenarioId);
            if (!string.IsNullOrEmpty(linkedDiagramId))
            {
                bowTieBarrierId = await _bowTieService.CreateBarrierAsync(new CreateBowTieBarrierDto
                {
                    DiagramId = linkedDiagramId,
                    Description = ipl.IplName ?? "Unnamed IPL",
                    Type = string.Equals(ipl.IplType, "SIS", StringComparison.OrdinalIgnoreCase)
                        ? "Mitigation" : "Prevention",
                    RiskReduction = ipl.Pfd > 0 ? $"PFD {ipl.Pfd:0.######}" : null,
                    SortOrder = 0
                }, changedBy);
            }
        }
        catch
        {
            // BowTie linkage is a best-effort enhancement; the Barrier record itself must
            // still be created even if no diagram is linked yet (or the BowTie write fails).
            bowTieBarrierId = null;
        }

        var barrier = await _barrierService.CreateBarrierAsync(new CreateBarrierRequest
        {
            lopa_ipl_id = lopaIplId,
            bowtie_barrier_id = bowTieBarrierId,
            barrier_name = ipl.IplName ?? "Unnamed IPL",
            barrier_type = MapIplTypeToBarrierType(ipl.IplType),
            description = ipl.Description,
            status = "Active",
            effectiveness_rating = ipl.Pfd is > 0 and < 1 ? (decimal)(1 - ipl.Pfd) : 0.9m,
            critical_flag = string.Equals(ipl.IplType, "SIS", StringComparison.OrdinalIgnoreCase),
            sil_level = null
        });

        // Back-link the IPL to the unified barrier record.
        try { await _lopaRepo.UpdateIplRiskBarrierIdAsync(lopaIplId, barrier.Id!); }
        catch { /* non-fatal — back-link is a convenience, the forward link already exists */ }

        return barrier;
    }

    public async Task<CreateLopaFromHazopResultDto> CreateLopaFromHazopAsync(CreateLopaFromHazopRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.hazop_deviation_id))
            throw new ArgumentException("hazop_deviation_id الزامی است");

        var deviation = await _hazopRepo.GetDeviationAsync(req.hazop_deviation_id);
        if (deviation is null)
            throw new KeyNotFoundException("سناریوی HAZOP (Deviation) یافت نشد");

        var hazopStudyId = req.hazop_study_id ?? deviation.StudyId;

        // Reuse an existing LOPA study already linked to this HAZOP study, if one exists,
        // instead of spawning a new study every time a deviation requests LOPA creation.
        var studyReused = false;
        LopaStudyDto study;
        if (!string.IsNullOrEmpty(hazopStudyId))
        {
            var existingStudies = (await _lopaRepo.ListStudiesAsync(hazopStudyId)).ToList();
            if (existingStudies.Count > 0)
            {
                study = existingStudies[0];
                studyReused = true;
            }
            else
            {
                var studyId = Guid.NewGuid().ToString();
                await _lopaRepo.CreateStudyAsync(
                    studyId,
                    req.title ?? $"LOPA — {deviation.Deviation ?? deviation.GuideWord} {deviation.Parameter}",
                    hazopStudyId, req.facility, req.unit, req.lead_engineer, "Draft", "system",
                    System.Text.Json.JsonSerializer.Serialize(new Dictionary<string, object>()));
                study = (await _lopaRepo.GetStudyAsync(studyId))!;
            }
        }
        else
        {
            var studyId = Guid.NewGuid().ToString();
            await _lopaRepo.CreateStudyAsync(
                studyId, req.title ?? "LOPA Study", null, req.facility, req.unit,
                req.lead_engineer, "Draft", "system",
                System.Text.Json.JsonSerializer.Serialize(new Dictionary<string, object>()));
            study = (await _lopaRepo.GetStudyAsync(studyId))!;
        }

        // Seed the scenario directly from the HAZOP deviation: consequence text, severity, and
        // a back-link via hazop_deviation_id so future incident/barrier impact queries can trace
        // this LOPA scenario back to its originating HAZOP scenario.
        var scenarioId = Guid.NewGuid().ToString();
        var scenarioNumber = $"S-{scenarioId[..6].ToUpperInvariant()}";
        var initiatingEvent = !string.IsNullOrWhiteSpace(deviation.Causes)
            ? deviation.Causes! : (deviation.Deviation ?? "Unspecified deviation");
        var severity = Math.Clamp(deviation.Severity > 0 ? deviation.Severity : 3, 1, 5);

        await _lopaRepo.CreateScenarioAsync(
            scenarioId, study.Id!, req.hazop_deviation_id, scenarioNumber,
            initiatingEvent, 1e-3, deviation.Consequences,
            severity, 1e-5, $"Auto-generated from HAZOP deviation {req.hazop_deviation_id}",
            System.Text.Json.JsonSerializer.Serialize(new Dictionary<string, object>()));

        var scenario = await _lopaRepo.GetScenarioAsync(scenarioId);

        return new CreateLopaFromHazopResultDto
        {
            LopaStudyId = study.Id,
            LopaScenarioId = scenarioId,
            ScenarioNumber = scenarioNumber,
            HazopStudyId = hazopStudyId,
            HazopDeviationId = req.hazop_deviation_id,
            StudyReused = studyReused,
            Study = study,
            Scenario = scenario
        };
    }

    public async Task<CreateBowTieFromHazopResultDto> CreateBowTieFromHazopAsync(CreateBowTieFromHazopRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.hazop_deviation_id))
            throw new ArgumentException("hazop_deviation_id الزامی است");

        var deviation = await _hazopRepo.GetDeviationAsync(req.hazop_deviation_id);
        if (deviation is null)
            throw new KeyNotFoundException("سناریوی HAZOP (Deviation) یافت نشد");

        var hazopStudyId = req.hazop_study_id ?? deviation.StudyId;
        var topEventDescription = req.top_event
            ?? deviation.Consequences
            ?? deviation.Deviation
            ?? "Unspecified top event";

        var diagramId = await _bowTieService.CreateDiagramAsync(new CreateBowTieDiagramDto
        {
            Title = req.title ?? $"BowTie — {deviation.GuideWord} {deviation.Parameter}",
            Description = req.hazard ?? deviation.Deviation,
            HazopStudyId = hazopStudyId,
            TopEventDescription = topEventDescription
        }, "system");

        // Seed an initial Cause / Consequence pair directly from the deviation so the diagram
        // isn't blank — engineers can expand on these afterwards.
        if (!string.IsNullOrWhiteSpace(deviation.Causes))
        {
            try
            {
                await _bowTieService.CreateCauseAsync(new CreateBowTieCauseDto
                {
                    DiagramId = diagramId,
                    Description = deviation.Causes!,
                    Category = deviation.GuideWord,
                    SortOrder = 0
                }, "system");
            }
            catch { /* best-effort seeding — diagram creation itself already succeeded */ }
        }

        if (!string.IsNullOrWhiteSpace(deviation.Consequences))
        {
            try
            {
                await _bowTieService.CreateConsequenceAsync(new CreateBowTieConsequenceDto
                {
                    DiagramId = diagramId,
                    Description = deviation.Consequences!,
                    Severity = deviation.RiskLevel,
                    SortOrder = 0
                }, "system");
            }
            catch { /* best-effort seeding */ }
        }

        // If a LOPA scenario already exists for this same HAZOP deviation, cross-link it to the
        // new diagram so barrier auto-creation (CreateBarrierFromIplAsync) can find it later.
        string? linkedScenarioId = null;
        var linked = false;
        try
        {
            var existingStudies = string.IsNullOrEmpty(hazopStudyId)
                ? Enumerable.Empty<LopaStudyWithCountsDto>()
                : await _lopaRepo.ListStudiesAsync(hazopStudyId);

            foreach (var s in existingStudies)
            {
                var scenarios = await _lopaRepo.ListScenariosAsync(s.Id!);
                var match = scenarios.FirstOrDefault(sc =>
                    sc.HazopDeviationId == req.hazop_deviation_id);
                if (match is not null)
                {
                    await _lopaRepo.LinkScenarioToBowTieAsync(match.Id!, diagramId);
                    linkedScenarioId = match.Id;
                    linked = true;
                    break;
                }
            }
        }
        catch { /* cross-linking is a best-effort enhancement */ }

        var diagram = await _bowTieService.GetDiagramAsync(diagramId);

        return new CreateBowTieFromHazopResultDto
        {
            BowTieDiagramId = diagramId,
            HazopStudyId = hazopStudyId,
            HazopDeviationId = req.hazop_deviation_id,
            LopaScenarioId = linkedScenarioId,
            LinkedToLopaScenario = linked,
            Diagram = diagram
        };
    }

    public async Task<BarrierFailureImpactDto> HandleBarrierFailureAsync(string barrierId,
        string reason, string userId)
    {
        // Update barrier status with cascade to BowTie and LOPA
        await _barrierRepo.UpdateBarrierStatusCascadeAsync(
            barrierId, "Failed", reason, null, userId
        );

        // Get impact analysis
        return await _crossAnalysisRepo.GetBarrierImpactAnalysisAsync(barrierId);
    }

    public Task<IncidentDetailedAnalysisDto> GetIncidentImpactAnalysisAsync(string incidentId) =>
        _crossAnalysisRepo.GetIncidentDetailedAnalysisAsync(incidentId);

    public Task<BarrierFailureImpactDto> GetBarrierImpactAsync(string barrierId) =>
        _crossAnalysisRepo.GetBarrierImpactAnalysisAsync(barrierId);

    public async Task<IEnumerable<IncidentDto>> FindRelatedIncidentsAsync(
        string? hazopId = null, string? lopaId = null, string? bowTieId = null)
    {
        if (!string.IsNullOrEmpty(hazopId))
            return await _crossAnalysisRepo.FindRelatedIncidentsByHazopAsync(hazopId);
        if (!string.IsNullOrEmpty(lopaId))
            return await _crossAnalysisRepo.FindRelatedIncidentsByLopaAsync(lopaId);
        if (!string.IsNullOrEmpty(bowTieId))
            return await _crossAnalysisRepo.FindRelatedIncidentsByBowTieAsync(bowTieId);

        return Enumerable.Empty<IncidentDto>();
    }

    public async Task<BatchOperationResultDto> BatchLinkBarriersToIncidentAsync(
        BatchCreateIncidentBarriersRequest req)
    {
        var result = new BatchOperationResultDto { TotalProcessed = req.barriers?.Count ?? 0 };
        var errors = new List<string>();

        if (req.barriers == null || !req.barriers.Any())
            return result;

        foreach (var barrier in req.barriers)
        {
            try
            {
                barrier.incident_id = req.incident_id;
                await _incidentService.LinkBarrierAsync(barrier);
                result.SuccessfulCount++;
            }
            catch (Exception ex)
            {
                result.FailedCount++;
                errors.Add($"Failed to link barrier: {ex.Message}");
            }
        }

        result.Errors = errors;
        result.Success = result.FailedCount == 0;
        return result;
    }

    public async Task<BatchOperationResultDto> BatchUpdateBarrierStatusAsync(
        BatchUpdateBarrierStatusRequest req, string userId)
    {
        var result = new BatchOperationResultDto { TotalProcessed = req.barrier_ids?.Count ?? 0 };
        var errors = new List<string>();

        if (req.barrier_ids == null || !req.barrier_ids.Any())
            return result;

        foreach (var barrierId in req.barrier_ids)
        {
            try
            {
                var updateReq = new UpdateBarrierStatusRequest
                {
                    new_status = req.new_status,
                    reason = req.reason
                };
                var (success, message) = await _barrierService.UpdateBarrierStatusAsync(
                    barrierId, updateReq, userId
                );

                if (success)
                    result.SuccessfulCount++;
                else
                {
                    result.FailedCount++;
                    errors.Add($"Barrier {barrierId}: {message}");
                }
            }
            catch (Exception ex)
            {
                result.FailedCount++;
                errors.Add($"Barrier {barrierId}: {ex.Message}");
            }
        }

        result.Errors = errors;
        result.Success = result.FailedCount == 0;
        return result;
    }
}
