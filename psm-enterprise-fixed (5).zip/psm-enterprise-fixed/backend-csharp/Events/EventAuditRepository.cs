using Npgsql;
using NpgsqlTypes;
using System.Text.Json;
using PSM.Api.Data;

namespace PSM.Api.Events;

/// <summary>
/// PostgreSQL implementation of event audit repository.
/// Provides event persistence, idempotency tracking, and audit trail.
/// Transaction-safe with proper error handling.
/// </summary>
public class EventAuditRepository : IEventAuditRepository
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<EventAuditRepository> _logger;

    public EventAuditRepository(
        IDbConnectionFactory connectionFactory,
        ILogger<EventAuditRepository> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>Record event in audit trail with automatic idempotency detection</summary>
    public async Task<EventAuditRecord> RecordEventAsync(IDomainEvent @event)
    {
        if (@event == null)
            throw new ArgumentNullException(nameof(@event));

        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            const string sql = @"
                INSERT INTO event_audit (
                    event_id, event_type, correlation_id, tenant_id, initiated_by,
                    occurred_at, recorded_at, processing_status, event_payload
                )
                VALUES (
                    @eventId, @eventType, @correlationId, @tenantId, @initiatedBy,
                    @occurredAt, NOW(), @processingStatus, @eventPayload
                )
                ON CONFLICT (event_id) DO UPDATE SET
                    processing_status = EXCLUDED.processing_status
                RETURNING 
                    event_id, event_type, correlation_id, tenant_id, initiated_by,
                    occurred_at, recorded_at, processing_status, event_payload,
                    error_message, retry_count, last_retry_at, completed_at";

            await using var cmd = new NpgsqlCommand(sql, conn);
            
            var payload = JsonSerializer.Serialize(@event, 
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            cmd.Parameters.AddWithValue("@eventId", @event.EventId);
            cmd.Parameters.AddWithValue("@eventType", @event.EventType);
            cmd.Parameters.AddWithValue("@correlationId", @event.CorrelationId);
            cmd.Parameters.AddWithValue("@tenantId", @event.TenantId ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@initiatedBy", @event.InitiatedBy);
            cmd.Parameters.AddWithValue("@occurredAt", @event.OccurredAt);
            cmd.Parameters.AddWithValue("@processingStatus", (int)EventProcessingStatus.Pending);
            cmd.Parameters.AddWithValue("@eventPayload", payload);

            await using var reader = await cmd.ExecuteReaderAsync();
            if (!await reader.ReadAsync())
                throw new InvalidOperationException("Failed to record event");

            var record = MapEventAuditRecord(reader);
            
            _logger.LogInformation(
                "Event {EventType} (Id={EventId}) recorded in audit trail",
                @event.EventType, @event.EventId);
            
            return record;
        }
        catch (PostgresException ex) when (ex.SqlState == "23505") // Unique violation
        {
            _logger.LogWarning(
                "Event {EventId} already exists in audit trail. Retrieving existing record.",
                @event.EventId);
            
            var existing = await GetEventAsync(@event.EventId);
            if (existing != null)
                return existing;
            
            throw; // Re-throw if not found
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error recording event {EventType} (Id={EventId})",
                @event.EventType, @event.EventId);
            throw;
        }
    }

    /// <summary>Update event processing status and optional error message</summary>
    public async Task UpdateEventStatusAsync(
        string eventId,
        EventProcessingStatus status,
        string? errorMessage = null)
    {
        if (string.IsNullOrWhiteSpace(eventId))
            throw new ArgumentNullException(nameof(eventId));

        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            string sql;
            NpgsqlCommand cmd;

            if (status == EventProcessingStatus.Completed)
            {
                sql = @"
                    UPDATE event_audit
                    SET processing_status = @status,
                        completed_at = NOW(),
                        error_message = NULL,
                        retry_count = 0
                    WHERE event_id = @eventId";
                
                cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@status", (int)status);
                cmd.Parameters.AddWithValue("@eventId", eventId);
            }
            else if (status == EventProcessingStatus.Failed)
            {
                sql = @"
                    UPDATE event_audit
                    SET processing_status = @status,
                        error_message = @errorMessage,
                        last_retry_at = NOW(),
                        retry_count = retry_count + 1
                    WHERE event_id = @eventId";
                
                cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@status", (int)status);
                cmd.Parameters.AddWithValue("@errorMessage", errorMessage ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@eventId", eventId);
            }
            else
            {
                sql = @"
                    UPDATE event_audit
                    SET processing_status = @status
                    WHERE event_id = @eventId";
                
                cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@status", (int)status);
                cmd.Parameters.AddWithValue("@eventId", eventId);
            }

            await using (cmd)
            {
                var affectedRows = await cmd.ExecuteNonQueryAsync();
                
                if (affectedRows == 0)
                    _logger.LogWarning("Event {EventId} not found for status update", eventId);
                else
                    _logger.LogDebug("Event {EventId} status updated to {Status}", eventId, status);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error updating event status for {EventId}",
                eventId);
            throw;
        }
    }

    /// <summary>Retrieve single event audit record by ID</summary>
    public async Task<EventAuditRecord?> GetEventAsync(string eventId)
    {
        if (string.IsNullOrWhiteSpace(eventId))
            throw new ArgumentNullException(nameof(eventId));

        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            const string sql = @"
                SELECT event_id, event_type, correlation_id, tenant_id, initiated_by,
                       occurred_at, recorded_at, processing_status, event_payload,
                       error_message, retry_count, last_retry_at, completed_at
                FROM event_audit
                WHERE event_id = @eventId";

            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@eventId", eventId);

            await using var reader = await cmd.ExecuteReaderAsync();
            if (!await reader.ReadAsync())
                return null;

            return MapEventAuditRecord(reader);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error retrieving event {EventId}",
                eventId);
            throw;
        }
    }

    /// <summary>Get all events for a correlation ID (distributed tracing)</summary>
    public async Task<List<EventAuditRecord>> GetEventsByCorrelationIdAsync(string correlationId)
    {
        if (string.IsNullOrWhiteSpace(correlationId))
            throw new ArgumentNullException(nameof(correlationId));

        var records = new List<EventAuditRecord>();

        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            const string sql = @"
                SELECT event_id, event_type, correlation_id, tenant_id, initiated_by,
                       occurred_at, recorded_at, processing_status, event_payload,
                       error_message, retry_count, last_retry_at, completed_at
                FROM event_audit
                WHERE correlation_id = @correlationId
                ORDER BY recorded_at DESC";

            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@correlationId", correlationId);

            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                records.Add(MapEventAuditRecord(reader));
            }

            return records;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error retrieving events for correlation {CorrelationId}",
                correlationId);
            throw;
        }
    }

    /// <summary>Get failed events for retry processing (dead letter queue)</summary>
    public async Task<List<EventAuditRecord>> GetFailedEventsAsync(DateTime? since = null)
    {
        var records = new List<EventAuditRecord>();

        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            var sql = @"
                SELECT event_id, event_type, correlation_id, tenant_id, initiated_by,
                       occurred_at, recorded_at, processing_status, event_payload,
                       error_message, retry_count, last_retry_at, completed_at
                FROM event_audit
                WHERE processing_status = @status";

            if (since.HasValue)
                sql += " AND recorded_at >= @since";

            sql += " ORDER BY recorded_at ASC LIMIT 1000";

            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@status", (int)EventProcessingStatus.Failed);
            
            if (since.HasValue)
                cmd.Parameters.AddWithValue("@since", since.Value);

            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                records.Add(MapEventAuditRecord(reader));
            }

            return records;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving failed events");
            throw;
        }
    }

    /// <summary>Mark event as dead lettered after max retries</summary>
    public async Task DeadLetterEventAsync(string eventId, string reason)
    {
        if (string.IsNullOrWhiteSpace(eventId))
            throw new ArgumentNullException(nameof(eventId));

        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            const string sql = @"
                UPDATE event_audit
                SET processing_status = @status,
                    error_message = @reason,
                    completed_at = NOW()
                WHERE event_id = @eventId";

            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@status", (int)EventProcessingStatus.DeadLettered);
            cmd.Parameters.AddWithValue("@reason", reason);
            cmd.Parameters.AddWithValue("@eventId", eventId);

            await cmd.ExecuteNonQueryAsync();
            
            _logger.LogWarning(
                "Event {EventId} dead lettered. Reason: {Reason}",
                eventId, reason);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error dead lettering event {EventId}",
                eventId);
            throw;
        }
    }

    /// <summary>Map database row to EventAuditRecord</summary>
    private static EventAuditRecord MapEventAuditRecord(NpgsqlDataReader reader)
    {
        return new EventAuditRecord
        {
            EventId = reader.GetString(reader.GetOrdinal("event_id")),
            EventType = reader.GetString(reader.GetOrdinal("event_type")),
            CorrelationId = reader.GetString(reader.GetOrdinal("correlation_id")),
            TenantId = reader.IsDBNull(reader.GetOrdinal("tenant_id"))
                ? null
                : reader.GetString(reader.GetOrdinal("tenant_id")),
            InitiatedBy = reader.GetString(reader.GetOrdinal("initiated_by")),
            OccurredAt = reader.GetDateTime(reader.GetOrdinal("occurred_at")),
            RecordedAt = reader.GetDateTime(reader.GetOrdinal("recorded_at")),
            ProcessingStatus = (EventProcessingStatus)reader.GetInt32(reader.GetOrdinal("processing_status")),
            EventPayload = reader.IsDBNull(reader.GetOrdinal("event_payload"))
                ? null
                : reader.GetString(reader.GetOrdinal("event_payload")),
            ErrorMessage = reader.IsDBNull(reader.GetOrdinal("error_message"))
                ? null
                : reader.GetString(reader.GetOrdinal("error_message")),
            RetryCount = reader.GetInt32(reader.GetOrdinal("retry_count")),
            LastRetryAt = reader.IsDBNull(reader.GetOrdinal("last_retry_at"))
                ? null
                : reader.GetDateTime(reader.GetOrdinal("last_retry_at")),
            CompletedAt = reader.IsDBNull(reader.GetOrdinal("completed_at"))
                ? null
                : reader.GetDateTime(reader.GetOrdinal("completed_at"))
        };
    }
}
