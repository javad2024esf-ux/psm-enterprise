namespace PSM.Api.Events;

/// <summary>
/// Base interface for all domain events.
/// Provides common properties for event tracking and idempotency.
/// </summary>
public interface IDomainEvent
{
    /// <summary>Unique event identifier for idempotency</summary>
    string EventId { get; }
    
    /// <summary>Event type name (e.g., "BarrierStatusChangedEvent")</summary>
    string EventType { get; }
    
    /// <summary>UTC timestamp when event was created</summary>
    DateTime OccurredAt { get; }
    
    /// <summary>User who triggered the event</summary>
    string InitiatedBy { get; }
    
    /// <summary>Correlation ID for distributed tracing</summary>
    string CorrelationId { get; }
    
    /// <summary>Tenant/Organization ID for multi-tenancy support</summary>
    string? TenantId { get; }
    
    /// <summary>Version for event schema evolution</summary>
    int SchemaVersion { get; }
}

/// <summary>Base implementation of domain event</summary>
public abstract class DomainEventBase : IDomainEvent
{
    public string EventId { get; } = Guid.NewGuid().ToString();
    public abstract string EventType { get; }
    public DateTime OccurredAt { get; } = DateTime.UtcNow;
    public string InitiatedBy { get; set; } = null!;
    public string CorrelationId { get; set; } = Guid.NewGuid().ToString();
    public string? TenantId { get; set; }
    public abstract int SchemaVersion { get; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// BARRIER EVENTS
// ════════════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Published when a barrier status changes (Active→Failed, Active→Degraded, etc.)
/// Subscribers: LOPA IPL updater, BowTie updater, Dashboard updater, KPI engine, Notification service, Audit service
/// </summary>
public class BarrierStatusChangedEvent : DomainEventBase
{
    public override string EventType => nameof(BarrierStatusChangedEvent);
    public override int SchemaVersion => 1;
    
    public string BarrierId { get; set; } = null!;
    public string BarrierName { get; set; } = null!;
    public string BarrierType { get; set; } = null!; // Prevention, Mitigation, Detection
    public string PreviousStatus { get; set; } = null!;
    public string CurrentStatus { get; set; } = null!;
    public string? Reason { get; set; }
    public string? SilLevel { get; set; }
    public bool IsSystemCritical { get; set; }
    public Dictionary<string, string>? LinkedLopaIPLIds { get; set; } // LopaId -> IplId
    public Dictionary<string, string>? LinkedBowTieBarrierIds { get; set; } // BowTieDiagramId -> BarrierId
}

/// <summary>Published when a barrier is created</summary>
public class BarrierCreatedEvent : DomainEventBase
{
    public override string EventType => nameof(BarrierCreatedEvent);
    public override int SchemaVersion => 1;
    
    public string BarrierId { get; set; } = null!;
    public string BarrierName { get; set; } = null!;
    public string BarrierType { get; set; } = null!;
    public string? Status { get; set; }
    public string? SilLevel { get; set; }
}

/// <summary>Published when barrier verification/maintenance occurs</summary>
public class BarrierVerifiedEvent : DomainEventBase
{
    public override string EventType => nameof(BarrierVerifiedEvent);
    public override int SchemaVersion => 1;
    
    public string BarrierId { get; set; } = null!;
    public string BarrierName { get; set; } = null!;
    public DateTime VerificationDate { get; set; }
    public string VerificationResult { get; set; } = null!; // Pass, Fail, Deferred
    public string? Notes { get; set; }
    public string? NextVerificationDue { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT EVENTS
// ════════════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Published when an incident is created.
/// Subscribers: Barrier updater, HAZOP updater, LOPA updater, BowTie updater, KPI engine, Dashboard, Notification, Audit
/// </summary>
public class IncidentCreatedEvent : DomainEventBase
{
    public override string EventType => nameof(IncidentCreatedEvent);
    public override int SchemaVersion => 1;
    
    public string IncidentId { get; set; } = null!;
    public string Title { get; set; } = null!;
    public string Description { get; set; } = null!;
    public DateTime IncidentDate { get; set; }
    public string IncidentType { get; set; } = null!; // Near-Miss, Lost-Time, Environmental, etc.
    public string Severity { get; set; } = null!; // Minor, Serious, Major, Catastrophic
    public string? Location { get; set; }
    public string? AffectedProcessUnit { get; set; }
    public int? InjuriesCount { get; set; }
    public string? EnvironmentalImpact { get; set; }
    public List<string>? AffectedBarrierIds { get; set; } // Barriers that failed/contributed
    public List<string>? AffectedHazopScenarioIds { get; set; }
    public List<string>? AffectedLopaStudyIds { get; set; }
    public List<string>? AffectedBowTieDiagramIds { get; set; }
}

/// <summary>Published when incident investigation progresses</summary>
public class IncidentInvestigationStartedEvent : DomainEventBase
{
    public override string EventType => nameof(IncidentInvestigationStartedEvent);
    public override int SchemaVersion => 1;
    
    public string IncidentId { get; set; } = null!;
    public string Title { get; set; } = null!;
    public string? InvestigationLead { get; set; }
    public DateTime InvestigationStartDate { get; set; }
}

/// <summary>Published when incident is closed/resolved</summary>
public class IncidentClosedEvent : DomainEventBase
{
    public override string EventType => nameof(IncidentClosedEvent);
    public override int SchemaVersion => 1;
    
    public string IncidentId { get; set; } = null!;
    public string Title { get; set; } = null!;
    public DateTime? InvestigationCompletionDate { get; set; }
    public string? RootCauseAnalysisId { get; set; }
    public List<string>? LinkedActionItems { get; set; }
    public List<string>? LinkedBarriers { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// HAZOP EVENTS
// ════════════════════════════════════════════════════════════════════════════════════

/// <summary>Published when a HAZOP study is created</summary>
public class HazopCreatedEvent : DomainEventBase
{
    public override string EventType => nameof(HazopCreatedEvent);
    public override int SchemaVersion => 1;
    
    public string HazopId { get; set; } = null!;
    public string Title { get; set; } = null!;
    public string ProcessUnit { get; set; } = null!;
    public string Status { get; set; } = null!;
    public DateTime? StudyDate { get; set; }
}

/// <summary>Published when a deviation is added/updated in HAZOP</summary>
public class HazopDeviationUpdatedEvent : DomainEventBase
{
    public override string EventType => nameof(HazopDeviationUpdatedEvent);
    public override int SchemaVersion => 1;
    
    public string HazopId { get; set; } = null!;
    public string DeviationId { get; set; } = null!;
    public string Parameter { get; set; } = null!;
    public string Deviation { get; set; } = null!;
    public string? Cause { get; set; }
    public string? Consequence { get; set; }
    public string? Safeguard { get; set; }
    public string RiskLevel { get; set; } = null!;
    public bool RequiresAction { get; set; }
    public List<string>? LinkedBarrierIds { get; set; }
}

/// <summary>Published when HAZOP study status changes</summary>
public class HazopStatusChangedEvent : DomainEventBase
{
    public override string EventType => nameof(HazopStatusChangedEvent);
    public override int SchemaVersion => 1;
    
    public string HazopId { get; set; } = null!;
    public string Title { get; set; } = null!;
    public string PreviousStatus { get; set; } = null!;
    public string CurrentStatus { get; set; } = null!;
}

// ════════════════════════════════════════════════════════════════════════════════════
// LOPA EVENTS
// ════════════════════════════════════════════════════════════════════════════════════

/// <summary>Published when a LOPA study is created</summary>
public class LopaCreatedEvent : DomainEventBase
{
    public override string EventType => nameof(LopaCreatedEvent);
    public override int SchemaVersion => 1;
    
    public string LopaId { get; set; } = null!;
    public string Title { get; set; } = null!;
    public string? HazopScenarioId { get; set; }
    public string Status { get; set; } = null!;
    public DateTime? StudyDate { get; set; }
}

/// <summary>Published when LOPA scenario is updated with new IPL/SIL determination</summary>
public class LopaScenarioUpdatedEvent : DomainEventBase
{
    public override string EventType => nameof(LopaScenarioUpdatedEvent);
    public override int SchemaVersion => 1;
    
    public string LopaId { get; set; } = null!;
    public string ScenarioId { get; set; } = null!;
    public string Scenario { get; set; } = null!;
    public int? RiskInitiatingEventFrequency { get; set; }
    public List<string>? IplIds { get; set; } // Independent Protection Layers
    public int? DeterminedSIL { get; set; }
    public string? SilDeterminationRationale { get; set; }
    public bool RequiredSilAchieved { get; set; }
}

/// <summary>Published when LOPA IPL status changes</summary>
public class LopaIplStatusChangedEvent : DomainEventBase
{
    public override string EventType => nameof(LopaIplStatusChangedEvent);
    public override int SchemaVersion => 1;
    
    public string LopaId { get; set; } = null!;
    public string IplId { get; set; } = null!;
    public string IplName { get; set; } = null!;
    public string PreviousStatus { get; set; } = null!;
    public string CurrentStatus { get; set; } = null!;
    public string? LinkedBarrierId { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// BOWTIE EVENTS
// ════════════════════════════════════════════════════════════════════════════════════

/// <summary>Published when a BowTie diagram is created</summary>
public class BowTieCreatedEvent : DomainEventBase
{
    public override string EventType => nameof(BowTieCreatedEvent);
    public override int SchemaVersion => 1;
    
    public string BowTieId { get; set; } = null!;
    public string Title { get; set; } = null!;
    public string TopEvent { get; set; } = null!;
    public string Status { get; set; } = null!;
    public DateTime? CreationDate { get; set; }
}

/// <summary>Published when BowTie barrier effectiveness changes</summary>
public class BowTieBarrierUpdatedEvent : DomainEventBase
{
    public override string EventType => nameof(BowTieBarrierUpdatedEvent);
    public override int SchemaVersion => 1;
    
    public string BowTieId { get; set; } = null!;
    public string BarrierId { get; set; } = null!;
    public string BarrierName { get; set; } = null!;
    public string BarrierFunction { get; set; } = null!; // Prevention, Detection, Recovery
    public string? PreviousStatus { get; set; }
    public string CurrentStatus { get; set; } = null!;
    public string? PreviousEffectiveness { get; set; }
    public string? CurrentEffectiveness { get; set; }
    public string? LinkedBarrierManagementId { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// ACTION ITEM EVENTS
// ════════════════════════════════════════════════════════════════════════════════════

/// <summary>Published when an action item is created from any PSM module</summary>
public class ActionCreatedEvent : DomainEventBase
{
    public override string EventType => nameof(ActionCreatedEvent);
    public override int SchemaVersion => 1;
    
    public string ActionId { get; set; } = null!;
    public string Title { get; set; } = null!;
    public string ActionType { get; set; } = null!; // Corrective, Preventive, Improvement
    public string Priority { get; set; } = "Medium";
    public DateTime DueDate { get; set; }
    public string? Owner { get; set; }
    public string SourceModule { get; set; } = null!; // HAZOP, LOPA, Incident, BowTie, MOC, Audit
    public string SourceId { get; set; } = null!;
}

/// <summary>Published when action item status changes</summary>
public class ActionStatusChangedEvent : DomainEventBase
{
    public override string EventType => nameof(ActionStatusChangedEvent);
    public override int SchemaVersion => 1;
    
    public string ActionId { get; set; } = null!;
    public string Title { get; set; } = null!;
    public string PreviousStatus { get; set; } = null!;
    public string CurrentStatus { get; set; } = null!;
    public DateTime? CompletionDate { get; set; }
    public string? VerifiedBy { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// MOC (MANAGEMENT OF CHANGE) EVENTS
// ════════════════════════════════════════════════════════════════════════════════════

/// <summary>Published when a MOC change request is approved</summary>
public class MocApprovedEvent : DomainEventBase
{
    public override string EventType => nameof(MocApprovedEvent);
    public override int SchemaVersion => 1;
    
    public string ChangeRequestId { get; set; } = null!;
    public string Title { get; set; } = null!;
    public string ChangeType { get; set; } = null!; // Technical, Operational, Organizational, Temporary
    public string Severity { get; set; } = null!;
    public DateTime ApprovalDate { get; set; }
    public string? ApprovedBy { get; set; }
    public string? ImpactedHazards { get; set; }
    public string? ImpactedBarriers { get; set; }
    public string? PSSRRequired { get; set; } // Yes, No, Partial
    public bool RequiresRevalidation { get; set; }
}

/// <summary>Published when MOC change request status changes</summary>
public class MocStatusChangedEvent : DomainEventBase
{
    public override string EventType => nameof(MocStatusChangedEvent);
    public override int SchemaVersion => 1;
    
    public string ChangeRequestId { get; set; } = null!;
    public string Title { get; set; } = null!;
    public string PreviousStatus { get; set; } = null!;
    public string CurrentStatus { get; set; } = null!;
    public string? ReviewComments { get; set; }
}
