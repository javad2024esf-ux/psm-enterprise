using System.Collections.Concurrent;

namespace PSM.Api.Events;

/// <summary>
/// Interface for event handlers.
/// Supports async processing with automatic idempotency through EventId.
/// </summary>
public interface IEventHandler<in TEvent> where TEvent : IDomainEvent
{
    /// <summary>Handle domain event asynchronously</summary>
    Task HandleAsync(TEvent @event);
}

/// <summary>
/// Interface for event dispatcher.
/// Provides pub/sub mechanism with loose coupling and async processing.
/// </summary>
public interface IEventDispatcher
{
    /// <summary>Publish event to all registered subscribers</summary>
    Task PublishAsync<TEvent>(TEvent @event) where TEvent : IDomainEvent;
    
    /// <summary>Register handler for specific event type</summary>
    void Subscribe<TEvent, THandler>() 
        where TEvent : IDomainEvent 
        where THandler : IEventHandler<TEvent>;
    
    /// <summary>Get all registered handlers for event type</summary>
    IEnumerable<IEventHandler<TEvent>> GetHandlers<TEvent>(TEvent @event) where TEvent : IDomainEvent;
}

/// <summary>
/// In-memory implementation of event dispatcher with async handlers.
/// Supports exception handling, logging, and concurrent processing.
/// Thread-safe for high-throughput scenarios.
/// </summary>
public class EventDispatcher : IEventDispatcher
{
    private readonly IServiceProvider _serviceProvider;
    private readonly IEventAuditRepository _eventAuditRepository;
    private readonly ILogger<EventDispatcher> _logger;
    
    // Store handler types: Key = Event type name, Value = list of handler types
    private static readonly ConcurrentDictionary<string, List<Type>> HandlerRegistry = 
        new();
    
    public EventDispatcher(
        IServiceProvider serviceProvider,
        IEventAuditRepository eventAuditRepository,
        ILogger<EventDispatcher> logger)
    {
        _serviceProvider = serviceProvider ?? throw new ArgumentNullException(nameof(serviceProvider));
        _eventAuditRepository = eventAuditRepository ?? throw new ArgumentNullException(nameof(eventAuditRepository));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Publish event to all registered handlers.
    /// 
    /// Flow:
    /// 1. Persist event to audit trail (for idempotency + audit)
    /// 2. Check if event already processed (idempotency)
    /// 3. Invoke all handlers sequentially OR in parallel (configurable)
    /// 4. Log exceptions, don't propagate (async fire-and-forget pattern)
    /// 5. Update event status in audit trail
    /// </summary>
    public async Task PublishAsync<TEvent>(TEvent @event) where TEvent : IDomainEvent
    {
        if (@event == null)
            throw new ArgumentNullException(nameof(@event));

        var eventType = @event.EventType;
        
        try
        {
            _logger.LogInformation(
                "Publishing event {EventType} (Id={EventId}, Correlation={CorrelationId})",
                eventType, @event.EventId, @event.CorrelationId);

            // 1. Persist event for audit trail and idempotency
            var eventAudit = await _eventAuditRepository.RecordEventAsync(@event);
            
            // 2. Check idempotency: if event already processed, skip
            if (eventAudit.ProcessingStatus == EventProcessingStatus.Completed)
            {
                _logger.LogWarning(
                    "Event {EventType} (Id={EventId}) already processed. Skipping duplicate.",
                    eventType, @event.EventId);
                return;
            }

            // 3. Mark event as processing
            await _eventAuditRepository.UpdateEventStatusAsync(
                @event.EventId, 
                EventProcessingStatus.Processing);

            // 4. Get all registered handlers for this event type
            var handlers = GetHandlers(@event).ToList();
            
            if (handlers.Count == 0)
            {
                _logger.LogWarning(
                    "No handlers registered for event {EventType} (Id={EventId})",
                    eventType, @event.EventId);
                
                await _eventAuditRepository.UpdateEventStatusAsync(
                    @event.EventId, 
                    EventProcessingStatus.CompletedNoHandlers);
                return;
            }

            // 5. Execute handlers
            var tasks = handlers.Select(handler => 
                ExecuteHandlerWithErrorHandling(handler, @event)
            ).ToList();

            await Task.WhenAll(tasks);

            // 6. Mark event as completed
            await _eventAuditRepository.UpdateEventStatusAsync(
                @event.EventId, 
                EventProcessingStatus.Completed);
            
            _logger.LogInformation(
                "Event {EventType} (Id={EventId}) published successfully. " +
                "Invoked {HandlerCount} handlers",
                eventType, @event.EventId, handlers.Count);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error publishing event {EventType} (Id={EventId}). Message: {Message}",
                eventType, @event.EventId, ex.Message);
            
            // Update event status to failed in audit trail
            await _eventAuditRepository.UpdateEventStatusAsync(
                @event.EventId, 
                EventProcessingStatus.Failed,
                ex.Message);
            
            // Don't propagate exception - fire-and-forget pattern for async events
            // Applications should query event audit trail for failures
        }
    }

    /// <summary>Execute handler with exception handling and logging</summary>
    private async Task ExecuteHandlerWithErrorHandling(
        object handler, 
        IDomainEvent @event)
    {
        try
        {
            // Invoke handler dynamically
            var handlerType = handler.GetType();
            var eventType = @event.GetType();
            
            var handleMethod = handlerType.GetMethod(
                "HandleAsync",
                new[] { eventType });
            
            if (handleMethod == null)
                throw new InvalidOperationException(
                    $"Handler {handlerType.Name} does not have HandleAsync method for {eventType.Name}");

            var task = (Task?)handleMethod.Invoke(handler, new[] { @event });
            if (task != null)
                await task.ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Handler {HandlerType} failed for event {EventType} (Id={EventId}). Message: {Message}",
                handler.GetType().Name, @event.EventType, @event.EventId, ex.Message);
            
            // Don't propagate - continue processing other handlers
        }
    }

    /// <summary>Register handler for event type</summary>
    public void Subscribe<TEvent, THandler>()
        where TEvent : IDomainEvent
        where THandler : IEventHandler<TEvent>
    {
        var eventTypeName = typeof(TEvent).Name;
        var handlerType = typeof(THandler);

        HandlerRegistry.AddOrUpdate(
            eventTypeName,
            new List<Type> { handlerType },
            (_, handlers) =>
            {
                if (!handlers.Contains(handlerType))
                    handlers.Add(handlerType);
                return handlers;
            });

        _logger.LogInformation(
            "Handler {HandlerType} registered for event {EventType}",
            handlerType.Name, eventTypeName);
    }

    /// <summary>Get all handlers registered for event type</summary>
    public IEnumerable<IEventHandler<TEvent>> GetHandlers<TEvent>(TEvent @event)
        where TEvent : IDomainEvent
    {
        var eventTypeName = @event.EventType;
        
        if (!HandlerRegistry.TryGetValue(eventTypeName, out var handlerTypes))
            return Enumerable.Empty<IEventHandler<TEvent>>();

        var handlers = new List<IEventHandler<TEvent>>();
        
        foreach (var handlerType in handlerTypes)
        {
            try
            {
                var handler = _serviceProvider.GetService(handlerType) 
                    as IEventHandler<TEvent>;
                
                if (handler != null)
                    handlers.Add(handler);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Failed to resolve handler {HandlerType} from DI container",
                    handlerType.Name);
            }
        }

        return handlers;
    }
}

/// <summary>Status of event processing</summary>
public enum EventProcessingStatus
{
    Pending = 0,
    Processing = 1,
    Completed = 2,
    CompletedNoHandlers = 3,
    Failed = 4,
    DeadLettered = 5
}

/// <summary>Repository for storing and tracking published events</summary>
public interface IEventAuditRepository
{
    /// <summary>Record event in audit trail</summary>
    Task<EventAuditRecord> RecordEventAsync(IDomainEvent @event);
    
    /// <summary>Update event processing status</summary>
    Task UpdateEventStatusAsync(
        string eventId,
        EventProcessingStatus status,
        string? errorMessage = null);
    
    /// <summary>Retrieve event audit record</summary>
    Task<EventAuditRecord?> GetEventAsync(string eventId);
    
    /// <summary>Get all events for correlation ID</summary>
    Task<List<EventAuditRecord>> GetEventsByCorrelationIdAsync(string correlationId);
    
    /// <summary>Get failed events for retry processing</summary>
    Task<List<EventAuditRecord>> GetFailedEventsAsync(DateTime? since = null);
    
    /// <summary>Mark event as dead lettered after max retries</summary>
    Task DeadLetterEventAsync(string eventId, string reason);
}

/// <summary>Event audit record for tracking and idempotency</summary>
public class EventAuditRecord
{
    public string EventId { get; set; } = null!;
    public string EventType { get; set; } = null!;
    public string CorrelationId { get; set; } = null!;
    public string? TenantId { get; set; }
    public string InitiatedBy { get; set; } = null!;
    public DateTime OccurredAt { get; set; }
    public DateTime RecordedAt { get; set; } = DateTime.UtcNow;
    public EventProcessingStatus ProcessingStatus { get; set; } = EventProcessingStatus.Pending;
    public string? EventPayload { get; set; } // JSON serialized event
    public string? ErrorMessage { get; set; }
    public int RetryCount { get; set; } = 0;
    public DateTime? LastRetryAt { get; set; }
    public DateTime? CompletedAt { get; set; }
}
