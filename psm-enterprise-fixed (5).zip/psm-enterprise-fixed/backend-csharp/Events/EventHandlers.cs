using Npgsql;
using PSM.Api.Data;

namespace PSM.Api.Events;

// ════════════════════════════════════════════════════════════════════════════════════
// BARRIER STATUS CHANGED EVENT HANDLERS
// ════════════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Updates LOPA IPL status when linked barrier status changes.
/// If barrier becomes Failed/Degraded, IPL status reflects that.
/// </summary>
public class BarrierStatusChanged_UpdateLopaIplHandler : IEventHandler<BarrierStatusChangedEvent>
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<BarrierStatusChanged_UpdateLopaIplHandler> _logger;

    public BarrierStatusChanged_UpdateLopaIplHandler(
        IDbConnectionFactory connectionFactory,
        ILogger<BarrierStatusChanged_UpdateLopaIplHandler> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task HandleAsync(BarrierStatusChangedEvent @event)
    {
        try
        {
            if (@event.LinkedLopaIPLIds == null || @event.LinkedLopaIPLIds.Count == 0)
                return;

            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            foreach (var kvp in @event.LinkedLopaIPLIds)
            {
                var lopaId = kvp.Key;
                var iplId = kvp.Value;

                // Map barrier status to IPL status
                var iplStatus = MapBarrierStatusToIplStatus(@event.CurrentStatus);

                const string sql = @"
                    UPDATE lopa_ipls
                    SET status = @status,
                        updated_at = NOW(),
                        barrier_status_updated_at = NOW()
                    WHERE id = @iplId AND lopa_id = @lopaId";

                await using var cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@status", iplStatus);
                cmd.Parameters.AddWithValue("@iplId", iplId);
                cmd.Parameters.AddWithValue("@lopaId", lopaId);

                await cmd.ExecuteNonQueryAsync();
            }

            _logger.LogInformation(
                "Barrier {BarrierId} status changed to {Status}. " +
                "Updated {IplCount} linked LOPA IPLs",
                @event.BarrierId, @event.CurrentStatus, @event.LinkedLopaIPLIds.Count);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error updating LOPA IPLs for barrier {BarrierId} status change",
                @event.BarrierId);
        }
    }

    private static string MapBarrierStatusToIplStatus(string barrierStatus) => barrierStatus switch
    {
        "Active" => "Operational",
        "Failed" => "Failed",
        "Degraded" => "Degraded",
        "Maintenance" => "Unavailable",
        _ => "Unknown"
    };
}

/// <summary>
/// Updates BowTie barrier effectiveness when linked barrier status changes.
/// Reflects real-time barrier health in BowTie diagrams.
/// </summary>
public class BarrierStatusChanged_UpdateBowTieHandler : IEventHandler<BarrierStatusChangedEvent>
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<BarrierStatusChanged_UpdateBowTieHandler> _logger;

    public BarrierStatusChanged_UpdateBowTieHandler(
        IDbConnectionFactory connectionFactory,
        ILogger<BarrierStatusChanged_UpdateBowTieHandler> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task HandleAsync(BarrierStatusChangedEvent @event)
    {
        try
        {
            if (@event.LinkedBowTieBarrierIds == null || @event.LinkedBowTieBarrierIds.Count == 0)
                return;

            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            foreach (var kvp in @event.LinkedBowTieBarrierIds)
            {
                var diagramId = kvp.Key;
                var bowTieBarrierId = kvp.Value;

                const string sql = @"
                    UPDATE bowtie_barriers
                    SET status = @status,
                        effectiveness = @effectiveness,
                        updated_at = NOW()
                    WHERE id = @barrierId AND diagram_id = @diagramId";

                await using var cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@status", @event.CurrentStatus);
                cmd.Parameters.AddWithValue("@effectiveness", 
                    GetEffectivenessFromStatus(@event.CurrentStatus));
                cmd.Parameters.AddWithValue("@barrierId", bowTieBarrierId);
                cmd.Parameters.AddWithValue("@diagramId", diagramId);

                await cmd.ExecuteNonQueryAsync();
            }

            _logger.LogInformation(
                "Barrier {BarrierId} status changed. " +
                "Updated {BowTieCount} linked BowTie barriers",
                @event.BarrierId, @event.LinkedBowTieBarrierIds.Count);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error updating BowTie barriers for barrier {BarrierId}",
                @event.BarrierId);
        }
    }

    private static string GetEffectivenessFromStatus(string status) => status switch
    {
        "Active" => "High",
        "Degraded" => "Medium",
        "Failed" => "Low",
        "Maintenance" => "Low",
        _ => "Unknown"
    };
}

/// <summary>
/// Updates barrier health dashboard when barrier status changes.
/// Aggregates status of all barriers for monitoring.
/// </summary>
public class BarrierStatusChanged_UpdateDashboardHandler : IEventHandler<BarrierStatusChangedEvent>
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<BarrierStatusChanged_UpdateDashboardHandler> _logger;

    public BarrierStatusChanged_UpdateDashboardHandler(
        IDbConnectionFactory connectionFactory,
        ILogger<BarrierStatusChanged_UpdateDashboardHandler> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task HandleAsync(BarrierStatusChangedEvent @event)
    {
        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            // Update or create dashboard metric
            const string sql = @"
                INSERT INTO barrier_health_metrics (
                    metric_id, barrier_id, status, previous_status,
                    status_changed_at, recorded_at
                )
                VALUES (
                    @metricId, @barrierId, @status, @previousStatus,
                    @statusChangedAt, NOW()
                )";

            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@metricId", Guid.NewGuid().ToString());
            cmd.Parameters.AddWithValue("@barrierId", @event.BarrierId);
            cmd.Parameters.AddWithValue("@status", @event.CurrentStatus);
            cmd.Parameters.AddWithValue("@previousStatus", @event.PreviousStatus);
            cmd.Parameters.AddWithValue("@statusChangedAt", DateTime.UtcNow);

            await cmd.ExecuteNonQueryAsync();

            _logger.LogInformation(
                "Dashboard metric recorded for barrier {BarrierId}: {PreviousStatus} → {CurrentStatus}",
                @event.BarrierId, @event.PreviousStatus, @event.CurrentStatus);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error updating dashboard for barrier {BarrierId}",
                @event.BarrierId);
        }
    }
}

/// <summary>
/// Updates risk analytics when barrier status changes.
/// Recalculates risk metrics based on barrier effectiveness.
/// </summary>
public class BarrierStatusChanged_UpdateRiskAnalyticsHandler : IEventHandler<BarrierStatusChangedEvent>
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<BarrierStatusChanged_UpdateRiskAnalyticsHandler> _logger;

    public BarrierStatusChanged_UpdateRiskAnalyticsHandler(
        IDbConnectionFactory connectionFactory,
        ILogger<BarrierStatusChanged_UpdateRiskAnalyticsHandler> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task HandleAsync(BarrierStatusChangedEvent @event)
    {
        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            // Record risk impact
            const string sql = @"
                INSERT INTO risk_impact_events (
                    event_id, barrier_id, barrier_name, status_change,
                    risk_level_change, recorded_at
                )
                VALUES (
                    @eventId, @barrierId, @barrierName, @statusChange,
                    @riskLevelChange, NOW()
                )";

            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@eventId", Guid.NewGuid().ToString());
            cmd.Parameters.AddWithValue("@barrierId", @event.BarrierId);
            cmd.Parameters.AddWithValue("@barrierName", @event.BarrierName);
            cmd.Parameters.AddWithValue("@statusChange", 
                $"{@event.PreviousStatus} → {@event.CurrentStatus}");
            cmd.Parameters.AddWithValue("@riskLevelChange",
                CalculateRiskImpact(@event.PreviousStatus, @event.CurrentStatus));

            await cmd.ExecuteNonQueryAsync();

            _logger.LogInformation(
                "Risk analytics updated for barrier {BarrierId}",
                @event.BarrierId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error updating risk analytics for barrier {BarrierId}",
                @event.BarrierId);
        }
    }

    private static string CalculateRiskImpact(string previousStatus, string currentStatus)
    {
        if (currentStatus == "Failed" || currentStatus == "Degraded")
            return "INCREASED";
        if (previousStatus == "Failed" || previousStatus == "Degraded")
            return "DECREASED";
        return "UNCHANGED";
    }
}

/// <summary>
/// Publishes notifications when barrier becomes critical (Failed, Degraded).
/// Alerts relevant stakeholders.
/// </summary>
public class BarrierStatusChanged_NotificationHandler : IEventHandler<BarrierStatusChangedEvent>
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<BarrierStatusChanged_NotificationHandler> _logger;

    public BarrierStatusChanged_NotificationHandler(
        IDbConnectionFactory connectionFactory,
        ILogger<BarrierStatusChanged_NotificationHandler> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task HandleAsync(BarrierStatusChangedEvent @event)
    {
        try
        {
            // Only notify for critical status changes
            var isCritical = @event.CurrentStatus == "Failed" || @event.CurrentStatus == "Degraded";
            if (!isCritical)
                return;

            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            const string sql = @"
                INSERT INTO notifications (
                    notification_id, notification_type, title, message,
                    severity, recipient_role, is_read, created_at
                )
                VALUES (
                    @notificationId, @type, @title, @message,
                    @severity, @role, FALSE, NOW()
                )";

            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@notificationId", Guid.NewGuid().ToString());
            cmd.Parameters.AddWithValue("@type", "BARRIER_STATUS_CRITICAL");
            cmd.Parameters.AddWithValue("@title", 
                $"Barrier [{@event.BarrierName}] Status: {@event.CurrentStatus}");
            cmd.Parameters.AddWithValue("@message",
                $"Barrier '{@event.BarrierName}' ({@event.BarrierType}) is now {@event.CurrentStatus.ToLower()}. " +
                $"Reason: {@event.Reason ?? "Not specified"}");
            cmd.Parameters.AddWithValue("@severity", 
                @event.CurrentStatus == "Failed" ? "CRITICAL" : "WARNING");
            cmd.Parameters.AddWithValue("@role", "PSM_MANAGER,SAFETY_OFFICER");

            await cmd.ExecuteNonQueryAsync();

            _logger.LogInformation(
                "Notification published for barrier {BarrierId} status change to {Status}",
                @event.BarrierId, @event.CurrentStatus);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error publishing notification for barrier {BarrierId}",
                @event.BarrierId);
        }
    }
}

/// <summary>
/// Creates audit trail entry when barrier status changes.
/// Maintains immutable history for compliance.
/// </summary>
public class BarrierStatusChanged_AuditHandler : IEventHandler<BarrierStatusChangedEvent>
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<BarrierStatusChanged_AuditHandler> _logger;

    public BarrierStatusChanged_AuditHandler(
        IDbConnectionFactory connectionFactory,
        ILogger<BarrierStatusChanged_AuditHandler> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task HandleAsync(BarrierStatusChangedEvent @event)
    {
        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            const string sql = @"
                INSERT INTO audit_logs (
                    audit_id, entity_type, entity_id, action, 
                    previous_value, new_value, changed_by, changed_at, details
                )
                VALUES (
                    @auditId, @entityType, @entityId, @action,
                    @previousValue, @newValue, @changedBy, NOW(), @details
                )";

            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@auditId", Guid.NewGuid().ToString());
            cmd.Parameters.AddWithValue("@entityType", "Barrier");
            cmd.Parameters.AddWithValue("@entityId", @event.BarrierId);
            cmd.Parameters.AddWithValue("@action", "STATUS_CHANGED");
            cmd.Parameters.AddWithValue("@previousValue", @event.PreviousStatus);
            cmd.Parameters.AddWithValue("@newValue", @event.CurrentStatus);
            cmd.Parameters.AddWithValue("@changedBy", @event.InitiatedBy);
            cmd.Parameters.AddWithValue("@details", 
                System.Text.Json.JsonSerializer.Serialize(new
                {
                    BarrierId = @event.BarrierId,
                    BarrierName = @event.BarrierName,
                    BarrierType = @event.BarrierType,
                    Reason = @event.Reason,
                    EventId = @event.EventId,
                    CorrelationId = @event.CorrelationId
                }));

            await cmd.ExecuteNonQueryAsync();

            _logger.LogInformation(
                "Audit entry created for barrier {BarrierId} status change",
                @event.BarrierId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error creating audit entry for barrier {BarrierId}",
                @event.BarrierId);
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT CREATED EVENT HANDLERS
// ════════════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Updates linked barriers when incident is created.
/// Marks barriers that contributed to incident.
/// </summary>
public class IncidentCreated_UpdateBarriersHandler : IEventHandler<IncidentCreatedEvent>
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<IncidentCreated_UpdateBarriersHandler> _logger;

    public IncidentCreated_UpdateBarriersHandler(
        IDbConnectionFactory connectionFactory,
        ILogger<IncidentCreated_UpdateBarriersHandler> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task HandleAsync(IncidentCreatedEvent @event)
    {
        try
        {
            if (@event.AffectedBarrierIds == null || @event.AffectedBarrierIds.Count == 0)
                return;

            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            foreach (var barrierId in @event.AffectedBarrierIds)
            {
                const string sql = @"
                    INSERT INTO barrier_incident_links (
                        link_id, barrier_id, incident_id, 
                        link_type, created_at
                    )
                    VALUES (
                        @linkId, @barrierId, @incidentId,
                        @linkType, NOW()
                    )
                    ON CONFLICT DO NOTHING";

                await using var cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@linkId", Guid.NewGuid().ToString());
                cmd.Parameters.AddWithValue("@barrierId", barrierId);
                cmd.Parameters.AddWithValue("@incidentId", @event.IncidentId);
                cmd.Parameters.AddWithValue("@linkType", "CONTRIBUTED_TO_INCIDENT");

                await cmd.ExecuteNonQueryAsync();
            }

            _logger.LogInformation(
                "Incident {IncidentId} linked to {BarrierCount} barriers",
                @event.IncidentId, @event.AffectedBarrierIds.Count);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error updating barriers for incident {IncidentId}",
                @event.IncidentId);
        }
    }
}

/// <summary>
/// Updates HAZOP scenarios when incident is created.
/// Links incident to relevant hazard/deviation scenarios.
/// </summary>
public class IncidentCreated_UpdateHazopHandler : IEventHandler<IncidentCreatedEvent>
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<IncidentCreated_UpdateHazopHandler> _logger;

    public IncidentCreated_UpdateHazopHandler(
        IDbConnectionFactory connectionFactory,
        ILogger<IncidentCreated_UpdateHazopHandler> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task HandleAsync(IncidentCreatedEvent @event)
    {
        try
        {
            if (@event.AffectedHazopScenarioIds == null || @event.AffectedHazopScenarioIds.Count == 0)
                return;

            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            foreach (var scenarioId in @event.AffectedHazopScenarioIds)
            {
                const string sql = @"
                    UPDATE hazop_deviations
                    SET linked_incident_id = @incidentId,
                        incident_link_date = NOW()
                    WHERE id = @scenarioId";

                await using var cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@incidentId", @event.IncidentId);
                cmd.Parameters.AddWithValue("@scenarioId", scenarioId);

                await cmd.ExecuteNonQueryAsync();
            }

            _logger.LogInformation(
                "Incident {IncidentId} linked to {HazopCount} HAZOP scenarios",
                @event.IncidentId, @event.AffectedHazopScenarioIds.Count);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error updating HAZOP scenarios for incident {IncidentId}",
                @event.IncidentId);
        }
    }
}

/// <summary>
/// Updates LOPA studies when incident is created.
/// Validates IPL effectiveness based on incident outcome.
/// </summary>
public class IncidentCreated_UpdateLopaHandler : IEventHandler<IncidentCreatedEvent>
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<IncidentCreated_UpdateLopaHandler> _logger;

    public IncidentCreated_UpdateLopaHandler(
        IDbConnectionFactory connectionFactory,
        ILogger<IncidentCreated_UpdateLopaHandler> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task HandleAsync(IncidentCreatedEvent @event)
    {
        try
        {
            if (@event.AffectedLopaStudyIds == null || @event.AffectedLopaStudyIds.Count == 0)
                return;

            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            foreach (var lopaId in @event.AffectedLopaStudyIds)
            {
                const string sql = @"
                    UPDATE lopa_studies
                    SET has_linked_incidents = TRUE,
                        last_incident_id = @incidentId,
                        last_incident_date = NOW()
                    WHERE id = @lopaId";

                await using var cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@incidentId", @event.IncidentId);
                cmd.Parameters.AddWithValue("@lopaId", lopaId);

                await cmd.ExecuteNonQueryAsync();
            }

            _logger.LogInformation(
                "Incident {IncidentId} linked to {LopaCount} LOPA studies",
                @event.IncidentId, @event.AffectedLopaStudyIds.Count);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error updating LOPA studies for incident {IncidentId}",
                @event.IncidentId);
        }
    }
}

/// <summary>
/// Updates BowTie diagrams when incident is created.
/// Validates top event sequences and barrier performance.
/// </summary>
public class IncidentCreated_UpdateBowTieHandler : IEventHandler<IncidentCreatedEvent>
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<IncidentCreated_UpdateBowTieHandler> _logger;

    public IncidentCreated_UpdateBowTieHandler(
        IDbConnectionFactory connectionFactory,
        ILogger<IncidentCreated_UpdateBowTieHandler> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task HandleAsync(IncidentCreatedEvent @event)
    {
        try
        {
            if (@event.AffectedBowTieDiagramIds == null || @event.AffectedBowTieDiagramIds.Count == 0)
                return;

            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            foreach (var diagramId in @event.AffectedBowTieDiagramIds)
            {
                const string sql = @"
                    UPDATE bowtie_diagrams
                    SET validation_required = TRUE,
                        linked_incident_id = @incidentId,
                        last_validation_date = NOW()
                    WHERE id = @diagramId";

                await using var cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@incidentId", @event.IncidentId);
                cmd.Parameters.AddWithValue("@diagramId", diagramId);

                await cmd.ExecuteNonQueryAsync();
            }

            _logger.LogInformation(
                "Incident {IncidentId} linked to {BowTieCount} BowTie diagrams",
                @event.IncidentId, @event.AffectedBowTieDiagramIds.Count);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error updating BowTie diagrams for incident {IncidentId}",
                @event.IncidentId);
        }
    }
}

/// <summary>
/// Updates KPI engine when incident is created.
/// Recalculates safety metrics and performance indicators.
/// </summary>
public class IncidentCreated_UpdateKpiHandler : IEventHandler<IncidentCreatedEvent>
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<IncidentCreated_UpdateKpiHandler> _logger;

    public IncidentCreated_UpdateKpiHandler(
        IDbConnectionFactory connectionFactory,
        ILogger<IncidentCreated_UpdateKpiHandler> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task HandleAsync(IncidentCreatedEvent @event)
    {
        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            const string sql = @"
                INSERT INTO kpi_metrics (
                    metric_id, metric_type, value, incident_id,
                    incident_severity, recorded_at
                )
                VALUES (
                    @metricId, @metricType, @value, @incidentId,
                    @severity, NOW()
                )";

            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@metricId", Guid.NewGuid().ToString());
            cmd.Parameters.AddWithValue("@metricType", "INCIDENT_CREATED");
            cmd.Parameters.AddWithValue("@value", 1);
            cmd.Parameters.AddWithValue("@incidentId", @event.IncidentId);
            cmd.Parameters.AddWithValue("@severity", @event.Severity);

            await cmd.ExecuteNonQueryAsync();

            _logger.LogInformation(
                "KPI metrics updated for incident {IncidentId}",
                @event.IncidentId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error updating KPI for incident {IncidentId}",
                @event.IncidentId);
        }
    }
}

/// <summary>
/// Updates dashboard with incident data for real-time monitoring.
/// </summary>
public class IncidentCreated_UpdateDashboardHandler : IEventHandler<IncidentCreatedEvent>
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<IncidentCreated_UpdateDashboardHandler> _logger;

    public IncidentCreated_UpdateDashboardHandler(
        IDbConnectionFactory connectionFactory,
        ILogger<IncidentCreated_UpdateDashboardHandler> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task HandleAsync(IncidentCreatedEvent @event)
    {
        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            const string sql = @"
                INSERT INTO dashboard_incident_events (
                    event_id, incident_id, title, incident_type, severity,
                    location, recorded_at
                )
                VALUES (
                    @eventId, @incidentId, @title, @type, @severity,
                    @location, NOW()
                )";

            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@eventId", Guid.NewGuid().ToString());
            cmd.Parameters.AddWithValue("@incidentId", @event.IncidentId);
            cmd.Parameters.AddWithValue("@title", @event.Title);
            cmd.Parameters.AddWithValue("@type", @event.IncidentType);
            cmd.Parameters.AddWithValue("@severity", @event.Severity);
            cmd.Parameters.AddWithValue("@location", @event.Location ?? (object)DBNull.Value);

            await cmd.ExecuteNonQueryAsync();

            _logger.LogInformation(
                "Dashboard updated with incident {IncidentId}",
                @event.IncidentId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error updating dashboard for incident {IncidentId}",
                @event.IncidentId);
        }
    }
}

/// <summary>
/// Creates audit trail entry when incident is created.
/// </summary>
public class IncidentCreated_AuditHandler : IEventHandler<IncidentCreatedEvent>
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<IncidentCreated_AuditHandler> _logger;

    public IncidentCreated_AuditHandler(
        IDbConnectionFactory connectionFactory,
        ILogger<IncidentCreated_AuditHandler> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task HandleAsync(IncidentCreatedEvent @event)
    {
        try
        {
            await using var conn = _connectionFactory.CreateConnection();
            await conn.OpenAsync();

            const string sql = @"
                INSERT INTO audit_logs (
                    audit_id, entity_type, entity_id, action,
                    new_value, changed_by, changed_at, details
                )
                VALUES (
                    @auditId, @entityType, @entityId, @action,
                    @newValue, @changedBy, NOW(), @details
                )";

            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@auditId", Guid.NewGuid().ToString());
            cmd.Parameters.AddWithValue("@entityType", "Incident");
            cmd.Parameters.AddWithValue("@entityId", @event.IncidentId);
            cmd.Parameters.AddWithValue("@action", "CREATED");
            cmd.Parameters.AddWithValue("@newValue", "REPORTED");
            cmd.Parameters.AddWithValue("@changedBy", @event.InitiatedBy);
            cmd.Parameters.AddWithValue("@details",
                System.Text.Json.JsonSerializer.Serialize(new
                {
                    IncidentId = @event.IncidentId,
                    Title = @event.Title,
                    Type = @event.IncidentType,
                    Severity = @event.Severity,
                    IncidentDate = @event.IncidentDate,
                    Location = @event.Location,
                    EventId = @event.EventId,
                    CorrelationId = @event.CorrelationId
                }));

            await cmd.ExecuteNonQueryAsync();

            _logger.LogInformation(
                "Audit entry created for incident {IncidentId}",
                @event.IncidentId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Error creating audit entry for incident {IncidentId}",
                @event.IncidentId);
        }
    }
}
