using Microsoft.AspNetCore.Http;
using System.Text.Json;
using PSM.Api.Infrastructure.Logging;
using PSM.Api.Infrastructure.Exceptions;

namespace PSM.Api.Infrastructure.Middleware;

/// <summary>
/// Enterprise exception handling middleware with structured logging.
/// Catches all exceptions and returns appropriate HTTP responses.
/// </summary>
public class EnterpriseExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IStructuredLogger _logger;

    public EnterpriseExceptionHandlingMiddleware(RequestDelegate next, IStructuredLogger logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var correlationId = Guid.NewGuid().ToString("N");
        context.Items["CorrelationId"] = correlationId;

        var loggingContext = new LoggingContext
        {
            CorrelationId = correlationId,
            IpAddress = context.Connection.RemoteIpAddress?.ToString()
        };

        try
        {
            await _next(context);
        }
        catch (Exception exception)
        {
            await HandleExceptionAsync(context, exception, loggingContext);
        }
    }

    private static Task HandleExceptionAsync(HttpContext context, Exception exception, LoggingContext loggingContext)
    {
        context.Response.ContentType = "application/json";

        var response = new ErrorResponse
        {
            Success = false,
            Message = GetErrorMessage(exception),
            CorrelationId = loggingContext.CorrelationId,
            Timestamp = DateTime.UtcNow
        };

        context.Response.StatusCode = GetStatusCode(exception);

        if (exception is ValidationException validationEx)
        {
            response.Errors = validationEx.Errors;
        }

        if (exception is DomainException domainEx)
        {
            response.ErrorCode = domainEx.Code;
            response.Metadata = domainEx.Metadata;
        }

        var json = JsonSerializer.Serialize(response, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
        return context.Response.WriteAsyncSafe(json);
    }

    private static int GetStatusCode(Exception exception) => exception switch
    {
        EntityNotFoundException => StatusCodes.Status404NotFound,
        ValidationException => StatusCodes.Status400BadRequest,
        UnauthorizedOperationException => StatusCodes.Status403Forbidden,
        DuplicateEntityException => StatusCodes.Status409Conflict,
        InvalidStateException => StatusCodes.Status409Conflict,
        BusinessRuleViolationException => StatusCodes.Status400BadRequest,
        _ => StatusCodes.Status500InternalServerError
    };

    private static string GetErrorMessage(Exception exception) => exception switch
    {
        DomainException domainEx => domainEx.Message,
        _ => "An unexpected error occurred. Please try again later."
    };
}

/// <summary>
/// Error response model for consistent error communication.
/// </summary>
public class ErrorResponse
{
    public bool Success { get; set; } = false;
    public string? Message { get; set; }
    public string? ErrorCode { get; set; }
    public Dictionary<string, string[]>? Errors { get; set; }
    public Dictionary<string, object>? Metadata { get; set; }
    public string? CorrelationId { get; set; }
    public DateTime Timestamp { get; set; }
}

/// <summary>
/// Extension methods for HttpResponse for safe writing.
/// </summary>
public static class HttpResponseExtensions
{
    public static async Task WriteAsyncSafe(this HttpResponse response, string content)
    {
        try
        {
            await response.WriteAsync(content);
        }
        catch (Exception)
        {
            // Silently ignore: response may already be started, throwing would be worse than the original error.
            // This is acceptable as the response headers have likely already been sent.
        }
    }
}

/// <summary>
/// Middleware for request/response logging with structured data.
/// </summary>
public class RequestResponseLoggingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IStructuredLogger _logger;

    public RequestResponseLoggingMiddleware(RequestDelegate next, IStructuredLogger logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var request = context.Request;
        var correlationId = context.Items["CorrelationId"]?.ToString() ?? Guid.NewGuid().ToString("N");

        // Create logging context
        var loggingContext = new LoggingContext
        {
            CorrelationId = correlationId,
            IpAddress = request.HttpContext.Connection.RemoteIpAddress?.ToString()
        };

        // Extract user if authenticated
        if (context.User?.Identity?.IsAuthenticated == true)
        {
            loggingContext.Username = context.User.Identity.Name;
        }

        var logger = _logger.WithContext(loggingContext);

        // Log incoming request
        logger.WithProperty("Method", request.Method)
              .WithProperty("Path", request.Path)
              .WithProperty("QueryString", request.QueryString.ToString());

        var originalBodyStream = context.Response.Body;

        using (var memoryStream = new MemoryStream())
        {
            context.Response.Body = memoryStream;

            var startTime = DateTime.UtcNow;

            try
            {
                await _next(context);

                var duration = DateTime.UtcNow - startTime;
                logger.LogOperationCompleted($"{request.Method} {request.Path}", duration);
            }
            catch (Exception ex)
            {
                logger.LogOperationFailed($"{request.Method} {request.Path}", ex);
                throw;
            }
            finally
            {
                await memoryStream.CopyToAsync(originalBodyStream);
            }
        }
    }
}
