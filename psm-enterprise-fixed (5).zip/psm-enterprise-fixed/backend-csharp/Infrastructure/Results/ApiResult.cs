using Microsoft.AspNetCore.Mvc;
using PSM.Api.Infrastructure.Exceptions;

namespace PSM.Api.Infrastructure.Results;

/// <summary>
/// Helper class for generating consistent API responses.
/// Implements the Result pattern for better error handling.
/// </summary>
public static class ApiResult
{
    /// <summary>
    /// Returns a successful response.
    /// </summary>
    public static ActionResult<T> Success<T>(T data, string message = "Success")
    {
        return new OkObjectResult(new ApiResponse<T>
        {
            Success = true,
            Data = data,
            Message = message,
            Timestamp = DateTime.UtcNow
        });
    }

    /// <summary>
    /// Returns a success response without data.
    /// </summary>
    public static ActionResult Success(string message = "Success")
    {
        return new OkObjectResult(new ApiResponse
        {
            Success = true,
            Message = message,
            Timestamp = DateTime.UtcNow
        });
    }

    /// <summary>
    /// Returns a created response (201).
    /// </summary>
    public static ActionResult<T> Created<T>(T data, string message = "Resource created successfully")
    {
        return new CreatedResult("", new ApiResponse<T>
        {
            Success = true,
            Data = data,
            Message = message,
            Timestamp = DateTime.UtcNow
        });
    }

    /// <summary>
    /// Returns a bad request response (400).
    /// </summary>
    public static ActionResult BadRequest(string message, Dictionary<string, string[]>? errors = null)
    {
        return new BadRequestObjectResult(new ApiResponse
        {
            Success = false,
            Message = message,
            Errors = errors,
            Timestamp = DateTime.UtcNow
        });
    }

    /// <summary>
    /// Returns a not found response (404).
    /// </summary>
    public static ActionResult NotFound(string message = "Resource not found")
    {
        return new NotFoundObjectResult(new ApiResponse
        {
            Success = false,
            Message = message,
            Timestamp = DateTime.UtcNow
        });
    }

    /// <summary>
    /// Returns an unauthorized response (401).
    /// </summary>
    public static ActionResult Unauthorized(string message = "Unauthorized")
    {
        return new UnauthorizedObjectResult(new ApiResponse
        {
            Success = false,
            Message = message,
            Timestamp = DateTime.UtcNow
        });
    }

    /// <summary>
    /// Returns a forbidden response (403).
    /// </summary>
    public static ActionResult Forbidden(string message = "Forbidden")
    {
        return new ObjectResult(new ApiResponse
        {
            Success = false,
            Message = message,
            Timestamp = DateTime.UtcNow
        })
        { StatusCode = StatusCodes.Status403Forbidden };
    }

    /// <summary>
    /// Returns a conflict response (409).
    /// </summary>
    public static ActionResult Conflict(string message)
    {
        return new ConflictObjectResult(new ApiResponse
        {
            Success = false,
            Message = message,
            Timestamp = DateTime.UtcNow
        });
    }

    /// <summary>
    /// Returns a server error response (500).
    /// </summary>
    public static ActionResult Error(string message = "Internal server error")
    {
        return new ObjectResult(new ApiResponse
        {
            Success = false,
            Message = message,
            Timestamp = DateTime.UtcNow
        })
        { StatusCode = StatusCodes.Status500InternalServerError };
    }

    /// <summary>
    /// Handles exceptions and returns appropriate responses.
    /// </summary>
    public static ActionResult HandleException(Exception exception)
    {
        return exception switch
        {
            EntityNotFoundException ex => NotFound(ex.Message),
            ValidationException ex => BadRequest("Validation failed", ex.Errors),
            DuplicateEntityException ex => Conflict(ex.Message),
            UnauthorizedOperationException ex => Forbidden(ex.Message),
            InvalidStateException ex => Conflict(ex.Message),
            BusinessRuleViolationException ex => BadRequest(ex.Message),
            _ => Error(exception.Message)
        };
    }
}

/// <summary>
/// Generic API response wrapper.
/// </summary>
public class ApiResponse<T>
{
    public bool Success { get; set; }
    public T? Data { get; set; }
    public string? Message { get; set; }
    public Dictionary<string, string[]>? Errors { get; set; }
    public DateTime Timestamp { get; set; }
}

/// <summary>
/// Non-generic API response wrapper.
/// </summary>
public class ApiResponse
{
    public bool Success { get; set; }
    public string? Message { get; set; }
    public Dictionary<string, string[]>? Errors { get; set; }
    public DateTime Timestamp { get; set; }
}

/// <summary>
/// Paginated API response wrapper.
/// </summary>
public class ApiPagedResponse<T>
{
    public bool Success { get; set; }
    public IEnumerable<T>? Data { get; set; }
    public int TotalCount { get; set; }
    public int PageNumber { get; set; }
    public int PageSize { get; set; }
    public int TotalPages => (TotalCount + PageSize - 1) / PageSize;
    public string? Message { get; set; }
    public DateTime Timestamp { get; set; }

    public static ActionResult<ApiPagedResponse<T>> Success(
        IEnumerable<T> data,
        int totalCount,
        int pageNumber,
        int pageSize,
        string message = "Success")
    {
        return new OkObjectResult(new ApiPagedResponse<T>
        {
            Success = true,
            Data = data,
            TotalCount = totalCount,
            PageNumber = pageNumber,
            PageSize = pageSize,
            Message = message,
            Timestamp = DateTime.UtcNow
        });
    }
}
