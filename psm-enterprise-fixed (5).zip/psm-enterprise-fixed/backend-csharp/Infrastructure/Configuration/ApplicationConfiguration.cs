namespace PSM.Api.Infrastructure.Configuration;

/// <summary>
/// Configuration validator to ensure required settings are present.
/// </summary>
public interface IConfigurationValidator
{
    void Validate();
}

/// <summary>
/// Database configuration with validation.
/// </summary>
public class DatabaseConfiguration
{
    public string Host { get; set; } = "localhost";
    public int Port { get; set; } = 5432;
    public string Database { get; set; } = "psm";
    public string Username { get; set; } = "psm_user";
    public string Password { get; set; } = "";
    public bool UseSsl { get; set; } = false;
    public int ConnectionTimeout { get; set; } = 30;
    public int CommandTimeout { get; set; } = 30;
    public int MaxPoolSize { get; set; } = 20;
    public int MinPoolSize { get; set; } = 5;

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(Host))
            throw new InvalidOperationException("Database Host is required");
        if (string.IsNullOrWhiteSpace(Database))
            throw new InvalidOperationException("Database name is required");
        if (string.IsNullOrWhiteSpace(Username))
            throw new InvalidOperationException("Database Username is required");
    }

    public string BuildConnectionString() =>
        $"Host={Host};Port={Port};Database={Database};Username={Username};Password={Password};" +
        $"SSL Mode={(UseSsl ? "Require" : "Disable")};Trust Server Certificate=true;" +
        $"Connection Timeout={ConnectionTimeout};Command Timeout={CommandTimeout};" +
        $"Maximum Pool Size={MaxPoolSize};Minimum Pool Size={MinPoolSize}";
}

/// <summary>
/// JWT configuration with validation.
/// </summary>
public class JwtConfiguration
{
    public string Secret { get; set; } = "";
    public string Issuer { get; set; } = "PSM";
    public string Audience { get; set; } = "PSM-Users";
    public string ExpiresIn { get; set; } = "24h";
    public int AccessTokenMinutes { get; set; } = 1440; // 24 hours

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(Secret))
            throw new InvalidOperationException("JWT Secret is required");
        if (Secret.Length < 32)
            throw new InvalidOperationException("JWT Secret must be at least 32 characters long");
        if (string.IsNullOrWhiteSpace(Issuer))
            throw new InvalidOperationException("JWT Issuer is required");
    }
}

/// <summary>
/// CORS configuration.
/// </summary>
public class CorsConfiguration
{
    public string[] AllowedOrigins { get; set; } = Array.Empty<string>();
    public string[] AllowedMethods { get; set; } = new[] { "GET", "POST", "PUT", "DELETE", "PATCH" };
    public string[] AllowedHeaders { get; set; } = new[] { "Content-Type", "Authorization" };
    public int MaxAge { get; set; } = 3600;
    public bool AllowCredentials { get; set; } = true;

    public void Validate()
    {
        if (AllowedOrigins == null || AllowedOrigins.Length == 0)
            throw new InvalidOperationException("CORS AllowedOrigins must be configured");
    }
}

/// <summary>
/// API configuration for external services.
/// </summary>
public class ApiConfiguration
{
    public string? AnthropicApiKey { get; set; }
    public string AnthropicModel { get; set; } = "claude-sonnet-4-6";
    public bool AnthropicEnabled { get; set; } = false;
    public string? LicenseSecret { get; set; }
    public int RequestTimeoutSeconds { get; set; } = 30;
    public int MaxRetryAttempts { get; set; } = 3;
    public int RetryDelayMilliseconds { get; set; } = 1000;
}

/// <summary>
/// Logging configuration.
/// </summary>
public class LoggingConfiguration
{
    public string MinimumLevel { get; set; } = "Information";
    public bool EnableConsoleLogging { get; set; } = true;
    public bool EnableFileLogging { get; set; } = true;
    public string LogFilePath { get; set; } = "logs/psm-.txt";
    public bool EnableStructuredLogging { get; set; } = true;
    public bool EnableSecurityAudit { get; set; } = true;
}

/// <summary>
/// Application-wide configuration.
/// </summary>
public class ApplicationConfiguration : IConfigurationValidator
{
    public string Environment { get; set; } = "Development";
    public int Port { get; set; } = 3000;
    public string DataDirectory { get; set; } = "data";
    public DatabaseConfiguration Database { get; set; } = new();
    public JwtConfiguration Jwt { get; set; } = new();
    public CorsConfiguration Cors { get; set; } = new();
    public ApiConfiguration Api { get; set; } = new();
    public LoggingConfiguration Logging { get; set; } = new();

    public void Validate()
    {
        if (Port <= 0 || Port > 65535)
            throw new InvalidOperationException("Port must be between 1 and 65535");

        Database.Validate();
        Jwt.Validate();
        Cors.Validate();
    }
}

/// <summary>
/// Factory for creating configuration from environment variables.
/// </summary>
public static class ConfigurationFactory
{
    public static ApplicationConfiguration CreateFromEnvironment()
    {
        var config = new ApplicationConfiguration
        {
            Environment = GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", "Development"),
            Port = int.Parse(GetEnvironmentVariable("PORT", "3000")),
            DataDirectory = GetEnvironmentVariable("DATA_DIR", "data"),
            Database = new DatabaseConfiguration
            {
                Host = GetEnvironmentVariable("PG_HOST", "localhost"),
                Port = int.Parse(GetEnvironmentVariable("PG_PORT", "5432")),
                Database = GetEnvironmentVariable("PG_DATABASE", "psm"),
                Username = GetEnvironmentVariable("PG_USER", "psm_user"),
                Password = GetEnvironmentVariable("PG_PASSWORD", ""),
                UseSsl = GetEnvironmentVariable("PG_SSL", "false").ToLower() == "true",
                ConnectionTimeout = int.Parse(GetEnvironmentVariable("PG_CONNECTION_TIMEOUT", "30")),
                CommandTimeout = int.Parse(GetEnvironmentVariable("PG_COMMAND_TIMEOUT", "30")),
                MaxPoolSize = int.Parse(GetEnvironmentVariable("PG_MAX_POOL_SIZE", "20")),
                MinPoolSize = int.Parse(GetEnvironmentVariable("PG_MIN_POOL_SIZE", "5"))
            },
            Jwt = new JwtConfiguration
            {
                Secret = GetEnvironmentVariable("JWT_SECRET", ""),
                Issuer = GetEnvironmentVariable("JWT_ISSUER", "PSM"),
                Audience = GetEnvironmentVariable("JWT_AUDIENCE", "PSM-Users"),
                ExpiresIn = GetEnvironmentVariable("JWT_EXPIRES_IN", "24h"),
                AccessTokenMinutes = int.Parse(GetEnvironmentVariable("JWT_ACCESS_TOKEN_MINUTES", "1440"))
            },
            Cors = new CorsConfiguration
            {
                AllowedOrigins = GetEnvironmentVariable("CORS_ORIGINS", "http://localhost,http://localhost:80")
                    .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries),
                AllowCredentials = GetEnvironmentVariable("CORS_ALLOW_CREDENTIALS", "true").ToLower() == "true"
            },
            Api = new ApiConfiguration
            {
                AnthropicApiKey = GetEnvironmentVariable("ANTHROPIC_API_KEY", ""),
                AnthropicModel = GetEnvironmentVariable("AI_MODEL", "claude-sonnet-4-6"),
                AnthropicEnabled = GetEnvironmentVariable("AI_ENABLED", "false").ToLower() == "true",
                LicenseSecret = GetEnvironmentVariable("PSM_LICENSE_SECRET", ""),
                RequestTimeoutSeconds = int.Parse(GetEnvironmentVariable("REQUEST_TIMEOUT_SECONDS", "30")),
                MaxRetryAttempts = int.Parse(GetEnvironmentVariable("MAX_RETRY_ATTEMPTS", "3")),
                RetryDelayMilliseconds = int.Parse(GetEnvironmentVariable("RETRY_DELAY_MS", "1000"))
            },
            Logging = new LoggingConfiguration
            {
                MinimumLevel = GetEnvironmentVariable("LOG_LEVEL", "Information"),
                EnableConsoleLogging = GetEnvironmentVariable("LOG_CONSOLE", "true").ToLower() == "true",
                EnableFileLogging = GetEnvironmentVariable("LOG_FILE", "true").ToLower() == "true",
                LogFilePath = GetEnvironmentVariable("LOG_FILE_PATH", "logs/psm-.txt"),
                EnableStructuredLogging = GetEnvironmentVariable("LOG_STRUCTURED", "true").ToLower() == "true",
                EnableSecurityAudit = GetEnvironmentVariable("LOG_SECURITY_AUDIT", "true").ToLower() == "true"
            }
        };

        config.Validate();
        return config;
    }

    private static string GetEnvironmentVariable(string key, string defaultValue) =>
        Environment.GetEnvironmentVariable(key) is { Length: > 0 } value ? value : defaultValue;
}
