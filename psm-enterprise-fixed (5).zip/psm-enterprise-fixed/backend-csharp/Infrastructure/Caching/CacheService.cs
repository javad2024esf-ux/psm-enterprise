using Microsoft.Extensions.Caching.Distributed;
using System.Text.Json;

namespace PSM.Api.Infrastructure.Caching;

/// <summary>
/// Abstraction for distributed caching following Dependency Inversion principle.
/// </summary>
public interface IDistributedCacheService
{
    /// <summary>
    /// Gets a value from cache.
    /// </summary>
    Task<T?> GetAsync<T>(string key) where T : class;

    /// <summary>
    /// Sets a value in cache.
    /// </summary>
    Task SetAsync<T>(string key, T value, TimeSpan? expiration = null) where T : class;

    /// <summary>
    /// Removes a value from cache.
    /// </summary>
    Task RemoveAsync(string key);

    /// <summary>
    /// Removes multiple keys from cache.
    /// </summary>
    Task RemoveAsync(params string[] keys);

    /// <summary>
    /// Gets or sets a value in cache.
    /// </summary>
    Task<T> GetOrSetAsync<T>(string key, Func<Task<T>> factory, TimeSpan? expiration = null) where T : class;

    /// <summary>
    /// Clears all cache.
    /// </summary>
    Task ClearAsync();

    /// <summary>
    /// Exists check for a key.
    /// </summary>
    Task<bool> ExistsAsync(string key);
}

/// <summary>
/// Implementation using distributed cache with JSON serialization.
/// </summary>
public class DistributedCacheService : IDistributedCacheService
{
    private readonly IDistributedCache _cache;
    private readonly JsonSerializerOptions _jsonOptions;

    public DistributedCacheService(IDistributedCache cache)
    {
        _cache = cache ?? throw new ArgumentNullException(nameof(cache));
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = false
        };
    }

    public async Task<T?> GetAsync<T>(string key) where T : class
    {
        if (string.IsNullOrEmpty(key))
            return null;

        try
        {
            var value = await _cache.GetStringAsync(key);
            return value == null ? null : JsonSerializer.Deserialize<T>(value, _jsonOptions);
        }
        catch
        {
            // If deserialization fails, remove the corrupted cache entry
            await _cache.RemoveAsync(key);
            return null;
        }
    }

    public async Task SetAsync<T>(string key, T value, TimeSpan? expiration = null) where T : class
    {
        if (string.IsNullOrEmpty(key) || value == null)
            return;

        try
        {
            var json = JsonSerializer.Serialize(value, _jsonOptions);
            var options = new DistributedCacheEntryOptions();

            if (expiration.HasValue)
                options.AbsoluteExpirationRelativeToNow = expiration;
            else
                options.AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(1); // Default 1 hour

            await _cache.SetStringAsync(key, json, options);
        }
        catch
        {
            // Log but don't throw - caching failure shouldn't break the app
        }
    }

    public async Task RemoveAsync(string key)
    {
        if (!string.IsNullOrEmpty(key))
            await _cache.RemoveAsync(key);
    }

    public async Task RemoveAsync(params string[] keys)
    {
        if (keys == null || keys.Length == 0)
            return;

        foreach (var key in keys)
        {
            if (!string.IsNullOrEmpty(key))
                await _cache.RemoveAsync(key);
        }
    }

    public async Task<T> GetOrSetAsync<T>(string key, Func<Task<T>> factory, TimeSpan? expiration = null) where T : class
    {
        if (string.IsNullOrEmpty(key))
            return await factory();

        var cached = await GetAsync<T>(key);
        if (cached != null)
            return cached;

        var value = await factory();
        if (value != null)
            await SetAsync(key, value, expiration);

        return value;
    }

    public async Task ClearAsync()
    {
        // Note: IDistributedCache doesn't have a clear method, so this is a no-op
        // For Redis, you would need to use specific implementation
        await Task.CompletedTask;
    }

    public async Task<bool> ExistsAsync(string key)
    {
        if (string.IsNullOrEmpty(key))
            return false;

        var value = await _cache.GetAsync(key);
        return value != null;
    }
}

/// <summary>
/// Cache key generator for creating consistent cache keys.
/// </summary>
public static class CacheKeyGenerator
{
    private const string Separator = ":";

    public static string GenerateKey(string module, string entity, string identifier)
    {
        return $"{module}{Separator}{entity}{Separator}{identifier}";
    }

    public static string GenerateListKey(string module, string entity, string filter = "")
    {
        var key = $"{module}{Separator}{entity}{Separator}list";
        return string.IsNullOrEmpty(filter) ? key : $"{key}{Separator}{filter}";
    }

    public static string GenerateCountKey(string module, string entity)
    {
        return $"{module}{Separator}{entity}{Separator}count";
    }

    public static string GenerateKey(params string[] parts)
    {
        return string.Join(Separator, parts.Where(p => !string.IsNullOrEmpty(p)));
    }
}

/// <summary>
/// Cache invalidation manager for coordinating cache updates across the system.
/// </summary>
public interface ICacheInvalidationManager
{
    Task InvalidateEntityCacheAsync(string module, string entity, string? identifier = null);
    Task InvalidateModuleCacheAsync(string module);
}

/// <summary>
/// Implementation of cache invalidation manager.
/// </summary>
public class CacheInvalidationManager : ICacheInvalidationManager
{
    private readonly IDistributedCacheService _cache;

    public CacheInvalidationManager(IDistributedCacheService cache)
    {
        _cache = cache ?? throw new ArgumentNullException(nameof(cache));
    }

    public async Task InvalidateEntityCacheAsync(string module, string entity, string? identifier = null)
    {
        if (string.IsNullOrEmpty(identifier))
        {
            // Invalidate all instances of this entity
            await _cache.RemoveAsync(
                CacheKeyGenerator.GenerateListKey(module, entity),
                CacheKeyGenerator.GenerateCountKey(module, entity)
            );
        }
        else
        {
            // Invalidate specific instance
            await _cache.RemoveAsync(
                CacheKeyGenerator.GenerateKey(module, entity, identifier),
                CacheKeyGenerator.GenerateListKey(module, entity),
                CacheKeyGenerator.GenerateCountKey(module, entity)
            );
        }
    }

    public async Task InvalidateModuleCacheAsync(string module)
    {
        // This would require a more sophisticated cache key tracking system
        // For now, we'll just invalidate known keys
        await _cache.ClearAsync();
    }
}
