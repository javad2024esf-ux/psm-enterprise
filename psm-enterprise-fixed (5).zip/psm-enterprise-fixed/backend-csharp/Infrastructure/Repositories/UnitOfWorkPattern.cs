using PSM.Api.Data;

namespace PSM.Api.Infrastructure.Repositories;

/// <summary>
/// Unit of Work pattern for coordinating multiple repositories.
/// Ensures all repositories use the same database connection/transaction.
/// </summary>
public interface IUnitOfWork : IAsyncDisposable
{
    /// <summary>
    /// Begins a new transaction.
    /// </summary>
    Task BeginTransactionAsync();

    /// <summary>
    /// Commits the current transaction.
    /// </summary>
    Task CommitAsync();

    /// <summary>
    /// Rolls back the current transaction.
    /// </summary>
    Task RollbackAsync();

    /// <summary>
    /// Gets the database helper for executing queries.
    /// </summary>
    IDbHelper DbHelper { get; }

    /// <summary>
    /// Gets or creates a repository instance.
    /// </summary>
    T GetRepository<T>(Func<IDbHelper, T> factory) where T : class;
}

/// <summary>
/// Enterprise implementation of Unit of Work pattern.
/// </summary>
public class UnitOfWork : IUnitOfWork
{
    private readonly IDbHelper _dbHelper;
    private readonly Dictionary<Type, object> _repositories;
    private System.Data.IDbTransaction? _transaction;
    private bool _disposed = false;

    public IDbHelper DbHelper => _dbHelper;

    public UnitOfWork(IDbHelper dbHelper)
    {
        _dbHelper = dbHelper ?? throw new ArgumentNullException(nameof(dbHelper));
        _repositories = new Dictionary<Type, object>();
    }

    public async Task BeginTransactionAsync()
    {
        if (_transaction != null)
            throw new InvalidOperationException("A transaction is already active. Complete or rollback the current transaction first.");

        var connection = await _dbHelper.GetConnectionAsync();
        if (connection.State != System.Data.ConnectionState.Open)
            connection.Open();

        _transaction = connection.BeginTransaction();
    }

    public async Task CommitAsync()
    {
        if (_transaction == null)
            throw new InvalidOperationException("No active transaction to commit.");

        try
        {
            _transaction.Commit();
        }
        finally
        {
            _transaction?.Dispose();
            _transaction = null;
        }
    }

    public async Task RollbackAsync()
    {
        if (_transaction == null)
            throw new InvalidOperationException("No active transaction to rollback.");

        try
        {
            _transaction.Rollback();
        }
        finally
        {
            _transaction?.Dispose();
            _transaction = null;
        }
    }

    public T GetRepository<T>(Func<IDbHelper, T> factory) where T : class
    {
        var type = typeof(T);
        if (_repositories.TryGetValue(type, out var repository))
            return (T)repository;

        var instance = factory(_dbHelper);
        _repositories[type] = instance;
        return instance;
    }

    public async ValueTask DisposeAsync()
    {
        if (_disposed)
            return;

        try
        {
            if (_transaction != null)
            {
                await RollbackAsync();
            }
        }
        finally
        {
            _disposed = true;
        }
    }
}

/// <summary>
/// Base repository with common CRUD operations and DRY principle application.
/// </summary>
public abstract class RepositoryBase<TEntity> where TEntity : class
{
    protected readonly IDbHelper DbHelper;
    protected abstract string TableName { get; }

    protected RepositoryBase(IDbHelper dbHelper)
    {
        DbHelper = dbHelper ?? throw new ArgumentNullException(nameof(dbHelper));
    }

    /// <summary>
    /// Executes a query and returns a single result.
    /// </summary>
    protected async Task<TEntity?> GetSingleAsync(string query, object? parameters = null)
    {
        try
        {
            return await DbHelper.QuerySingleOrDefaultAsync<TEntity>(query, parameters);
        }
        catch (Exception ex)
        {
            throw new Infrastructure.Exceptions.ExternalServiceException(
                "Database",
                $"Failed to query {TableName}: {ex.Message}",
                innerException: ex);
        }
    }

    /// <summary>
    /// Executes a query and returns multiple results.
    /// </summary>
    protected async Task<IEnumerable<TEntity>> GetListAsync(string query, object? parameters = null)
    {
        try
        {
            return await DbHelper.QueryAsync<TEntity>(query, parameters) ?? Enumerable.Empty<TEntity>();
        }
        catch (Exception ex)
        {
            throw new Infrastructure.Exceptions.ExternalServiceException(
                "Database",
                $"Failed to query {TableName}: {ex.Message}",
                innerException: ex);
        }
    }

    /// <summary>
    /// Executes a non-query command.
    /// </summary>
    protected async Task<int> ExecuteAsync(string query, object? parameters = null)
    {
        try
        {
            return await DbHelper.ExecuteAsync(query, parameters) ?? 0;
        }
        catch (Exception ex)
        {
            throw new Infrastructure.Exceptions.ExternalServiceException(
                "Database",
                $"Failed to execute command on {TableName}: {ex.Message}",
                innerException: ex);
        }
    }

    /// <summary>
    /// Executes a scalar query returning a single value.
    /// </summary>
    protected async Task<T?> GetScalarAsync<T>(string query, object? parameters = null)
    {
        try
        {
            return await DbHelper.ExecuteScalarAsync<T>(query, parameters);
        }
        catch (Exception ex)
        {
            throw new Infrastructure.Exceptions.ExternalServiceException(
                "Database",
                $"Failed to execute scalar query on {TableName}: {ex.Message}",
                innerException: ex);
        }
    }

    /// <summary>
    /// Checks if an entity exists.
    /// </summary>
    protected async Task<bool> ExistsAsync(string query, object? parameters = null)
    {
        try
        {
            var count = await DbHelper.ExecuteScalarAsync<int>($"SELECT COUNT(*) FROM ({query}) t", parameters);
            return count > 0;
        }
        catch (Exception ex)
        {
            throw new Infrastructure.Exceptions.ExternalServiceException(
                "Database",
                $"Failed to check existence in {TableName}: {ex.Message}",
                innerException: ex);
        }
    }

    /// <summary>
    /// Gets the count of entities matching a condition.
    /// </summary>
    protected async Task<int> CountAsync(string query, object? parameters = null)
    {
        try
        {
            return await DbHelper.ExecuteScalarAsync<int>(query, parameters) ?? 0;
        }
        catch (Exception ex)
        {
            throw new Infrastructure.Exceptions.ExternalServiceException(
                "Database",
                $"Failed to count {TableName}: {ex.Message}",
                innerException: ex);
        }
    }
}
