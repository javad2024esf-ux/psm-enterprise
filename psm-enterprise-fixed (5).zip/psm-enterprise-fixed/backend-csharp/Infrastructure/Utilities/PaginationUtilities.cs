namespace PSM.Api.Infrastructure.Utilities;

using System.Text;
using System.Collections.Generic;
using System.Dynamic;

/// <summary>
/// Pagination request parameters.
/// </summary>
public class PaginationRequest
{
    public int PageNumber { get; set; } = 1;
    public int PageSize { get; set; } = 10;
    public string? SortBy { get; set; }
    public bool SortDescending { get; set; } = false;

    public void Validate()
    {
        if (PageNumber < 1)
            PageNumber = 1;

        if (PageSize < 1)
            PageSize = 10;

        if (PageSize > 1000)
            PageSize = 1000; // Max page size
    }

    public int GetOffset() => (PageNumber - 1) * PageSize;
}

/// <summary>
/// Pagination response metadata.
/// </summary>
public class PageMetadata
{
    public int PageNumber { get; set; }
    public int PageSize { get; set; }
    public int TotalCount { get; set; }
    public int TotalPages => (TotalCount + PageSize - 1) / PageSize;
    public bool HasPreviousPage => PageNumber > 1;
    public bool HasNextPage => PageNumber < TotalPages;
}

/// <summary>
/// Filtering specifications for database queries.
/// </summary>
public class FilterSpecification
{
    public string? SearchTerm { get; set; }
    public Dictionary<string, object> Filters { get; set; } = new();
    public string? DateFromField { get; set; }
    public string? DateToField { get; set; }
    public DateTime? DateFrom { get; set; }
    public DateTime? DateTo { get; set; }

    public FilterSpecification WithSearch(string? term)
    {
        SearchTerm = term;
        return this;
    }

    public FilterSpecification WithFilter(string field, object value)
    {
        Filters[field] = value;
        return this;
    }

    public FilterSpecification WithDateRange(DateTime? from, DateTime? to, string fromField = "created_at", string toField = "created_at")
    {
        DateFrom = from;
        DateTo = to;
        DateFromField = fromField;
        DateToField = toField;
        return this;
    }

    public bool HasFilters => !string.IsNullOrEmpty(SearchTerm) || Filters.Count > 0 || DateFrom.HasValue || DateTo.HasValue;
}

/// <summary>
/// Query builder helper for constructing SQL queries dynamically.
/// </summary>
public class QueryBuilder
{
    private readonly StringBuilder _query = new();
    private readonly Dictionary<string, object?> _parameters = new();
    private int _parameterIndex = 0;

    public QueryBuilder Append(string sql)
    {
        _query.Append(sql);
        return this;
    }

    public QueryBuilder AppendLine(string sql)
    {
        _query.AppendLine(sql);
        return this;
    }

    public string AddParameter(object? value)
    {
        var paramName = $"@p{_parameterIndex++}";
        _parameters[paramName] = value;
        return paramName;
    }

    public QueryBuilder AddWhere(string condition, object? value = null)
    {
        if (value != null)
        {
            var paramName = AddParameter(value);
            _query.Append($" WHERE {condition.Replace("@param", paramName)}");
        }
        else
        {
            _query.Append($" WHERE {condition}");
        }
        return this;
    }

    public QueryBuilder AddAnd(string condition, object? value = null)
    {
        if (value != null)
        {
            var paramName = AddParameter(value);
            _query.Append($" AND {condition.Replace("@param", paramName)}");
        }
        else
        {
            _query.Append($" AND {condition}");
        }
        return this;
    }

    public QueryBuilder AddOrderBy(string field, bool descending = false)
    {
        _query.Append($" ORDER BY {field} {(descending ? "DESC" : "ASC")}");
        return this;
    }

    public QueryBuilder AddPagination(int offset, int limit)
    {
        _query.Append($" OFFSET {offset} ROWS FETCH NEXT {limit} ROWS ONLY");
        return this;
    }

    public string Build() => _query.ToString();

    public dynamic GetParameters() => new ExpandoObject().BuildDynamic(_parameters);
}

/// <summary>
/// Extension methods for dynamic object building.
/// </summary>
public static class DynamicObjectExtensions
{
    public static dynamic BuildDynamic(this ExpandoObject obj, Dictionary<string, object?> values)
    {
        var expando = obj as IDictionary<string, object?>;
        foreach (var kvp in values)
        {
            expando![kvp.Key] = kvp.Value;
        }
        return obj;
    }
}

/// <summary>
/// Sorting specification for building ORDER BY clauses.
/// </summary>
public class SortSpecification
{
    public string PropertyName { get; set; } = "";
    public bool IsDescending { get; set; } = false;

    public static SortSpecification Parse(string? sortString)
    {
        if (string.IsNullOrEmpty(sortString))
            return new SortSpecification { PropertyName = "id" };

        var isDescending = sortString.StartsWith("-");
        var propertyName = isDescending ? sortString[1..] : sortString;

        return new SortSpecification
        {
            PropertyName = propertyName,
            IsDescending = isDescending
        };
    }

    public string ToSqlOrderBy(string columnName) =>
        $"{columnName} {(IsDescending ? "DESC" : "ASC")}";
}
