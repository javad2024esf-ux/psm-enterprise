using PSM.Api.Infrastructure.Logging;

namespace PSM.Api.Infrastructure.Resilience;

/// <summary>
/// Retry policy for handling transient failures.
/// </summary>
public interface IRetryPolicy
{
    Task<T> ExecuteAsync<T>(Func<Task<T>> operation, string operationName);
    Task ExecuteAsync(Func<Task> operation, string operationName);
}

/// <summary>
/// Exponential backoff retry policy implementation.
/// </summary>
public class ExponentialBackoffRetryPolicy : IRetryPolicy
{
    private readonly int _maxRetries;
    private readonly int _initialDelayMs;
    private readonly IStructuredLogger _logger;

    public ExponentialBackoffRetryPolicy(
        int maxRetries = 3,
        int initialDelayMs = 1000,
        IStructuredLogger? logger = null)
    {
        _maxRetries = maxRetries;
        _initialDelayMs = initialDelayMs;
        _logger = logger ?? new NullStructuredLogger();
    }

    public async Task<T> ExecuteAsync<T>(Func<Task<T>> operation, string operationName)
    {
        int attempt = 0;

        while (true)
        {
            try
            {
                return await operation();
            }
            catch (Exception ex) when (IsTransient(ex) && attempt < _maxRetries)
            {
                attempt++;
                var delay = _initialDelayMs * (int)Math.Pow(2, attempt - 1);
                _logger.LogWarning($"Transient error in {operationName}, retrying in {delay}ms (Attempt {attempt}/{_maxRetries})");

                await Task.Delay(delay);
            }
        }
    }

    public async Task ExecuteAsync(Func<Task> operation, string operationName)
    {
        int attempt = 0;

        while (true)
        {
            try
            {
                await operation();
                return;
            }
            catch (Exception ex) when (IsTransient(ex) && attempt < _maxRetries)
            {
                attempt++;
                var delay = _initialDelayMs * (int)Math.Pow(2, attempt - 1);
                _logger.LogWarning($"Transient error in {operationName}, retrying in {delay}ms (Attempt {attempt}/{_maxRetries})");

                await Task.Delay(delay);
            }
        }
    }

    private static bool IsTransient(Exception exception)
    {
        return exception is TimeoutException ||
               exception is HttpRequestException ||
               (exception is InvalidOperationException && exception.Message.Contains("transient"));
    }
}

/// <summary>
/// Null object pattern for logger when not available.
/// </summary>
public class NullStructuredLogger : IStructuredLogger
{
    public IStructuredLogger WithContext(PSM.Api.Infrastructure.Logging.LoggingContext context) => this;
    public IStructuredLogger WithProperty(string key, object value) => this;
    public void LogInformation(string message) { }
    public void LogWarning(string message) { }
    public void LogError(string message, Exception? exception = null) { }
    public void LogDebug(string message) { }
    public void LogCritical(string message, Exception? exception = null) { }
    public void LogEntityCreated<T>(string entityId, T entity) { }
    public void LogEntityUpdated<T>(string entityId, T oldEntity, T newEntity) { }
    public void LogEntityDeleted<T>(string entityId, T entity) { }
    public void LogOperationCompleted(string operation, TimeSpan duration) { }
    public void LogOperationFailed(string operation, Exception exception) { }
    public void LogSecurityEvent(string eventType, string details) { }
}

/// <summary>
/// Circuit breaker pattern to prevent cascading failures.
/// </summary>
public interface ICircuitBreaker
{
    Task<T> ExecuteAsync<T>(Func<Task<T>> operation, string operationName);
    void Reset();
}

/// <summary>
/// Simple circuit breaker implementation.
/// </summary>
public class SimpleCircuitBreaker : ICircuitBreaker
{
    private int _failureCount = 0;
    private DateTime _lastFailureTime = DateTime.MinValue;
    private readonly int _failureThreshold;
    private readonly TimeSpan _resetTimeout;
    private readonly IStructuredLogger _logger;

    public SimpleCircuitBreaker(
        int failureThreshold = 5,
        TimeSpan? resetTimeout = null,
        IStructuredLogger? logger = null)
    {
        _failureThreshold = failureThreshold;
        _resetTimeout = resetTimeout ?? TimeSpan.FromSeconds(60);
        _logger = logger ?? new NullStructuredLogger();
    }

    public async Task<T> ExecuteAsync<T>(Func<Task<T>> operation, string operationName)
    {
        // Check if circuit should be reset
        if (_failureCount >= _failureThreshold &&
            DateTime.UtcNow - _lastFailureTime > _resetTimeout)
        {
            Reset();
        }

        // Check if circuit is open
        if (_failureCount >= _failureThreshold)
        {
            throw new InvalidOperationException(
                $"Circuit breaker is open for {operationName}. Service is unavailable.");
        }

        try
        {
            var result = await operation();
            // Reset on success
            if (_failureCount > 0)
            {
                _logger.LogInformation($"Circuit breaker reset for {operationName}");
                _failureCount = 0;
            }
            return result;
        }
        catch (Exception ex)
        {
            _failureCount++;
            _lastFailureTime = DateTime.UtcNow;
            _logger.LogError(
                $"Circuit breaker failure ({_failureCount}/{_failureThreshold}) in {operationName}: {ex.Message}",
                ex);
            throw;
        }
    }

    public void Reset()
    {
        _failureCount = 0;
        _lastFailureTime = DateTime.MinValue;
    }
}

/// <summary>
/// Bulkhead isolation pattern to isolate failures.
/// </summary>
public interface IBulkheadPolicy
{
    Task<T> ExecuteAsync<T>(Func<Task<T>> operation, string isolationKey);
}

/// <summary>
/// Simple bulkhead implementation using semaphores.
/// </summary>
public class SemaphoreBulkheadPolicy : IBulkheadPolicy
{
    private readonly Dictionary<string, SemaphoreSlim> _semaphores = new();
    private readonly int _maxConcurrency;
    private readonly object _lock = new object();

    public SemaphoreBulkheadPolicy(int maxConcurrency = 10)
    {
        _maxConcurrency = maxConcurrency;
    }

    public async Task<T> ExecuteAsync<T>(Func<Task<T>> operation, string isolationKey)
    {
        var semaphore = GetOrCreateSemaphore(isolationKey);
        await semaphore.WaitAsync();

        try
        {
            return await operation();
        }
        finally
        {
            semaphore.Release();
        }
    }

    private SemaphoreSlim GetOrCreateSemaphore(string key)
    {
        lock (_lock)
        {
            if (!_semaphores.TryGetValue(key, out var semaphore))
            {
                semaphore = new SemaphoreSlim(_maxConcurrency, _maxConcurrency);
                _semaphores[key] = semaphore;
            }
            return semaphore;
        }
    }
}
