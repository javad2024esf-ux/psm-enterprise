using Serilog.Core;
using Serilog.Events;

namespace PSM.Api.Infrastructure.Logging;

/// <summary>
/// Structured logging context for correlation and tracing.
/// </summary>
public class LoggingContext
{
    public string CorrelationId { get; set; } = Guid.NewGuid().ToString("N");
    public string? UserId { get; set; }
    public string? Username { get; set; }
    public string? IpAddress { get; set; }
    public Dictionary<string, object> Tags { get; set; } = new();

    public LoggingContext WithUserId(string? userId)
    {
        UserId = userId;
        return this;
    }

    public LoggingContext WithUsername(string? username)
    {
        Username = username;
        return this;
    }

    public LoggingContext WithIpAddress(string? ipAddress)
    {
        IpAddress = ipAddress;
        return this;
    }

    public LoggingContext AddTag(string key, object value)
    {
        Tags[key] = value;
        return this;
    }
}

/// <summary>
/// Structured logger interface for enterprise logging.
/// </summary>
public interface IStructuredLogger
{
    IStructuredLogger WithContext(LoggingContext context);
    IStructuredLogger WithProperty(string key, object value);

    void LogInformation(string message);
    void LogWarning(string message);
    void LogError(string message, Exception? exception = null);
    void LogDebug(string message);
    void LogCritical(string message, Exception? exception = null);

    void LogEntityCreated<T>(string entityId, T entity);
    void LogEntityUpdated<T>(string entityId, T oldEntity, T newEntity);
    void LogEntityDeleted<T>(string entityId, T entity);
    void LogOperationCompleted(string operation, TimeSpan duration);
    void LogOperationFailed(string operation, Exception exception);
    void LogSecurityEvent(string eventType, string details);
}

/// <summary>
/// Enterprise implementation of structured logger using Serilog.
/// </summary>
public class StructuredLogger : IStructuredLogger
{
    private readonly Serilog.ILogger _logger;
    private readonly LoggingContext _context;
    private readonly Dictionary<string, object> _additionalProperties;

    public StructuredLogger(Serilog.ILogger logger, LoggingContext? context = null)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _context = context ?? new LoggingContext();
        _additionalProperties = new Dictionary<string, object>();
    }

    public IStructuredLogger WithContext(LoggingContext context)
    {
        var newContext = new LoggingContext
        {
            CorrelationId = context.CorrelationId,
            UserId = context.UserId,
            Username = context.Username,
            IpAddress = context.IpAddress,
            Tags = new Dictionary<string, object>(context.Tags)
        };
        return new StructuredLogger(_logger, newContext);
    }

    public IStructuredLogger WithProperty(string key, object value)
    {
        _additionalProperties[key] = value;
        return this;
    }

    public void LogInformation(string message)
    {
        _logger.ForContext(_context)
            .ForContext(_additionalProperties)
            .Information(message);
    }

    public void LogWarning(string message)
    {
        _logger.ForContext(_context)
            .ForContext(_additionalProperties)
            .Warning(message);
    }

    public void LogError(string message, Exception? exception = null)
    {
        var log = _logger.ForContext(_context)
            .ForContext(_additionalProperties);

        if (exception != null)
            log.Error(exception, message);
        else
            log.Error(message);
    }

    public void LogDebug(string message)
    {
        _logger.ForContext(_context)
            .ForContext(_additionalProperties)
            .Debug(message);
    }

    public void LogCritical(string message, Exception? exception = null)
    {
        var log = _logger.ForContext(_context)
            .ForContext(_additionalProperties);

        if (exception != null)
            log.Fatal(exception, message);
        else
            log.Fatal(message);
    }

    public void LogEntityCreated<T>(string entityId, T entity)
    {
        _logger.ForContext(_context)
            .ForContext(_additionalProperties)
            .ForContext("Entity", typeof(T).Name)
            .ForContext("EntityId", entityId)
            .ForContext("Action", "Created")
            .Information("Entity created: {EntityType} with ID {EntityId}");
    }

    public void LogEntityUpdated<T>(string entityId, T oldEntity, T newEntity)
    {
        _logger.ForContext(_context)
            .ForContext(_additionalProperties)
            .ForContext("Entity", typeof(T).Name)
            .ForContext("EntityId", entityId)
            .ForContext("Action", "Updated")
            .Information("Entity updated: {EntityType} with ID {EntityId}");
    }

    public void LogEntityDeleted<T>(string entityId, T entity)
    {
        _logger.ForContext(_context)
            .ForContext(_additionalProperties)
            .ForContext("Entity", typeof(T).Name)
            .ForContext("EntityId", entityId)
            .ForContext("Action", "Deleted")
            .Information("Entity deleted: {EntityType} with ID {EntityId}");
    }

    public void LogOperationCompleted(string operation, TimeSpan duration)
    {
        _logger.ForContext(_context)
            .ForContext(_additionalProperties)
            .ForContext("Operation", operation)
            .ForContext("Duration", duration.TotalMilliseconds)
            .Information("Operation completed: {Operation} in {Duration}ms");
    }

    public void LogOperationFailed(string operation, Exception exception)
    {
        _logger.ForContext(_context)
            .ForContext(_additionalProperties)
            .ForContext("Operation", operation)
            .Error(exception, "Operation failed: {Operation}");
    }

    public void LogSecurityEvent(string eventType, string details)
    {
        _logger.ForContext(_context)
            .ForContext(_additionalProperties)
            .ForContext("EventType", "SecurityEvent")
            .ForContext("SecurityEventType", eventType)
            .Warning("Security event: {EventType} - {Details}");
    }
}

/// <summary>
/// Serilog enricher for adding context to all logs.
/// </summary>
public class LoggingContextEnricher : ILogEventEnricher
{
    private readonly LoggingContext _context;

    public LoggingContextEnricher(LoggingContext context)
    {
        _context = context;
    }

    public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
    {
        if (!logEvent.Properties.ContainsKey("CorrelationId"))
            logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("CorrelationId", _context.CorrelationId));

        if (_context.UserId != null && !logEvent.Properties.ContainsKey("UserId"))
            logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("UserId", _context.UserId));

        if (_context.Username != null && !logEvent.Properties.ContainsKey("Username"))
            logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("Username", _context.Username));

        if (_context.IpAddress != null && !logEvent.Properties.ContainsKey("IpAddress"))
            logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("IpAddress", _context.IpAddress));

        foreach (var tag in _context.Tags)
        {
            if (!logEvent.Properties.ContainsKey(tag.Key))
                logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty(tag.Key, tag.Value));
        }
    }
}
