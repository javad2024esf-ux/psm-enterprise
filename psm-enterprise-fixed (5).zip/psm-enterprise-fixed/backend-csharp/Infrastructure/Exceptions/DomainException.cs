namespace PSM.Api.Infrastructure.Exceptions;

/// <summary>
/// Base exception for all domain-level errors.
/// Represents business logic violations and domain constraints.
/// </summary>
public class DomainException : Exception
{
    public string Code { get; }
    public Dictionary<string, object> Metadata { get; }

    public DomainException(string message, string code = "DOMAIN_ERROR", Exception? innerException = null)
        : base(message, innerException)
    {
        Code = code;
        Metadata = new Dictionary<string, object>();
    }

    public DomainException WithMetadata(string key, object value)
    {
        Metadata[key] = value;
        return this;
    }
}

/// <summary>
/// Thrown when a requested resource is not found.
/// </summary>
public class EntityNotFoundException : DomainException
{
    public string EntityType { get; }
    public object EntityId { get; }

    public EntityNotFoundException(string entityType, object entityId)
        : base($"{entityType} with id '{entityId}' not found.", "ENTITY_NOT_FOUND")
    {
        EntityType = entityType;
        EntityId = entityId;
    }
}

/// <summary>
/// Thrown when attempting to violate a business rule or constraint.
/// </summary>
public class BusinessRuleViolationException : DomainException
{
    public BusinessRuleViolationException(string rule, string message)
        : base(message, $"BUSINESS_RULE_VIOLATION_{rule}")
    {
    }
}

/// <summary>
/// Thrown when a duplicate entity is detected.
/// </summary>
public class DuplicateEntityException : DomainException
{
    public DuplicateEntityException(string entityType, string identifier)
        : base($"A {entityType} with identifier '{identifier}' already exists.", "DUPLICATE_ENTITY")
    {
    }
}

/// <summary>
/// Thrown when an operation is not permitted due to state or permissions.
/// </summary>
public class UnauthorizedOperationException : DomainException
{
    public UnauthorizedOperationException(string operation, string reason)
        : base($"Operation '{operation}' is not authorized: {reason}", "UNAUTHORIZED_OPERATION")
    {
    }
}

/// <summary>
/// Thrown when the entity is in an invalid state for the requested operation.
/// </summary>
public class InvalidStateException : DomainException
{
    public InvalidStateException(string entityType, string currentState, string requiredState)
        : base($"{entityType} is in state '{currentState}' but operation requires state '{requiredState}'.", "INVALID_STATE")
    {
    }
}

/// <summary>
/// Thrown when validation fails.
/// </summary>
public class ValidationException : DomainException
{
    public Dictionary<string, string[]> Errors { get; }

    public ValidationException(Dictionary<string, string[]> errors)
        : base("Validation failed.", "VALIDATION_FAILED")
    {
        Errors = errors ?? new Dictionary<string, string[]>();
    }

    public ValidationException(string fieldName, string error)
        : base($"Validation failed for {fieldName}.", "VALIDATION_FAILED")
    {
        Errors = new Dictionary<string, string[]> { { fieldName, new[] { error } } };
    }
}

/// <summary>
/// Thrown when an external service call fails.
/// </summary>
public class ExternalServiceException : DomainException
{
    public string ServiceName { get; }
    public int? StatusCode { get; }

    public ExternalServiceException(string serviceName, string message, int? statusCode = null, Exception? innerException = null)
        : base($"External service '{serviceName}' failed: {message}", "EXTERNAL_SERVICE_ERROR", innerException)
    {
        ServiceName = serviceName;
        StatusCode = statusCode;
    }
}

/// <summary>
/// Thrown when a concurrency conflict is detected.
/// </summary>
public class ConcurrencyException : DomainException
{
    public ConcurrencyException(string entityType, object entityId)
        : base($"Concurrency conflict detected for {entityType} with id '{entityId}'. The resource has been modified by another user.", "CONCURRENCY_CONFLICT")
    {
    }
}
