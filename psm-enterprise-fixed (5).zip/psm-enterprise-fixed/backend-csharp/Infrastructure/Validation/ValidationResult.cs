namespace PSM.Api.Infrastructure.Validation;

/// <summary>
/// Result of a validation operation.
/// </summary>
public class ValidationResult
{
    public bool IsValid { get; private set; }
    public Dictionary<string, string[]> Errors { get; private set; }

    public ValidationResult()
    {
        IsValid = true;
        Errors = new Dictionary<string, string[]>();
    }

    public static ValidationResult Success() => new() { IsValid = true, Errors = new() };

    public static ValidationResult Failure(string fieldName, string error) =>
        Failure(new Dictionary<string, string[]> { { fieldName, new[] { error } } });

    public static ValidationResult Failure(Dictionary<string, string[]> errors) =>
        new() { IsValid = false, Errors = errors };

    public ValidationResult AddError(string fieldName, string error)
    {
        IsValid = false;
        if (Errors.ContainsKey(fieldName))
            Errors[fieldName] = Errors[fieldName].Append(error).ToArray();
        else
            Errors[fieldName] = new[] { error };
        return this;
    }

    public void ThrowIfInvalid()
    {
        if (!IsValid)
            throw new ValidationException(Errors);
    }
}

/// <summary>
/// Base interface for validators following SOLID principles.
/// </summary>
public interface IValidator<T>
{
    /// <summary>
    /// Validates the entity and returns a ValidationResult.
    /// </summary>
    Task<ValidationResult> ValidateAsync(T entity);
}

/// <summary>
/// Composite validator that runs multiple validators.
/// </summary>
public class CompositeValidator<T> : IValidator<T>
{
    private readonly IValidator<T>[] _validators;

    public CompositeValidator(params IValidator<T>[] validators)
    {
        _validators = validators ?? Array.Empty<IValidator<T>>();
    }

    public async Task<ValidationResult> ValidateAsync(T entity)
    {
        var result = ValidationResult.Success();
        foreach (var validator in _validators)
        {
            var validationResult = await validator.ValidateAsync(entity);
            if (!validationResult.IsValid)
            {
                result.IsValid = false;
                foreach (var error in validationResult.Errors)
                {
                    foreach (var errorMessage in error.Value)
                    {
                        result.AddError(error.Key, errorMessage);
                    }
                }
            }
        }
        return result;
    }
}

/// <summary>
/// Base class for validators with common validation logic.
/// </summary>
public abstract class ValidatorBase<T> : IValidator<T>
{
    protected ValidationResult Result { get; set; } = ValidationResult.Success();

    public virtual Task<ValidationResult> ValidateAsync(T entity)
    {
        Result = ValidationResult.Success();
        ValidateInternal(entity);
        return Task.FromResult(Result);
    }

    protected abstract void ValidateInternal(T entity);

    protected void ValidateRequired(string? value, string fieldName)
    {
        if (string.IsNullOrWhiteSpace(value))
            Result.AddError(fieldName, $"{fieldName} is required");
    }

    protected void ValidateLength(string? value, int minLength, int maxLength, string fieldName)
    {
        if (string.IsNullOrWhiteSpace(value))
            return;

        if (value.Length < minLength || value.Length > maxLength)
            Result.AddError(fieldName, $"{fieldName} must be between {minLength} and {maxLength} characters");
    }

    protected void ValidateEmail(string? email, string fieldName = "Email")
    {
        if (string.IsNullOrWhiteSpace(email))
            return;

        if (!System.ComponentModel.DataAnnotations.EmailAddressAttribute.IsValidEmail(email))
            Result.AddError(fieldName, $"{fieldName} is not a valid email address");
    }

    protected void ValidatePattern(string? value, string pattern, string fieldName)
    {
        if (string.IsNullOrWhiteSpace(value))
            return;

        if (!System.Text.RegularExpressions.Regex.IsMatch(value, pattern))
            Result.AddError(fieldName, $"{fieldName} has invalid format");
    }

    protected void ValidateRange<T>(T? value, T? min, T? max, string fieldName) where T : IComparable<T>
    {
        if (value == null)
            return;

        if (min != null && value.CompareTo(min) < 0)
            Result.AddError(fieldName, $"{fieldName} must be at least {min}");

        if (max != null && value.CompareTo(max) > 0)
            Result.AddError(fieldName, $"{fieldName} must not exceed {max}");
    }

    protected void ValidateCondition(bool condition, string fieldName, string message)
    {
        if (!condition)
            Result.AddError(fieldName, message);
    }
}
