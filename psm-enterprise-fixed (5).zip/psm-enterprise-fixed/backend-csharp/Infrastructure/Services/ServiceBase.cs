using PSM.Api.Infrastructure.Logging;
using PSM.Api.Infrastructure.Validation;
using PSM.Api.Infrastructure.Exceptions;

namespace PSM.Api.Infrastructure.Services;

/// <summary>
/// Base service class implementing SOLID principles and DRY.
/// Provides common functionality for all domain services.
/// </summary>
public abstract class ServiceBase
{
    protected readonly IStructuredLogger Logger;

    protected ServiceBase(IStructuredLogger logger)
    {
        Logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Executes an operation with error handling and logging.
    /// </summary>
    protected async Task<T> ExecuteAsync<T>(string operationName, Func<Task<T>> operation)
    {
        var startTime = DateTime.UtcNow;
        try
        {
            var result = await operation();
            var duration = DateTime.UtcNow - startTime;
            Logger.LogOperationCompleted(operationName, duration);
            return result;
        }
        catch (DomainException ex)
        {
            Logger.LogError($"Domain error in {operationName}: {ex.Message}", ex);
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogOperationFailed(operationName, ex);
            throw new ExternalServiceException(
                "Service",
                $"Operation '{operationName}' failed: {ex.Message}",
                innerException: ex);
        }
    }

    /// <summary>
    /// Executes an operation without return value, with error handling and logging.
    /// </summary>
    protected async Task ExecuteAsync(string operationName, Func<Task> operation)
    {
        var startTime = DateTime.UtcNow;
        try
        {
            await operation();
            var duration = DateTime.UtcNow - startTime;
            Logger.LogOperationCompleted(operationName, duration);
        }
        catch (DomainException ex)
        {
            Logger.LogError($"Domain error in {operationName}: {ex.Message}", ex);
            throw;
        }
        catch (Exception ex)
        {
            Logger.LogOperationFailed(operationName, ex);
            throw new ExternalServiceException(
                "Service",
                $"Operation '{operationName}' failed: {ex.Message}",
                innerException: ex);
        }
    }

    /// <summary>
    /// Validates an entity before processing.
    /// </summary>
    protected async Task ValidateAsync<T>(T entity, IValidator<T> validator)
    {
        var result = await validator.ValidateAsync(entity);
        result.ThrowIfInvalid();
    }

    /// <summary>
    /// Throws EntityNotFoundException if entity is null.
    /// </summary>
    protected void ThrowIfNotFound<T>(T? entity, string entityType, object entityId)
    {
        if (entity == null)
            throw new EntityNotFoundException(entityType, entityId);
    }

    /// <summary>
    /// Throws BusinessRuleViolationException if condition is false.
    /// </summary>
    protected void ThrowIfViolatesRule(bool condition, string rule, string message)
    {
        if (!condition)
            throw new BusinessRuleViolationException(rule, message);
    }

    /// <summary>
    /// Throws DuplicateEntityException if entity already exists.
    /// </summary>
    protected void ThrowIfDuplicate(bool exists, string entityType, string identifier)
    {
        if (exists)
            throw new DuplicateEntityException(entityType, identifier);
    }

    /// <summary>
    /// Throws InvalidStateException if current state doesn't match required state.
    /// </summary>
    protected void ThrowIfInvalidState(string currentState, string requiredState, string entityType)
    {
        if (currentState != requiredState)
            throw new InvalidStateException(entityType, currentState, requiredState);
    }

    /// <summary>
    /// Throws UnauthorizedOperationException if operation is not allowed.
    /// </summary>
    protected void ThrowIfUnauthorized(bool isAuthorized, string operation, string reason)
    {
        if (!isAuthorized)
            throw new UnauthorizedOperationException(operation, reason);
    }
}

/// <summary>
/// Service response wrapper for consistent API responses.
/// </summary>
public class ServiceResponse<T>
{
    public bool Success { get; set; }
    public T? Data { get; set; }
    public string? Message { get; set; }
    public Dictionary<string, object>? Errors { get; set; }

    public static ServiceResponse<T> SuccessResponse(T data, string message = "Operation successful")
    {
        return new ServiceResponse<T>
        {
            Success = true,
            Data = data,
            Message = message
        };
    }

    public static ServiceResponse<T> ErrorResponse(string message, Dictionary<string, object>? errors = null)
    {
        return new ServiceResponse<T>
        {
            Success = false,
            Message = message,
            Errors = errors
        };
    }

    public static ServiceResponse<T> ErrorResponse(string message, Exception exception)
    {
        var errors = new Dictionary<string, object>
        {
            { "exception", exception.GetType().Name },
            { "details", exception.Message }
        };

        if (exception.InnerException != null)
            errors["innerException"] = exception.InnerException.Message;

        return ErrorResponse(message, errors);
    }
}

/// <summary>
/// Paginated service response for list operations.
/// </summary>
public class PagedServiceResponse<T>
{
    public bool Success { get; set; }
    public IEnumerable<T> Data { get; set; } = Enumerable.Empty<T>();
    public int TotalCount { get; set; }
    public int PageNumber { get; set; }
    public int PageSize { get; set; }
    public int TotalPages => (TotalCount + PageSize - 1) / PageSize;
    public string? Message { get; set; }

    public static PagedServiceResponse<T> SuccessResponse(
        IEnumerable<T> data,
        int totalCount,
        int pageNumber,
        int pageSize,
        string message = "Operation successful")
    {
        return new PagedServiceResponse<T>
        {
            Success = true,
            Data = data,
            TotalCount = totalCount,
            PageNumber = pageNumber,
            PageSize = pageSize,
            Message = message
        };
    }

    public static PagedServiceResponse<T> ErrorResponse(string message)
    {
        return new PagedServiceResponse<T>
        {
            Success = false,
            Message = message
        };
    }
}
