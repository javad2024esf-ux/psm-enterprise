namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════
// Workflow Engine — Request DTOs
// NOTE: property names are intentionally camelCase/snake-free to match what
// frontend/src/webApi.ts sends (see startWorkflow / doTransition). The API's
// global JsonNamingPolicy is CamelCase, so these bind cleanly either way.
// ════════════════════════════════════════════════════════════════════════════

public class StartWorkflowRequest
{
    public string recordId { get; set; } = "";
    public string collection { get; set; } = "";
    public string? priority { get; set; } = "normal";
}

public class TransitionRequest
{
    public string recordId { get; set; } = "";
    public string action { get; set; } = "";
    public string? comment { get; set; } = "";
}

public class CreateWorkflowDefinitionRequest
{
    public string? name { get; set; }
    public string? module { get; set; }
    public int? version { get; set; }
    public Dictionary<string, object>? config { get; set; }
    public bool? isActive { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Workflow Engine — Response DTOs (strongly typed, Dapper snake_case mapping)
// ════════════════════════════════════════════════════════════════════════════

public class WorkflowDefinitionDto
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string Module { get; set; } = "";
    public int Version { get; set; }
    public string? Config { get; set; }
    public bool IsActive { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}

public class WorkflowStateDto
{
    public string Id { get; set; } = "";
    public string WorkflowId { get; set; } = "";
    public string Name { get; set; } = "";
    public string Label { get; set; } = "";
    public bool IsInitial { get; set; }
    public bool IsFinal { get; set; }
    public int? SlaHours { get; set; }
    public string? RequiredRole { get; set; }
    public string? Color { get; set; }
}

public class WorkflowTransitionDto
{
    public string Id { get; set; } = "";
    public string WorkflowId { get; set; } = "";
    public string FromState { get; set; } = "";
    public string ToState { get; set; } = "";
    public string Action { get; set; } = "";
    public string? Label { get; set; }
    public string? RequiredRole { get; set; }
}

public class WorkflowDefinitionDetailDto : WorkflowDefinitionDto
{
    public List<WorkflowStateDto> States { get; set; } = new();
    public List<WorkflowTransitionDto> Transitions { get; set; } = new();
}

public class WorkflowInstanceDto
{
    public string Id { get; set; } = "";
    public string RecordId { get; set; } = "";
    public string WorkflowId { get; set; } = "";
    public string Collection { get; set; } = "";
    public string CurrentState { get; set; } = "";
    public DateTime? DueAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    public string EscalationPolicy { get; set; } = "Standard";
    public string? CreatedBy { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}

public class WorkflowInstanceDetailDto : WorkflowInstanceDto
{
    public string? StateLabel { get; set; }
    public bool IsFinal { get; set; }
    public bool IsOverdue { get; set; }
    public double? HoursRemaining { get; set; }
    public List<WorkflowTransitionDto> AvailableActions { get; set; } = new();
    public List<PendingApprovalDto> PendingApprovals { get; set; } = new();
}

public class WorkflowHistoryDto
{
    public string Id { get; set; } = "";
    public string InstanceId { get; set; } = "";
    public string Action { get; set; } = "";
    public string? FromState { get; set; }
    public string? ToState { get; set; }
    public string Comment { get; set; } = "";
    public string PerformedBy { get; set; } = "";
    public string? PerformedByName { get; set; }
    public DateTime PerformedAt { get; set; }
}

public class PendingApprovalDto
{
    public string Id { get; set; } = "";
    public string InstanceId { get; set; } = "";
    public string Role { get; set; } = "";
    public string? AssignedTo { get; set; }
    public string Status { get; set; } = "pending";
    public DateTime AssignedAt { get; set; }
    public DateTime? DueAt { get; set; }
    public int Priority { get; set; }
    public bool Escalated { get; set; }
    // Joined context — populated only on dashboard-style queries
    public string? RecordId { get; set; }
    public string? Collection { get; set; }
}

public class EscalationDto
{
    public string Id { get; set; } = "";
    public string InstanceId { get; set; } = "";
    public string EscalateTo { get; set; } = "";
    public string[] NotifyRoles { get; set; } = Array.Empty<string>();
    public int EscalationLevel { get; set; }
    public string? Reason { get; set; }
    public bool NotificationSent { get; set; }
    public bool Acknowledged { get; set; }
    public DateTime EscalatedAt { get; set; }
}

public class SlaBreachDto
{
    public string Id { get; set; } = "";
    public string InstanceId { get; set; } = "";
    public string StateName { get; set; } = "";
    public int? SlaHours { get; set; }
    public DateTime BreachTime { get; set; }
    public decimal? BreachDurationHours { get; set; }
    public string Severity { get; set; } = "warning";
    public bool Notified { get; set; }
    public bool Resolved { get; set; }
}

public class WorkflowDashboardDto
{
    public int ActiveWorkflows { get; set; }
    public int OverdueWorkflows { get; set; }
    public int ActiveSlaBreaches { get; set; }
    public int PendingApprovals { get; set; }
    public int UnacknowledgedEscalations { get; set; }
    public double? AvgCompletionHours { get; set; }
    public double? SlaCompliancePercentage { get; set; }
    public List<PendingApprovalDto> MyPendingApprovals { get; set; } = new();
    public List<WorkflowInstanceDto> OverdueInstances { get; set; } = new();
    public List<EscalationDto> RecentEscalations { get; set; } = new();
}

public class ModuleStatDto
{
    public string Module { get; set; } = "";
    public int ActiveCount { get; set; }
    public int CompletedCount { get; set; }
    public double? AvgCompletionHours { get; set; }
}

public class WorkflowAnalyticsDto : WorkflowDashboardDto
{
    public List<ModuleStatDto> ByModule { get; set; } = new();
}

// ═══════════════════════════════════════════════════════════════════════════
// Work Permit DTOs
// ═══════════════════════════════════════════════════════════════════════════

public class WorkPermitDto
{
    public string Id { get; set; }
    public string Number { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public string Status { get; set; }
    public string Type { get; set; } // "Hot Work", "Cold Work", "Confined Space", etc.
    public DateTime IssueDate { get; set; }
    public DateTime ExpiryDate { get; set; }
    public string IssuedBy { get; set; }
    public string ApprovedBy { get; set; }
    public List<string> Signatories { get; set; }
    public Dictionary<string, object> FieldData { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}

public class CreateWorkPermitDto
{
    public string Title { get; set; }
    public string Description { get; set; }
    public string Type { get; set; }
    public DateTime ExpiryDate { get; set; }
    public Dictionary<string, object> FieldData { get; set; }
}

public class UpdateWorkPermitDto
{
    public string Title { get; set; }
    public string Description { get; set; }
    public DateTime ExpiryDate { get; set; }
    public Dictionary<string, object> FieldData { get; set; }
}

public class WorkPermitTransitionDto
{
    public string State { get; set; }
    public string Reason { get; set; }
    public Dictionary<string, object> Data { get; set; }
}

public class WorkPermitSlaStatusDto
{
    public string PermitId { get; set; }
    public string State { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? DueAt { get; set; }
    public bool Overdue { get; set; }
    public int HoursRemaining { get; set; }
    public string NextApprover { get; set; }
}

public class WorkPermitSchemaDto
{
    public string State { get; set; }
    public List<FieldDefinitionDto> Fields { get; set; }
    public List<string> AllowedTransitions { get; set; }
    public List<string> RequiredSignatories { get; set; }
}

public class FieldDefinitionDto
{
    public string Name { get; set; }
    public string Type { get; set; }
    public bool Required { get; set; }
    public List<string> Options { get; set; }
    public string Label { get; set; }
}

public class WorkPermitAuditDto
{
    public string PermitId { get; set; }
    public string Event { get; set; }
    public string Actor { get; set; }
    public DateTime Timestamp { get; set; }
    public Dictionary<string, object> Changes { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// PSSR DTOs (Pre-Startup Safety Review)
// ═══════════════════════════════════════════════════════════════════════════

public class PssrDto
{
    public string Id { get; set; }
    public string Number { get; set; }
    public string Title { get; set; }
    public string Status { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime CompletionDate { get; set; }
    public string Scope { get; set; }
    public List<string> TeamMembers { get; set; }
    public Dictionary<string, object> Findings { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class CreatePssrDto
{
    public string Title { get; set; }
    public string Scope { get; set; }
    public List<string> TeamMembers { get; set; }
    public DateTime CompletionDate { get; set; }
}

public class UpdatePssrDto
{
    public string Title { get; set; }
    public string Scope { get; set; }
    public List<string> TeamMembers { get; set; }
    public Dictionary<string, object> Findings { get; set; }
}
