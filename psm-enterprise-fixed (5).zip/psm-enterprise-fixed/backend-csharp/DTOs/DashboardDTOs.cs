using System.Text.Json.Serialization;

namespace PSM.Api.DTOs;

/// <summary>
/// Main Dashboard KPI Container - Aggregates metrics from all PSM modules
/// </summary>
public class DashboardKpisDto
{
    [JsonPropertyName("timestamp")]
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;

    [JsonPropertyName("hazop_kpis")]
    public HazopKpisDto HazopKpis { get; set; } = new();

    [JsonPropertyName("lopa_kpis")]
    public LopaKpisDto LopaKpis { get; set; } = new();

    [JsonPropertyName("incident_kpis")]
    public IncidentKpisDto IncidentKpis { get; set; } = new();

    [JsonPropertyName("permit_kpis")]
    public PermitKpisDto PermitKpis { get; set; } = new();

    [JsonPropertyName("workflow_kpis")]
    public WorkflowKpisDto WorkflowKpis { get; set; } = new();

    [JsonPropertyName("action_register_kpis")]
    public ActionRegisterKpisDto ActionRegisterKpis { get; set; } = new();

    [JsonPropertyName("audit_kpis")]
    public AuditKpisDto AuditKpis { get; set; } = new();

    [JsonPropertyName("summary")]
    public DashboardSummaryDto Summary { get; set; } = new();
}

/// <summary>
/// HAZOP Module KPIs
/// </summary>
public class HazopKpisDto
{
    [JsonPropertyName("total_studies")]
    public int TotalStudies { get; set; }

    [JsonPropertyName("active_studies")]
    public int ActiveStudies { get; set; }

    [JsonPropertyName("completed_studies")]
    public int CompletedStudies { get; set; }

    [JsonPropertyName("total_hazards_identified")]
    public int TotalHazardsIdentified { get; set; }

    [JsonPropertyName("high_risk_hazards")]
    public int HighRiskHazards { get; set; }

    [JsonPropertyName("medium_risk_hazards")]
    public int MediumRiskHazards { get; set; }

    [JsonPropertyName("low_risk_hazards")]
    public int LowRiskHazards { get; set; }

    [JsonPropertyName("total_recommendations")]
    public int TotalRecommendations { get; set; }

    [JsonPropertyName("open_recommendations")]
    public int OpenRecommendations { get; set; }

    [JsonPropertyName("closed_recommendations")]
    public int ClosedRecommendations { get; set; }

    [JsonPropertyName("recommendation_closure_rate")]
    public decimal ClosureRate { get; set; }

    [JsonPropertyName("average_days_to_close")]
    public decimal AverageDaysToClose { get; set; }

    [JsonPropertyName("studies_due_for_review")]
    public int StudiesDueForReview { get; set; }

    [JsonPropertyName("equipment_count")]
    public int EquipmentCount { get; set; }

    [JsonPropertyName("team_members_engaged")]
    public int TeamMembersEngaged { get; set; }

    [JsonPropertyName("last_study_date")]
    public DateTime? LastStudyDate { get; set; }
}

/// <summary>
/// LOPA Module KPIs
/// </summary>
public class LopaKpisDto
{
    [JsonPropertyName("total_analyses")]
    public int TotalAnalyses { get; set; }

    [JsonPropertyName("active_analyses")]
    public int ActiveAnalyses { get; set; }

    [JsonPropertyName("completed_analyses")]
    public int CompletedAnalyses { get; set; }

    [JsonPropertyName("total_scenarios")]
    public int TotalScenarios { get; set; }

    [JsonPropertyName("sil_1_count")]
    public int SIL1Count { get; set; }

    [JsonPropertyName("sil_2_count")]
    public int SIL2Count { get; set; }

    [JsonPropertyName("sil_3_count")]
    public int SIL3Count { get; set; }

    [JsonPropertyName("sil_4_count")]
    public int SIL4Count { get; set; }

    [JsonPropertyName("total_ipls")]
    public int TotalIPLs { get; set; }

    [JsonPropertyName("ipls_implemented")]
    public int IPLsImplemented { get; set; }

    [JsonPropertyName("ipls_pending")]
    public int IPLsPending { get; set; }

    [JsonPropertyName("high_risk_scenarios")]
    public int HighRiskScenarios { get; set; }

    [JsonPropertyName("sil_target_compliance_rate")]
    public decimal SILComplianceRate { get; set; }

    [JsonPropertyName("average_residual_risk")]
    public decimal AverageResidualRisk { get; set; }

    [JsonPropertyName("mitigated_scenarios")]
    public int MitigatedScenarios { get; set; }

    [JsonPropertyName("last_analysis_date")]
    public DateTime? LastAnalysisDate { get; set; }
}

/// <summary>
/// Incident Management KPIs
/// </summary>
public class IncidentKpisDto
{
    [JsonPropertyName("total_incidents")]
    public int TotalIncidents { get; set; }

    [JsonPropertyName("open_incidents")]
    public int OpenIncidents { get; set; }

    [JsonPropertyName("closed_incidents")]
    public int ClosedIncidents { get; set; }

    [JsonPropertyName("high_severity_incidents")]
    public int HighSeverityIncidents { get; set; }

    [JsonPropertyName("incidents_under_investigation")]
    public int UnderInvestigation { get; set; }

    [JsonPropertyName("incidents_with_actions")]
    public int WithActions { get; set; }

    [JsonPropertyName("barrier_failures")]
    public int BarrierFailures { get; set; }

    [JsonPropertyName("average_investigation_days")]
    public decimal AverageInvestigationDays { get; set; }

    [JsonPropertyName("incidents_this_year")]
    public int IncidentsThisYear { get; set; }

    [JsonPropertyName("incidents_last_month")]
    public int IncidentsLastMonth { get; set; }

    [JsonPropertyName("incidents_last_week")]
    public int IncidentsLastWeek { get; set; }

    [JsonPropertyName("lessons_learned_count")]
    public int LessonsLearnedCount { get; set; }

    [JsonPropertyName("barrier_effectiveness_avg")]
    public decimal BarrierEffectivenessAverage { get; set; }

    [JsonPropertyName("last_incident_date")]
    public DateTime? LastIncidentDate { get; set; }
}

/// <summary>
/// Permit Management KPIs
/// </summary>
public class PermitKpisDto
{
    [JsonPropertyName("total_permits")]
    public int TotalPermits { get; set; }

    [JsonPropertyName("active_permits")]
    public int ActivePermits { get; set; }

    [JsonPropertyName("expired_permits")]
    public int ExpiredPermits { get; set; }

    [JsonPropertyName("permits_expiring_soon")]
    public int ExpiringWithin30Days { get; set; }

    [JsonPropertyName("permits_pending_approval")]
    public int PendingApproval { get; set; }

    [JsonPropertyName("rejected_permits")]
    public int RejectedPermits { get; set; }

    [JsonPropertyName("permits_this_month")]
    public int IssuedThisMonth { get; set; }

    [JsonPropertyName("average_approval_days")]
    public decimal AverageApprovalDays { get; set; }

    [JsonPropertyName("permit_types")]
    public Dictionary<string, int> PermitTypeCount { get; set; } = new();

    [JsonPropertyName("compliance_rate")]
    public decimal ComplianceRate { get; set; }

    [JsonPropertyName("high_risk_permits")]
    public int HighRiskPermits { get; set; }

    [JsonPropertyName("latest_permit_date")]
    public DateTime? LatestPermitDate { get; set; }
}

/// <summary>
/// Workflow Execution KPIs
/// </summary>
public class WorkflowKpisDto
{
    [JsonPropertyName("total_workflows")]
    public int TotalWorkflows { get; set; }

    [JsonPropertyName("active_workflows")]
    public int ActiveWorkflows { get; set; }

    [JsonPropertyName("completed_workflows")]
    public int CompletedWorkflows { get; set; }

    [JsonPropertyName("pending_approvals")]
    public int PendingApprovals { get; set; }

    [JsonPropertyName("awaiting_review")]
    public int AwaitingReview { get; set; }

    [JsonPropertyName("overdue_workflows")]
    public int OverdueWorkflows { get; set; }

    [JsonPropertyName("rejected_workflows")]
    public int RejectedWorkflows { get; set; }

    [JsonPropertyName("workflow_types")]
    public Dictionary<string, int> WorkflowTypeCount { get; set; } = new();

    [JsonPropertyName("average_cycle_time_days")]
    public decimal AverageCycleTimeDays { get; set; }

    [JsonPropertyName("completion_rate")]
    public decimal CompletionRate { get; set; }

    [JsonPropertyName("workflows_by_status")]
    public Dictionary<string, int> StatusBreakdown { get; set; } = new();

    [JsonPropertyName("recent_completions")]
    public int CompletedThisMonth { get; set; }

    [JsonPropertyName("avg_approval_time_hours")]
    public decimal AvgApprovalTimeHours { get; set; }
}

/// <summary>
/// Action Register KPIs
/// </summary>
public class ActionRegisterKpisDto
{
    [JsonPropertyName("total_actions")]
    public int TotalActions { get; set; }

    [JsonPropertyName("open_actions")]
    public int OpenActions { get; set; }

    [JsonPropertyName("closed_actions")]
    public int ClosedActions { get; set; }

    [JsonPropertyName("overdue_actions")]
    public int OverdueActions { get; set; }

    [JsonPropertyName("due_within_30_days")]
    public int DueWithin30Days { get; set; }

    [JsonPropertyName("high_priority_actions")]
    public int HighPriorityActions { get; set; }

    [JsonPropertyName("medium_priority_actions")]
    public int MediumPriorityActions { get; set; }

    [JsonPropertyName("low_priority_actions")]
    public int LowPriorityActions { get; set; }

    [JsonPropertyName("actions_by_source")]
    public Dictionary<string, int> SourceBreakdown { get; set; } = new();

    [JsonPropertyName("actions_by_owner")]
    public Dictionary<string, int> OwnerBreakdown { get; set; } = new();

    [JsonPropertyName("average_closure_days")]
    public decimal AverageClosureDays { get; set; }

    [JsonPropertyName("closure_rate_percentage")]
    public decimal ClosureRate { get; set; }

    [JsonPropertyName("effectiveness_score")]
    public decimal EffectivenessScore { get; set; }

    [JsonPropertyName("actions_created_this_month")]
    public int CreatedThisMonth { get; set; }

    [JsonPropertyName("last_action_date")]
    public DateTime? LastActionDate { get; set; }
}

/// <summary>
/// Audit & Compliance KPIs
/// </summary>
public class AuditKpisDto
{
    [JsonPropertyName("total_audit_records")]
    public int TotalAuditRecords { get; set; }

    [JsonPropertyName("audit_records_this_month")]
    public int AuditRecordsThisMonth { get; set; }

    [JsonPropertyName("audit_records_this_year")]
    public int AuditRecordsThisYear { get; set; }

    [JsonPropertyName("unique_users_audited")]
    public int UniqueUsersAudited { get; set; }

    [JsonPropertyName("critical_changes")]
    public int CriticalChanges { get; set; }

    [JsonPropertyName("high_risk_operations")]
    public int HighRiskOperations { get; set; }

    [JsonPropertyName("compliance_actions")]
    public int ComplianceActions { get; set; }

    [JsonPropertyName("audit_events_by_type")]
    public Dictionary<string, int> EventTypeBreakdown { get; set; } = new();

    [JsonPropertyName("audit_events_by_user")]
    public Dictionary<string, int> TopUsersBreakdown { get; set; } = new();

    [JsonPropertyName("data_modifications")]
    public int DataModifications { get; set; }

    [JsonPropertyName("failed_access_attempts")]
    public int FailedAccessAttempts { get; set; }

    [JsonPropertyName("permission_changes")]
    public int PermissionChanges { get; set; }

    [JsonPropertyName("last_audit_date")]
    public DateTime? LastAuditDate { get; set; }
}

/// <summary>
/// Overall Dashboard Summary
/// </summary>
public class DashboardSummaryDto
{
    [JsonPropertyName("total_identified_hazards")]
    public int TotalIdentifiedHazards { get; set; }

    [JsonPropertyName("total_open_actions")]
    public int TotalOpenActions { get; set; }

    [JsonPropertyName("total_overdue_items")]
    public int TotalOverdueItems { get; set; }

    [JsonPropertyName("critical_alerts")]
    public int CriticalAlerts { get; set; }

    [JsonPropertyName("system_health_percentage")]
    public decimal SystemHealthPercentage { get; set; }

    [JsonPropertyName("compliance_status")]
    public string ComplianceStatus { get; set; } = "Compliant";

    [JsonPropertyName("risk_level")]
    public string OverallRiskLevel { get; set; } = "Moderate";

    [JsonPropertyName("barriers_effective")]
    public int BarriersEffective { get; set; }

    [JsonPropertyName("barriers_degraded")]
    public int BarriersDegraded { get; set; }

    [JsonPropertyName("barriers_failed")]
    public int BarriersFailed { get; set; }

    [JsonPropertyName("last_update_timestamp")]
    public DateTime LastUpdateTimestamp { get; set; } = DateTime.UtcNow;

    [JsonPropertyName("data_freshness_minutes")]
    public int DataFreshnessMinutes { get; set; }
}

/// <summary>
/// Request to refresh specific module KPIs
/// </summary>
public class RefreshKpisRequest
{
    [JsonPropertyName("modules")]
    public List<string> Modules { get; set; } = new();
}

/// <summary>
/// KPI Update Event for real-time notifications
/// </summary>
public class KpiUpdateEventDto
{
    [JsonPropertyName("module_name")]
    public string ModuleName { get; set; } = string.Empty;

    [JsonPropertyName("kpi_name")]
    public string KpiName { get; set; } = string.Empty;

    [JsonPropertyName("old_value")]
    public object? OldValue { get; set; }

    [JsonPropertyName("new_value")]
    public object? NewValue { get; set; }

    [JsonPropertyName("change_type")]
    public string ChangeType { get; set; } = string.Empty; // "created", "updated", "deleted"

    [JsonPropertyName("timestamp")]
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;

    [JsonPropertyName("user_id")]
    public string? UserId { get; set; }
}
