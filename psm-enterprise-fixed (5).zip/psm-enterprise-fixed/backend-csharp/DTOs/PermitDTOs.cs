using System.Text.Json.Serialization;

namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════
// Permit To Work (PTW) — DTOs
// Columns map directly from work_permits and child tables.
// Dapper.DefaultTypeMap.MatchNamesWithUnderscores = true is set globally
// in Program.cs, so snake_case DB columns bind to PascalCase properties.
// ════════════════════════════════════════════════════════════════════════════

// ── Main permit ──────────────────────────────────────────────────────────────

public class PermitDto
{
    public string   Id                      { get; set; } = "";
    public string   TenantId                { get; set; } = "tenant_1";
    public string   PermitType              { get; set; } = "";
    public string   JobTitle                { get; set; } = "";
    public string?  Description             { get; set; }
    public string   Location                { get; set; } = "";
    public DateTime JobDate                 { get; set; }
    public decimal? EstimatedDuration       { get; set; }
    public DateTime? ActualStartTime        { get; set; }
    public DateTime? ActualEndTime          { get; set; }
    public string   ContractorName          { get; set; } = "";
    public string?  ContractorLicense       { get; set; }
    public string   Supervisor              { get; set; } = "";
    public string   State                   { get; set; } = "Draft";
    public DateTime? StateChangedAt         { get; set; }
    public string?  RiskLevel               { get; set; }
    public bool     SupervisorApproval      { get; set; }
    public bool     HseApproval             { get; set; }
    public bool     AreaManagerApproval     { get; set; }
    public string?  EscalationLevel         { get; set; }
    public string?  FormData                { get; set; }   // JSONB → string
    public string[]? RequiredPpe            { get; set; }
    public string[]? RequiredEquipment      { get; set; }
    public string?  AdditionalMeasures      { get; set; }
    public decimal? ActualDuration          { get; set; }
    public string?  SafetyIncidents         { get; set; }
    public string?  IssuesEncountered       { get; set; }
    public string?  CompletionNotes         { get; set; }
    public string?  WatchPerson             { get; set; }
    public bool     SafetyBriefingConducted { get; set; }
    public bool     EquipmentStatusCheck    { get; set; }
    public bool     SiteRestoration         { get; set; }
    public bool     ToolsReturned           { get; set; }
    public string?  CreatedBy               { get; set; }
    public DateTime CreatedAt               { get; set; }
    public string?  LastModifiedBy          { get; set; }
    public DateTime UpdatedAt               { get; set; }
    public string[]? Tags                   { get; set; }
    public string?  CustomFields            { get; set; }   // JSONB → string
}

public class PermitDetailDto : PermitDto
{
    public List<PermitCrewDto>          Crew            { get; set; } = new();
    public List<PermitSafetyRecordDto>  SafetyRecords   { get; set; } = new();
    public List<PermitSlaTrackingDto>   SlaTracking     { get; set; } = new();
    public List<PermitEscalationDto>    Escalations     { get; set; } = new();
    public List<PermitLessonDto>        LessonsLearned  { get; set; } = new();

    // Computed fields
    public bool     IsOverdue           { get; set; }
    public string?  WorkflowInstanceId  { get; set; }
    public List<string> AvailableActions { get; set; } = new();
}

// ── Child tables ─────────────────────────────────────────────────────────────

public class PermitCrewDto
{
    public int      Id                  { get; set; }
    public string   PermitId            { get; set; } = "";
    public string   CrewMemberName      { get; set; } = "";
    public string?  CrewMemberId        { get; set; }
    public string?  Role                { get; set; }
    public string[]? Qualifications     { get; set; }
    public bool     TrainedForTask      { get; set; }
    public DateTime AddedAt             { get; set; }
}

public class PermitSafetyRecordDto
{
    public int      Id                  { get; set; }
    public string   PermitId            { get; set; } = "";
    public string?  SafetyCheckType     { get; set; }
    public DateTime CheckedAt           { get; set; }
    public string?  CheckedBy           { get; set; }
    public string?  Status              { get; set; }
    public string?  Findings            { get; set; }
    public string?  CorrectiveActions   { get; set; }
    public DateTime? FollowUpDate       { get; set; }
}

public class PermitSlaTrackingDto
{
    public int      Id                  { get; set; }
    public string   PermitId            { get; set; } = "";
    public string   State               { get; set; } = "";
    public decimal  TargetHours         { get; set; }
    public DateTime EnteredAt           { get; set; }
    public DateTime? ExitedAt           { get; set; }
    public bool     Exceeded            { get; set; }
}

public class PermitEscalationDto
{
    public int      Id                  { get; set; }
    public string   PermitId            { get; set; } = "";
    public string?  EscalationReason    { get; set; }
    public string[]? EscalatedTo        { get; set; }
    public DateTime EscalatedAt         { get; set; }
    public DateTime? ResolvedAt         { get; set; }
    public string?  ResolvedBy          { get; set; }
    public string?  ResolutionNotes     { get; set; }
}

public class PermitLessonDto
{
    public int      Id                       { get; set; }
    public string   PermitId                 { get; set; } = "";
    public string?  LessonTitle              { get; set; }
    public string?  Description              { get; set; }
    public string?  LessonCategory           { get; set; }
    public bool     SharedOrganizationWide   { get; set; }
    public DateTime CreatedAt                { get; set; }
    public string?  CreatedBy                { get; set; }
}

// ── Request DTOs ─────────────────────────────────────────────────────────────

public class CreatePermitRequest
{
    public string   PermitType              { get; set; } = "";
    public string   JobTitle                { get; set; } = "";
    public string?  Description             { get; set; }
    public string   Location                { get; set; } = "";
    public DateTime JobDate                 { get; set; }
    public decimal? EstimatedDuration       { get; set; }
    public string   ContractorName          { get; set; } = "";
    public string?  ContractorLicense       { get; set; }
    public string   Supervisor              { get; set; } = "";
    public string?  RiskLevel               { get; set; }
    public string[]? RequiredPpe            { get; set; }
    public string[]? RequiredEquipment      { get; set; }
    public string?  AdditionalMeasures      { get; set; }
    public string?  WatchPerson             { get; set; }
    public string[]? Tags                   { get; set; }
    public string?  TenantId               { get; set; }

    // Optional crew members to attach at creation
    public List<CreateCrewMemberRequest>? Crew { get; set; }
}

public class UpdatePermitRequest
{
    public string?  PermitType              { get; set; }
    public string?  JobTitle                { get; set; }
    public string?  Description             { get; set; }
    public string?  Location                { get; set; }
    public DateTime? JobDate                { get; set; }
    public decimal? EstimatedDuration       { get; set; }
    public DateTime? ActualStartTime        { get; set; }
    public DateTime? ActualEndTime          { get; set; }
    public string?  ContractorName          { get; set; }
    public string?  ContractorLicense       { get; set; }
    public string?  Supervisor              { get; set; }
    public string?  RiskLevel               { get; set; }
    public string[]? RequiredPpe            { get; set; }
    public string[]? RequiredEquipment      { get; set; }
    public string?  AdditionalMeasures      { get; set; }
    public decimal? ActualDuration          { get; set; }
    public string?  SafetyIncidents         { get; set; }
    public string?  IssuesEncountered       { get; set; }
    public string?  CompletionNotes         { get; set; }
    public string?  WatchPerson             { get; set; }
    public bool?    SafetyBriefingConducted { get; set; }
    public bool?    EquipmentStatusCheck    { get; set; }
    public bool?    SiteRestoration         { get; set; }
    public bool?    ToolsReturned           { get; set; }
    public string[]? Tags                   { get; set; }
}

public class ApprovePermitRequest
{
    /// <summary>Which approval level: supervisor | hse | area_manager</summary>
    public string   Level       { get; set; } = "supervisor";
    public string?  Comment     { get; set; }
}

public class ClosePermitRequest
{
    public string?  CompletionNotes     { get; set; }
    public string?  SafetyIncidents     { get; set; }
    public string?  IssuesEncountered   { get; set; }
    public decimal? ActualDuration      { get; set; }
    public bool     SiteRestoration     { get; set; }
    public bool     ToolsReturned       { get; set; }
}

public class CreateCrewMemberRequest
{
    public string   CrewMemberName  { get; set; } = "";
    public string?  CrewMemberId    { get; set; }
    public string?  Role            { get; set; }
    public string[]? Qualifications { get; set; }
    public bool     TrainedForTask  { get; set; }
}

public class AddSafetyRecordRequest
{
    public string?  SafetyCheckType     { get; set; }
    public string?  Status              { get; set; }
    public string?  Findings            { get; set; }
    public string?  CorrectiveActions   { get; set; }
    public DateTime? FollowUpDate       { get; set; }
}

public class AddLessonRequest
{
    public string?  LessonTitle             { get; set; }
    public string?  Description             { get; set; }
    public string?  LessonCategory          { get; set; }
    public bool     SharedOrganizationWide  { get; set; }
}

// ── List / summary ────────────────────────────────────────────────────────────

public class PermitListDto
{
    public string   Id              { get; set; } = "";
    public string   PermitType      { get; set; } = "";
    public string   JobTitle        { get; set; } = "";
    public string   Location        { get; set; } = "";
    public DateTime JobDate         { get; set; }
    public string   State           { get; set; } = "";
    public string?  RiskLevel       { get; set; }
    public string   ContractorName  { get; set; } = "";
    public string   Supervisor      { get; set; } = "";
    public bool     SupervisorApproval  { get; set; }
    public bool     HseApproval         { get; set; }
    public bool     AreaManagerApproval { get; set; }
    public string?  CreatedBy       { get; set; }
    public DateTime CreatedAt       { get; set; }
    public DateTime UpdatedAt       { get; set; }
}
