namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════════════
// UNIFIED BARRIER MANAGEMENT DTOs
// Extends and replaces existing BarrierManagementDTOs.cs
// Backward-compatible: all existing types are preserved unchanged.
// ════════════════════════════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────────────────────────────
// API REQUEST DTOs
// POST /api/barriers
// ─────────────────────────────────────────────────────────────────────────────────

public class CreateUnifiedBarrierRequest
{
    public string BarrierName { get; set; } = null!;
    public string BarrierType { get; set; } = "Engineering"; // Engineering|Administrative|Procedural|SIS|Detection
    public string? Description { get; set; }
    public string? OwnerDiscipline { get; set; }
    public string? OwnerContact { get; set; }
    public string? MaintenanceFrequency { get; set; }
    public decimal? EffectivenessRating { get; set; }
    public string Status { get; set; } = "Active";
    public int? SilLevel { get; set; }
    public string? DocumentationRef { get; set; }
    public bool CriticalFlag { get; set; }
    /// <summary>When provided, the new Barrier is linked to this LOPA IPL on creation.</summary>
    public string? LopaIplId { get; set; }
    /// <summary>When provided, the new Barrier is linked to this BowTie Barrier on creation.</summary>
    public string? BowTieBarrierId { get; set; }
}

// ─────────────────────────────────────────────────────────────────────────────────
// PUT /api/barriers/{id}/status
// ─────────────────────────────────────────────────────────────────────────────────

public class UpdateUnifiedBarrierStatusRequest
{
    /// <summary>Must be one of: Active | Degraded | Failed | OutOfService</summary>
    public string NewStatus { get; set; } = null!;
    public string? Reason { get; set; }
    /// <summary>Optional incident that triggered this status change.</summary>
    public string? TriggeredByIncidentId { get; set; }
}

// ─────────────────────────────────────────────────────────────────────────────────
// POST /api/incidents/{id}/barriers
// ─────────────────────────────────────────────────────────────────────────────────

public class LinkBarrierToIncidentRequest
{
    public string BarrierId { get; set; } = null!;
    public string? BarrierFailureType { get; set; } // Not Available | Failed to Function | Inadequate Effectiveness
    public string? FailureEvidence { get; set; }
    public decimal? ContributionToIncident { get; set; }
}

// ─────────────────────────────────────────────────────────────────────────────────
// BARRIER FULL RESPONSE  (GET /api/barriers, GET /api/barriers/{id})
// ─────────────────────────────────────────────────────────────────────────────────

public class UnifiedBarrierDto
{
    public string Id { get; set; } = null!;
    public string BarrierName { get; set; } = null!;
    public string BarrierType { get; set; } = null!;
    public string? Description { get; set; }
    public string? OwnerDiscipline { get; set; }
    public string? OwnerContact { get; set; }
    public string? MaintenanceFrequency { get; set; }
    public DateTime? LastTested { get; set; }
    public DateTime? NextTestDue { get; set; }
    public decimal EffectivenessRating { get; set; }
    public string Status { get; set; } = null!;          // Active | Degraded | Failed | OutOfService
    public string? FailureMode { get; set; }
    public string? FailureReason { get; set; }
    public DateTime? FailureDate { get; set; }
    public string? RemediationPlan { get; set; }
    public DateTime? RemediationDueDate { get; set; }
    public decimal? PfdActual { get; set; }
    public int? SilLevel { get; set; }
    public string? DocumentationRef { get; set; }
    public bool CriticalFlag { get; set; }

    // Unified-model links
    public string? LopaIplId { get; set; }
    public string? LopaIplName { get; set; }
    public string? BowTieBarrierId { get; set; }
    public string? BowTieDiagramId { get; set; }
    public string? BowTieDiagramTitle { get; set; }
    public string? BowTieSide { get; set; }              // Preventive | Recovery

    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
    public bool Deleted { get; set; }

    public List<BarrierStatusHistoryEntryDto> StatusHistory { get; set; } = new();
}

// ─────────────────────────────────────────────────────────────────────────────────
// GET /api/barriers/{id}/impact
// ─────────────────────────────────────────────────────────────────────────────────

public class UnifiedBarrierImpactDto
{
    public string BarrierId { get; set; } = null!;
    public string BarrierName { get; set; } = null!;
    public string Status { get; set; } = null!;
    public decimal EffectivenessRating { get; set; }
    public bool CriticalFlag { get; set; }

    // Direct LOPA link
    public BarrierLinkedLopaIplDto? LopaIpl { get; set; }
    public BarrierLinkedLopaScenarioDto? LopaScenario { get; set; }
    public BarrierLinkedLopaStudyDto? LopaStudy { get; set; }

    // Direct BowTie link
    public BarrierLinkedBowTieBarrierDto? BowTieBarrier { get; set; }
    public BarrierLinkedBowTieDiagramDto? BowTieDiagram { get; set; }

    // HAZOP (via LOPA → HAZOP deviation)
    public BarrierLinkedHazopDeviationDto? HazopDeviation { get; set; }
    public BarrierLinkedHazopStudyDto? HazopStudy { get; set; }

    // Summary counts
    public int LinkedHazopStudies { get; set; }
    public int LinkedHazopDeviations { get; set; }
    public int LinkedLopaStudies { get; set; }
    public int LinkedLopaScenarios { get; set; }
    public int LinkedLopaIpls { get; set; }
    public int LinkedBowTieDiagrams { get; set; }
    public int LinkedIncidents { get; set; }
    public List<string> RelatedIncidentNumbers { get; set; } = new();

    public List<BarrierStatusHistoryEntryDto> StatusHistory { get; set; } = new();
}

public class BarrierLinkedLopaIplDto
{
    public string Id { get; set; } = null!;
    public string? IplName { get; set; }
    public string? IplType { get; set; }
    public double Pfd { get; set; }
    public string? Status { get; set; }
}

public class BarrierLinkedLopaScenarioDto
{
    public string Id { get; set; } = null!;
    public string? ScenarioNumber { get; set; }
    public string? InitiatingEvent { get; set; }
    public double ResidualRisk { get; set; }
    public bool RiskGapMet { get; set; }
}

public class BarrierLinkedLopaStudyDto
{
    public string Id { get; set; } = null!;
    public string? Title { get; set; }
    public string? Status { get; set; }
}

public class BarrierLinkedBowTieBarrierDto
{
    public string Id { get; set; } = null!;
    public string? Description { get; set; }
    public string? BowTieSide { get; set; }
    public string? Status { get; set; }
}

public class BarrierLinkedBowTieDiagramDto
{
    public string Id { get; set; } = null!;
    public string? Title { get; set; }
    public string? TopEvent { get; set; }
}

public class BarrierLinkedHazopDeviationDto
{
    public string Id { get; set; } = null!;
    public string? Deviation { get; set; }
    public string? RiskLevel { get; set; }
}

public class BarrierLinkedHazopStudyDto
{
    public string Id { get; set; } = null!;
    public string? Title { get; set; }
}

// ─────────────────────────────────────────────────────────────────────────────────
// GET /api/incidents/{id}/impact
// ─────────────────────────────────────────────────────────────────────────────────

public class UnifiedIncidentImpactDto
{
    public string IncidentId { get; set; } = null!;
    public string? IncidentNumber { get; set; }
    public string? Title { get; set; }
    public int SeverityActual { get; set; }
    public DateTime? DateOccurred { get; set; }
    public string? Status { get; set; }

    public List<IncidentBarrierSummaryDto> Barriers { get; set; } = new();
    public List<RelatedHazopStudyDto> RelatedHazopStudies { get; set; } = new();
    public List<RelatedHazopDeviationDto> RelatedHazopDeviations { get; set; } = new();
    public List<RelatedLopaStudyDto> RelatedLopaStudies { get; set; } = new();
    public List<RelatedLopaScenarioDto> RelatedLopaScenarios { get; set; } = new();
    public List<RelatedBowTieDiagramDto> RelatedBowTieDiagrams { get; set; } = new();

    public IncidentImpactSummaryDto Summary { get; set; } = new();
}

public class IncidentBarrierSummaryDto
{
    public string BarrierId { get; set; } = null!;
    public string? BarrierName { get; set; }
    public string? BarrierType { get; set; }
    public string? BarrierStatus { get; set; }
    public bool CriticalFlag { get; set; }
    public string? BarrierFailureType { get; set; }
    public string? FailureEvidence { get; set; }
    public decimal? ContributionToIncident { get; set; }
}

public class RelatedHazopStudyDto
{
    public string Id { get; set; } = null!;
    public string? Title { get; set; }
    public string? Facility { get; set; }
    public string? Status { get; set; }
}

public class RelatedHazopDeviationDto
{
    public string Id { get; set; } = null!;
    public string? StudyId { get; set; }
    public string? Deviation { get; set; }
    public string? GuideWord { get; set; }
    public string? Parameter { get; set; }
    public string? RiskLevel { get; set; }
}

public class RelatedLopaStudyDto
{
    public string Id { get; set; } = null!;
    public string? Title { get; set; }
    public string? Status { get; set; }
}

public class RelatedLopaScenarioDto
{
    public string Id { get; set; } = null!;
    public string? LopaStudyId { get; set; }
    public string? ScenarioNumber { get; set; }
    public string? InitiatingEvent { get; set; }
    public double ResidualRisk { get; set; }
    public bool RiskGapMet { get; set; }
}

public class RelatedBowTieDiagramDto
{
    public string Id { get; set; } = null!;
    public string? Title { get; set; }
    public string? TopEvent { get; set; }
    public string? Hazard { get; set; }
}

public class IncidentImpactSummaryDto
{
    public int BarriersInvolved { get; set; }
    public int CriticalBarriersAffected { get; set; }
    public int HazopStudiesAffected { get; set; }
    public int LopaStudiesAffected { get; set; }
    public int BowTieDiagramsAffected { get; set; }
}

// ─────────────────────────────────────────────────────────────────────────────────
// STATUS CHANGE RESULT  (PUT /api/barriers/{id}/status response)
// ─────────────────────────────────────────────────────────────────────────────────

public class UnifiedBarrierStatusUpdateResultDto
{
    public bool Success { get; set; }
    public string Message { get; set; } = null!;
    public int AffectedRows { get; set; }
    public UnifiedBarrierDto? UpdatedBarrier { get; set; }
    public string? SyncedLopaIplId { get; set; }
    public string? SyncedLopaIplStatus { get; set; }
    public string? SyncedBowTieBarrierId { get; set; }
    public string? SyncedBowTieBarrierStatus { get; set; }
    public List<string> AuditLogIds { get; set; } = new();
}

// ─────────────────────────────────────────────────────────────────────────────────
// INCIDENT WITH FULL BARRIER CONTEXT  (GET /api/incidents/{id}/barriers)
// ─────────────────────────────────────────────────────────────────────────────────

public class UnifiedIncidentWithBarriersDto
{
    public string Id { get; set; } = null!;
    public string? IncidentNumber { get; set; }
    public string? Title { get; set; }
    public string? Description { get; set; }
    public string? Facility { get; set; }
    public string? Unit { get; set; }
    public DateTime? DateOccurred { get; set; }
    public string? IncidentType { get; set; }
    public int SeverityActual { get; set; }
    public string? Status { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }

    public List<UnifiedBarrierDto> Barriers { get; set; } = new();
    public List<string> RelatedHazopStudyIds { get; set; } = new();
    public List<string> RelatedHazopDeviationIds { get; set; } = new();
    public List<string> RelatedLopaStudyIds { get; set; } = new();
    public List<string> RelatedLopaScenarioIds { get; set; } = new();
    public List<string> RelatedBowTieDiagramIds { get; set; } = new();
}

// ─────────────────────────────────────────────────────────────────────────────────
// BARRIER AUDIT LOG DTO
// ─────────────────────────────────────────────────────────────────────────────────

public class BarrierAuditLogEntryDto
{
    public string Id { get; set; } = null!;
    public string BarrierId { get; set; } = null!;
    public string Action { get; set; } = null!; // STATUS_CHANGE | FIELD_UPDATE | CREATED | DELETED | SYNC_LOPA | SYNC_BOWTIE
    public string? FieldName { get; set; }
    public string? OldValue { get; set; }
    public string? NewValue { get; set; }
    public string? Reason { get; set; }
    public string? TriggeredBy { get; set; }        // user | system | cascade | trigger
    public string? TriggeredByEntity { get; set; }  // incident | lopa_ipl | bowtie_barrier
    public string? TriggeredById { get; set; }
    public string? ChangedBy { get; set; }
    public DateTime ChangedAt { get; set; }
}

// ─────────────────────────────────────────────────────────────────────────────────
// LOPA IPL DTO EXTENSION  (adds unified-model sync fields)
// ─────────────────────────────────────────────────────────────────────────────────

public class LopaIplWithBarrierRefDto
{
    public string Id { get; set; } = null!;
    public string? ScenarioId { get; set; }
    public string? IplName { get; set; }
    public string? IplType { get; set; }
    public string? Description { get; set; }
    public double Pfd { get; set; }
    public bool IsValidated { get; set; }
    public string? Owner { get; set; }
    public string? AuditInterval { get; set; }
    public string? Status { get; set; }
    public int FailureCount { get; set; }
    public DateTime? LastStatusSync { get; set; }

    // Unified barrier reference
    public string? RiskBarrierId { get; set; }
    public string? BowTieBarrierId { get; set; }
    public UnifiedBarrierDto? LinkedBarrier { get; set; }

    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

// ─────────────────────────────────────────────────────────────────────────────────
// BOWTIE BARRIER DTO EXTENSION  (adds unified-model sync fields)
// ─────────────────────────────────────────────────────────────────────────────────

public class BowTieBarrierWithBarrierRefDto
{
    public string Id { get; set; } = null!;
    public string DiagramId { get; set; } = null!;
    public string? Description { get; set; }
    public string? Type { get; set; }
    public string? RiskReduction { get; set; }
    public int SortOrder { get; set; }
    public string? BarrierStatus { get; set; }
    public bool IsDegraded { get; set; }
    public string? BowTieSide { get; set; }         // Preventive | Recovery
    public string? LopaIplId { get; set; }
    public DateTime? LastTested { get; set; }
    public string? LinkedBarrierId { get; set; }
    public UnifiedBarrierDto? LinkedBarrier { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}
