namespace PSM.Api.DTOs;

// ═══════════════════════════════════════════════════════════════════════════════
// Domain Entity DTOs
// ═══════════════════════════════════════════════════════════════════════════════

public record AssetDto(
    string Id,
    string Name,
    string? Description,
    string? Category,
    string? Manufacturer,
    string? ModelNumber,
    string? SerialNumber,
    string? Unit,
    DateTime? InstallationDate,
    DateTime? LastMaintenance,
    string? Status,
    string? DesignCode,
    string? Criticality,
    string? DrawingReference,
    DateTime CreatedAt,
    DateTime UpdatedAt,
    string? CreatedBy
);

public record CreateAssetDto(
    string Name,
    string? Description,
    string? Category,
    string? Manufacturer,
    string? ModelNumber,
    string? SerialNumber,
    string? Unit,
    DateTime? InstallationDate,
    string? Status,
    string? DesignCode,
    string? Criticality,
    string? DrawingReference
);

public record UpdateAssetDto(
    string Name,
    string? Description,
    string? Status,
    string? DrawingReference,
    DateTime? LastMaintenance
);

public record ProcessUnitDto(
    string Id,
    string Name,
    string? Description,
    string? UnitType,
    string? Location,
    string? OperatingMode,
    double? DesignTemperature,
    double? DesignPressure,
    string? PressureUnit,
    string? Status,
    string? ResponsiblePerson,
    DateTime CreatedAt,
    DateTime UpdatedAt
);

public record HazardDto(
    string Id,
    string Name,
    string? Description,
    string HazardCategory,
    string? HazardSource,
    string? Severity,
    string? Probability,
    string? RiskLevel,
    string? Status,
    string? ProcessUnitId,
    DateTime? IdentifiedDate,
    string? IdentifiedBy,
    DateTime CreatedAt
);

public record ScenarioDto(
    string Id,
    string Name,
    string? Description,
    string? ScenarioType,
    string? TriggeringEvent,
    string? Consequences,
    string? Severity,
    string? Likelihood,
    string? RiskLevel,
    string? HazardId,
    string? ProcessUnitId,
    DateTime CreatedAt
);

public record ActionItemDto(
    string Id,
    string Title,
    string? Description,
    string? ActionType,
    string Priority,
    string Status,
    string? Owner,
    DateTime DueDate,
    DateTime? CompletionDate,
    string? SourceModule,
    string? SourceId,
    string? VerifiedBy,
    DateTime? VerificationDate,
    DateTime CreatedAt
);

public record PsmDocumentDto(
    string Id,
    string Title,
    string? Description,
    string DocumentType,
    string? Module,
    string? Version,
    DateTime? RevisionDate,
    string? ApprovedBy,
    bool IsArchived,
    string[]? Tags,
    DateTime CreatedAt
);

// ═══════════════════════════════════════════════════════════════════════════════
// Relationship DTOs
// ═══════════════════════════════════════════════════════════════════════════════

public record PsmRelationshipDto(
    string Id,
    string RelationshipType,
    string SourceEntityType,
    string SourceEntityId,
    string TargetEntityType,
    string TargetEntityId,
    string Direction,
    int? Weight,
    string Status,
    string? Context,
    DateTime EstablishedDate,
    DateTime CreatedAt
);

public record CreateRelationshipDto(
    string RelationshipType,
    string SourceEntityType,
    string SourceEntityId,
    string TargetEntityType,
    string TargetEntityId,
    string? Direction = "OneWay",
    int? Weight = null,
    string? Context = null,
    string? Notes = null
);

public record UpdateRelationshipDto(
    string? Status = null,
    int? Weight = null,
    string? Context = null,
    string? Notes = null
);

public record RelationshipChangeDto(
    string Id,
    string RelationshipId,
    string ChangeType,
    string? FieldChanged,
    string? OldValue,
    string? NewValue,
    string? ChangedBy,
    DateTime ChangeTimestamp,
    DateTime CreatedAt
);

public record EntityReferenceDto(
    string EntityType,
    string EntityId,
    int ReferenceCount,
    DateTime LastReferencedDate
);

public record RelationshipLineageDto(
    string Id,
    string RootEntityType,
    string RootEntityId,
    string DownstreamEntityType,
    string DownstreamEntityId,
    int PathLength,
    string PathDescription,
    string? CriticalityLevel,
    DateTime CalculatedDate,
    bool IsActive
);

public record ImpactAnalysisResultDto(
    string EntityId,
    string EntityType,
    List<ImpactedItemDto> DirectlyImpacted,
    List<ImpactedItemDto> IndirectlyImpacted,
    int TotalImpactedRecords,
    string OverallRiskLevel,
    string? Recommendation,
    DateTime AnalysisDate
);

public record ImpactedItemDto(
    string EntityId,
    string EntityType,
    string RelationshipType,
    int HopsFromRoot,
    string? ImpactDescription,
    string? RiskLevel,
    string? RecommendedAction
);

public record RelationshipQueryDto(
    string EntityId,
    string EntityType,
    List<RelationshipGraphNodeDto> InboundRelationships,
    List<RelationshipGraphNodeDto> OutboundRelationships,
    Dictionary<string, int> RelationshipSummary
);

public record RelationshipGraphNodeDto(
    string EntityId,
    string EntityType,
    string RelationshipType,
    int HopsFromRoot,
    string? EntityName,
    string? EntityStatus
);

public record BulkCreateRelationshipsDto(
    List<CreateRelationshipDto> Relationships,
    string? BatchDescription = null,
    string? ApprovalRequired = "false"
);

public record BulkCreateRelationshipsResultDto(
    int SuccessCount,
    int FailureCount,
    List<string> CreatedRelationshipIds,
    List<string> FailureReasons
);

public record RelationshipValidationResultDto(
    bool IsValid,
    List<string>? ValidationErrors = null,
    List<string>? Warnings = null,
    string? SuggestedSourceId = null,
    string? SuggestedTargetId = null
);

public record RelationshipAuditEntryDto(
    string Id,
    string RelationshipId,
    string Action,
    Dictionary<string, object>? Changes,
    string? Reason,
    string? ActedBy,
    DateTime Timestamp
);

public record RelationshipStatisticsDto(
    int TotalRelationships,
    Dictionary<string, int> RelationshipTypeCount,
    Dictionary<string, int> EntityTypeCount,
    int ActiveRelationshipCount,
    int ArchivedRelationshipCount,
    List<TopRelationshipDto> TopRelationships,
    DateTime CalculatedAt
);

public record TopRelationshipDto(
    string RelationshipType,
    int Count,
    double PercentageOfTotal
);

public record CrossModuleFlowDto(
    string SourceModule,
    string TargetModule,
    List<PsmRelationshipDto> Relationships,
    int RelationshipCount,
    List<string> SourceIds,
    List<string> TargetIds
);

public record IntegrationHealthDto(
    string ModuleA,
    string ModuleB,
    int RelationshipCount,
    List<string> MissingIntegrations,
    string HealthStatus, // Good, Warning, Critical
    string? Recommendation
);

public record EntityComplianceCheckDto(
    string EntityId,
    string EntityType,
    bool IsCompliant,
    List<string> MissingRelationships,
    List<string> ExcessRelationships,
    List<string> ComplianceIssues,
    string? Recommendation
);
