namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════
// Notification DTOs
// Table: notifications (id TEXT, user_id TEXT, type TEXT, title TEXT,
//        message TEXT, module TEXT, record_id TEXT, is_read BOOLEAN,
//        created_at TIMESTAMPTZ)
// Dapper.DefaultTypeMap.MatchNamesWithUnderscores = true (set in Program.cs)
// ════════════════════════════════════════════════════════════════════════════

public class NotificationDto
{
    public string   Id        { get; set; } = "";
    public string?  UserId    { get; set; }
    public string?  Type      { get; set; }   // info | warning | approval | success | error
    public string?  Title     { get; set; }
    public string?  Message   { get; set; }
    public string?  Module    { get; set; }
    public string?  RecordId  { get; set; }
    public bool     IsRead    { get; set; }
    public DateTime CreatedAt { get; set; }
    public string[]? Recipients { get; set; }
}

public class NotificationPageDto
{
    public List<NotificationDto> Data       { get; set; } = new();
    public int                   Total      { get; set; }
    public int                   UnreadCount{ get; set; }
    public int                   Page       { get; set; }
    public int                   Limit      { get; set; }
}

/// <summary>Used internally by services to push a notification.</summary>
public class CreateNotificationRequest
{
    public string?  UserId   { get; set; }   // null → broadcast / system
    public string   Type     { get; set; } = "info";
    public string   Title    { get; set; } = "";
    public string   Message  { get; set; } = "";
    public string?  Module   { get; set; }
    public string?  RecordId { get; set; }
}
