namespace PSM.Api.DTOs;
public class LicenseStatusDto
{
    public string? Status { get; set; }        // "active", "expired", "trial", "invalid"
    public string? LicenseKey { get; set; }
    public DateTime IssuedDate { get; set; }
    public DateTime ExpiryDate { get; set; }
    public string? LicenseType { get; set; }   // "professional", "enterprise", "trial"
    public int MaxUsers { get; set; }
    public int CurrentUsers { get; set; }
    public int MaxProjects { get; set; }
    public int CurrentProjects { get; set; }
    public bool IsExpired { get; set; }
    public int DaysRemaining { get; set; }
    public string? Organization { get; set; }
}

public class MachineIdDto
{
    public string? MachineId { get; set; }
    public string? Hostname { get; set; }
    public string? OsVersion { get; set; }
    public string? DotNetVersion { get; set; }
}

public class ActivateLicenseDto
{
    public string? LicenseKey { get; set; }
    public string? Organization { get; set; }
    public string? ContactEmail { get; set; }
}

public class ActivateLicenseResponseDto
{
    public bool Success { get; set; }
    public string? Message { get; set; }
    public LicenseStatusDto? LicenseStatus { get; set; }
}

public class DeactivateLicenseResponseDto
{
    public bool Success { get; set; }
    public string? Message { get; set; }
}
