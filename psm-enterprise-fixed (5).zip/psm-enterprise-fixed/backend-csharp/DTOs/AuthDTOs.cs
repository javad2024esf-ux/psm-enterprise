namespace PSM.Api.DTOs;

public record LoginRequest(string Username, string Password);
public record RefreshRequest(string Token);
public record ChangePasswordRequest
{
    // Frontend sends "oldPassword"; also accept "currentPassword" for API clients
    [System.Text.Json.Serialization.JsonPropertyName("oldPassword")]
    public string? OldPassword { get; init; }

    [System.Text.Json.Serialization.JsonPropertyName("currentPassword")]
    public string? CurrentPassword { get; init; }

    public string NewPassword { get; init; } = string.Empty;

    [System.Text.Json.Serialization.JsonIgnore]
    public string ResolvedCurrentPassword => OldPassword ?? CurrentPassword ?? string.Empty;
}

public record LoginResponse(bool Success, string? Token, string? RefreshToken, object? User, string? Error = null);
