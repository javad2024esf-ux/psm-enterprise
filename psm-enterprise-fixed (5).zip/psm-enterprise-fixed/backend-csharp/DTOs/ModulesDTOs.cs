using System.Text.Json.Serialization;

namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════
// HIRA — Hazard Identification and Risk Assessment
// ════════════════════════════════════════════════════════════════════════════
public class CreateHiraRequest
{
    public string? title { get; set; }
    public string? facility { get; set; }
    public string? department { get; set; }
    public string? assessor { get; set; }
    public string? status { get; set; }
    public DateTime? assessment_date { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateHiraRequest : CreateHiraRequest { }
public class HiraDto
{
    public string? id { get; set; }
    public string? title { get; set; }
    public string? facility { get; set; }
    public string? department { get; set; }
    public string? assessor { get; set; }
    public string? status { get; set; }
    public DateTime? assessment_date { get; set; }
    public DateTime? created_at { get; set; }
    public string? created_by { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class CreateHiraHazardRequest
{
    public string? hira_id { get; set; }
    public string? hazard_description { get; set; }
    public string? activity { get; set; }
    public string? potential_consequence { get; set; }
    public string? existing_controls { get; set; }
    public int likelihood { get; set; }
    public int severity { get; set; }
    public string? risk_level { get; set; }
    public string? recommended_actions { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateHiraHazardRequest : CreateHiraHazardRequest { }
public class HiraHazardDto
{
    public string? id { get; set; }
    public string? hira_id { get; set; }
    public string? hazard_description { get; set; }
    public string? activity { get; set; }
    public string? potential_consequence { get; set; }
    public string? existing_controls { get; set; }
    public int likelihood { get; set; }
    public int severity { get; set; }
    public string? risk_level { get; set; }
    public string? recommended_actions { get; set; }
    public DateTime? created_at { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// RCA — Root Cause Analysis
// ════════════════════════════════════════════════════════════════════════════
public class CreateRcaRequest
{
    public string? title { get; set; }
    public string? incident_date { get; set; }
    public string? location { get; set; }
    public string? description { get; set; }
    public string? investigator { get; set; }
    public string? status { get; set; }
    public string? methodology { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateRcaRequest : CreateRcaRequest { }
public class RcaDto
{
    public string? id { get; set; }
    public string? title { get; set; }
    public string? incident_date { get; set; }
    public string? location { get; set; }
    public string? description { get; set; }
    public string? investigator { get; set; }
    public string? status { get; set; }
    public string? methodology { get; set; }
    public DateTime? created_at { get; set; }
    public string? created_by { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class CreateRcaCauseRequest
{
    public string? rca_id { get; set; }
    public string? cause_type { get; set; }
    public string? description { get; set; }
    public string? contributing_factor { get; set; }
    public string? corrective_action { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateRcaCauseRequest : CreateRcaCauseRequest { }
public class RcaCauseDto
{
    public string? id { get; set; }
    public string? rca_id { get; set; }
    public string? cause_type { get; set; }
    public string? description { get; set; }
    public string? contributing_factor { get; set; }
    public string? corrective_action { get; set; }
    public DateTime? created_at { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Competency — Competency Management
// ════════════════════════════════════════════════════════════════════════════
public class CreateCompetencyRequest
{
    public string? title { get; set; }
    public string? category { get; set; }
    public string? description { get; set; }
    public string? level { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateCompetencyRequest : CreateCompetencyRequest { }
public class CompetencyDto
{
    public string? id { get; set; }
    public string? title { get; set; }
    public string? category { get; set; }
    public string? description { get; set; }
    public string? level { get; set; }
    public DateTime? created_at { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class CreateCompetencyAssessmentRequest
{
    public string? competency_id { get; set; }
    public string? employee_id { get; set; }
    public string? employee_name { get; set; }
    public int score { get; set; }
    public string? assessor { get; set; }
    public DateTime? assessment_date { get; set; }
    public string? notes { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class CompetencyAssessmentDto
{
    public string? id { get; set; }
    public string? competency_id { get; set; }
    public string? employee_id { get; set; }
    public string? employee_name { get; set; }
    public int score { get; set; }
    public string? assessor { get; set; }
    public DateTime? assessment_date { get; set; }
    public string? notes { get; set; }
    public DateTime? created_at { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Training — Training Management
// ════════════════════════════════════════════════════════════════════════════
public class CreateTrainingRequest
{
    public string? title { get; set; }
    public string? category { get; set; }
    public string? trainer { get; set; }
    public DateTime? scheduled_date { get; set; }
    public int duration_hours { get; set; }
    public string? location { get; set; }
    public string? status { get; set; }
    public string? description { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateTrainingRequest : CreateTrainingRequest { }
public class TrainingDto
{
    public string? id { get; set; }
    public string? title { get; set; }
    public string? category { get; set; }
    public string? trainer { get; set; }
    public DateTime? scheduled_date { get; set; }
    public int duration_hours { get; set; }
    public string? location { get; set; }
    public string? status { get; set; }
    public string? description { get; set; }
    public DateTime? created_at { get; set; }
    public string? created_by { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class CreateTrainingParticipantRequest
{
    public string? training_id { get; set; }
    public string? employee_id { get; set; }
    public string? employee_name { get; set; }
    public string? status { get; set; }
    public bool passed { get; set; }
    public string? notes { get; set; }
}
public class TrainingParticipantDto
{
    public string? id { get; set; }
    public string? training_id { get; set; }
    public string? employee_id { get; set; }
    public string? employee_name { get; set; }
    public string? status { get; set; }
    public bool passed { get; set; }
    public string? notes { get; set; }
    public DateTime? created_at { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Contractors — Contractor Management
// ════════════════════════════════════════════════════════════════════════════
public class CreateContractorRequest
{
    public string? name { get; set; }
    public string? company { get; set; }
    public string? contact_person { get; set; }
    public string? contact_email { get; set; }
    public string? contact_phone { get; set; }
    public string? contract_number { get; set; }
    public DateTime? contract_start { get; set; }
    public DateTime? contract_end { get; set; }
    public string? status { get; set; }
    public string? scope_of_work { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateContractorRequest : CreateContractorRequest { }
public class ContractorDto
{
    public string? id { get; set; }
    public string? name { get; set; }
    public string? company { get; set; }
    public string? contact_person { get; set; }
    public string? contact_email { get; set; }
    public string? contact_phone { get; set; }
    public string? contract_number { get; set; }
    public DateTime? contract_start { get; set; }
    public DateTime? contract_end { get; set; }
    public string? status { get; set; }
    public string? scope_of_work { get; set; }
    public DateTime? created_at { get; set; }
    public string? created_by { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// PSI — Process Safety Information
// ════════════════════════════════════════════════════════════════════════════
public class CreatePsiRequest
{
    public string? title { get; set; }
    public string? category { get; set; }
    public string? document_number { get; set; }
    public string? revision { get; set; }
    public string? status { get; set; }
    public string? description { get; set; }
    public string? responsible_person { get; set; }
    public DateTime? review_date { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdatePsiRequest : CreatePsiRequest { }
public class PsiDto
{
    public string? id { get; set; }
    public string? title { get; set; }
    public string? category { get; set; }
    public string? document_number { get; set; }
    public string? revision { get; set; }
    public string? status { get; set; }
    public string? description { get; set; }
    public string? responsible_person { get; set; }
    public DateTime? review_date { get; set; }
    public DateTime? created_at { get; set; }
    public string? created_by { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Mechanical Integrity — Equipment Inspection
// ════════════════════════════════════════════════════════════════════════════
public class CreateMiEquipmentRequest
{
    public string? tag_number { get; set; }
    public string? equipment_name { get; set; }
    public string? equipment_type { get; set; }
    public string? location { get; set; }
    public string? status { get; set; }
    public DateTime? installation_date { get; set; }
    public DateTime? next_inspection_date { get; set; }
    public string? responsible_person { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateMiEquipmentRequest : CreateMiEquipmentRequest { }
public class MiEquipmentDto
{
    public string? id { get; set; }
    public string? tag_number { get; set; }
    public string? equipment_name { get; set; }
    public string? equipment_type { get; set; }
    public string? location { get; set; }
    public string? status { get; set; }
    public DateTime? installation_date { get; set; }
    public DateTime? next_inspection_date { get; set; }
    public string? responsible_person { get; set; }
    public DateTime? created_at { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class CreateMiInspectionRequest
{
    public string? equipment_id { get; set; }
    public string? inspection_type { get; set; }
    public DateTime? inspection_date { get; set; }
    public string? inspector { get; set; }
    public string? result { get; set; }
    public string? findings { get; set; }
    public string? recommendations { get; set; }
    public DateTime? next_due_date { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class MiInspectionDto
{
    public string? id { get; set; }
    public string? equipment_id { get; set; }
    public string? inspection_type { get; set; }
    public DateTime? inspection_date { get; set; }
    public string? inspector { get; set; }
    public string? result { get; set; }
    public string? findings { get; set; }
    public string? recommendations { get; set; }
    public DateTime? next_due_date { get; set; }
    public DateTime? created_at { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Emergency — Emergency Response Plan
// ════════════════════════════════════════════════════════════════════════════
public class CreateEmergencyPlanRequest
{
    public string? title { get; set; }
    public string? scenario_type { get; set; }
    public string? location { get; set; }
    public string? description { get; set; }
    public string? response_team { get; set; }
    public string? status { get; set; }
    public DateTime? last_drill_date { get; set; }
    public DateTime? next_drill_date { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateEmergencyPlanRequest : CreateEmergencyPlanRequest { }
public class EmergencyPlanDto
{
    public string? id { get; set; }
    public string? title { get; set; }
    public string? scenario_type { get; set; }
    public string? location { get; set; }
    public string? description { get; set; }
    public string? response_team { get; set; }
    public string? status { get; set; }
    public DateTime? last_drill_date { get; set; }
    public DateTime? next_drill_date { get; set; }
    public DateTime? created_at { get; set; }
    public string? created_by { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Participation — Employee Safety Participation
// ════════════════════════════════════════════════════════════════════════════
public class CreateParticipationRequest
{
    public string? title { get; set; }
    public string? activity_type { get; set; }
    public DateTime? activity_date { get; set; }
    public string? organizer { get; set; }
    public string? department { get; set; }
    public string? description { get; set; }
    public string? status { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateParticipationRequest : CreateParticipationRequest { }
public class ParticipationDto
{
    public string? id { get; set; }
    public string? title { get; set; }
    public string? activity_type { get; set; }
    public DateTime? activity_date { get; set; }
    public string? organizer { get; set; }
    public string? department { get; set; }
    public string? description { get; set; }
    public string? status { get; set; }
    public DateTime? created_at { get; set; }
    public string? created_by { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Culture — Safety Culture Assessment
// ════════════════════════════════════════════════════════════════════════════
public class CreateCultureAssessmentRequest
{
    public string? title { get; set; }
    public string? assessment_type { get; set; }
    public DateTime? assessment_date { get; set; }
    public string? assessor { get; set; }
    public string? department { get; set; }
    public string? status { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateCultureAssessmentRequest : CreateCultureAssessmentRequest { }
public class CultureAssessmentDto
{
    public string? id { get; set; }
    public string? title { get; set; }
    public string? assessment_type { get; set; }
    public DateTime? assessment_date { get; set; }
    public string? assessor { get; set; }
    public string? department { get; set; }
    public string? status { get; set; }
    public DateTime? created_at { get; set; }
    public string? created_by { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class CreateCultureResponseRequest
{
    public string? assessment_id { get; set; }
    public string? question_id { get; set; }
    public string? question_text { get; set; }
    public int score { get; set; }
    public string? comments { get; set; }
}
public class CultureResponseDto
{
    public string? id { get; set; }
    public string? assessment_id { get; set; }
    public string? question_id { get; set; }
    public string? question_text { get; set; }
    public int score { get; set; }
    public string? comments { get; set; }
    public DateTime? created_at { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Stakeholders — Stakeholder Management
// ════════════════════════════════════════════════════════════════════════════
public class CreateStakeholderRequest
{
    public string? name { get; set; }
    public string? organization { get; set; }
    public string? role { get; set; }
    public string? email { get; set; }
    public string? phone { get; set; }
    public string? interest_level { get; set; }
    public string? influence_level { get; set; }
    public string? engagement_strategy { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateStakeholderRequest : CreateStakeholderRequest { }
public class StakeholderDto
{
    public string? id { get; set; }
    public string? name { get; set; }
    public string? organization { get; set; }
    public string? role { get; set; }
    public string? email { get; set; }
    public string? phone { get; set; }
    public string? interest_level { get; set; }
    public string? influence_level { get; set; }
    public string? engagement_strategy { get; set; }
    public DateTime? created_at { get; set; }
    public string? created_by { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Standards — Standards & Regulations
// ════════════════════════════════════════════════════════════════════════════
public class CreateStandardRequest
{
    public string? title { get; set; }
    public string? standard_number { get; set; }
    public string? issuing_body { get; set; }
    public string? category { get; set; }
    public string? revision { get; set; }
    public DateTime? issue_date { get; set; }
    public DateTime? review_date { get; set; }
    public string? status { get; set; }
    public string? description { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateStandardRequest : CreateStandardRequest { }
public class StandardDto
{
    public string? id { get; set; }
    public string? title { get; set; }
    public string? standard_number { get; set; }
    public string? issuing_body { get; set; }
    public string? category { get; set; }
    public string? revision { get; set; }
    public DateTime? issue_date { get; set; }
    public DateTime? review_date { get; set; }
    public string? status { get; set; }
    public string? description { get; set; }
    public DateTime? created_at { get; set; }
    public string? created_by { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Metrics — PSM Performance Metrics / KPIs
// ════════════════════════════════════════════════════════════════════════════
public class CreateMetricRequest
{
    public string? title { get; set; }
    public string? category { get; set; }
    public string? metric_type { get; set; }
    public string? unit { get; set; }
    public double? target_value { get; set; }
    public string? frequency { get; set; }
    public string? responsible_person { get; set; }
    public string? description { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateMetricRequest : CreateMetricRequest { }
public class MetricDto
{
    public string? id { get; set; }
    public string? title { get; set; }
    public string? category { get; set; }
    public string? metric_type { get; set; }
    public string? unit { get; set; }
    public double? target_value { get; set; }
    public string? frequency { get; set; }
    public string? responsible_person { get; set; }
    public string? description { get; set; }
    public DateTime? created_at { get; set; }
    public string? created_by { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class CreateMetricEntryRequest
{
    public string? metric_id { get; set; }
    public double actual_value { get; set; }
    public DateTime? period_date { get; set; }
    public string? notes { get; set; }
    public string? recorded_by { get; set; }
}
public class MetricEntryDto
{
    public string? id { get; set; }
    public string? metric_id { get; set; }
    public double actual_value { get; set; }
    public DateTime? period_date { get; set; }
    public string? notes { get; set; }
    public string? recorded_by { get; set; }
    public DateTime? created_at { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Management Review — Management Review Meeting
// ════════════════════════════════════════════════════════════════════════════
public class CreateManagementReviewRequest
{
    public string? title { get; set; }
    public DateTime? review_date { get; set; }
    public string? chairperson { get; set; }
    public string? location { get; set; }
    public string? status { get; set; }
    public string? agenda { get; set; }
    public string? minutes { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class UpdateManagementReviewRequest : CreateManagementReviewRequest { }
public class ManagementReviewDto
{
    public string? id { get; set; }
    public string? title { get; set; }
    public DateTime? review_date { get; set; }
    public string? chairperson { get; set; }
    public string? location { get; set; }
    public string? status { get; set; }
    public string? agenda { get; set; }
    public string? minutes { get; set; }
    public DateTime? created_at { get; set; }
    public string? created_by { get; set; }
    public Dictionary<string, object>? data { get; set; }
}
public class CreateMrActionItemRequest
{
    public string? review_id { get; set; }
    public string? description { get; set; }
    public string? assigned_to { get; set; }
    public DateTime? due_date { get; set; }
    public string? priority { get; set; }
    public string? status { get; set; }
}
public class MrActionItemDto
{
    public string? id { get; set; }
    public string? review_id { get; set; }
    public string? description { get; set; }
    public string? assigned_to { get; set; }
    public DateTime? due_date { get; set; }
    public string? priority { get; set; }
    public string? status { get; set; }
    public DateTime? created_at { get; set; }
}
