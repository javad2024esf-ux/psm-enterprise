using System.Text.Json.Serialization;

namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════
// HAZOP — Request DTOs
// NOTE: Property names are intentionally snake_case to match the JSON field
// names the frontend sends/expects (see frontend/api/hazop.ts and the
// original Node.js routes in backend/modules/hazop/routes.cjs). The API's
// global JsonNamingPolicy is CamelCase, whose CamelCase transform is a no-op
// on already-lowercase/underscored names, so these serialize unchanged.
// ════════════════════════════════════════════════════════════════════════════

public class CreateHazopStudyRequest
{
    public string? title { get; set; }
    public string? facility { get; set; }
    public string? unit { get; set; }
    public string? lead_engineer { get; set; }
    public string? scope { get; set; }
    public string? methodology { get; set; }
    public string? status { get; set; }
    public DateTime? start_date { get; set; }
    public DateTime? end_date { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

public class UpdateHazopStudyRequest : CreateHazopStudyRequest { }

public class CreateHazopNodeRequest
{
    public string? node_number { get; set; }
    public string? description { get; set; }
    public string? process_line { get; set; }
    public string? design_intent { get; set; }
    public string? p_and_id { get; set; }
}

public class UpdateHazopNodeRequest : CreateHazopNodeRequest { }

public class CreateHazopDeviationRequest
{
    public string? guide_word { get; set; }
    public string? parameter { get; set; }
    public string? deviation { get; set; }
    public string? causes { get; set; }
    public string? consequences { get; set; }
    public string? existing_safeguards { get; set; }
    public string? recommendations { get; set; }
    public object? severity { get; set; }
    public object? likelihood { get; set; }
    public string? status { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

public class UpdateHazopDeviationRequest : CreateHazopDeviationRequest { }

// ════════════════════════════════════════════════════════════════════════════
// HAZOP-to-Action Conversion Request
// For converting a HAZOP deviation/recommendation into an Action
// ════════════════════════════════════════════════════════════════════════════

public class CreateActionFromHazopRequest
{
    /// <summary>
    /// The ID of the HAZOP deviation to create an action from
    /// </summary>
    public string DeviationId { get; set; } = "";

    /// <summary>
    /// The recommendation text (or null to use the full recommendations field from the deviation)
    /// </summary>
    public string? RecommendationText { get; set; }

    /// <summary>
    /// Action priority (Critical, High, Medium, Low)
    /// Default: High (since it comes from a HAZOP finding)
    /// </summary>
    public string Priority { get; set; } = "High";

    /// <summary>
    /// Due date for the action (optional)
    /// </summary>
    public DateTime? DueDate { get; set; }

    /// <summary>
    /// Person responsible for the action (optional)
    /// </summary>
    public string? Responsible { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// HAZOP — Response DTOs (Strongly Typed - replaces dynamic)
// ════════════════════════════════════════════════════════════════════════════

public class HazopStudyDto
{
    public string? Id { get; set; }
    public string? Title { get; set; }
    public string? Facility { get; set; }
    public string? Unit { get; set; }
    public string? LeadEngineer { get; set; }
    public string? Scope { get; set; }
    public string? Methodology { get; set; }
    public string? Status { get; set; }
    public DateTime? StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? Data { get; set; }
    public bool Deleted { get; set; }
}

public class HazopStudyWithCountsDto : HazopStudyDto
{
    public int NodeCount { get; set; }
    public int DeviationCount { get; set; }
}

public class HazopNodeDto
{
    public string? Id { get; set; }
    public string? StudyId { get; set; }
    public string? NodeNumber { get; set; }
    public string? Description { get; set; }
    public string? ProcessLine { get; set; }
    public string? DesignIntent { get; set; }
    public string? PAndId { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public bool Deleted { get; set; }
}

public class HazopNodeWithCountsDto : HazopNodeDto
{
    public int DeviationCount { get; set; }
}

public class HazopDeviationDto
{
    public string? Id { get; set; }
    public string? StudyId { get; set; }
    public string? NodeId { get; set; }
    public string? GuideWord { get; set; }
    public string? Parameter { get; set; }
    public string? Deviation { get; set; }
    public string? Causes { get; set; }
    public string? Consequences { get; set; }
    public string? ExistingSafeguards { get; set; }
    public string? Recommendations { get; set; }
    public int Severity { get; set; }
    public int Likelihood { get; set; }
    public string? RiskLevel { get; set; }
    public string? Status { get; set; }
    public double RiskScore { get; set; }
    public string? IncidentReference { get; set; }
    public List<string>? LinkedIncidents { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? Data { get; set; }
    public bool Deleted { get; set; }
}

/// <summary>
/// HAZOP Deviation with study context (facility, unit, etc.)
/// Used when creating actions from deviations
/// </summary>
public class HazopDeviationWithContextDto : HazopDeviationDto
{
    public string? StudyTitle { get; set; }
    public string? Facility { get; set; }
    public string? Unit { get; set; }
    public string? StudyStatus { get; set; }
}

public class HazopAnalyticsDto
{
    public int TotalStudies { get; set; }
    public int TotalNodes { get; set; }
    public int TotalDeviations { get; set; }
    public int HighRiskCount { get; set; }
    public int MediumRiskCount { get; set; }
    public int LowRiskCount { get; set; }
    public int OpenDeviationCount { get; set; }
    public int ClosedDeviationCount { get; set; }
    public Dictionary<string, int>? RiskDistribution { get; set; }
    public Dictionary<string, int>? StatusDistribution { get; set; }
}
