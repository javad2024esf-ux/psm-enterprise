namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════
// Action Register DTOs
// Table: action_register
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Data transfer object for action register records.
/// Matches ActionRecord interface from frontend.
/// </summary>
public class ActionRegisterDto
{
    public string       Id                { get; set; } = "";
    public string       Title             { get; set; } = "";
    public string?      Description       { get; set; }
    public string       Source            { get; set; } = "Other";     // MOC, Incident, HAZOP, Audit, PSSR, Management Review, Inspection, Other
    public string?      SourceId          { get; set; }
    public string?      SourceRef         { get; set; }
    public string?      Unit              { get; set; }
    public string?      Responsible       { get; set; }
    public DateTime?    DueDate           { get; set; }
    public string       Status            { get; set; } = "Open";      // Open, In Progress, Overdue, Done, Verified, Closed
    public string       Priority          { get; set; } = "Medium";    // Critical, High, Medium, Low
    public DateTime?    CompletionDate    { get; set; }
    public string?      VerifiedBy        { get; set; }
    public string?      VerificationNote  { get; set; }
    public string[]?    Tags              { get; set; }
    public DateTime     CreatedAt         { get; set; }
    public DateTime?    UpdatedAt         { get; set; }
    public string?      CreatedBy         { get; set; }
}

/// <summary>Request to create a new action register record.</summary>
public class CreateActionRegisterRequest
{
    public string       Title             { get; set; } = "";
    public string?      Description       { get; set; }
    public string       Source            { get; set; } = "Other";
    public string?      SourceId          { get; set; }
    public string?      SourceRef         { get; set; }
    public string?      Unit              { get; set; }
    public string?      Responsible       { get; set; }
    public DateTime?    DueDate           { get; set; }
    public string       Status            { get; set; } = "Open";
    public string       Priority          { get; set; } = "Medium";
    public string[]?    Tags              { get; set; }
}

/// <summary>Request to update an existing action register record.</summary>
public class UpdateActionRegisterRequest
{
    public string?      Title             { get; set; }
    public string?      Description       { get; set; }
    public string?      Source            { get; set; }
    public string?      SourceId          { get; set; }
    public string?      SourceRef         { get; set; }
    public string?      Unit              { get; set; }
    public string?      Responsible       { get; set; }
    public DateTime?    DueDate           { get; set; }
    public string?      Status            { get; set; }
    public string?      Priority          { get; set; }
    public DateTime?    CompletionDate    { get; set; }
    public string?      VerifiedBy        { get; set; }
    public string?      VerificationNote  { get; set; }
    public string[]?    Tags              { get; set; }
}

/// <summary>List response with pagination.</summary>
public class ActionRegisterListResponse
{
    public List<ActionRegisterDto> Data  { get; set; } = new();
    public int                     Total { get; set; }
    public int                     Page  { get; set; }
    public int                     Limit { get; set; }
}

/// <summary>Request to create action from Incident recommendation</summary>
public class CreateActionFromIncidentRequest
{
    /// <summary>The ID of the Incident</summary>
    public string IncidentId { get; set; } = "";

    /// <summary>Type of recommendation: immediate|corrective|preventive</summary>
    public string RecommendationType { get; set; } = "corrective";

    /// <summary>The recommendation text to convert to action</summary>
    public string RecommendationText { get; set; } = "";

    /// <summary>Action priority (Critical, High, Medium, Low)</summary>
    public string Priority { get; set; } = "High";

    /// <summary>Responsible person for the action</summary>
    public string? Responsible { get; set; }

    /// <summary>Due date for completion</summary>
    public DateTime? DueDate { get; set; }
}

/// <summary>Status statistics for dashboard.</summary>
public class ActionRegisterStats
{
    public int Open       { get; set; }
    public int InProgress { get; set; }
    public int Overdue    { get; set; }
    public int Done       { get; set; }
    public int Verified   { get; set; }
    public int Closed     { get; set; }
    public int Total      { get; set; }

    public Dictionary<string, int> ByPriority { get; set; } = new();
    public Dictionary<string, int> BySource   { get; set; } = new();
}
