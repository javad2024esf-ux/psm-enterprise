namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════
// HAZOP-LOPA Integration Request DTOs
// ════════════════════════════════════════════════════════════════════════════

public class CreateLopaFromHazopRequest
{
    public string? hazop_study_id { get; set; }
    public string? hazop_deviation_id { get; set; }
    public string? lopa_title { get; set; }
    public string? title { get; set; }
    public string? facility { get; set; }
    public string? unit { get; set; }
    public string? lead_engineer { get; set; }
    public bool include_all_deviations { get; set; } = false;
    public string[]? selected_deviation_ids { get; set; }
    public string? scenario_number { get; set; }
    public string? initiating_event { get; set; }
    public object? initiating_frequency { get; set; }
    public string? consequence_description { get; set; }
    public object? consequence_severity { get; set; }
    public object? target_risk { get; set; }
    public Dictionary<string, object>? additional_data { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

public class CreateLopaScenarioFromHazopDeviationRequest
{
    public string? hazop_study_id { get; set; }
    public string? hazop_node_id { get; set; }
    public string? hazop_deviation_id { get; set; }
    public string? lopa_study_id { get; set; }
    public string? scenario_number { get; set; }
    public string? initiating_event { get; set; }
    public object? initiating_frequency { get; set; }
    public string? consequence_description { get; set; }
    public object? consequence_severity { get; set; }
    public object? target_risk { get; set; }
    public string? notes { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

public class GenerateLopaFromHazopRequest
{
    public string? hazop_study_id { get; set; }
    public string? hazop_deviation_id { get; set; }
    public Dictionary<string, object>? deviation_data { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// HAZOP-LOPA Integration Response DTOs with Traceability
// ════════════════════════════════════════════════════════════════════════════

public class LopaStudyWithHazopTracingDto
{
    public string? Id { get; set; }
    public string? Title { get; set; }
    public string? HazopStudyId { get; set; }
    public string? CreatedFromHazopStudyId { get; set; }
    public string? CreationMethod { get; set; }
    public string? Facility { get; set; }
    public string? Unit { get; set; }
    public string? LeadEngineer { get; set; }
    public string? Status { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? Data { get; set; }
    public bool Deleted { get; set; }
    public int ScenarioCount { get; set; }
    public int RelatedHazopDeviationCount { get; set; }
    public HazopStudyDto? RelatedHazopStudy { get; set; }
    public List<LopaScenarioWithTracingDto>? Scenarios { get; set; }
}

public class LopaScenarioWithTracingDto
{
    public string? Id { get; set; }
    public string? StudyId { get; set; }
    public string? HazopStudyId { get; set; }
    public string? HazopNodeId { get; set; }
    public string? HazopDeviationId { get; set; }
    public string? ScenarioNumber { get; set; }
    public string? InitiatingEvent { get; set; }
    public double InitiatingFrequency { get; set; }
    public string? ConsequenceDescription { get; set; }
    public int ConsequenceSeverity { get; set; }
    public double TargetRisk { get; set; }
    public double MitigatedFrequency { get; set; }
    public double RiskGap { get; set; }
    public bool RiskGapMet { get; set; }
    public double RequiredRrfSis { get; set; }
    public string? SilRequired { get; set; }
    public double AchievedRrfSis { get; set; }
    public string? SilAchieved { get; set; }
    public bool SilGapMet { get; set; }
    public double PfdNonSis { get; set; }
    public double PfdSis { get; set; }
    public string? Notes { get; set; }
    public string[]? RelatedRecommendationIds { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? Data { get; set; }
    public bool Deleted { get; set; }
    public int IplCount { get; set; }
    public HazopDeviationDto? SourceHazopDeviation { get; set; }
    public HazopNodeDto? SourceHazopNode { get; set; }
    public List<LopaIplDto>? Ipls { get; set; }
}

public class HazopLopaIntegrationSummaryDto
{
    public string? HazopStudyId { get; set; }
    public string? HazopStudyTitle { get; set; }
    public int TotalDeviations { get; set; }
    public int DeviationsWithLopaScenarios { get; set; }
    public double CoveragePercentage { get; set; }
    public List<string>? LinkedLopaStudyIds { get; set; }
    public DateTime? LastIntegrationUpdate { get; set; }
}

public class HazopLopaAuditTrailDto
{
    public long Id { get; set; }
    public string? Action { get; set; }
    public string? HazopStudyId { get; set; }
    public string? HazopNodeId { get; set; }
    public string? HazopDeviationId { get; set; }
    public string? LopaStudyId { get; set; }
    public string? LopaScenarioId { get; set; }
    public string? PerformedBy { get; set; }
    public DateTime PerformedAt { get; set; }
    public Dictionary<string, object>? Details { get; set; }
    public string? IpAddress { get; set; }
    public string? UserAgent { get; set; }
}
