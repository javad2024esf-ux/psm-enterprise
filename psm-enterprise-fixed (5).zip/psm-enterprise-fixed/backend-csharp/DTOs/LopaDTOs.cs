namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════
// LOPA — Request DTOs (snake_case — see note in HazopDTOs.cs)
// ════════════════════════════════════════════════════════════════════════════

public class CreateLopaStudyRequest
{
    public string? title { get; set; }
    public string? hazop_study_id { get; set; }
    public string? facility { get; set; }
    public string? unit { get; set; }
    public string? lead_engineer { get; set; }
    public string? status { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

public class UpdateLopaStudyRequest : CreateLopaStudyRequest { }

public class CreateLopaScenarioRequest
{
    public string? scenario_number { get; set; }
    public string? initiating_event { get; set; }
    public object? initiating_frequency { get; set; }
    public string? consequence_description { get; set; }
    public object? consequence_severity { get; set; }
    public object? target_risk { get; set; }
    public string? notes { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

public class UpdateLopaScenarioRequest : CreateLopaScenarioRequest { }

public class CreateLopaIplRequest
{
    public string? ipl_name { get; set; }
    public string? ipl_type { get; set; }
    public string? description { get; set; }
    public object? pfd { get; set; }
    public bool? is_validated { get; set; }
    public string? owner { get; set; }
    public string? audit_interval { get; set; }
}

public class UpdateLopaIplRequest : CreateLopaIplRequest { }

// ════════════════════════════════════════════════════════════════════════════
// LOPA — Response DTOs (Strongly Typed - replaces dynamic)
// ════════════════════════════════════════════════════════════════════════════

public class LopaStudyDto
{
    public string? Id { get; set; }
    public string? Title { get; set; }
    public string? HazopStudyId { get; set; }
    public string? Facility { get; set; }
    public string? Unit { get; set; }
    public string? LeadEngineer { get; set; }
    public string? Status { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? Data { get; set; }
    public bool Deleted { get; set; }
}

public class LopaStudyWithCountsDto : LopaStudyDto
{
    public int ScenarioCount { get; set; }
}

public class LopaScenarioDto
{
    public string? Id { get; set; }
    public string? StudyId { get; set; }
    public string? HazopStudyId { get; set; }
    public string? HazopNodeId { get; set; }
    public string? HazopDeviationId { get; set; }
    public string? hazop_deviation_id { get; set; }
    public string? ScenarioNumber { get; set; }
    public string? InitiatingEvent { get; set; }
    public double InitiatingFrequency { get; set; }
    public string? ConsequenceDescription { get; set; }
    public int ConsequenceSeverity { get; set; }
    public double TargetRisk { get; set; }
    public double MitigatedFrequency { get; set; }
    public double RiskGap { get; set; }
    public bool RiskGapMet { get; set; }
    public double RequiredRrfSis { get; set; }
    public string? SilRequired { get; set; }
    public double AchievedRrfSis { get; set; }
    public string? SilAchieved { get; set; }
    public bool SilGapMet { get; set; }
    public double PfdNonSis { get; set; }
    public double PfdSis { get; set; }
    public string? Notes { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? Data { get; set; }
    public bool Deleted { get; set; }
}

public class LopaScenarioWithCountsDto : LopaScenarioDto
{
    public int IplCount { get; set; }
}

public class LopaIplDto
{
    public string? Id { get; set; }
    public string? ScenarioId { get; set; }
    public string? IplName { get; set; }
    public string? IplType { get; set; }
    public string? Description { get; set; }
    public double Pfd { get; set; }
    public bool IsValidated { get; set; }
    public string? Owner { get; set; }
    public string? AuditInterval { get; set; }
    public string? Status { get; set; }
    public DateTime? LastTested { get; set; }
    public int FailureCount { get; set; }
    public string? BowTieBarrierId { get; set; }
    public string? RiskBarrierId { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public bool Deleted { get; set; }
}

public class LopaIplForCalcDto
{
    public string? Id { get; set; }
    public string? IplName { get; set; }
    public string? IplType { get; set; }
    public double Pfd { get; set; }
    public bool IsValidated { get; set; }
}

public class LopaSilBandDto
{
    public string? SilLevel { get; set; }
    public double MinRrf { get; set; }
    public double MaxRrf { get; set; }
    public int ScenarioCount { get; set; }
}

public class LopaDashboardSummaryDto
{
    public int TotalStudies { get; set; }
    public int TotalScenarios { get; set; }
    public int TotalIpls { get; set; }
    public int SilGapMetCount { get; set; }
    public int SilGapNotMetCount { get; set; }
    public int SIL1Count { get; set; }
    public int SIL2Count { get; set; }
    public int SIL3Count { get; set; }
    public int SIL4Count { get; set; }
    public Dictionary<string, int>? StatusDistribution { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// LOPA from HAZOP Result DTO
// ════════════════════════════════════════════════════════════════════════════

public class CreateLopaFromHazopResultDto
{
    public LopaStudyDto? Study { get; set; }
    public LopaScenarioDto? Scenario { get; set; }
    public string? LopaStudyId { get; set; }
    public string? LopaScenarioId { get; set; }
    public string? ScenarioNumber { get; set; }
    public string? HazopStudyId { get; set; }
    public string? HazopDeviationId { get; set; }
    public bool StudyReused { get; set; }
    public string? Message { get; set; }
}
