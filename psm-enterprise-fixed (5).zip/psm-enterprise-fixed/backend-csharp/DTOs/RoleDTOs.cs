// 📁 DTOs/RoleDTOs.cs
// ============================================================================
// Enterprise-Grade Role and Permission DTOs for PSM.Api
// 
// Purpose: Replace all `dynamic` types in RoleRepository with strongly-typed DTOs
// Includes: Role definitions, permission models, and audit support
// Security: Removes Admin bypass vulnerability, introduces SuperAdmin pattern
// ============================================================================

namespace PSM.Api.DTOs;

#region ── Role DTOs ──────────────────────────────────────────────────────────

/// <summary>
/// Core role entity with full details.
/// Used for role management, profiles, and dashboard displays.
/// </summary>
public record RoleDto
{
    /// <summary>Unique identifier (PK from database).</summary>
    public int Id { get; init; }

    /// <summary>Role name (e.g., "SuperAdmin", "PSMManager", "Operator").</summary>
    public string Name { get; init; } = string.Empty;

    /// <summary>Human-readable description for admin UI.</summary>
    public string? Description { get; init; }

    /// <summary>
    /// Built-in role marker. System roles (SuperAdmin, PSMManager) are immutable.
    /// User-created roles default to false.
    /// </summary>
    public bool IsSystemRole { get; init; }

    /// <summary>Soft-delete flag for compliance/audit trails.</summary>
    public bool IsActive { get; init; } = true;

    /// <summary>Timestamp when role was created.</summary>
    public DateTime CreatedAt { get; init; }

    /// <summary>Timestamp of last modification (null if never updated).</summary>
    public DateTime? UpdatedAt { get; init; }

    /// <summary>User who last modified this role (for audit logs).</summary>
    public string? UpdatedBy { get; init; }
}

/// <summary>
/// Lightweight role reference used in API responses (e.g., user profile).
/// Omits audit fields to reduce payload size.
/// </summary>
public record RoleBriefDto
{
    public int Id { get; init; }
    public string Name { get; init; } = string.Empty;
    public string? Description { get; init; }
}

/// <summary>
/// Create/Update request for roles.
/// Excludes Id and audit fields (server-managed).
/// </summary>
public record CreateUpdateRoleRequest
{
    public string Name { get; init; } = string.Empty;
    public string? Description { get; init; }

    /// <summary>Only SuperAdmin can set this; defaults to false for new roles.</summary>
    public bool IsSystemRole { get; init; } = false;
}

#endregion

#region ── Permission DTOs ───────────────────────────────────────────────────

/// <summary>
/// Individual permission for a module (read/write/approve/delete capability).
/// Linked to a role through the junction table.
/// </summary>
public record PermissionDto
{
    /// <summary>Unique identifier (PK from role_permissions table).</summary>
    public int Id { get; init; }

    /// <summary>Foreign key to role.</summary>
    public int RoleId { get; init; }

    /// <summary>Module name (e.g., "HAZOP", "LOPA", "MOC", "INCIDENT").</summary>
    public string Module { get; init; } = string.Empty;

    /// <summary>Can read/view module records.</summary>
    public bool CanRead { get; init; }

    /// <summary>Can create/edit module records.</summary>
    public bool CanWrite { get; init; }

    /// <summary>Can approve/sign-off module records (workflow-dependent).</summary>
    public bool CanApprove { get; init; }

    /// <summary>Can permanently delete module records.</summary>
    public bool CanDelete { get; init; }

    /// <summary>Timestamp when permission was assigned.</summary>
    public DateTime CreatedAt { get; init; }
}

/// <summary>
/// Flat permission view for admin dashboards and audit logs.
/// Includes role name for easy filtering/searching.
/// </summary>
public record RolePermissionDto
{
    public int PermissionId { get; init; }
    public int RoleId { get; init; }
    public string RoleName { get; init; } = string.Empty;
    public string Module { get; init; } = string.Empty;
    public bool CanRead { get; init; }
    public bool CanWrite { get; init; }
    public bool CanApprove { get; init; }
    public bool CanDelete { get; init; }
    public DateTime CreatedAt { get; init; }
}

/// <summary>
/// Create/Update request for permissions.
/// Used by admin UI to grant/revoke module access.
/// </summary>
public record SetPermissionRequest
{
    public int RoleId { get; init; }
    public string Module { get; init; } = string.Empty;
    public bool CanRead { get; init; }
    public bool CanWrite { get; init; }
    public bool CanApprove { get; init; }
    public bool CanDelete { get; init; }
}

#endregion

#region ── Role with Permissions (Nested) ────────────────────────────────────

/// <summary>
/// Complete role profile including all assigned permissions.
/// Used for role detail pages and permission audits.
/// </summary>
public record RoleWithPermissionsDto
{
    public int Id { get; init; }
    public string Name { get; init; } = string.Empty;
    public string? Description { get; init; }
    public bool IsSystemRole { get; init; }
    public bool IsActive { get; init; }
    public DateTime CreatedAt { get; init; }
    public DateTime? UpdatedAt { get; init; }
    public string? UpdatedBy { get; init; }

    /// <summary>All permissions assigned to this role, grouped by module.</summary>
    public ICollection<PermissionDto> Permissions { get; init; } = new List<PermissionDto>();
}

#endregion

#region ── Response Envelopes ────────────────────────────────────────────────

/// <summary>Standard response for GetAll roles with pagination support.</summary>
public record GetAllRolesResponse
{
    public ICollection<RoleDto> Roles { get; init; } = new List<RoleDto>();
    public int Total { get; init; }
}

/// <summary>Standard response for permission listing with role context.</summary>
public record GetPermissionsResponse
{
    public string RoleName { get; init; } = string.Empty;
    public bool IsSystemRole { get; init; }
    public ICollection<PermissionDto> Permissions { get; init; } = new List<PermissionDto>();
}

#endregion

#region ── Audit/Logging DTOs ────────────────────────────────────────────────

/// <summary>
/// Log entry for role modifications (created, updated, deleted).
/// Critical for compliance: tracks who changed what and when.
/// </summary>
public record RoleAuditLogDto
{
    public int Id { get; init; }
    public string Action { get; init; } = string.Empty; // "CREATE", "UPDATE", "DELETE", "PERMISSION_GRANT", "PERMISSION_REVOKE"
    public string? RoleName { get; init; }
    public string? TargetUser { get; init; } // User affected by permission change
    public string ChangedBy { get; init; } = string.Empty; // Admin who made the change
    public string? Details { get; init; } // JSON serialized changes
    public DateTime CreatedAt { get; init; }
}

#endregion
