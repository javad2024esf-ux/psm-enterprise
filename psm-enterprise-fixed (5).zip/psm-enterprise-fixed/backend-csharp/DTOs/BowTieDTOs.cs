namespace PSM.Api.DTOs;
// ═══════════════════════════════════════════════════════════════════════════
// BowTie Diagram DTOs
// ═══════════════════════════════════════════════════════════════════════════

public class BowTieDiagramDto
{
    public string Id { get; set; } = "";
    public string Title { get; set; } = "";
    public string? Description { get; set; }       // nullable — optional in DB
    public string? HazopStudyId { get; set; }      // nullable — optional FK
    public string? LopaStudyId { get; set; }       // nullable — optional FK
    public string? TopEventId { get; set; }        // nullable — optional FK
    public string? TopEventDescription { get; set; }
    public int? CauseCount { get; set; }
    public int? ConsequenceCount { get; set; }
    public int? BarrierCount { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }         // nullable — optional FK
    public string? UpdatedBy { get; set; }         // nullable — optional FK
    public bool Deleted { get; set; }
}

public class BowTieDiagramDetailDto
{
    public string Id { get; set; } = "";
    public string Title { get; set; } = "";
    public string? Description { get; set; }
    public string? HazopStudyId { get; set; }
    public string? LopaStudyId { get; set; }
    public string? TopEventId { get; set; }
    public string? TopEventDescription { get; set; }
    public List<BowTieCauseDto> Causes { get; set; } = new();
    public List<BowTieBarrierDto> Barriers { get; set; } = new();
    public List<BowTieConsequenceDto> Consequences { get; set; } = new();
    public List<BowTieControlDto> Controls { get; set; } = new();
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
}

public class CreateBowTieDiagramDto
{
    public string Title { get; set; } = "";
    public string? Description { get; set; }
    public string? HazopStudyId { get; set; }
    public string? LopaStudyId { get; set; }
    public string? TopEventId { get; set; }
    public string? TopEventDescription { get; set; }
}

public class UpdateBowTieDiagramDto
{
    public string? Title { get; set; }
    public string? Description { get; set; }
    public string? TopEventId { get; set; }
    public string? TopEventDescription { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// BowTie Causes
// ═══════════════════════════════════════════════════════════════════════════

public class BowTieCauseDto
{
    public string Id { get; set; } = "";
    public string DiagramId { get; set; } = "";
    public string Description { get; set; } = "";
    public string? Category { get; set; }          // nullable — optional in DB
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}

public class CreateBowTieCauseDto
{
    public string DiagramId { get; set; } = "";
    public string Description { get; set; } = "";
    public string? Category { get; set; }
    public int SortOrder { get; set; }
    /// <summary>
    /// Optional. Set by LopaBowTieIntegrationService when the cause node is
    /// generated from a LOPA Scenario's initiating event. Stored in
    /// bowtie_causes.lopa_scenario_id (migration 035).
    /// </summary>
    public string? LopaScenarioId { get; set; }
}

public class UpdateBowTieCauseDto
{
    public string? Description { get; set; }
    public string? Category { get; set; }
    public int SortOrder { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// BowTie Consequences
// ═══════════════════════════════════════════════════════════════════════════

public class BowTieConsequenceDto
{
    public string Id { get; set; } = "";
    public string DiagramId { get; set; } = "";
    public string Description { get; set; } = "";
    public string? Severity { get; set; }          // nullable — optional in DB
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}

public class CreateBowTieConsequenceDto
{
    public string DiagramId { get; set; } = "";
    public string Description { get; set; } = "";
    public string? Severity { get; set; }
    public int SortOrder { get; set; }
    /// <summary>
    /// Optional. Set by LopaBowTieIntegrationService when the consequence node
    /// is generated from a LOPA Scenario. Stored in
    /// bowtie_consequences.lopa_scenario_id (migration 035).
    /// </summary>
    public string? LopaScenarioId { get; set; }
    /// <summary>Risk value flowed from LOPA: initiating_frequency × non-SIS PFD product.</summary>
    public double? MitigatedFrequency { get; set; }
    /// <summary>Risk value flowed from LOPA: target_risk of the scenario.</summary>
    public double? TargetRisk { get; set; }
    /// <summary>Risk value flowed from LOPA: SIL band required (None/SIL1-SIL4).</summary>
    public string? SilRequired { get; set; }
}

public class UpdateBowTieConsequenceDto
{
    public string? Description { get; set; }
    public string? Severity { get; set; }
    public int SortOrder { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// BowTie Barriers
// ═══════════════════════════════════════════════════════════════════════════

public class BowTieBarrierDto
{
    public string Id { get; set; } = "";
    public string DiagramId { get; set; } = "";
    public string Description { get; set; } = "";
    public string? Type { get; set; }              // nullable — "Prevention" or "Mitigation"
    public string? RiskReduction { get; set; }     // nullable — optional in DB
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public List<BowTieControlDto> Controls { get; set; } = new();
}

public class CreateBowTieBarrierDto
{
    public string DiagramId { get; set; } = "";
    public string Description { get; set; } = "";
    public string? Type { get; set; }
    public string? RiskReduction { get; set; }
    public int SortOrder { get; set; }
}

public class UpdateBowTieBarrierDto
{
    public string? Description { get; set; }
    public string? Type { get; set; }
    public string? RiskReduction { get; set; }
    public int SortOrder { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// BowTie Controls (nested under Barriers)
// ═══════════════════════════════════════════════════════════════════════════

public class BowTieControlDto
{
    public string Id { get; set; } = "";
    public string BarrierId { get; set; } = "";
    public string DiagramId { get; set; } = "";
    public string Description { get; set; } = "";
    public string? ControlType { get; set; }       // nullable — optional in DB
    public string? Frequency { get; set; }         // nullable — optional in DB
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}

public class CreateBowTieControlDto
{
    public string BarrierId { get; set; } = "";
    public string Description { get; set; } = "";
    public string? ControlType { get; set; }
    public string? Frequency { get; set; }
    public bool IsActive { get; set; } = true;
}

public class UpdateBowTieControlDto
{
    public string? Description { get; set; }
    public string? ControlType { get; set; }
    public string? Frequency { get; set; }
    public bool IsActive { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// BowTie Generation from HAZOP/LOPA
// ═══════════════════════════════════════════════════════════════════════════

public class GenerateBowTieFromHazopDto
{
    public string HazopStudyId { get; set; } = "";
    public string Title { get; set; } = "";
    public string? Description { get; set; }
}

public class GenerateBowTieFromLopaDto
{
    public string LopaStudyId { get; set; } = "";
    public string Title { get; set; } = "";
    public string? Description { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// BowTie Summary
// ═══════════════════════════════════════════════════════════════════════════

public class BowTieSummaryDto
{
    public int TotalDiagrams { get; set; }
    public int DiagramsLinkedToHazop { get; set; }
    public int DiagramsLinkedToLopa { get; set; }
    public int TotalCauses { get; set; }
    public int TotalConsequences { get; set; }
    public int TotalBarriers { get; set; }
    public int TotalControls { get; set; }
    public double AverageBarriersPerDiagram { get; set; }
    public double AverageControlsPerBarrier { get; set; }
}
