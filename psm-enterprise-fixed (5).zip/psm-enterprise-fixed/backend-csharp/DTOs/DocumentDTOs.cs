namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════
// Document DTOs
// Table: documents (id TEXT, name TEXT, module TEXT, tags TEXT[],
//        file_path TEXT, file_size BIGINT, mime_type TEXT,
//        created_by TEXT, created_at TIMESTAMPTZ)
// ════════════════════════════════════════════════════════════════════════════

public class DocumentDto
{
    public string    Id        { get; set; } = "";
    public string    Name      { get; set; } = "";
    public string?   Module    { get; set; }
    public string[]? Tags      { get; set; }
    public string?   FilePath  { get; set; }
    public long?     FileSize  { get; set; }
    public string?   MimeType  { get; set; }
    public string?   CreatedBy { get; set; }
    public DateTime  CreatedAt { get; set; }
}

public class DocumentListResponse
{
    public List<DocumentDto> Data  { get; set; } = new();
    public int               Total { get; set; }
    public int               Page  { get; set; }
    public int               Limit { get; set; }
}

/// <summary>Metadata fields accepted alongside the multipart file upload.</summary>
public class UploadDocumentRequest
{
    public string?   Module { get; set; }
    public string[]? Tags   { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Document DTOs - Enhanced with Attachments, Versioning, and Preview
// NOTE: Base DocumentDto, DocumentListResponse, and UploadDocumentRequest 
// are defined in DocumentDTOs.cs - DUPLICATES REMOVED
// ════════════════════════════════════════════════════════════════════════════

// ─── Document Attachment ──────────────────────────────────────────────────
public class DocumentAttachmentDto
{
    public string    Id                   { get; set; } = "";
    public string    DocumentId           { get; set; } = "";
    public string    Module               { get; set; } = "";
    public string    RecordId             { get; set; } = "";
    public string?   AttachmentType       { get; set; }
    public string?   AttachmentCategory   { get; set; }
    public string?   Description          { get; set; }
    public int       SortOrder            { get; set; }
    public string?   CreatedBy            { get; set; }
    public DateTime  CreatedAt            { get; set; }
    public DateTime  UpdatedAt            { get; set; }
    
    // Related document info
    public DocumentDto? Document          { get; set; }
}

// ─── Attach Document Request ──────────────────────────────────────────────
public class AttachDocumentRequest
{
    public string   DocumentId           { get; set; } = "";
    public string   Module               { get; set; } = "";
    public string   RecordId             { get; set; } = "";
    public string?  AttachmentType       { get; set; }
    public string?  AttachmentCategory   { get; set; }
    public string?  Description          { get; set; }
    public int      SortOrder            { get; set; }
}

// ─── Detach Document Request ──────────────────────────────────────────────
public class DetachDocumentRequest
{
    public string DocumentId { get; set; } = "";
    public string Module     { get; set; } = "";
    public string RecordId   { get; set; } = "";
}

// ─── Document Version ─────────────────────────────────────────────────────
public class DocumentVersionDto
{
    public string    Id              { get; set; } = "";
    public string    DocumentId      { get; set; } = "";
    public int       VersionNumber   { get; set; }
    public string?   PreviousId      { get; set; }
    public string?   FilePath        { get; set; }
    public long?     FileSize        { get; set; }
    public string?   MimeType        { get; set; }
    public string?   ChangeSummary   { get; set; }
    public string?   ChangeType      { get; set; } // initial, updated, restored, minor, major
    public string?   CreatedBy       { get; set; }
    public DateTime  CreatedAt       { get; set; }
}

// ─── Upload Version Request ────────────────────────────────────────────────
public class UploadDocumentVersionRequest
{
    public string   DocumentId      { get; set; } = "";
    public string?  ChangeSummary   { get; set; }
    public string?  ChangeType      { get; set; } // initial, updated, restored, minor, major
}

// ─── Document Preview ─────────────────────────────────────────────────────
public class DocumentPreviewDto
{
    public string    Id            { get; set; } = "";
    public string    DocumentId    { get; set; } = "";
    public string?   PreviewType   { get; set; }
    public string?   ThumbnailPath { get; set; }
    public int?      PageCount     { get; set; }
    public string?   PreviewUrl    { get; set; }
    public DateTime  GeneratedAt   { get; set; }
    public DateTime? ExpiresAt     { get; set; }
}

// ─── Document Access Log ───────────────────────────────────────────────────
public class DocumentAccessLogDto
{
    public string    Id         { get; set; } = "";
    public string    DocumentId { get; set; } = "";
    public string?   UserId     { get; set; }
    public string?   ActionType { get; set; }
    public DateTime  AccessTime { get; set; }
    public string?   IpAddress  { get; set; }
    public string?   UserAgent  { get; set; }
}

// ─── Document with Attachments ────────────────────────────────────────────
public class DocumentWithAttachmentsDto
{
    public DocumentDto                    Document     { get; set; } = new();
    public List<DocumentAttachmentDto>    Attachments  { get; set; } = new();
    public List<DocumentVersionDto>       Versions     { get; set; } = new();
    public DocumentPreviewDto?            Preview      { get; set; }
}

// ─── Module Document Summary ───────────────────────────────────────────────
public class ModuleDocumentSummaryDto
{
    public string              Module              { get; set; } = "";
    public string              RecordId            { get; set; } = "";
    public int                 TotalDocuments      { get; set; }
    public int                 TotalVersions       { get; set; }
    public List<DocumentAttachmentDto> Attachments { get; set; } = new();
    public DateTime?           LastDocumentAdded   { get; set; }
}
