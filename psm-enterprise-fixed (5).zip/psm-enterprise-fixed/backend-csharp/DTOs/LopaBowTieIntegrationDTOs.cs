namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════
// LOPA → BowTie Integration — Request DTOs
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Creates a BowTie diagram from an approved LOPA Scenario.
/// The scenario's initiating event becomes the top-event/cause;
/// its IPLs become prevention barriers; its consequence becomes a
/// BowTie consequence node. Risk values (MitigatedFrequency, SilRequired,
/// ConsequenceSeverity) flow through to the diagram metadata.
/// </summary>
public class CreateBowTieFromLopaScenarioRequest
{
    /// <summary>ID of the LOPA Scenario that seeds this BowTie.</summary>
    public string? lopa_scenario_id { get; set; }

    /// <summary>Optional override for the BowTie diagram title.</summary>
    public string? bowtie_title { get; set; }

    /// <summary>
    /// Optional top-event description override.
    /// Defaults to the LOPA scenario's initiating_event.
    /// </summary>
    public string? top_event { get; set; }

    /// <summary>
    /// When true, each LOPA IPL is auto-imported as a prevention barrier.
    /// Defaults to true.
    /// </summary>
    public bool import_ipls_as_barriers { get; set; } = true;

    /// <summary>Additional free-form metadata to store on the diagram.</summary>
    public Dictionary<string, object>? data { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// LOPA → BowTie Integration — Response DTOs
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Returned after successfully creating a BowTie diagram from a LOPA Scenario.
/// Carries the diagram detail plus the risk values that flowed from LOPA.
/// </summary>
public class CreateBowTieFromLopaScenarioResultDto
{
    public string? BowTieDiagramId { get; set; }
    public BowTieDiagramDetailDto? Diagram { get; set; }

    // ── Source traceability ──────────────────────────────────────────────
    public string? LopaScenarioId { get; set; }
    public string? LopaStudyId { get; set; }
    public string? HazopStudyId { get; set; }
    public string? HazopDeviationId { get; set; }

    // ── Risk values that flowed from LOPA ────────────────────────────────
    /// <summary>Initiating frequency × non-SIS PFD product from LOPA.</summary>
    public double MitigatedFrequency { get; set; }
    /// <summary>Target risk level from the LOPA scenario.</summary>
    public double TargetRisk { get; set; }
    /// <summary>Consequence severity (1-5) from LOPA.</summary>
    public int ConsequenceSeverity { get; set; }
    /// <summary>SIL requirement derived by LOPA engine.</summary>
    public string? SilRequired { get; set; }
    /// <summary>Whether the LOPA risk gap was met before this BowTie was created.</summary>
    public bool RiskGapMet { get; set; }

    // ── Created child elements ───────────────────────────────────────────
    public int BarriersCreated { get; set; }
    public string? Message { get; set; }
}

/// <summary>
/// Summary of all BowTie diagrams that were generated from a given LOPA study.
/// </summary>
public class LopaBowTieIntegrationSummaryDto
{
    public string? LopaStudyId { get; set; }
    public string? LopaStudyTitle { get; set; }
    public int TotalScenarios { get; set; }
    public int ScenariosWithBowTie { get; set; }
    public double CoveragePercentage { get; set; }
    public List<string>? LinkedBowTieDiagramIds { get; set; }
    public DateTime? LastIntegrationUpdate { get; set; }
}
