using System.Text.Json.Serialization;

namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════
// HAZOP CHAIN DTOs
// Study → Node → Deviation → Cause → Consequence → Safeguard
//       → Recommendation → Action Register → Workflow → Notification → Audit
// ════════════════════════════════════════════════════════════════════════════

// ─── Cause ──────────────────────────────────────────────────────────────────
public class HazopCauseDto
{
    public string? Id                { get; set; }
    public string? DeviationId       { get; set; }
    public string? StudyId           { get; set; }
    public string? Description       { get; set; }
    public string? CauseType         { get; set; }
    public int     Likelihood        { get; set; }
    public string? InitiatingEvent   { get; set; }
    public string? FrequencyBasis    { get; set; }
    public DateTime? CreatedAt       { get; set; }
    public string? CreatedBy         { get; set; }
}

public class CreateHazopCauseRequest
{
    public string  deviation_id      { get; set; } = "";
    public string  description       { get; set; } = "";
    public string? cause_type        { get; set; }
    public int?    likelihood        { get; set; }
    public string? initiating_event  { get; set; }
    public string? frequency_basis   { get; set; }
}

public class UpdateHazopCauseRequest : CreateHazopCauseRequest { }

// ─── Consequence ─────────────────────────────────────────────────────────────
public class HazopConsequenceDto
{
    public string? Id                       { get; set; }
    public string? DeviationId              { get; set; }
    public string? StudyId                  { get; set; }
    public string? Description              { get; set; }
    public string? ConsequenceCategory      { get; set; }
    public int     Severity                 { get; set; }
    public string? AffectedPopulation       { get; set; }
    public bool    Credible                 { get; set; }
    public DateTime? CreatedAt              { get; set; }
    public string? CreatedBy               { get; set; }
}

public class CreateHazopConsequenceRequest
{
    public string  deviation_id             { get; set; } = "";
    public string  description              { get; set; } = "";
    public string? consequence_category     { get; set; }
    public int?    severity                 { get; set; }
    public string? affected_population      { get; set; }
    public bool?   credible                 { get; set; }
}

public class UpdateHazopConsequenceRequest : CreateHazopConsequenceRequest { }

// ─── Safeguard ───────────────────────────────────────────────────────────────
public class HazopSafeguardDto
{
    public string?  Id              { get; set; }
    public string?  DeviationId     { get; set; }
    public string?  StudyId         { get; set; }
    public string?  Description     { get; set; }
    public string?  SafeguardType   { get; set; }
    public bool     IplCredited     { get; set; }
    public decimal? Pfd             { get; set; }
    public string?  TagNumber       { get; set; }
    public string?  Status          { get; set; }
    public DateTime? CreatedAt      { get; set; }
    public string?  CreatedBy       { get; set; }
}

public class CreateHazopSafeguardRequest
{
    public string   deviation_id    { get; set; } = "";
    public string   description     { get; set; } = "";
    public string?  safeguard_type  { get; set; }
    public bool?    ipl_credited    { get; set; }
    public decimal? pfd             { get; set; }
    public string?  tag_number      { get; set; }
    public string?  status          { get; set; }
}

public class UpdateHazopSafeguardRequest : CreateHazopSafeguardRequest { }

// ─── Workflow ─────────────────────────────────────────────────────────────────
public class HazopWorkflowInstanceDto
{
    public string?   Id             { get; set; }
    public string?   EntityType     { get; set; }
    public string?   EntityId       { get; set; }
    public string?   StudyId        { get; set; }
    public string?   CurrentState   { get; set; }
    public string?   PreviousState  { get; set; }
    public string?   AssignedTo     { get; set; }
    public string?   AssignedRole   { get; set; }
    public DateTime? DueDate        { get; set; }
    public string?   Priority       { get; set; }
    public string?   Comments       { get; set; }
    public DateTime? StartedAt      { get; set; }
    public DateTime? CompletedAt    { get; set; }
    public List<HazopWorkflowHistoryDto> History { get; set; } = new();
}

public class HazopWorkflowHistoryDto
{
    public string?   Id             { get; set; }
    public string?   InstanceId     { get; set; }
    public string?   FromState      { get; set; }
    public string?   ToState        { get; set; }
    public string?   Action         { get; set; }
    public string?   ActorId        { get; set; }
    public string?   ActorName      { get; set; }
    public string?   Comment        { get; set; }
    public DateTime  TransitionedAt { get; set; }
}

public class StartHazopWorkflowRequest
{
    public string entity_type  { get; set; } = "study";  // study | deviation | recommendation
    public string entity_id    { get; set; } = "";
    public string? assigned_to { get; set; }
    public string? priority    { get; set; }
    public string? due_date    { get; set; }
}

public class HazopWorkflowTransitionRequest
{
    public string entity_id  { get; set; } = "";
    public string action     { get; set; } = "";
    public string? comment   { get; set; }
}

// ─── Notification ─────────────────────────────────────────────────────────────
public class HazopNotificationDto
{
    public string?   Id                   { get; set; }
    public string?   StudyId              { get; set; }
    public string?   EntityType           { get; set; }
    public string?   EntityId             { get; set; }
    public string?   RecipientId          { get; set; }
    public string?   NotificationType     { get; set; }
    public string?   Title                { get; set; }
    public string?   Body                 { get; set; }
    public string?   Priority             { get; set; }
    public bool      IsRead               { get; set; }
    public DateTime? ReadAt               { get; set; }
    public DateTime  CreatedAt            { get; set; }
}

// ─── Audit Trail ─────────────────────────────────────────────────────────────
public class HazopAuditTrailDto
{
    public string?   Id          { get; set; }
    public string?   StudyId     { get; set; }
    public string?   EntityType  { get; set; }
    public string?   EntityId    { get; set; }
    public string?   Action      { get; set; }
    public string?   ActorId     { get; set; }
    public string?   ActorName   { get; set; }
    public object?   OldValues   { get; set; }
    public object?   NewValues   { get; set; }
    public DateTime  OccurredAt  { get; set; }
}

// ─── Full Chain Response ──────────────────────────────────────────────────────
/// <summary>
/// پاسخ کامل یک انحراف با تمام زنجیره:
/// Deviation + Causes + Consequences + Safeguards + Recommendations + Workflow + Audit
/// </summary>
public class HazopDeviationFullChainDto
{
    public HazopDeviationDto?              Deviation       { get; set; }
    public List<HazopCauseDto>             Causes          { get; set; } = new();
    public List<HazopConsequenceDto>       Consequences    { get; set; } = new();
    public List<HazopSafeguardDto>         Safeguards      { get; set; } = new();
    public List<HazopRecommendationDto>    Recommendations { get; set; } = new();
    public List<HazopActionDto>            Actions         { get; set; } = new();
    public HazopWorkflowInstanceDto?       Workflow        { get; set; }
    public List<HazopAuditTrailDto>        AuditTrail      { get; set; } = new();
}

// ─── Recommendation (کامل‌شده) ───────────────────────────────────────────────
public class HazopRecommendationDto
{
    public string?  Id                  { get; set; }
    public string?  StudyId             { get; set; }
    public string?  DeviationId         { get; set; }
    public string?  NodeId              { get; set; }
    public string?  RecommendationText  { get; set; }
    public string?  Owner               { get; set; }
    public string?  Priority            { get; set; }
    public DateTime? DueDate            { get; set; }
    public string?  Status              { get; set; }
    public string?  ApprovalStatus      { get; set; }
    public string?  Approver            { get; set; }
    public string?  ClosureEvidence     { get; set; }
    public DateTime? ClosureDate        { get; set; }
    public string?  Remarks             { get; set; }
    public DateTime? CreatedAt          { get; set; }
    public string?  CreatedBy           { get; set; }
    // لینک به action register
    public string?  ActionId            { get; set; }
}

public class CreateHazopRecommendationRequest
{
    public string  study_id             { get; set; } = "";
    public string  deviation_id         { get; set; } = "";
    public string? node_id              { get; set; }
    public string  recommendation_text  { get; set; } = "";
    public string? owner                { get; set; }
    public string? priority             { get; set; }
    public DateTime? due_date           { get; set; }
    public string? status               { get; set; }
    public string? remarks              { get; set; }
}

public class UpdateHazopRecommendationRequest : CreateHazopRecommendationRequest
{
    public string? approval_status      { get; set; }
    public string? approver             { get; set; }
    public string? closure_evidence     { get; set; }
    public DateTime? closure_date       { get; set; }
}

// ─── Action (اختصاصی HAZOP) ──────────────────────────────────────────────────
public class HazopActionDto
{
    public string?  Id                  { get; set; }
    public string?  StudyId             { get; set; }
    public string?  DeviationId         { get; set; }
    public string?  RecommendationId    { get; set; }
    public string?  ActionRegisterRef   { get; set; }  // ID در جدول action_register
    public string?  Title               { get; set; }
    public string?  Description         { get; set; }
    public string?  Responsible         { get; set; }
    public DateTime? DueDate            { get; set; }
    public string?  Status              { get; set; }
    public string?  Priority            { get; set; }
    public DateTime? CompletedDate      { get; set; }
    public string?  VerifiedBy          { get; set; }
    public string?  VerificationNote    { get; set; }
    public DateTime? CreatedAt          { get; set; }
}

// ─── Analytics (کامل‌شده) ─────────────────────────────────────────────────────
public class HazopChainAnalyticsDto
{
    // مطالعات
    public int TotalStudies             { get; set; }
    public int ActiveStudies            { get; set; }
    public int CompletedStudies         { get; set; }

    // گره‌ها و انحرافات
    public int TotalNodes               { get; set; }
    public int TotalDeviations          { get; set; }
    public int HighRiskDeviations       { get; set; }
    public int CriticalDeviations       { get; set; }
    public int OpenDeviations           { get; set; }

    // علل و پیامدها
    public int TotalCauses              { get; set; }
    public int TotalConsequences        { get; set; }

    // حفاظ‌ها
    public int TotalSafeguards          { get; set; }
    public int IplCreditedSafeguards    { get; set; }

    // توصیه‌ها
    public int TotalRecommendations     { get; set; }
    public int OpenRecommendations      { get; set; }
    public int OverdueRecommendations   { get; set; }
    public int ClosedRecommendations    { get; set; }

    // اقدامات
    public int TotalActions             { get; set; }
    public int OpenActions              { get; set; }
    public int ClosedActions            { get; set; }

    // Workflow
    public int WorkflowPending          { get; set; }

    // درصد اکمال
    public double ClosureRate           { get; set; }
    public double ComplianceScore       { get; set; }
}
