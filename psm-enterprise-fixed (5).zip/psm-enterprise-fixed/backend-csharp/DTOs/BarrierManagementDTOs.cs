namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════════════
// UNIFIED BARRIER MANAGEMENT DTOs
// ════════════════════════════════════════════════════════════════════════════════════

public enum BarrierStatus
{
    Active,
    Degraded,
    Failed,
    OutOfService
}

public enum BarrierType
{
    Engineering,
    Administrative,
    Procedural,
    SIS,
    Detection
}

// ════════════════════════════════════════════════════════════════════════════════════
// BARRIER Core DTOs
// ════════════════════════════════════════════════════════════════════════════════════

public class BarrierDto
{
    public string? Id { get; set; }
    public string? LopaIplId { get; set; }
    public string? BowTieBarrierId { get; set; }
    public string? Data { get; set; }
    public string? BarrierName { get; set; }
    public string? BarrierType { get; set; }
    public string? Description { get; set; }
    public string? OwnerDiscipline { get; set; }
    public string? OwnerContact { get; set; }
    public string? MaintenanceFrequency { get; set; }
    public DateTime? LastTested { get; set; }
    public DateTime? NextTestDue { get; set; }
    public decimal? EffectivenessRating { get; set; }
    public string? Status { get; set; }
    public string? FailureMode { get; set; }
    public string? FailureReason { get; set; }
    public DateTime? FailureDate { get; set; }
    public string? RemediationPlan { get; set; }
    public DateTime? RemediationDueDate { get; set; }
    public decimal? PfdActual { get; set; }
    public int? SilLevel { get; set; }
    public string? DocumentationRef { get; set; }
    public bool CriticalFlag { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
    public bool Deleted { get; set; }
}

public class CreateBarrierDto
{
    public string? BarrierName { get; set; }
    public string? BarrierType { get; set; }
    public string? Description { get; set; }
    public string? OwnerDiscipline { get; set; }
    public string? OwnerContact { get; set; }
    public string? MaintenanceFrequency { get; set; }
    public decimal? EffectivenessRating { get; set; }
    public string? Status { get; set; } = "Active";
    public int? SilLevel { get; set; }
    public string? DocumentationRef { get; set; }
    public bool CriticalFlag { get; set; }
}

public class UpdateBarrierDto
{
    public string? BarrierName { get; set; }
    public string? BarrierType { get; set; }
    public string? Description { get; set; }
    public string? OwnerDiscipline { get; set; }
    public string? OwnerContact { get; set; }
    public string? MaintenanceFrequency { get; set; }
    public DateTime? LastTested { get; set; }
    public DateTime? NextTestDue { get; set; }
    public decimal? EffectivenessRating { get; set; }
    public string? Status { get; set; }
    public string? FailureMode { get; set; }
    public string? FailureReason { get; set; }
    public DateTime? FailureDate { get; set; }
    public string? RemediationPlan { get; set; }
    public DateTime? RemediationDueDate { get; set; }
    public decimal? PfdActual { get; set; }
    public int? SilLevel { get; set; }
    public string? DocumentationRef { get; set; }
    public bool CriticalFlag { get; set; }
}

public class BarrierStatusChangeDto
{
    public string? NewStatus { get; set; }
    public string? Reason { get; set; }
    public string? UpdatedBy { get; set; }
}

public class BarrierWithLinksDto : BarrierDto
{
    public new string? LopaIplId { get; set; }
    public string? LopaIplName { get; set; }
    public new string? BowTieBarrierId { get; set; }
    public string? BowTieDiagramId { get; set; }
    public string? BowTieDiagramTitle { get; set; }
    public List<BarrierStatusHistoryDto> StatusHistory { get; set; } = new();
}

public class BarrierStatusHistoryDto
{
    public string? Id { get; set; }
    public string? BarrierId { get; set; }
    public string? PreviousStatus { get; set; }
    public string? NewStatus { get; set; }
    public string? Reason { get; set; }
    public string? TriggeredByIncident { get; set; }
    public string? TriggeredByIncidentId { get; set; }
    public string? ChangedBy { get; set; }
    public DateTime? ChangedAt { get; set; }
}

public class BarrierImpactDto
{
    public string? BarrierId { get; set; }
    public string? BarrierName { get; set; }
    public string? Status { get; set; }
    public decimal? EffectivenessRating { get; set; }
    public int LinkedHazopStudies { get; set; }
    public int LinkedHazopDeviations { get; set; }
    public int LinkedLopaStudies { get; set; }
    public int LinkedLopaScenarios { get; set; }
    public int LinkedLopaIpls { get; set; }
    public int LinkedBowTieDiagrams { get; set; }
    public int LinkedIncidents { get; set; }
    public List<string>? RelatedIncidentNumbers { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// UNIFIED LOPA IPL - BOWTIE BARRIER - BARRIER INTEGRATION
// ════════════════════════════════════════════════════════════════════════════════════

public class LopaIplWithBarrierDto
{
    public string? Id { get; set; }
    public string? ScenarioId { get; set; }
    public string? IplName { get; set; }
    public string? IplType { get; set; }
    public string? Description { get; set; }
    public double Pfd { get; set; }
    public bool IsValidated { get; set; }
    public string? Owner { get; set; }
    public string? AuditInterval { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public BarrierDto? LinkedBarrier { get; set; }
    public string? LinkedBarrierId { get; set; }
}

public class BowTieBarrierWithLinksDto
{
    public string? Id { get; set; }
    public string? DiagramId { get; set; }
    public string? Description { get; set; }
    public string? Type { get; set; }
    public string? RiskReduction { get; set; }
    public int SortOrder { get; set; }
    public string? BarrierStatus { get; set; }
    public DateTime? LastTested { get; set; }
    public BarrierDto? LinkedBarrier { get; set; }
    public string? LinkedBarrierId { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class CreateLopaIplWithBarrierDto
{
    public string? IplName { get; set; }
    public string? IplType { get; set; }
    public string? Description { get; set; }
    public object? Pfd { get; set; }
    public bool? IsValidated { get; set; }
    public string? Owner { get; set; }
    public string? AuditInterval { get; set; }
    public CreateBarrierDto? Barrier { get; set; }
}

public class CreateBowTieBarrierWithLinkDto
{
    public string? Description { get; set; }
    public string? Type { get; set; }
    public string? RiskReduction { get; set; }
    public int SortOrder { get; set; }
    public CreateBarrierDto? Barrier { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT-BARRIER INTEGRATION
// ════════════════════════════════════════════════════════════════════════════════════

public class IncidentWithBarriersDto
{
    public string? Id { get; set; }
    public string? IncidentNumber { get; set; }
    public string? Title { get; set; }
    public string? Description { get; set; }
    public string? Facility { get; set; }
    public string? Unit { get; set; }
    public DateTime? DateOccurred { get; set; }
    public DateTime? DateReported { get; set; }
    public string? ReporterName { get; set; }
    public string? IncidentType { get; set; }
    public int SeverityActual { get; set; }
    public string? Status { get; set; }
    public List<IncidentBarrierDto> Barriers { get; set; } = new();
    public List<string>? RelatedHazopStudyIds { get; set; }
    public List<string>? RelatedHazopDeviationIds { get; set; }
    public List<string>? RelatedLopaStudyIds { get; set; }
    public List<string>? RelatedLopaScenarioIds { get; set; }
    public List<string>? RelatedBowTieDiagramIds { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class IncidentBarrierDto
{
    public string? Id { get; set; }
    public string? IncidentId { get; set; }
    public string? BarrierId { get; set; }
    public string? BarrierName { get; set; }
    public string? BarrierType { get; set; }
    public string? BarrierStatus { get; set; }
    public string? BarrierFailureType { get; set; }
    public string? FailureEvidence { get; set; }
    public decimal? ContributionToIncident { get; set; }
    public DateTime? CreatedAt { get; set; }
}

public class CreateIncidentBarrierDto
{
    public string? BarrierId { get; set; }
    public string? BarrierFailureType { get; set; }
    public string? FailureEvidence { get; set; }
    public decimal? ContributionToIncident { get; set; }
}

public class IncidentImpactDto
{
    public string? IncidentId { get; set; }
    public string? IncidentNumber { get; set; }
    public string? Title { get; set; }
    public DateTime? DateOccurred { get; set; }
    public int SeverityActual { get; set; }
    public int BarriersInvolved { get; set; }
    public int CriticalBarriersAffected { get; set; }
    public decimal? AverageBarrierFailureContribution { get; set; }
    public List<string>? AffectedBarrierIds { get; set; }
    public List<string>? AffectedLopaStudyIds { get; set; }
    public List<string>? AffectedBowTieDiagramIds { get; set; }
    public int HazopScenariosAffected { get; set; }
    public int LopaStudiesAffected { get; set; }
    public int BowTieDiagramsAffected { get; set; }
    public int BarriersFailed { get; set; }
    public string? MaxSeverityHazop { get; set; }
    public decimal? MaxSeverityLopa { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// BARRIER SYNCHRONIZATION DTOs
// ════════════════════════════════════════════════════════════════════════════════════

public class BarrierSyncDto
{
    public string? BarrierId { get; set; }
    public string? NewStatus { get; set; }
    public string? LopaIplId { get; set; }
    public string? BowTieBarrierId { get; set; }
    public List<string>? AffectedIncidentIds { get; set; }
    public string? ChangedBy { get; set; }
    public string? Reason { get; set; }
}

public class SyncResultDto
{
    public bool Success { get; set; }
    public string? Message { get; set; }
    public BarrierDto? UpdatedBarrier { get; set; }
    public List<string>? SyncedLopaIpls { get; set; }
    public List<string>? SyncedBowTieBarriers { get; set; }
    public List<string>? AuditLogIds { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// BARRIER SUMMARY AND ANALYTICS DTOs
// ════════════════════════════════════════════════════════════════════════════════════

public class BarrierSummaryDto
{
    public int TotalBarriers { get; set; }
    public int ActiveBarriers { get; set; }
    public int DegradedBarriers { get; set; }
    public int FailedBarriers { get; set; }
    public int OutOfServiceBarriers { get; set; }
    public int CriticalBarriers { get; set; }
    public decimal AverageEffectivenessRating { get; set; }
    public int BarriersNeedingMaintenance { get; set; }
    public int BarriersOverdue { get; set; }
    public Dictionary<string, int>? BarrierTypeDistribution { get; set; }
    public Dictionary<string, int>? SilLevelDistribution { get; set; }
}

public class BarrierMigrationDto
{
    public string? BarrierId { get; set; }
    public string? LopaIplId { get; set; }
    public string? BowTieBarrierId { get; set; }
    public DateTime? CreatedAt { get; set; }
    public string? MigrationStatus { get; set; }
}

public class BarrierCrossReferenceDto
{
    public string? BarrierId { get; set; }
    public List<LopaIplDto>? LinkedLopaIpls { get; set; }
    public List<BowTieBarrierDto>? LinkedBowTieBarriers { get; set; }
    public List<IncidentDto>? LinkedIncidents { get; set; }
    public int TotalReferences { get; set; }
}
