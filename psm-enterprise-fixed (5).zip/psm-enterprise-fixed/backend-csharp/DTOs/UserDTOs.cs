namespace PSM.Api.DTOs;

public record CreateUserRequest(
    string Username,
    string Password,
    string FullName,
    string? Email,
    string Role,
    string? Department,
    string? Unit
);

public record UpdateUserRequest(
    string? FullName,
    string? Email,
    string? Role,
    string? Department,
    string? Unit,
    string? Status,
    string? Password,
    bool? MustChangePassword = null
);
