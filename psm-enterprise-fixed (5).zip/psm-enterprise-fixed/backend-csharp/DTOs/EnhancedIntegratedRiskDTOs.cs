using System.Text.Json.Serialization;

namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════════════
// REQUEST DTOs — Integrated Risk Model Cross-Creations
// ════════════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Create BowTie diagram directly from HAZOP deviation (cross-creation)
/// </summary>
public class CreateBowTieFromHazopRequest
{
    public string? hazop_study_id { get; set; }
    public string? hazop_deviation_id { get; set; }
    public string? bowtie_title { get; set; }
    public string? title { get; set; }
    public string? top_event { get; set; }
    public string? hazard { get; set; }
    public string? consequence { get; set; }
    public Dictionary<string, object>? preventive_barriers { get; set; }
    public Dictionary<string, object>? mitigative_barriers { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

/// <summary>
/// Create Barrier manually from LOPA IPL (called after IPL creation or on demand)
/// </summary>
public class CreateBarrierFromLopaIplRequest
{
    public string? lopa_ipl_id { get; set; }
    public string? bowtie_barrier_id { get; set; }
    public string? barrier_name { get; set; }
    public string? barrier_type { get; set; } // Engineering, Administrative, Procedural, SIS, Detection
    public string? description { get; set; }
    public string? owner_discipline { get; set; }
    public string? owner_contact { get; set; }
    public string? maintenance_frequency { get; set; }
    public DateTime? last_tested { get; set; }
    public DateTime? next_test_due { get; set; }
    public decimal? effectiveness_rating { get; set; }
    public string? documentation_ref { get; set; }
    public int? sil_level { get; set; }
    public bool? critical_flag { get; set; }
}

/// <summary>
/// Link incident to barrier with failure evidence
/// </summary>
public class LinkIncidentToBarrierRequest
{
    public string? incident_id { get; set; }
    public string? barrier_id { get; set; }
    public string? barrier_failure_type { get; set; } // Not Available, Failed to Function, Inadequate Effectiveness
    public string? failure_evidence { get; set; }
    public decimal? contribution_to_incident { get; set; }
}

/// <summary>
/// Link incident to HAZOP scenario/study
/// </summary>
public class LinkIncidentToHazopRequest
{
    public string? incident_id { get; set; }
    public string? hazop_deviation_id { get; set; }
    public string? hazop_study_id { get; set; }
    public decimal? relevance_score { get; set; }
    public string? notes { get; set; }
}

/// <summary>
/// Link incident to LOPA scenario/study
/// </summary>
public class LinkIncidentToLopaRequest
{
    public string? incident_id { get; set; }
    public string? lopa_scenario_id { get; set; }
    public string? lopa_study_id { get; set; }
    public int? ipl_failure_count { get; set; }
    public decimal? relevance_score { get; set; }
    public string? notes { get; set; }
}

/// <summary>
/// Link incident to BowTie diagram
/// </summary>
public class LinkIncidentToBowTieRequest
{
    public string? incident_id { get; set; }
    public string? bowtie_diagram_id { get; set; }
    public bool? top_event_occurred { get; set; }
    public int? barriers_failed { get; set; }
    public decimal? relevance_score { get; set; }
    public string? notes { get; set; }
}

/// <summary>
/// Batch link incident to multiple barriers
/// </summary>
public class BatchLinkBarriersRequest
{
    public string? incident_id { get; set; }
    public List<LinkIncidentToBarrierRequest>? barriers { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// RESPONSE DTOs — Integrated Risk Model Results
// ════════════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Result when creating BowTie from HAZOP
/// </summary>
public class CreateBowTieFromHazopResultDto
{
    public BowTieDiagramDetailDto? Diagram { get; set; }
    public string? BowTieDiagramId { get; set; }
    public string? HazopStudyId { get; set; }
    public string? HazopDeviationId { get; set; }
    public string? LopaScenarioId { get; set; }
    public bool LinkedToLopaScenario { get; set; }
    public string? Message { get; set; }
}

/// <summary>
/// Details when a barrier fails (cascade impact)
/// </summary>
public class BarrierFailureImpactDto
{
    public string? BarrierId { get; set; }
    public string? BarrierName { get; set; }
    public string? Status { get; set; }
    public List<BarrierImpactAnalysisDto> AffectedHazopScenarios { get; set; } = new();
    public List<BarrierImpactAnalysisDto> AffectedLopaScenarios { get; set; } = new();
    public List<BarrierImpactAnalysisDto> AffectedBowTieDiagrams { get; set; } = new();
    public BarrierDto? Barrier { get; set; }
    public List<string>? AffectedLopaIpls { get; set; }
    public List<string>? AffectedBowTieBarriers { get; set; }
    public List<string>? AffectedHazopDeviations { get; set; }
    public int TotalAffectedAnalyses { get; set; }
    public string? Message { get; set; }
}

/// <summary>
/// Detailed impact analysis when incident references barriers
/// </summary>
public class IncidentDetailedAnalysisDto
{
    public IncidentDto? Incident { get; set; }
    public List<BarrierDto>? AffectedBarriers { get; set; }
    public List<BarrierDto>? FailedBarriers { get; set; }
    public List<HazopDeviationDto>? AffectedHazopDeviations { get; set; }
    public List<HazopDeviationDto>? AffectedHazopScenarios { get; set; }
    public List<IncidentHazopMappingDto>? AffectedHazopMappings { get; set; }
    public List<LopaScenarioDto>? AffectedLopaScenarios { get; set; }
    public List<IncidentLopaMappingDto>? AffectedLopaMappings { get; set; }
    public List<BowTieDiagramDto>? AffectedBowTieDiagrams { get; set; }
    public List<IncidentBowTieMappingDto>? AffectedBowTieMappings { get; set; }
    public List<LopaScenarioDto>? LopaScenarios { get; set; }
    public List<BowTieDiagramDto>? BowTieDiagrams { get; set; }
    public IncidentImpactDto? ImpactSummary { get; set; }
    public int TotalBarriersFailed { get; set; }
    public int TotalAnalysisTypesAffected { get; set; }
}

/// <summary>
/// Status history entry for barrier
/// </summary>
public class BarrierStatusHistoryEntryDto
{
    public string? Id { get; set; }
    public string? BarrierId { get; set; }
    public string? PreviousStatus { get; set; }
    public string? NewStatus { get; set; }
    public string? Reason { get; set; }
    public string? TriggeredByIncident { get; set; }
    public string? ChangedBy { get; set; }
    public DateTime? ChangedAt { get; set; }
}

/// <summary>
/// Relationship summary (e.g., HAZOP → LOPA → Barrier → BowTie)
/// </summary>
public class RiskAnalysisPathDto
{
    public string? HazopStudyId { get; set; }
    public string? HazopDeviationId { get; set; }
    public string? LopaStudyId { get; set; }
    public string? LopaScenarioId { get; set; }
    public List<string>? LopaIplIds { get; set; }
    public List<string>? BarrierIds { get; set; }
    public string? BowTieDiagramId { get; set; }
    public List<string>? BowTieBarrierIds { get; set; }
    public List<string>? LinkedIncidents { get; set; }
}

/// <summary>
/// Cross-analysis query result
/// </summary>
public class CrossAnalysisResultDto
{
    public string? AnalysisType { get; set; } // HAZOP, LOPA, BowTie, Barrier, Incident
    public string? AnalysisId { get; set; }
    public string? AnalysisTitle { get; set; }
    public string? Status { get; set; }
    public int RelatedCount { get; set; }
    public DateTime? LastUpdated { get; set; }
}

/// <summary>
/// Batch operation result
//// <summary>
/// Dashboard summary for integrated risk model
/// </summary>
public class IntegratedRiskDashboardDto
{
    public int TotalHazopStudies { get; set; }
    public int TotalLopaStudies { get; set; }
    public int TotalBowTieDiagrams { get; set; }
    public int TotalBarriers { get; set; }
    public int TotalIncidents { get; set; }
    
    public int CriticalBarriers { get; set; }
    public int FailedBarriers { get; set; }
    public int DegradedBarriers { get; set; }
    public int ActiveBarriers { get; set; }
    
    public int OpenIncidents { get; set; }
    public int HighSeverityIncidents { get; set; }
    public int IncidentsWithBarrierFailures { get; set; }
    
    public Dictionary<string, int>? BarrierTypeDistribution { get; set; }
    public Dictionary<string, int>? IncidentTypeDistribution { get; set; }
    public Dictionary<string, int>? BarrierStatusDistribution { get; set; }
    
    public DateTime? LastUpdated { get; set; }
}

/// <summary>
/// Response for linked incident-barrier mapping
/// </summary>
public class IncidentBarrierMappingDto
{
    public string? Id { get; set; }
    public string? IncidentId { get; set; }
    public string? BarrierId { get; set; }
    public string? BarrierFailureType { get; set; }
    public string? FailureEvidence { get; set; }
    public decimal? ContributionToIncident { get; set; }
    public DateTime? CreatedAt { get; set; }
}
