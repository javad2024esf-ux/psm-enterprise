namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════
// Integration Rule DTOs
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Represents an integration rule that defines how to respond to events.
/// When a trigger_event occurs in source_module matching trigger_condition,
/// execute action_type in target_module using action_template.
/// </summary>
public class IntegrationRuleDto
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    
    // Source event specification
    public string SourceModule { get; set; } = "";              // MOC-Registry, Incident-Core, Audit-Findings, etc.
    public string TriggerEvent { get; set; } = "";             // STATUS_CHANGE, RECORD_CREATED, FIELD_CHANGE, MANUAL
    public Dictionary<string, object>? TriggerCondition { get; set; }
    
    // Target action specification
    public string TargetModule { get; set; } = "";             // Action-Register, PSSR-Registry, Notifications, etc.
    public string ActionType { get; set; } = "";               // CREATE_RECORD, UPDATE_RECORD, SEND_NOTIFICATION, START_WORKFLOW
    public Dictionary<string, object>? ActionTemplate { get; set; }
    
    // Control
    public bool IsActive { get; set; } = true;
    public int Priority { get; set; } = 10;                    // Lower number = higher priority
    
    // Metadata
    public string? CreatedBy { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}

/// <summary>
/// Request to create a new integration rule.
/// </summary>
public class CreateIntegrationRuleRequest
{
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public string SourceModule { get; set; } = "";
    public string TriggerEvent { get; set; } = "";
    public Dictionary<string, object>? TriggerCondition { get; set; } = new();
    public string TargetModule { get; set; } = "";
    public string ActionType { get; set; } = "";
    public Dictionary<string, object>? ActionTemplate { get; set; } = new();
    public bool IsActive { get; set; } = true;
    public int Priority { get; set; } = 10;
}

/// <summary>
/// Request to update an existing integration rule.
/// All fields are optional and only provided fields will be updated.
/// </summary>
public class UpdateIntegrationRuleRequest
{
    public string? Name { get; set; }
    public string? Description { get; set; }
    public string? SourceModule { get; set; }
    public string? TriggerEvent { get; set; }
    public Dictionary<string, object>? TriggerCondition { get; set; }
    public string? TargetModule { get; set; }
    public string? ActionType { get; set; }
    public Dictionary<string, object>? ActionTemplate { get; set; }
    public bool? IsActive { get; set; }
    public int? Priority { get; set; }
}

/// <summary>
/// Paginated list response for integration rules.
/// </summary>
public class IntegrationRuleListResponse
{
    public List<IntegrationRuleDto> Data { get; set; } = new();
    public int Total { get; set; }
    public int Page { get; set; }
    public int Limit { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Integration Event DTOs
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Represents an integration event that triggers integration rules.
/// Events are created when significant actions occur in any module.
/// </summary>
public class IntegrationEventDto
{
    public string Id { get; set; } = "";
    public string EventType { get; set; } = "";                // STATUS_CHANGE, RECORD_CREATED, FIELD_CHANGE
    public string SourceModule { get; set; } = "";             // Which module generated the event
    public string SourceId { get; set; } = "";                 // ID of the source record
    public Dictionary<string, object>? Payload { get; set; }   // Complete event data
    public string? TriggeredBy { get; set; }                   // User ID or 'system'
    public DateTime CreatedAt { get; set; }
    
    // Processing status
    public string Status { get; set; } = "pending";            // pending, processing, done, failed
    public DateTime? ProcessedAt { get; set; }
    public string? ErrorMessage { get; set; }
    public int RetryCount { get; set; } = 0;
}

/// <summary>
/// Request to create a new integration event.
/// </summary>
public class CreateIntegrationEventRequest
{
    public string EventType { get; set; } = "";
    public string SourceModule { get; set; } = "";
    public string SourceId { get; set; } = "";
    public Dictionary<string, object>? Payload { get; set; } = new();
    public string? TriggeredBy { get; set; }
}

/// <summary>
/// Request to manually trigger integration execution.
/// </summary>
public class ExecuteIntegrationRequest
{
    public string EventId { get; set; } = "";                  // Which event to execute
    public List<string>? RuleIds { get; set; }                 // Optional: specific rules to execute. If null, executes all matching rules.
}

/// <summary>
/// Paginated list response for integration events.
/// </summary>
public class IntegrationEventListResponse
{
    public List<IntegrationEventDto> Data { get; set; } = new();
    public int Total { get; set; }
    public int Page { get; set; }
    public int Limit { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Integration Execution DTOs
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Represents the result of executing an integration rule against an event.
/// </summary>
public class IntegrationExecutionDto
{
    public string Id { get; set; } = "";
    public string EventId { get; set; } = "";
    public string RuleId { get; set; } = "";
    
    public string Status { get; set; } = "pending";            // success, failed, skipped
    public Dictionary<string, object>? Result { get; set; }    // Created record ID, workflow started, etc.
    public string? ErrorMessage { get; set; }
    public int? DurationMs { get; set; }
    public DateTime ExecutedAt { get; set; }
}

/// <summary>
/// Response for integration execution result.
/// </summary>
public class IntegrationExecutionResponse
{
    public string ExecutionId { get; set; } = "";
    public string Status { get; set; } = "";                   // success, failed, skipped
    public Dictionary<string, object>? Result { get; set; }
    public string? ErrorMessage { get; set; }
    public int? DurationMs { get; set; }
}

/// <summary>
/// Aggregated execution results for multiple rules.
/// </summary>
public class IntegrationExecutionResultsResponse
{
    public List<IntegrationExecutionResponse> Executions { get; set; } = new();
    public int Successful { get; set; }
    public int Failed { get; set; }
    public int Skipped { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Integration Statistics & Health DTOs
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Statistics about integration system health and activity.
/// </summary>
public class IntegrationStatsDto
{
    public int ActiveRules { get; set; }
    public int TotalRules { get; set; }
    public int PendingEvents { get; set; }
    public int ProcessingEvents { get; set; }
    public int CompletedEvents { get; set; }
    public int FailedEvents { get; set; }
    public int SuccessfulExecutions { get; set; }
    public int FailedExecutions { get; set; }
    public double AverageExecutionTimeMs { get; set; }
    public DateTime? LastActivityAt { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════
// Enumerations for Type Safety
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Supported event types in the integration system.
/// </summary>
public static class IntegrationEventTypes
{
    public const string StatusChange = "STATUS_CHANGE";
    public const string RecordCreated = "RECORD_CREATED";
    public const string FieldChange = "FIELD_CHANGE";
    public const string Manual = "MANUAL";
}

/// <summary>
/// Supported action types for integration rules.
/// </summary>
public static class IntegrationActionTypes
{
    public const string CreateRecord = "CREATE_RECORD";
    public const string UpdateRecord = "UPDATE_RECORD";
    public const string SendNotification = "SEND_NOTIFICATION";
    public const string StartWorkflow = "START_WORKFLOW";
    public const string CreateActionRegister = "CREATE_ACTION_REGISTER";
    public const string TriggerWebhook = "TRIGGER_WEBHOOK";
}

/// <summary>
/// Event and execution statuses.
/// </summary>
public static class IntegrationStatuses
{
    // Event statuses
    public const string Pending = "pending";
    public const string Processing = "processing";
    public const string Done = "done";
    public const string Failed = "failed";
    
    // Execution statuses
    public const string Success = "success";
    public const string Skipped = "skipped";
}

/// <summary>
/// Source modules that can trigger integrations.
/// </summary>
public static class IntegrationSourceModules
{
    public const string MocRegistry = "MOC-Registry";
    public const string IncidentCore = "Incident-Core";
    public const string HazopAnalysis = "HAZOP-Analysis";
    public const string AuditFindings = "Audit-Findings";
    public const string PssrRegistry = "PSSR-Registry";
    public const string ActionRegister = "Action-Register";
    public const string NotificationCenter = "Notification-Center";
    public const string WorkflowEngine = "Workflow-Engine";
}

/// <summary>
/// Target modules for integration actions.
/// </summary>
public static class IntegrationTargetModules
{
    public const string ActionRegister = "Action-Register";
    public const string PssrRegistry = "PSSR-Registry";
    public const string NotificationCenter = "Notification-Center";
    public const string WorkflowEngine = "Workflow-Engine";
    public const string IncidentCore = "Incident-Core";
    public const string HazopAnalysis = "HAZOP-Analysis";
}
