using System.Text.Json;
using System.Text.Json.Serialization;

namespace PSM.Api.DTOs;

public record CreateRecordRequest
{
    // Frontend sends "element"; backend DB uses "collection" — accept both.
    [JsonPropertyName("collection")]
    public string? Collection { get; init; }

    [JsonPropertyName("element")]
    public string? Element { get; init; }

    // Resolved collection name (Element takes priority for backward compat)
    [JsonIgnore]
    public string ResolvedCollection => Element ?? Collection ?? string.Empty;

    public string? Unit   { get; init; }
    public string? Status { get; init; }
    public JsonElement Data { get; init; }
}

public record UpdateRecordRequest
{
    // Frontend sends {element, data} — accept element for collection identification
    [JsonPropertyName("element")]
    public string? Collection { get; init; }

    public string? Unit   { get; init; }
    public string? Status { get; init; }
    public JsonElement? Data { get; init; }
}
