namespace PSM.Api.DTOs;
// ═══════════════════════════════════════════════════════════════════════════
// Change Request DTOs
// ═══════════════════════════════════════════════════════════════════════════

public class CreateChangeRequestDto
{
    public string Title { get; set; }
    public string Description { get; set; }
    public string PsiId { get; set; }
    public string ChangeType { get; set; } // 'Major' | 'Minor' | 'Emergency'
    public string Priority { get; set; } = "Medium";
    public List<string> ImpactArea { get; set; } = new();
    public List<string> EquipmentIds { get; set; } = new();
    public DateTime? TargetDate { get; set; }
}

public class ChangeRequestDto
{
    public string Id { get; set; }
    public string RequestNumber { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public string PsiId { get; set; }
    public string ChangeType { get; set; }
    public string Priority { get; set; }
    public List<string> ImpactArea { get; set; }
    public List<string> EquipmentIds { get; set; }
    public string RequestedBy { get; set; }
    public DateTime RequestedAt { get; set; }
    public DateTime? TargetDate { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string CurrentStage { get; set; }
    public List<ChangeWorkflowStageDto> Stages { get; set; } = new();
}

// ═══════════════════════════════════════════════════════════════════════════
// Workflow Stage DTOs
// ═══════════════════════════════════════════════════════════════════════════

public class ChangeWorkflowStageDto
{
    public string Id { get; set; }
    public string ChangeId { get; set; }
    public string StageName { get; set; }
    public string StageStatus { get; set; } // 'Pending' | 'In_Progress' | 'On_Hold' | 'Completed' | 'Failed'
    public DateTime? StartedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    public string AssignedTo { get; set; }
    public string Notes { get; set; }
    public Dictionary<string, object> Metadata { get; set; } = new();
    public List<ChangeStageActionDto> Actions { get; set; } = new();
}

public class UpdateWorkflowStageDto
{
    public string StageStatus { get; set; }
    public string AssignedTo { get; set; }
    public string Notes { get; set; }
    public Dictionary<string, object> Metadata { get; set; }
}

public class AdvanceWorkflowDto
{
    public string ChangeId { get; set; }
    public string NextStage { get; set; }
    public string Comment { get; set; }
    public Dictionary<string, object> Metadata { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// Stage Action DTOs
// ═══════════════════════════════════════════════════════════════════════════

public class ChangeStageActionDto
{
    public string Id { get; set; }
    public string StageId { get; set; }
    public string ActionItem { get; set; }
    public string ActionType { get; set; }
    public bool IsOpen { get; set; }
    public string AssignedTo { get; set; }
    public DateTime? DueDate { get; set; }
    public DateTime? CompletedAt { get; set; }
    public string CompletedBy { get; set; }
    public string Notes { get; set; }
}

public class CreateStageActionDto
{
    public string StageId { get; set; }
    public string ActionItem { get; set; }
    public string ActionType { get; set; }
    public string AssignedTo { get; set; }
    public DateTime? DueDate { get; set; }
    public string Notes { get; set; }
}

public class CompleteActionDto
{
    public string ActionId { get; set; }
    public string CompletionNotes { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// HAZOP/LOPA Mapping DTOs
// ═══════════════════════════════════════════════════════════════════════════

public class LinkHazopToChangeDto
{
    public string ChangeId { get; set; }
    public string HazopId { get; set; }
}

public class LinkLopaToChangeDto
{
    public string ChangeId { get; set; }
    public string LopaId { get; set; }
}

public class ChangeHazopMappingDto
{
    public string Id { get; set; }
    public string ChangeId { get; set; }
    public string HazopId { get; set; }
    public DateTime MappedAt { get; set; }
    public string MappedBy { get; set; }
}

public class ChangeLopaMappingDto
{
    public string Id { get; set; }
    public string ChangeId { get; set; }
    public string LopaId { get; set; }
    public bool SilDetermined { get; set; }
    public DateTime MappedAt { get; set; }
    public string MappedBy { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// Training DTOs
// ═══════════════════════════════════════════════════════════════════════════

public class CreateTrainingRecordDto
{
    public string ChangeId { get; set; }
    public string UserId { get; set; }
    public DateTime TrainingDate { get; set; }
}

public class CompleteTrainingDto
{
    public string TrainingRecordId { get; set; }
    public string CertificateUrl { get; set; }
    public string Notes { get; set; }
}

public class TrainingRecordDto
{
    public string Id { get; set; }
    public string ChangeId { get; set; }
    public string UserId { get; set; }
    public DateTime TrainingDate { get; set; }
    public bool Completed { get; set; }
    public DateTime? CompletionDate { get; set; }
    public string CertificateUrl { get; set; }
    public string Notes { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// PSSR Checklist DTOs
// ═══════════════════════════════════════════════════════════════════════════

public class PssrChecklistItemDto
{
    public string Id { get; set; }
    public string ChangeId { get; set; }
    public string PssrItem { get; set; }
    public string ItemCategory { get; set; }
    public bool IsVerified { get; set; }
    public string VerifiedBy { get; set; }
    public DateTime? VerifiedAt { get; set; }
    public string VerificationNotes { get; set; }
}

public class VerifyPssrItemDto
{
    public string PssrItemId { get; set; }
    public string VerificationNotes { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// Startup Gate DTOs
// ═══════════════════════════════════════════════════════════════════════════

public class StartupGateStatusDto
{
    public string Id { get; set; }
    public string ChangeId { get; set; }
    public bool TrainingComplete { get; set; }
    public bool PssrComplete { get; set; }
    public bool HazopActionsClosed { get; set; }
    public bool LopaActionsClosed { get; set; }
    public bool CanStartup { get; set; }
    public string ApprovalStatus { get; set; } // 'Pending' | 'Approved' | 'Rejected'
    public string ApprovedBy { get; set; }
    public DateTime? ApprovedAt { get; set; }
    public string RejectionReason { get; set; }
    public List<string> BlockingIssues { get; set; } = new();
}

public class ApproveStartupDto
{
    public string ChangeId { get; set; }
    public string ApprovalComment { get; set; }
}

public class RejectStartupDto
{
    public string ChangeId { get; set; }
    public string RejectionReason { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// Dashboard DTOs
// ═══════════════════════════════════════════════════════════════════════════

public class ChangeDashboardMetricsDto
{
    public int TotalChanges { get; set; }
    public int InProgressChanges { get; set; }
    public int CompletedChanges { get; set; }
    public int BlockedChanges { get; set; }
    public int MajorChangesInProgress { get; set; }
    public int OverdueChanges { get; set; }
    public Dictionary<string, int> ChangesByType { get; set; } = new();
    public Dictionary<string, int> ChangesByPriority { get; set; } = new();
    public Dictionary<string, int> ChangesByStage { get; set; } = new();
    public List<ChangeRequestDto> RecentChanges { get; set; } = new();
}

public class DashboardIndicatorDto
{
    public string MetricName { get; set; }
    public int MetricValue { get; set; }
    public string MetricType { get; set; }
    public string ChangeType { get; set; }
    public string Priority { get; set; }
    public DateTime LastUpdated { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// Workflow History & Audit DTOs
// ═══════════════════════════════════════════════════════════════════════════

public class WorkflowAuditDto
{
    public string Id { get; set; }
    public string ChangeId { get; set; }
    public string Action { get; set; }
    public string FromStage { get; set; }
    public string ToStage { get; set; }
    public string PerformedBy { get; set; }
    public DateTime PerformedAt { get; set; }
    public string Comment { get; set; }
    public Dictionary<string, object> Metadata { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// Notification DTOs
// ═══════════════════════════════════════════════════════════════════════════

public class ChangeNotificationDto
{
    public string Id { get; set; }
    public string ChangeId { get; set; }
    public string NotificationType { get; set; }
    public string Title { get; set; }
    public string Message { get; set; }
    public string Recipient { get; set; }
    public bool IsRead { get; set; }
    public DateTime CreatedAt { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// Query & Filter DTOs
// ═══════════════════════════════════════════════════════════════════════════

public class ChangeRequestFilterDto
{
    public string Status { get; set; }
    public string ChangeType { get; set; }
    public string Priority { get; set; }
    public string CurrentStage { get; set; }
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
    public string RequestedBy { get; set; }
    public int PageNumber { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}

public class ChangeStatusReportDto
{
    public int Total { get; set; }
    public int Completed { get; set; }
    public int InProgress { get; set; }
    public int Pending { get; set; }
    public int Blocked { get; set; }
    public decimal CompletionPercentage { get; set; }
    public TimeSpan AverageCompletionTime { get; set; }
    public Dictionary<string, int> StageBreakdown { get; set; } = new();
}
