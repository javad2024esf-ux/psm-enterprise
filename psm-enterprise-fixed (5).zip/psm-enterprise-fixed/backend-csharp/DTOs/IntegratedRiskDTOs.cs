using System.Text.Json.Serialization;

namespace PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════════════
// BARRIER DTOs — Linked to LOPA IPLs and BowTie Barriers
// ════════════════════════════════════════════════════════════════════════════════════

public class CreateBarrierRequest
{
    public string? lopa_ipl_id { get; set; }
    public string? bowtie_barrier_id { get; set; }
    public string? barrier_name { get; set; }
    public string? barrier_type { get; set; }
    public string? description { get; set; }
    public string? owner_discipline { get; set; }
    public string? owner_contact { get; set; }
    public string? maintenance_frequency { get; set; }
    public DateTime? last_tested { get; set; }
    public DateTime? next_test_due { get; set; }
    public decimal? effectiveness_rating { get; set; }
    public string? status { get; set; }
    public string? failure_mode { get; set; }
    public string? documentation_ref { get; set; }
    public int? sil_level { get; set; }
    public bool? critical_flag { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

public class UpdateBarrierRequest : CreateBarrierRequest { }

public class UpdateBarrierStatusRequest
{
    public string? new_status { get; set; }
    public string? reason { get; set; }
    public string? incident_id { get; set; }
}

public class BarrierWithRelatedAnalysisDto : BarrierDto
{
    public int LinkedIncidents { get; set; }
    public int AffectedHazopScenarios { get; set; }
    public int AffectedLopaScenarios { get; set; }
    public int AffectedBowTieDiagrams { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT DTOs — Operational Incidents with Cross-Analysis Linkages
// ════════════════════════════════════════════════════════════════════════════════════

public class CreateIncidentRequest
{
    public string? incident_number { get; set; }
    public string? title { get; set; }
    public string? description { get; set; }
    public string? facility { get; set; }
    public string? unit { get; set; }
    public DateTime? date_occurred { get; set; }
    public string? reporter_name { get; set; }
    public string? reporter_contact { get; set; }
    public string? incident_type { get; set; }
    public int? severity_actual { get; set; }
    public string? root_cause { get; set; }
    public string? immediate_actions { get; set; }
    public string? corrective_actions { get; set; }
    public string? preventive_actions { get; set; }
    public string? status { get; set; }
    public string? investigation_lead { get; set; }
    public string? lessons_learned { get; set; }
    public bool? shared_with_industry { get; set; }
    public Dictionary<string, object>? data { get; set; }
}

public class UpdateIncidentRequest : CreateIncidentRequest { }

public class CloseIncidentRequest
{
    public string? lessons_learned { get; set; }
    public DateTime? date_closed { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT-BARRIER RELATIONSHIP DTOs
// ════════════════════════════════════════════════════════════════════════════════════

public class CreateIncidentBarrierRequest
{
    public string? incident_id { get; set; }
    public string? barrier_id { get; set; }
    public string? barrier_failure_type { get; set; }
    public string? failure_evidence { get; set; }
    public decimal? contribution_to_incident { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT-HAZOP MAPPING DTOs
// ════════════════════════════════════════════════════════════════════════════════════

public class CreateIncidentHazopMappingRequest
{
    public string? incident_id { get; set; }
    public string? hazop_deviation_id { get; set; }
    public string? hazop_study_id { get; set; }
    public decimal? relevance_score { get; set; }
    public string? notes { get; set; }
}

public class IncidentHazopMappingDto
{
    public string? Id { get; set; }
    public string? IncidentId { get; set; }
    public string? HazopDeviationId { get; set; }
    public string? HazopStudyId { get; set; }
    public decimal? RelevanceScore { get; set; }
    public string? Notes { get; set; }
    public DateTime? CreatedAt { get; set; }
    public HazopDeviationDto? HazopDeviation { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT-LOPA MAPPING DTOs
// ════════════════════════════════════════════════════════════════════════════════════

public class CreateIncidentLopaMappingRequest
{
    public string? incident_id { get; set; }
    public string? lopa_scenario_id { get; set; }
    public string? lopa_study_id { get; set; }
    public decimal? relevance_score { get; set; }
    public int? ipl_failure_count { get; set; }
    public string? notes { get; set; }
}

public class IncidentLopaMappingDto
{
    public string? Id { get; set; }
    public string? IncidentId { get; set; }
    public string? LopaScenarioId { get; set; }
    public string? LopaStudyId { get; set; }
    public decimal? RelevanceScore { get; set; }
    public int IplFailureCount { get; set; }
    public string? Notes { get; set; }
    public DateTime? CreatedAt { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT-BOWTIE MAPPING DTOs
// ════════════════════════════════════════════════════════════════════════════════════

public class CreateIncidentBowTieMappingRequest
{
    public string? incident_id { get; set; }
    public string? bowtie_diagram_id { get; set; }
    public bool? top_event_occurred { get; set; }
    public int? barriers_failed { get; set; }
    public decimal? relevance_score { get; set; }
    public string? notes { get; set; }
}

public class IncidentBowTieMappingDto
{
    public string? Id { get; set; }
    public string? IncidentId { get; set; }
    public string? BowTieDiagramId { get; set; }
    public bool TopEventOccurred { get; set; }
    public int BarriersFailed { get; set; }
    public decimal? RelevanceScore { get; set; }
    public string? Notes { get; set; }
    public DateTime? CreatedAt { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// COMPREHENSIVE INCIDENT ANALYSIS DTOs
// ════════════════════════════════════════════════════════════════════════════════════

// ════════════════════════════════════════════════════════════════════════════════════
// BARRIER IMPACT ANALYSIS DTOs
// ════════════════════════════════════════════════════════════════════════════════════

public class BarrierImpactAnalysisDto
{
    public string? AnalysisType { get; set; }
    public string? AnalysisId { get; set; }
    public string? AnalysisTitle { get; set; }
    public string? Severity { get; set; }
    public int RelatedCount { get; set; }
    public DateTime? LastUpdated { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INTEGRATED CREATION DTOs — Create LOPA/BowTie from HAZOP
// ════════════════════════════════════════════════════════════════════════════════════

// ════════════════════════════════════════════════════════════════════════════════════
// ANALYSIS LINKING RESPONSE DTOs
// ════════════════════════════════════════════════════════════════════════════════════

public class LinkedAnalysisDto
{
    public string? HazopStudyId { get; set; }
    public string? HazopDeviationId { get; set; }
    public string? LopaStudyId { get; set; }
    public string? LopaScenarioId { get; set; }
    public string? BowTieDiagramId { get; set; }
    public List<BarrierDto>? LinkedBarriers { get; set; }
    public List<IncidentDto>? RelatedIncidents { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// BATCH OPERATIONS DTOs
// ════════════════════════════════════════════════════════════════════════════════════

public class BatchUpdateBarrierStatusRequest
{
    public List<string>? barrier_ids { get; set; }
    public string? new_status { get; set; }
    public string? reason { get; set; }
}

public class BatchCreateIncidentBarriersRequest
{
    public string? incident_id { get; set; }
    public List<CreateIncidentBarrierRequest>? barriers { get; set; }
}

public class BatchOperationResultDto
{
    public bool Success { get; set; }
    public int TotalProcessed { get; set; }
    public int SuccessfulCount { get; set; }
    public int SuccessCount { get; set; }
    public int FailedCount { get; set; }
    public int FailureCount { get; set; }
    public List<string>? SuccessIds { get; set; }
    public List<string>? Errors { get; set; }
    public List<string>? ErrorMessages { get; set; }
    public string? Message { get; set; }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT DTO
// ════════════════════════════════════════════════════════════════════════════════════

public class IncidentDto
{
    public string? Id { get; set; }
    public string? IncidentNumber { get; set; }
    public string? Title { get; set; }
    public string? Description { get; set; }
    public string? Facility { get; set; }
    public string? Unit { get; set; }
    public DateTime? DateOccurred { get; set; }
    public DateTime? DateReported { get; set; }
    public string? ReporterName { get; set; }
    public string? ReporterContact { get; set; }
    public string? IncidentType { get; set; }
    public int SeverityActual { get; set; }
    public string? RootCause { get; set; }
    public string? ImmediateActions { get; set; }
    public string? CorrectiveActions { get; set; }
    public string? PreventiveActions { get; set; }
    public string? Status { get; set; }
    public string? InvestigationLead { get; set; }
    public DateTime? DateClosed { get; set; }
    public string? LessonsLearned { get; set; }
    public bool SharedWithIndustry { get; set; }
    public DateTime? CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? Data { get; set; }
}
