namespace PSM.Api.DTOs;

// ═══════════════════════════════════════════════════════════════════════════
// AI Assist Request/Response DTOs
// ═══════════════════════════════════════════════════════════════════════════

public class AiAssistRequestDto
{
    public string Context { get; set; } = "";
    public string Language { get; set; } = "en";
    public Dictionary<string, object> Metadata { get; set; } = new();
}

// ═══════════════════════════════════════════════════════════════════════════
// HAZOP AI Assist
// ═══════════════════════════════════════════════════════════════════════════

public class SuggestHazopCauseDto
{
    public string GuideWord { get; set; } = "";
    public string Parameter { get; set; } = "";
    public string ProcessDescription { get; set; } = "";
    public string? ExistingCauses { get; set; }    // optional input
    public string Language { get; set; } = "en";
}

public class SuggestHazopCauseResponseDto
{
    public List<string> Suggestions { get; set; } = new();
    public string? Reasoning { get; set; }
    public int ConfidenceScore { get; set; }
}

public class SuggestHazopConsequenceDto
{
    public string Cause { get; set; } = "";
    public string Parameter { get; set; } = "";
    public string ProcessDescription { get; set; } = "";
    public string Severity { get; set; } = "";
    public string Language { get; set; } = "en";
}

public class SuggestHazopConsequenceResponseDto
{
    public List<string> Suggestions { get; set; } = new();
    public string? SeverityAssessment { get; set; }
    public int ConfidenceScore { get; set; }
}

public class SuggestHazopSafeguardDto
{
    public string Hazard { get; set; } = "";
    public string Consequence { get; set; } = "";
    public string? ExistingSafeguards { get; set; } // optional input
    public string? SafeguardType { get; set; }      // optional filter: "Engineering", "Procedural", "Administrative"
    public string Language { get; set; } = "en";
}

public class SuggestHazopSafeguardResponseDto
{
    public List<string> Suggestions { get; set; } = new();
    public List<string> SafeguardTypes { get; set; } = new();
    public int ConfidenceScore { get; set; }
}

public class SuggestHazopActionDto
{
    public string ResidualRisk { get; set; } = "";
    public string Consequence { get; set; } = "";
    public string? RecommendedSafeguards { get; set; }
    public string Language { get; set; } = "en";
}

public class SuggestHazopActionResponseDto
{
    public List<string> Actions { get; set; } = new();
    public List<string> Priorities { get; set; } = new();
    public string? Timeline { get; set; }
    public int ConfidenceScore { get; set; }
}

public class AssessHazopRiskDto
{
    public string Consequence { get; set; } = "";
    public string Likelihood { get; set; } = "";
    public string Severity { get; set; } = "";
    public string? ExistingControls { get; set; }  // optional input
    public string Language { get; set; } = "en";
}

public class AssessHazopRiskResponseDto
{
    public string? RiskLevel { get; set; }          // "High", "Medium", "Low"
    public int RiskScore { get; set; }
    public string? Justification { get; set; }
    public bool RequiresAction { get; set; }
    public List<string> RecommendedControls { get; set; } = new();
}

// ═══════════════════════════════════════════════════════════════════════════
// LOPA AI Assist
// ═══════════════════════════════════════════════════════════════════════════

public class SuggestLopaIplDto
{
    public string Hazard { get; set; } = "";
    public string Consequence { get; set; } = "";
    public string InitiatingEvent { get; set; } = "";
    public string? ExistingIpls { get; set; }      // optional input
    public string Language { get; set; } = "en";
}

public class SuggestLopaIplResponseDto
{
    public List<string> Suggestions { get; set; } = new();
    public List<string> IndependentLayers { get; set; } = new();
    public int ConfidenceScore { get; set; }
}

public class EstimaLopaLopaDto
{
    public string Ipl { get; set; } = "";
    public string IplType { get; set; } = "";
    public string MaintenanceFrequency { get; set; } = "";
    public string TestingFrequency { get; set; } = "";
    public string Language { get; set; } = "en";
}

public class EstimateLopaIplResponseDto
{
    public double PfdValue { get; set; }
    public string? PfdRange { get; set; }
    public string? Justification { get; set; }
    public List<string> RelevantFactors { get; set; } = new();
}

public class RecommendLopaSilDto
{
    public int InitiatingEventFrequency { get; set; }
    public int ConsequenceSeverity { get; set; }
    public double IplPfd { get; set; }
    public int ExistingIplCount { get; set; }
    public string Language { get; set; } = "en";
}

public class RecommendLopaSilResponseDto
{
    public int RecommendedSil { get; set; }
    public string? SilJustification { get; set; }
    public List<string> RequiredIplCharacteristics { get; set; } = new();
    public double RiskReductionAchieved { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// Generic Field Completion
// ═══════════════════════════════════════════════════════════════════════════

public class CompleteFieldDto
{
    public string FieldName { get; set; } = "";
    public string? PartialValue { get; set; }
    public string Context { get; set; } = "";
    public string Module { get; set; } = "";       // "hazop", "lopa", "bowtie", etc.
    public Dictionary<string, object> ContextData { get; set; } = new();
    public string Language { get; set; } = "en";
}

public class CompleteFieldResponseDto
{
    public string? CompletedValue { get; set; }
    public List<string> AlternativeSuggestions { get; set; } = new();
    public int ConfidenceScore { get; set; }
    public string? Reasoning { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// Health Check
// ═══════════════════════════════════════════════════════════════════════════

public class AiAssistHealthDto
{
    public string? Status { get; set; }
    public string? Message { get; set; }
    public long ResponseTimeMs { get; set; }
    public bool ApiConnected { get; set; }
    public string? Version { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// BOWTIE AI ASSIST
// ═══════════════════════════════════════════════════════════════════════════

public class SuggestBowTieTopEventDto
{
    public string SystemDescription { get; set; } = "";
    public string ProcessDescription { get; set; } = "";
    public string? HistoricalIncidents { get; set; }
    public string Language { get; set; } = "en";
}

public class SuggestBowTieTopEventResponseDto
{
    public List<string> TopEventSuggestions { get; set; } = new();
    public string? Severity { get; set; }
    public int ConfidenceScore { get; set; }
}

public class SuggestBowTieThreatsDto
{
    public string TopEvent { get; set; } = "";
    public string SystemDescription { get; set; } = "";
    public string? ExistingThreats { get; set; }
    public string Language { get; set; } = "en";
}

public class SuggestBowTieThreatsResponseDto
{
    public List<string> ThreatSuggestions { get; set; } = new();
    public List<string> ThreatCategories { get; set; } = new();
    public int ConfidenceScore { get; set; }
}

public class SuggestBowTieConsequencesDto
{
    public string TopEvent { get; set; } = "";
    public string Severity { get; set; } = "";
    public string? ProcessContext { get; set; }
    public string Language { get; set; } = "en";
}

public class SuggestBowTieConsequencesResponseDto
{
    public List<string> ConsequenceSuggestions { get; set; } = new();
    public string? OverallRiskLevel { get; set; }
    public int ConfidenceScore { get; set; }
}

public class SuggestBowTieBarriersDto
{
    public string BarrierPosition { get; set; } = ""; // "Prevention" or "Mitigation"
    public string TopEvent { get; set; } = "";
    public string? ThreatOrConsequence { get; set; }
    public string? ExistingBarriers { get; set; }
    public string Language { get; set; } = "en";
}

public class SuggestBowTieBarriersResponseDto
{
    public List<string> BarrierSuggestions { get; set; } = new();
    public List<string> BarrierTypes { get; set; } = new();  // "Engineering", "Administrative", "PPE"
    public int ConfidenceScore { get; set; }
}

public class AssessBowTieIntegrityDto
{
    public string TopEvent { get; set; } = "";
    public List<string> Threats { get; set; } = new();
    public List<string> PreventionBarriers { get; set; } = new();
    public List<string> Consequences { get; set; } = new();
    public List<string> MitigationBarriers { get; set; } = new();
    public string Language { get; set; } = "en";
}

public class AssessBowTieIntegrityResponseDto
{
    public string? OverallRiskAssessment { get; set; }
    public List<string> GapIdentifications { get; set; } = new();
    public List<string> ImprovementSuggestions { get; set; } = new();
    public int RiskScore { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// RISK ASSESSMENT AI ASSIST
// ═══════════════════════════════════════════════════════════════════════════

public class AssessIntegratedRiskDto
{
    public string HazardDescription { get; set; } = "";
    public string? HazopFindings { get; set; }
    public string? LopaResults { get; set; }
    public string? BowTieAnalysis { get; set; }
    public string? ExistingControls { get; set; }
    public string Language { get; set; } = "en";
}

public class AssessIntegratedRiskResponseDto
{
    public string? OverallRiskLevel { get; set; }   // "Critical", "High", "Medium", "Low"
    public int RiskScore { get; set; }
    public int IplNeeded { get; set; }              // SIL level
    public List<string> ControlRecommendations { get; set; } = new();
    public List<string> MonitoringRecommendations { get; set; } = new();
}

public class RecommendRiskControlsDto
{
    public string RiskLevel { get; set; } = "";
    public string? HazardCategory { get; set; }
    public string? ProcessDescription { get; set; }
    public List<string>? ExistingControls { get; set; }
    public string Language { get; set; } = "en";
}

public class RecommendRiskControlsResponseDto
{
    public List<string> EngineeringControls { get; set; } = new();
    public List<string> AdministrativeControls { get; set; } = new();
    public List<string> PPEControls { get; set; } = new();
    public List<string> MonitoringMeasures { get; set; } = new();
    public string? ImplementationPriority { get; set; }
}

public class AnalyzeRiskTrendsDto
{
    public List<RiskIncidentData> HistoricalIncidents { get; set; } = new();
    public string? TimeframePeriod { get; set; }
    public string Language { get; set; } = "en";

    public class RiskIncidentData
    {
        public DateTime Date { get; set; }
        public string Category { get; set; } = "";
        public string Severity { get; set; } = "";
        public string Description { get; set; } = "";
    }
}

public class AnalyzeRiskTrendsResponseDto
{
    public List<string> TrendIdentifications { get; set; } = new();
    public List<string> HighRiskAreas { get; set; } = new();
    public List<string> ProactiveRecommendations { get; set; } = new();
    public string? OverallTrendAssessment { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// DOCUMENT AI ASSIST
// ═══════════════════════════════════════════════════════════════════════════

public class AnalyzeDocumentDto
{
    public int DocumentId { get; set; }
    public string DocumentType { get; set; } = ""; // "HAZOP", "LOPA", "BowTie", "RCA", "Incident", "Procedure", etc.
    public string? DocumentContent { get; set; }
    public string? DocumentTitle { get; set; }
    public string AnalysisType { get; set; } = "summary"; // "summary", "risks", "compliance", "gaps"
    public string Language { get; set; } = "en";
}

public class AnalyzeDocumentResponseDto
{
    public string? Summary { get; set; }
    public List<string> KeyFindings { get; set; } = new();
    public List<string> IdentifiedRisks { get; set; } = new();
    public List<string> ComplianceGaps { get; set; } = new();
    public List<string> ActionItems { get; set; } = new();
    public Dictionary<string, object>? Metadata { get; set; }
}

public class GenerateDocumentRecommendationsDto
{
    public int DocumentId { get; set; }
    public string DocumentType { get; set; } = "";
    public string? DocumentContext { get; set; }
    public List<string>? IdentifiedIssues { get; set; }
    public string Language { get; set; } = "en";
}

public class GenerateDocumentRecommendationsResponseDto
{
    public List<DocumentRecommendation> Recommendations { get; set; } = new();
    public string? ImplementationStrategy { get; set; }
    public List<string> ResourcesNeeded { get; set; } = new();

    public class DocumentRecommendation
    {
        public string Title { get; set; } = "";
        public string Description { get; set; } = "";
        public string Priority { get; set; } = ""; // "Critical", "High", "Medium", "Low"
        public string? Timeline { get; set; }
    }
}

public class ExtractDocumentDataDto
{
    public int DocumentId { get; set; }
    public string DocumentType { get; set; } = "";
    public string? DocumentContent { get; set; }
    public List<string> DataFieldsToExtract { get; set; } = new();
    public string Language { get; set; } = "en";
}

public class ExtractDocumentDataResponseDto
{
    public Dictionary<string, object> ExtractedData { get; set; } = new();
    public List<string> UnrecognizedFields { get; set; } = new();
    public double ExtractionConfidence { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// RECOMMENDATIONS AI ASSIST
// ═══════════════════════════════════════════════════════════════════════════

public class GenerateHazopRecommendationsDto
{
    public int HazopStudyId { get; set; }
    public string TopicsIdentified { get; set; } = "";
    public string RiskLevel { get; set; } = "";
    public string? ExistingActions { get; set; }
    public string Language { get; set; } = "en";
}

public class GenerateHazopRecommendationsResponseDto
{
    public List<HazopRecommendation> Recommendations { get; set; } = new();
    public string? ImplementationSequence { get; set; }
    public List<string> ResourceRequirements { get; set; } = new();

    public class HazopRecommendation
    {
        public string Title { get; set; } = "";
        public string Description { get; set; } = "";
        public string Priority { get; set; } = ""; // "Critical", "High", "Medium", "Low"
        public string? Owner { get; set; }
        public string? Timeline { get; set; }
        public List<string> SuccessCriteria { get; set; } = new();
    }
}

public class GenerateLopaRecommendationsDto
{
    public int LopaStudyId { get; set; }
    public string IplGaps { get; set; } = "";
    public int RequiredSil { get; set; }
    public int AchievedSil { get; set; }
    public string Language { get; set; } = "en";
}

public class GenerateLopaRecommendationsResponseDto
{
    public List<LopaRecommendation> Recommendations { get; set; } = new();
    public string? ImplementationRoadmap { get; set; }
    public List<string> VendorConsiderations { get; set; } = new();

    public class LopaRecommendation
    {
        public string Title { get; set; } = "";
        public string Description { get; set; } = "";
        public string Priority { get; set; } = ""; // Critical for gap closure
        public int SilContribution { get; set; }
        public string? Timeline { get; set; }
        public decimal? EstimatedCost { get; set; }
    }
}

public class PrioritizeActionsDto
{
    public List<ActionItem> Actions { get; set; } = new();
    public string? Budget { get; set; }
    public string? TimeConstraint { get; set; }
    public List<string>? Dependencies { get; set; }
    public string Language { get; set; } = "en";

    public class ActionItem
    {
        public string Title { get; set; } = "";
        public string Description { get; set; } = "";
        public string InitialPriority { get; set; } = ""; // "Critical", "High", "Medium", "Low"
        public string? Impact { get; set; }
        public int? EstimatedDays { get; set; }
    }
}

public class PrioritizeActionsResponseDto
{
    public List<PrioritizedAction> PrioritizedActions { get; set; } = new();
    public string? ImplementationStrategy { get; set; }
    public List<string> QuickWins { get; set; } = new();
    public List<string> LongTermInvestments { get; set; } = new();

    public class PrioritizedAction
    {
        public int SequenceNumber { get; set; }
        public string Title { get; set; } = "";
        public string Phase { get; set; } = ""; // "Immediate", "Short-term", "Medium-term", "Long-term"
        public List<string> Dependencies { get; set; } = new();
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// CROSS-MODULE ANALYSIS
// ═══════════════════════════════════════════════════════════════════════════

public class AnalyzeCrossModuleConsistencyDto
{
    public int? HazopStudyId { get; set; }
    public int? LopaStudyId { get; set; }
    public int? BowTieStudyId { get; set; }
    public string? AnalysisScope { get; set; }
    public string Language { get; set; } = "en";
}

public class AnalyzeCrossModuleConsistencyResponseDto
{
    public List<string> ConsistencyIssues { get; set; } = new();
    public List<string> DataGaps { get; set; } = new();
    public List<string> ConflictingFindings { get; set; } = new();
    public List<string> RecommendationGaps { get; set; } = new();
    public string? OverallAssessment { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════════
// GENERIC HELPER DTOs - REMOVED: These are defined in AiAssistDTOs.cs
// ═══════════════════════════════════════════════════════════════════════════

// Removed CompleteFieldDto - defined in AiAssistDTOs.cs
// Removed CompleteFieldResponseDto - defined in AiAssistDTOs.cs  
// Removed AiAssistHealthDto - defined in AiAssistDTOs.cs

public class BulkAiAnalysisDto
{
    public List<int> ModuleIds { get; set; } = new();
    public string ModuleType { get; set; } = ""; // "HAZOP", "LOPA", "BowTie"
    public string AnalysisType { get; set; } = ""; // "summary", "risks", "recommendations"
    public string Language { get; set; } = "en";
}

public class BulkAiAnalysisResponseDto
{
    public Dictionary<int, object> Results { get; set; } = new();
    public int SuccessCount { get; set; }
    public int FailureCount { get; set; }
}
