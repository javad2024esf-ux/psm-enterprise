// PermissionDto and RoleDto are defined in RoleDTOs.cs
// This file is intentionally left empty to avoid duplicate class definitions (CS0101)
namespace PSM.Api.DTOs;
