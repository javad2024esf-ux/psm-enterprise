namespace PSM.Api.Models;

using System.ComponentModel.DataAnnotations;

/// <summary>
/// Base entity class for all PSM domain entities.
/// Provides common audit and lifecycle properties.
/// </summary>
public abstract class PsmDomainEntity
{
    public string Id { get; set; } = null!;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public bool Deleted { get; set; }
    
    /// <summary>
    /// Concurrency control token - automatically managed by EF Core
    /// Updated on every change to prevent lost updates
    /// </summary>
    [Timestamp]
    public byte[]? RowVersion { get; set; }
}

/// <summary>
/// Asset: Physical or logical equipment/system in the process.
/// Example: Reactor Vessel A, Pump P-101, Control System
/// </summary>
public class Asset : PsmDomainEntity
{
    public string Name { get; set; } = null!;
    public string? Description { get; set; }
    public string? Category { get; set; } // Equipment, Instrumentation, Control System, etc.
    public string? Manufacturer { get; set; }
    public string? ModelNumber { get; set; }
    public string? SerialNumber { get; set; }
    public string? Unit { get; set; } // Facility unit/area
    public DateTime? InstallationDate { get; set; }
    public DateTime? LastMaintenance { get; set; }
    public string? Status { get; set; } // Active, Inactive, In-Maintenance, etc.
    public string? DesignCode { get; set; }
    public string? Criticality { get; set; } // High, Medium, Low
    public string? DrawingReference { get; set; }
    public Dictionary<string, object>? Metadata { get; set; }
}

/// <summary>
/// ProcessUnit: Operational unit combining multiple assets.
/// Example: Reactor Section, Distillation Unit, Storage Area
/// </summary>
public class ProcessUnit : PsmDomainEntity
{
    public string Name { get; set; } = null!;
    public string? Description { get; set; }
    public string? UnitType { get; set; } // Reactor, Distillation, Separation, etc.
    public string? Location { get; set; }
    public string? OperatingMode { get; set; } // Continuous, Batch, Startup, etc.
    public double? DesignTemperature { get; set; }
    public double? DesignPressure { get; set; }
    public string? PressureUnit { get; set; } // bar, psi, MPa
    public string? Status { get; set; } // Operating, Idle, Under-Maintenance
    public DateTime? StartupDate { get; set; }
    public DateTime? LastMajorRevamp { get; set; }
    public string? ResponsiblePerson { get; set; }
    public Dictionary<string, object>? Metadata { get; set; }
}

/// <summary>
/// Hazard: Potential source of harm or dangerous situation.
/// Associated with processes, equipment, or substances.
/// </summary>
public class Hazard : PsmDomainEntity
{
    public string Name { get; set; } = null!;
    public string? Description { get; set; }
    public string HazardCategory { get; set; } = null!; // Pressure, Temperature, Chemical, Mechanical, etc.
    public string? HazardSource { get; set; } // Inherent property or design-related
    public string? Severity { get; set; } // Catastrophic, Critical, Major, Minor
    public string? Probability { get; set; } // High, Medium, Low, Remote
    public string? RiskLevel { get; set; } // Calculated from severity × probability
    public string? Status { get; set; } // Identified, Assessed, Mitigated, Closed
    public string? ProcessUnitId { get; set; } // Link to process unit
    public DateTime? IdentifiedDate { get; set; }
    public string? IdentifiedBy { get; set; }
    public Dictionary<string, object>? Metadata { get; set; }
}

/// <summary>
/// Scenario: Specific incident sequence or accident scenario.
/// Describes how a hazard could lead to harm.
/// </summary>
public class Scenario : PsmDomainEntity
{
    public string Name { get; set; } = null!;
    public string? Description { get; set; }
    public string? ScenarioType { get; set; } // Loss of Containment, Overpressure, etc.
    public string? TriggeringEvent { get; set; }
    public string? Consequences { get; set; }
    public string? SequenceOfEvents { get; set; }
    public string? Severity { get; set; } // Minor, Moderate, Severe, Catastrophic
    public string? Likelihood { get; set; } // Remote, Low, Medium, High
    public string? RiskLevel { get; set; }
    public string? Status { get; set; } // Potential, Evaluated, Mitigated
    public string? HazardId { get; set; }
    public string? ProcessUnitId { get; set; }
    public DateTime? CreatedDate { get; set; }
    public Dictionary<string, object>? Metadata { get; set; }
}

/// <summary>
/// Barrier: Technical, administrative, or procedural control to prevent or mitigate scenarios.
/// Examples: Relief valve, Shutdown system, Inspection procedure
/// </summary>
public class Barrier : PsmDomainEntity
{
    public string Name { get; set; } = null!;
    public string? Description { get; set; }
    public string BarrierType { get; set; } = null!; // Prevention, Mitigation, Detection
    public string? ControlType { get; set; } // Engineering, Administrative, PPE, etc.
    public string? FunctionDescription { get; set; }
    public string? IndependenceLevel { get; set; } // Independent, Semi-Independent, Dependent
    public string? Effectiveness { get; set; } // High, Medium, Low, Unknown
    public string? Status { get; set; } // Active, Pending-Implementation, Disabled, Obsolete
    public string? Owner { get; set; }
    public DateTime? ImplementationDate { get; set; }
    public DateTime? LastVerificationDate { get; set; }
    public string? VerificationFrequency { get; set; } // Annual, Quarterly, etc.
    public string? StandardOrRequirement { get; set; } // Reference to applicable standard
    public Dictionary<string, object>? Metadata { get; set; }
}

/// <summary>
/// ActionItem: Corrective, preventive, or improvement actions tracked through lifecycle.
/// Linked from HAZOP, LOPA, RCA, MOC, Audit findings, etc.
/// </summary>
public class ActionItem : PsmDomainEntity
{
    public string Title { get; set; } = null!;
    public string? Description { get; set; }
    public string? ActionType { get; set; } // Corrective, Preventive, Improvement
    public string Priority { get; set; } = "Medium"; // High, Medium, Low
    public string Status { get; set; } = "Open"; // Open, In-Progress, Completed, Closed
    public string? Owner { get; set; }
    public DateTime DueDate { get; set; }
    public DateTime? CompletionDate { get; set; }
    public string? SourceModule { get; set; } // HAZOP, LOPA, RCA, MOC, Audit, etc.
    public string? SourceId { get; set; } // Reference to source record
    public string? Evidence { get; set; } // Document path or description
    public string? VerifiedBy { get; set; }
    public DateTime? VerificationDate { get; set; }
    public int? Priority_SIL { get; set; } // For safety-critical actions
    public Dictionary<string, object>? Metadata { get; set; }
}

/// <summary>
/// ChangeRequest: Formal request for modification following MOC procedure.
/// Can be technical, operational, or organizational changes.
/// </summary>
public class ChangeRequest : PsmDomainEntity
{
    public string Title { get; set; } = null!;
    public string? Description { get; set; }
    public string ChangeType { get; set; } = null!; // Technical, Operational, Organizational, Temporary
    public string Severity { get; set; } = "Medium"; // Critical, Major, Minor
    public string Status { get; set; } = "Proposed"; // Proposed, Reviewed, Approved, Implemented, Closed
    public string? Justification { get; set; }
    public string? ProposedBy { get; set; }
    public DateTime ProposedDate { get; set; }
    public string? ReviewedBy { get; set; }
    public DateTime? ReviewDate { get; set; }
    public string? ApprovedBy { get; set; }
    public DateTime? ApprovalDate { get; set; }
    public string? ImplementedBy { get; set; }
    public DateTime? ImplementationDate { get; set; }
    public DateTime? PlannedCompletionDate { get; set; }
    public DateTime? ActualCompletionDate { get; set; }
    public string? ImpactAssessment { get; set; }
    public string? OperationalEquivalenceStatement { get; set; }
    public string? RiskAssessment { get; set; }
    public string? PSSRRequired { get; set; } // Yes, No, Partial
    public string? PSSRId { get; set; }
    public Dictionary<string, object>? Metadata { get; set; }
}

/// <summary>
/// PsmDocument: Centralized document management with relationship tracking.
/// Supports HAZOP reports, LOPA studies, MOC documentation, etc.
/// </summary>
public class PsmDocument : PsmDomainEntity
{
    public string Title { get; set; } = null!;
    public string? Description { get; set; }
    public string DocumentType { get; set; } = null!; // Report, Procedure, Checklist, etc.
    public string? Module { get; set; } // HAZOP, LOPA, MOC, RCA, etc.
    public string? FilePath { get; set; }
    public long? FileSize { get; set; }
    public string? MimeType { get; set; }
    public string? Version { get; set; }
    public DateTime? RevisionDate { get; set; }
    public string? ApprovedBy { get; set; }
    public DateTime? ApprovalDate { get; set; }
    public string? ExpiryDate { get; set; }
    public bool IsArchived { get; set; }
    public string[]? Tags { get; set; }
    public string? AccessLevel { get; set; } // Public, Internal, Confidential
    public Dictionary<string, object>? Metadata { get; set; }
}

/// <summary>
/// Incident: Historical incident/accident for tracking and learning.
/// Links to RCA, action items, and barriers.
/// </summary>
public class Incident : PsmDomainEntity
{
    public string Title { get; set; } = null!;
    public string? Description { get; set; }
    public DateTime IncidentDate { get; set; }
    public DateTime? ReportedDate { get; set; }
    public string? ReportedBy { get; set; }
    public string IncidentType { get; set; } = null!; // Near-Miss, Lost-Time, Environmental, etc.
    public string Severity { get; set; } = "Minor"; // Minor, Serious, Major, Catastrophic
    public string? Location { get; set; }
    public string? AffectedProcessUnit { get; set; }
    public string? RootCauseAnalysisId { get; set; }
    public int? InjuriesCount { get; set; }
    public string? EnvironmentalImpact { get; set; }
    public bool ImmediateCorrectionsTaken { get; set; }
    public string? ImmediateCorrections { get; set; }
    public string? Status { get; set; } // Reported, Investigated, Closed
    public string? InvestigationLead { get; set; }
    public DateTime? InvestigationStartDate { get; set; }
    public DateTime? InvestigationCompletionDate { get; set; }
    public Dictionary<string, object>? Metadata { get; set; }
}
