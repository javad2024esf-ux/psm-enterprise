using System.Text.Json;
using System.Text.Json.Serialization;

namespace PSM.Api.Models;

/// <summary>
/// رویداد Audit کامل — یک ردیف به ازای هر عملیات با diff کامل.
/// </summary>
public class AuditEntry
{
    public long      Id           { get; set; }
    public string    EventId      { get; set; } = "";   // aud_<ts>_<guid8>  — برای ردیابی در لاگ‌ها
    public string    Action       { get; set; } = "";   // LOGIN | UPDATE_USER | APPROVE_PERMIT | ...
    public string    Severity     { get; set; } = AuditSeverity.Info;
    public string?   UserId       { get; set; }
    public string?   Username     { get; set; }
    public string?   UserFullName { get; set; }
    public string?   UserRole     { get; set; }
    public string?   IpAddress    { get; set; }
    public string?   UserAgent    { get; set; }
    public string?   Module       { get; set; }   // hazop | moc | work_permit | auth | users | ...
    public string?   RecordId     { get; set; }
    public string?   RecordTitle  { get; set; }   // خلاصه قابل خواندن رکورد
    public JsonDocument? OldValues   { get; set; } // snapshot قبل از تغییر
    public JsonDocument? NewValues   { get; set; } // snapshot بعد از تغییر
    public JsonDocument? ChangedFields { get; set; } // [{field, oldValue, newValue}, ...]
    public string?   Outcome      { get; set; }   // SUCCESS | FAILURE | DENIED
    public string?   FailureReason { get; set; }
    public JsonDocument? Metadata  { get; set; }  // اطلاعات اضافه context-specific
    public DateTime  CreatedAt    { get; set; }
}

/// <summary>
/// ثابت‌های Severity برای فیلتر و alert.
/// </summary>
public static class AuditSeverity
{
    public const string Info     = "INFO";
    public const string Warning  = "WARNING";
    public const string Critical = "CRITICAL";
}

/// <summary>
/// ثابت‌های Action — یک‌بار تعریف تا در لاگ‌ها یکدست باشد.
/// </summary>
public static class AuditAction
{
    // Auth
    public const string Login           = "LOGIN";
    public const string LoginFailed     = "LOGIN_FAILED";
    public const string Logout          = "LOGOUT";
    public const string LogoutAll       = "LOGOUT_ALL";
    public const string ChangePassword  = "CHANGE_PASSWORD";
    public const string TokenRefreshed  = "TOKEN_REFRESHED";

    // کاربران
    public const string CreateUser      = "CREATE_USER";
    public const string UpdateUser      = "UPDATE_USER";
    public const string DeleteUser      = "DELETE_USER";
    public const string UnlockUser      = "UNLOCK_USER";
    public const string RoleChanged     = "ROLE_CHANGED";
    public const string UserLocked      = "USER_LOCKED";

    // رکوردها
    public const string CreateRecord    = "CREATE_RECORD";
    public const string UpdateRecord    = "UPDATE_RECORD";
    public const string DeleteRecord    = "DELETE_RECORD";
    public const string StatusChanged   = "STATUS_CHANGED";

    // Workflow
    public const string ApprovePermit   = "APPROVE_WORK_PERMIT";
    public const string CloseHazop      = "CLOSE_HAZOP";
    public const string ReviewMoc       = "REVIEW_MOC";
    public const string ApproveMoc      = "APPROVE_MOC";
    public const string ApprovePssr     = "APPROVE_PSSR";
    public const string CloseIncident   = "CLOSE_INCIDENT";
    public const string ApproveLopa     = "APPROVE_LOPA";

    // دسترسی
    public const string AccessDenied    = "ACCESS_DENIED";
    public const string PermissionChanged = "PERMISSION_CHANGED";
}

/// <summary>
/// خروجی صفحه‌بندی‌شده برای API.
/// </summary>
public class AuditPage
{
    public IEnumerable<AuditEntry> Data    { get; set; } = [];
    public long                    Total   { get; set; }
    public int                     Limit   { get; set; }
    public int                     Offset  { get; set; }
}

// Legacy — نگه داشته شده تا کد قدیمی کامپایل شود؛ در Migration جدید migrate می‌شود
public class AuditLog
{
    public string   Id        { get; set; } = "";
    public string?  UserId    { get; set; }
    public string   Action    { get; set; } = "";
    public string?  Module    { get; set; }
    public string?  Details   { get; set; }
    public string?  IpAddress { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class RefreshToken
{
    public string   Id         { get; set; } = "";
    public string   UserId     { get; set; } = "";
    public string   Token      { get; set; } = "";
    public DateTime ExpiresAt  { get; set; }
    public DateTime CreatedAt  { get; set; }
    public bool     Revoked    { get; set; }
}
