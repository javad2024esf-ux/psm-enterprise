using System.Text.Json;

namespace PSM.Api.Models;

public class Record
{
    public string   Id          { get; set; } = "";
    public string   Collection  { get; set; } = "";
    public string?  Unit        { get; set; }
    public string?  Status      { get; set; }
    public JsonDocument? Data   { get; set; }
    public DateTime CreatedAt   { get; set; }
    public DateTime UpdatedAt   { get; set; }
    public string?  CreatedBy   { get; set; }
    public bool     Deleted     { get; set; }
    public long     TotalCount  { get; set; }
}
