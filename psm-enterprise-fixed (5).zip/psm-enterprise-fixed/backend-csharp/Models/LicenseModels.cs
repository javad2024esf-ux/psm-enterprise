using System.Text.Json;

namespace PSM.Api.Models;

/// <summary>
/// License activation record in database
/// </summary>
public class LicenseStatus
{
    public long Id { get; set; }
    public string LicenseKey { get; set; } = "";
    public string Organization { get; set; } = "";
    public string? ContactEmail { get; set; }
    public string? MachineId { get; set; }
    
    public string Status { get; set; } = "inactive"; // active, inactive, expired, revoked
    
    public DateTime? IssuedAt { get; set; }
    public DateTime? ActivatedAt { get; set; }
    public DateTime? DeactivatedAt { get; set; }
    public DateTime? ExpiresAt { get; set; }
    
    public string? LicenseType { get; set; } = "enterprise";
    public int? MaxUsers { get; set; }
    public int? CurrentUsers { get; set; }
    public int? MaxProjects { get; set; }
    public int? CurrentProjects { get; set; }
    
    public JsonDocument? Metadata { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

/// <summary>
/// License audit event for tracking activation/deactivation
/// </summary>
public class LicenseAuditEvent
{
    public long Id { get; set; }
    public string EventType { get; set; } = "";
    public string? LicenseKey { get; set; }
    public string? Organization { get; set; }
    public string? Status { get; set; }
    public string? IpAddress { get; set; }
    public string? UserAgent { get; set; }
    public DateTime Timestamp { get; set; }
    public JsonDocument? Details { get; set; }
}
