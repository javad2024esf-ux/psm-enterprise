namespace PSM.Api.Models;

public class User
{
    public string  Id                 { get; set; } = "";
    public string  Username           { get; set; } = "";
    public string  PasswordHash       { get; set; } = "";
    public string  FullName           { get; set; } = "";
    public string? Email              { get; set; }
    public string  Role               { get; set; } = "Viewer";
    public string? Department         { get; set; }
    public string? Unit               { get; set; }
    public string  Status             { get; set; } = "Active";
    public int     FailedAttempts     { get; set; }
    public DateTime? LockedUntil      { get; set; }
    public bool    MfaEnabled         { get; set; }
    public bool    MustChangePassword { get; set; }
    public DateTime CreatedAt         { get; set; }
    public DateTime? LastLogin        { get; set; }
}

public class SafeUser
{
    public string  Id                 { get; set; } = "";
    public string  Username           { get; set; } = "";
    public string  FullName           { get; set; } = "";
    public string? Email              { get; set; }
    public string  Role               { get; set; } = "";
    public string? Department         { get; set; }
    public string? Unit               { get; set; }
    public string  Status             { get; set; } = "";
    public int     FailedAttempts     { get; set; }
    public DateTime? LockedUntil      { get; set; }
    public bool    MfaEnabled         { get; set; }
    public bool    MustChangePassword { get; set; }
    public DateTime CreatedAt         { get; set; }
    public DateTime? LastLogin        { get; set; }

    public static SafeUser From(User u) => new()
    {
        Id = u.Id, Username = u.Username, FullName = u.FullName,
        Email = u.Email, Role = u.Role, Department = u.Department,
        Unit = u.Unit, Status = u.Status, FailedAttempts = u.FailedAttempts,
        LockedUntil = u.LockedUntil, MfaEnabled = u.MfaEnabled,
        MustChangePassword = u.MustChangePassword,
        CreatedAt = u.CreatedAt, LastLogin = u.LastLogin,
    };
}
