namespace PSM.Api.Models;

/// <summary>
/// Defines relationship types between PSM entities.
/// Examples: PSI -> HAZOP, HAZOP -> LOPA, LOPA -> BowTie, etc.
/// </summary>
public enum RelationshipType
{
    // PSI Relationships
    PsiToHazop,          // PSI study generates hazops
    PsiToMoc,            // PSI includes MOC implementation
    PsiToLopa,           // PSI LOPA analysis
    
    // HAZOP Relationships
    HazopToLopa,         // HAZOP findings lead to LOPA
    HazopToBowTie,       // HAZOP scenario mapped to BowTie
    HazopToActionItems,  // HAZOP recommendations become actions
    HazopToDocument,     // HAZOP report
    
    // LOPA Relationships
    LopaToBarrier,       // LOPA identifies layers of protection
    LopaToSIL,           // LOPA determines SIL requirement
    LopaToBowTie,        // LOPA results inform BowTie
    LopaToActionItems,   // SIL gap actions
    
    // BowTie Relationships
    BowTieToBarrier,     // BowTie shows barrier role
    BowTieToIncident,    // Incident validates/invalidates BowTie
    BowTieToActionItems, // Barrier improvement actions
    
    // MOC Relationships
    MocToChangeRequest,  // MOC contains change requests
    MocToPSSR,          // MOC triggers PSSR
    MocToRiskAssessment,// MOC includes risk assessment
    
    // Incident Relationships
    IncidentToBowTie,    // Incident tests barrier effectiveness
    IncidentToRCA,       // Incident triggers RCA
    IncidentToActionItems,// RCA actions from incident
    IncidentToHazard,    // Incident validates hazard
    
    // Audit Relationships
    AuditToActionItems,  // Audit findings become actions
    AuditToNonconformity,// Audit nonconformance tracking
    
    // Asset/Equipment Relationships
    AssetToHazard,       // Equipment associated with hazards
    AssetToBarrier,      // Barrier implemented on asset
    AssetToMaintenance,  // Maintenance actions on asset
    AssetToProcessUnit,  // Asset part of process unit
    
    // Process Unit Relationships
    ProcessUnitToHazard,  // Unit-specific hazards
    ProcessUnitToScenario,// Unit-specific scenarios
    ProcessUnitToBarrier, // Unit-level barriers
    
    // Document Relationships
    DocumentToModule,     // Document related to module
    DocumentToRecord,     // Document supports record
    
    // Cross-Module
    HazardToScenario,     // Hazard can lead to scenarios
    ScenarioToBarrier,    // Barriers protect against scenarios
    BarrierToHazard,      // Barrier mitigates hazard
    BarrierToAsset,       // Barrier implemented via asset
    ActionItemToHazard,   // Action item related to hazard
    ActionItemToBarrier,  // Action item improves barrier
    ChangeRequestToAsset, // Change affects equipment
    ChangeRequestToProcessUnit, // Change affects unit
    ChangeRequestToBarrier,      // Change may affect barrier
}

/// <summary>
/// PsmRelationship: Core relationship entity linking any two PSM domain entities.
/// Provides flexible, extensible relationship management.
/// </summary>
public class PsmRelationship : PsmDomainEntity
{
    /// <summary>
    /// Type of relationship (from RelationshipType enum)
    /// </summary>
    public RelationshipType RelationshipType { get; set; }

    /// <summary>
    /// Fully qualified name of source entity type
    /// Example: "PSM.Api.Models.Hazard"
    /// </summary>
    public string SourceEntityType { get; set; } = null!;

    /// <summary>
    /// ID of source entity
    /// </summary>
    public string SourceEntityId { get; set; } = null!;

    /// <summary>
    /// Fully qualified name of target entity type
    /// </summary>
    public string TargetEntityType { get; set; } = null!;

    /// <summary>
    /// ID of target entity
    /// </summary>
    public string TargetEntityId { get; set; } = null!;

    /// <summary>
    /// Direction: "OneWay" or "TwoWay"
    /// </summary>
    public string Direction { get; set; } = "OneWay";

    /// <summary>
    /// Weight/strength of relationship (0-100)
    /// Used for impact analysis and dependency tracking
    /// </summary>
    public int? Weight { get; set; }

    /// <summary>
    /// Current state of relationship
    /// Active, Dormant, Archived, Superseded
    /// </summary>
    public string Status { get; set; } = "Active";

    /// <summary>
    /// Optional context/reason for relationship
    /// </summary>
    public string? Context { get; set; }

    /// <summary>
    /// Optional notes
    /// </summary>
    public string? Notes { get; set; }

    /// <summary>
    /// Date relationship was established
    /// </summary>
    public DateTime EstablishedDate { get; set; }

    /// <summary>
    /// Date relationship is planned to end (if applicable)
    /// </summary>
    public DateTime? PlannedEndDate { get; set; }

    /// <summary>
    /// Metadata for relationship (impact analysis, lineage, etc.)
    /// </summary>
    public Dictionary<string, object>? Metadata { get; set; }
}

/// <summary>
/// RelationshipChange: Audit log for relationship lifecycle changes.
/// Tracks all modifications to relationships.
/// </summary>
public class RelationshipChange : PsmDomainEntity
{
    public string RelationshipId { get; set; } = null!;
    public string ChangeType { get; set; } = null!; // Created, Updated, Deleted, StatusChanged
    public string? FieldChanged { get; set; }
    public string? OldValue { get; set; }
    public string? NewValue { get; set; }
    public string? Reason { get; set; }
    public string? ChangedBy { get; set; }
    public DateTime ChangeTimestamp { get; set; }
    public string? ReviewedBy { get; set; }
    public DateTime? ReviewDate { get; set; }
    public string? ApprovedBy { get; set; }
    public DateTime? ApprovalDate { get; set; }
}

/// <summary>
/// EntityReference: Cross-module entity reference for relationship navigation.
/// Allows querying which entities reference a given entity.
/// </summary>
public class EntityReference : PsmDomainEntity
{
    public string ReferencingEntityType { get; set; } = null!;
    public string ReferencingEntityId { get; set; } = null!;
    public string ReferencedEntityType { get; set; } = null!;
    public string ReferencedEntityId { get; set; } = null!;
    public string? ReferenceContext { get; set; } // Where the reference is used
    public int ReferenceCount { get; set; } = 1; // How many times referenced
    public DateTime LastReferencedDate { get; set; }
}

/// <summary>
/// RelationshipLineage: Tracks the lineage/inheritance of risks and actions through relationships.
/// Used for impact analysis: if Asset fails → which Hazards → which Scenarios → which Barriers needed
/// </summary>
public class RelationshipLineage : PsmDomainEntity
{
    public string RootEntityType { get; set; } = null!;
    public string RootEntityId { get; set; } = null!;
    public string DownstreamEntityType { get; set; } = null!;
    public string DownstreamEntityId { get; set; } = null!;
    public int PathLength { get; set; } // How many hops
    public string PathDescription { get; set; } = null!; // Description of the path
    public string? CriticalityLevel { get; set; } // High, Medium, Low
    public string[]? IntermediateEntityIds { get; set; } // Entities in the path
    public DateTime CalculatedDate { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>
/// ImpactAnalysisResult: Result of analyzing impact of changes.
/// Shows what could be affected by modifying an entity.
/// </summary>
public class ImpactAnalysisResult
{
    public string EntityId { get; set; } = null!;
    public string EntityType { get; set; } = null!;
    public List<ImpactedItem> DirectlyImpacted { get; set; } = [];
    public List<ImpactedItem> IndirectlyImpacted { get; set; } = [];
    public int TotalImpactedRecords { get; set; }
    public string OverallRiskLevel { get; set; } = "Low"; // Low, Medium, High, Critical
    public string? Recommendation { get; set; }
    public DateTime AnalysisDate { get; set; }
}

/// <summary>
/// ImpactedItem: Single item affected by change.
/// </summary>
public class ImpactedItem
{
    public string EntityId { get; set; } = null!;
    public string EntityType { get; set; } = null!;
    public RelationshipType RelationshipType { get; set; }
    public int HopsFromRoot { get; set; }
    public string? ImpactDescription { get; set; }
    public string? RiskLevel { get; set; }
    public string? RecommendedAction { get; set; }
}

/// <summary>
/// CrossModuleIntegrationMap: Predefined integration patterns between modules.
/// Used to automatically suggest relationships.
/// </summary>
public class CrossModuleIntegrationMap
{
    public string Id { get; set; } = null!;
    public string SourceModule { get; set; } = null!; // HAZOP, LOPA, MOC, etc.
    public string TargetModule { get; set; } = null!;
    public string MappingRule { get; set; } = null!; // Rule for automatic linking
    public string? TransformationLogic { get; set; } // How data flows between modules
    public bool IsAutomatic { get; set; } // Whether mapping is auto-applied
    public int ExecutionOrder { get; set; }
    public DateTime CreatedDate { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>
/// RelationshipCache: Performance-optimized relationship cache.
/// Stores pre-computed relationship paths and counts.
/// </summary>
public class RelationshipCache
{
    public string EntityId { get; set; } = null!;
    public string EntityType { get; set; } = null!;
    public int InboundRelationshipCount { get; set; }
    public int OutboundRelationshipCount { get; set; }
    public int TotalDependentRecords { get; set; }
    public DateTime LastUpdated { get; set; }
    public DateTime? CacheExpiresAt { get; set; }
}
