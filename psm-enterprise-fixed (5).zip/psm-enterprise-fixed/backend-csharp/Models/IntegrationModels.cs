namespace PSM.Api.Models;

/// <summary>
/// Integration statistics for monitoring system health
/// </summary>
public class IntegrationStats
{
    public int TotalRules { get; set; }
    public int ActiveRules { get; set; }
    public int PendingEvents { get; set; }
    public int ProcessingEvents { get; set; }
    public int ProcessedEvents { get; set; }
    public int FailedEvents { get; set; }
    public double SuccessRate { get; set; }
    public Dictionary<string, int> EventsBySource { get; set; } = new();
    public Dictionary<string, int> ActionsByType { get; set; } = new();
    public DateTime LastUpdatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// Convert to DTO for API responses
    /// </summary>
    public DTOs.IntegrationStatsDto ToDto() => new()
    {
        TotalRules = TotalRules,
        ActiveRules = ActiveRules,
        PendingEvents = PendingEvents,
        ProcessingEvents = ProcessingEvents,
        CompletedEvents = ProcessedEvents,
        FailedEvents = FailedEvents,
        SuccessfulExecutions = (int)((TotalRules * SuccessRate) / 100),
        FailedExecutions = (int)(TotalRules * (100 - SuccessRate) / 100),
        AverageExecutionTimeMs = 0.0, // Would need to calculate from actual executions
        LastActivityAt = LastUpdatedAt,
    };
}

/// <summary>
/// Integration rule record
/// </summary>
public class IntegrationRule
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public string SourceModule { get; set; } = "";
    public string TriggerEvent { get; set; } = "";
    public string TargetModule { get; set; } = "";
    public string ActionType { get; set; } = "";
    public bool IsActive { get; set; } = true;
    public int Priority { get; set; } = 10;
    public string? CreatedBy { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}

/// <summary>
/// Integration event record
/// </summary>
public class IntegrationEvent
{
    public string Id { get; set; } = "";
    public string EventType { get; set; } = "";
    public string SourceModule { get; set; } = "";
    public string SourceId { get; set; } = "";
    public string Status { get; set; } = "pending";
    public string? TriggeredBy { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? ProcessedAt { get; set; }
    public string? ErrorMessage { get; set; }
    public int RetryCount { get; set; } = 0;
}

/// <summary>
/// Integration execution record
/// </summary>
public class IntegrationExecution
{
    public string Id { get; set; } = "";
    public string EventId { get; set; } = "";
    public string RuleId { get; set; } = "";
    public string Status { get; set; } = "pending";
    public string? Result { get; set; }
    public string? ErrorMessage { get; set; }
    public int? DurationMs { get; set; }
    public DateTime ExecutedAt { get; set; }
}
