using System.Security.Claims;

namespace PSM.Api.Middleware;

public static class CurrentUserExtensions
{
    public static string? GetUserId(this ClaimsPrincipal user) =>
        user.FindFirstValue(ClaimTypes.NameIdentifier);

    public static string? GetUsername(this ClaimsPrincipal user) =>
        user.FindFirstValue(ClaimTypes.Name);

    public static string GetRole(this ClaimsPrincipal user) =>
        user.FindFirstValue(ClaimTypes.Role) ?? "";

    public static string? GetUnit(this ClaimsPrincipal user) =>
        user.FindFirstValue("unit");

    public static string GetFullName(this ClaimsPrincipal user) =>
        user.FindFirstValue("fullName") ?? "";
}
