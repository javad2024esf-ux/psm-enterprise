using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace PSM.Api.Middleware;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class RateLimitAttribute : TypeFilterAttribute
{
    public RateLimitAttribute(string policyName) 
        : base(typeof(RateLimitFilter))
    {
        Arguments = new object[] { policyName };
    }
}

public class RateLimitFilter : IAsyncActionFilter
{
    private readonly string _policyName;
    private readonly ILogger<RateLimitFilter> _logger;

    public RateLimitFilter(string policyName, ILogger<RateLimitFilter> logger)
    {
        _policyName = policyName;
        _logger = logger;
    }

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        context.HttpContext.Features.Get<IRateLimitMetadata>()?.AddPolicy(_policyName);
        await next();
    }
}

public interface IRateLimitMetadata
{
    void AddPolicy(string policyName);
    IEnumerable<string> GetPolicies();
}

public class RateLimitMetadata : IRateLimitMetadata
{
    private readonly List<string> _policies = new();

    public void AddPolicy(string policyName) => _policies.Add(policyName);

    public IEnumerable<string> GetPolicies() => _policies.AsReadOnly();
}
