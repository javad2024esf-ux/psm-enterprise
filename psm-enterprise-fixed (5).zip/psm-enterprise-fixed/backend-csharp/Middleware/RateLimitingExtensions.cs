using Microsoft.AspNetCore.RateLimiting;
using System.Threading.RateLimiting;

namespace PSM.Api.Middleware;

/// <summary>
/// Rate limiting configuration for PSM Enterprise API
/// Uses token bucket algorithm with per-user and global limits
/// </summary>
public static class RateLimitingExtensions
{
    /// <summary>
    /// تنظیم محدودیت میزان درخواست برای API PSM
    /// </summary>
    public static void AddPsmRateLimiting(this IServiceCollection services)
    {
        services.AddRateLimiter(options =>
        {
            // ── Global rate limiter (all users combined) ────────────────────────
            // 1000 requests per minute globally
            options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(context =>
            {
                return RateLimitPartition.GetTokenBucketLimiter("global", _ =>
                    new TokenBucketRateLimiterOptions
                    {
                        TokenLimit = 1000,
                        QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                        QueueLimit = 100,
                        ReplenishmentPeriod = TimeSpan.FromSeconds(60),
                        TokensPerPeriod = 1000,
                    });
            });

            // ── Per-user rate limiter ────────────────────────────────────────────
            // 100 requests per minute per authenticated user
            options.AddPolicy("auth-user", context =>
            {
                var userId = context.User?.FindFirst("sub")?.Value 
                          ?? context.User?.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

                if (!string.IsNullOrEmpty(userId))
                {
                    return RateLimitPartition.GetTokenBucketLimiter(
                        $"auth-user-{userId}",
                        _ => new TokenBucketRateLimiterOptions
                        {
                            TokenLimit = 100,
                            QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                            QueueLimit = 50,
                            ReplenishmentPeriod = TimeSpan.FromSeconds(60),
                            TokensPerPeriod = 100,
                        }
                    );
                }

                return RateLimitPartition.GetNoLimiter("no-auth");
            });

            // ── Per-IP rate limiter (anonymous users) ───────────────────────────
            // 30 requests per minute per IP (for login attempts, public endpoints)
            options.AddPolicy("ip-based", context =>
            {
                var ipAddress = context.Connection.RemoteIpAddress?.ToString() ?? "unknown";
                return RateLimitPartition.GetTokenBucketLimiter(
                    $"ip-{ipAddress}",
                    _ => new TokenBucketRateLimiterOptions
                    {
                        TokenLimit = 30,
                        QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                        QueueLimit = 10,
                        ReplenishmentPeriod = TimeSpan.FromSeconds(60),
                        TokensPerPeriod = 30,
                    }
                );
            });

            // ── Strict policy for login/sensitive endpoints ──────────────────────
            // 5 requests per minute per IP (brute force protection)
            options.AddPolicy("login-strict", context =>
            {
                var ipAddress = context.Connection.RemoteIpAddress?.ToString() ?? "unknown";
                return RateLimitPartition.GetTokenBucketLimiter(
                    $"login-{ipAddress}",
                    _ => new TokenBucketRateLimiterOptions
                    {
                        TokenLimit = 5,
                        QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                        QueueLimit = 0,
                        ReplenishmentPeriod = TimeSpan.FromSeconds(60),
                        TokensPerPeriod = 5,
                    }
                );
            });

            // ── Heavy operation limiter (file uploads, AI requests) ──────────────
            // 10 requests per minute per user
            options.AddPolicy("heavy-operation", context =>
            {
                var userId = context.User?.FindFirst("sub")?.Value 
                          ?? context.User?.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

                if (!string.IsNullOrEmpty(userId))
                {
                    return RateLimitPartition.GetTokenBucketLimiter(
                        $"heavy-{userId}",
                        _ => new TokenBucketRateLimiterOptions
                        {
                            TokenLimit = 10,
                            QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                            QueueLimit = 5,
                            ReplenishmentPeriod = TimeSpan.FromSeconds(60),
                            TokensPerPeriod = 10,
                        }
                    );
                }

                var ipAddress = context.Connection.RemoteIpAddress?.ToString() ?? "unknown";
                return RateLimitPartition.GetTokenBucketLimiter(
                    $"heavy-ip-{ipAddress}",
                    _ => new TokenBucketRateLimiterOptions
                    {
                        TokenLimit = 3,
                        QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                        QueueLimit = 0,
                        ReplenishmentPeriod = TimeSpan.FromSeconds(60),
                        TokensPerPeriod = 3,
                    }
                );
            });

            // ── Customize error response ────────────────────────────────────────
            options.OnRejected = async (context, cancellationToken) =>
            {
                context.HttpContext.Response.StatusCode = StatusCodes.Status429TooManyRequests;
                context.HttpContext.Response.ContentType = "application/json";

                var response = new
                {
                    error = "درخواست‌های بیش از حد",
                    message = "تعداد درخواست‌های شما از حد مجاز بیشتر است. لطفاً بعداً دوباره تلاش کنید.",
                    retryAfter = 60
                };

                await context.HttpContext.Response.WriteAsJsonAsync(response, cancellationToken);
            };
        });
    }
}
