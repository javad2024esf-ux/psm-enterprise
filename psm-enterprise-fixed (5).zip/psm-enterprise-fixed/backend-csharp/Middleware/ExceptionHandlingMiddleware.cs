using Microsoft.AspNetCore.Http;
using Serilog;
using System;
using System.Threading.Tasks;

namespace PSM.Api.Middleware;

/// <summary>
/// Global Exception Handler Middleware
/// Prevents sensitive exception details from leaking to clients.
/// Logs exceptions securely server-side.
/// </summary>
public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly Serilog.ILogger _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, Serilog.ILogger logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            _logger.Error(ex, "Unhandled exception in request pipeline. Path: {Path}, Method: {Method}",
                context.Request.Path, context.Request.Method);

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = StatusCodes.Status500InternalServerError;

            // Return generic error to client - never expose implementation details
            var response = new
            {
                success = false,
                error = "An internal error occurred. Please contact support.",
                requestId = context.TraceIdentifier
            };

            await context.Response.WriteAsJsonAsync(response);
        }
    }
}
