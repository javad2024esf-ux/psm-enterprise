namespace PSM.Api.Middleware;

public static class RateLimitPolicies
{
    public const string Auth = "ip-based";
    public const string AuthUser = "auth-user";
    public const string HeavyOperation = "heavy-operation";
    public const string LoginStrict = "login-strict";
    public const string IpBased = "ip-based";
}
