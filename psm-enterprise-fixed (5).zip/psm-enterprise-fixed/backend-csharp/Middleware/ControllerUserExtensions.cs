using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;

namespace PSM.Api.Middleware;

public static class ControllerUserExtensions
{
    /// <summary>
    /// Get current user ID from controller claims
    /// </summary>
    public static string GetCurrentUser(this ControllerBase controller) =>
        controller.User?.FindFirstValue(ClaimTypes.NameIdentifier) ?? "Unknown";

    /// <summary>
    /// Get current user name from controller claims
    /// </summary>
    public static string GetCurrentUsername(this ControllerBase controller) =>
        controller.User?.FindFirstValue(ClaimTypes.Name) ?? "Unknown";

    /// <summary>
    /// Get current user role from controller claims
    /// </summary>
    public static string GetCurrentUserRole(this ControllerBase controller) =>
        controller.User?.FindFirstValue(ClaimTypes.Role) ?? "";
}
