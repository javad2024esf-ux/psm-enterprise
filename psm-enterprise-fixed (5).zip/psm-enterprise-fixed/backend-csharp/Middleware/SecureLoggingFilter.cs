using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace PSM.Api.Middleware;

/// <summary>
/// Secure logging filter for sensitive data.
/// Prevents passwords, tokens, API keys, and other sensitive data from being logged.
/// </summary>
public static class SecureLoggingFilter
{
    private static readonly string[] SENSITIVE_PATTERNS = new[]
    {
        "password",
        "passwd",
        "pwd",
        "secret",
        "token",
        "api_key",
        "apikey",
        "authorization",
        "bearer",
        "jwt",
        "refresh_token",
        "csrf",
        "xsrf",
        "private_key",
        "privatekey",
        "ssn",
        "social_security",
        "credit_card",
        "creditcard",
        "cvv",
        "card_number"
    };

    /// <summary>
    /// Sanitizes log messages to remove sensitive data.
    /// </summary>
    public static string SanitizeLogMessage(string message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return message;

        var result = message;

        // Remove JSON values for sensitive keys
        foreach (var pattern in SENSITIVE_PATTERNS)
        {
            // Match JSON: "key": "value" or "key":"value"
            result = Regex.Replace(result, 
                $@"""{pattern}""?\s*:\s*""[^""]*""", 
                $"\"{pattern}\": \"***REDACTED***\"",
                RegexOptions.IgnoreCase);

            // Match query parameters: key=value
            result = Regex.Replace(result,
                $@"{pattern}=[^&\s]*",
                $"{pattern}=***REDACTED***",
                RegexOptions.IgnoreCase);

            // Match headers: Authorization: Bearer ...
            result = Regex.Replace(result,
                $@"{pattern}:\s*[^\s,]+",
                $"{pattern}: ***REDACTED***",
                RegexOptions.IgnoreCase);
        }

        return result;
    }

    /// <summary>
    /// Sanitizes dictionary for logging.
    /// </summary>
    public static Dictionary<string, object?> SanitizeDictionary(Dictionary<string, object?> data)
    {
        if (data == null)
            return data;

        var sanitized = new Dictionary<string, object?>(data);

        foreach (var key in data.Keys.ToList())
        {
            if (IsSensitiveKey(key))
            {
                sanitized[key] = "***REDACTED***";
            }
        }

        return sanitized;
    }

    /// <summary>
    /// Checks if a key name indicates sensitive data.
    /// </summary>
    private static bool IsSensitiveKey(string key)
    {
        return SENSITIVE_PATTERNS.Any(p => 
            key.Contains(p, StringComparison.OrdinalIgnoreCase));
    }
}
