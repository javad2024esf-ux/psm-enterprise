using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace PSM.Api.Middleware;

/// <summary>
/// CSRF Token Protection Middleware
/// Implements double-submit cookie pattern for CSRF prevention.
/// </summary>
public class CsrfTokenMiddleware
{
    private readonly RequestDelegate _next;
    private const string CSRF_TOKEN_HEADER = "X-CSRF-Token";
    private const string CSRF_TOKEN_COOKIE = "XSRF-TOKEN";

    public CsrfTokenMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // Generate and set CSRF token if not present
        if (!context.Request.Cookies.ContainsKey(CSRF_TOKEN_COOKIE))
        {
            var token = GenerateToken();
            context.Response.Cookies.Append(
                CSRF_TOKEN_COOKIE,
                token,
                new CookieOptions
                {
                    HttpOnly = false, // Must be accessible to JavaScript
                    Secure = true,    // HTTPS only
                    SameSite = SameSiteMode.Strict,
                    MaxAge = TimeSpan.FromHours(24)
                });
        }

        // Validate CSRF token on state-changing requests
        if (IsStateChangingRequest(context.Request.Method))
        {
            var tokenFromCookie = context.Request.Cookies[CSRF_TOKEN_COOKIE];
            var tokenFromHeader = context.Request.Headers[CSRF_TOKEN_HEADER].ToString();

            if (string.IsNullOrEmpty(tokenFromCookie) || 
                string.IsNullOrEmpty(tokenFromHeader) || 
                tokenFromCookie != tokenFromHeader)
            {
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                await context.Response.WriteAsJsonAsync(new { 
                    success = false, 
                    error = "CSRF token validation failed" 
                });
                return;
            }
        }

        await _next(context);
    }

    private static bool IsStateChangingRequest(string method)
    {
        return method switch
        {
            "POST" or "PUT" or "PATCH" or "DELETE" => true,
            _ => false
        };
    }

    private static string GenerateToken()
    {
        using var rng = RandomNumberGenerator.Create();
        var tokenData = new byte[32];
        rng.GetBytes(tokenData);
        return Convert.ToBase64String(tokenData);
    }
}
