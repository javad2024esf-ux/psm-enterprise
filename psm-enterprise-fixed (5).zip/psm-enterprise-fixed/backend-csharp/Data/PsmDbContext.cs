// ⚠️ DEPRECATED: Legacy Entity Framework Core code - NOT USED
// This file is kept for reference but is NOT compiled into the application.
// The application has fully migrated to Dapper ORM for all database operations.
// All data access is handled via Dapper repositories in /Repositories/

using PSM.Api.Models;

namespace PSM.Api.Data;

/// <summary>
/// DEPRECATED - Legacy EF Core DbContext (Not Used)
/// 
/// This class exists only for reference purposes and is not instantiated.
/// All database operations now use Dapper ORM through the repository pattern.
/// 
/// Database access layers:
/// - PSM.Api.Repositories.* - Dapper-based data access
/// - PSM.Api.Data.DbHelper - Direct SQL execution with Dapper
/// - PSM.Api.Migrations.Runner - SQL-based migrations
/// </summary>
public class PsmDbContext
{
    [Obsolete("Use Dapper repositories instead. See PSM.Api.Repositories.*", true)]
    public PsmDbContext()
    {
        throw new NotSupportedException(
            "PsmDbContext is deprecated. This application uses Dapper ORM. " +
            "Access data through repository interfaces in PSM.Api.Repositories namespace.");
    }
}
