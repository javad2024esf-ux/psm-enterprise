using System.Data;
using Npgsql;

namespace PSM.Api.Data;

public interface IDbConnectionFactory
{
    NpgsqlConnection CreateConnection();
    Task<NpgsqlConnection> CreateOpenConnectionAsync();
}
