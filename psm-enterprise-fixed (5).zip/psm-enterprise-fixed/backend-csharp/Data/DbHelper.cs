using Dapper;
using Npgsql;
using System.Data;

namespace PSM.Api.Data;

public interface IDbHelper
{
    Task<IEnumerable<T>> QueryAsync<T>(string sql, object? param = null);
    Task<T?> QueryFirstOrDefaultAsync<T>(string sql, object? param = null);
    Task<int> ExecuteAsync(string sql, object? param = null);
    Task<T?> ExecuteScalarAsync<T>(string sql, object? param = null);
    Task WithTransactionAsync(Func<IDbConnection, IDbTransaction, Task> fn);
    string GetConnectionString();
    NpgsqlConnection GetConnection();
}

public class DbHelper : IDbHelper
{
    private readonly IDbConnectionFactory _factory;

    public DbHelper(IDbConnectionFactory factory)
    {
        _factory = factory;
    }

    public string GetConnectionString()
    {
        using var conn = _factory.CreateConnection();
        return conn.ConnectionString;
    }

    public NpgsqlConnection GetConnection()
    {
        return _factory.CreateConnection();
    }

    public async Task<IEnumerable<T>> QueryAsync<T>(string sql, object? param = null)
    {
        using var conn = _factory.CreateConnection();
        return await conn.QueryAsync<T>(sql, param);
    }

    public async Task<T?> QueryFirstOrDefaultAsync<T>(string sql, object? param = null)
    {
        using var conn = _factory.CreateConnection();
        return await conn.QueryFirstOrDefaultAsync<T>(sql, param);
    }

    public async Task<int> ExecuteAsync(string sql, object? param = null)
    {
        using var conn = _factory.CreateConnection();
        return await conn.ExecuteAsync(sql, param);
    }

    public async Task<T?> ExecuteScalarAsync<T>(string sql, object? param = null)
    {
        using var conn = _factory.CreateConnection();
        return await conn.ExecuteScalarAsync<T>(sql, param);
    }

    public async Task WithTransactionAsync(Func<IDbConnection, IDbTransaction, Task> fn)
    {
        using var conn = await _factory.CreateOpenConnectionAsync();
        using var tx   = conn.BeginTransaction();
        try
        {
            await fn(conn, tx);
            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }
}
