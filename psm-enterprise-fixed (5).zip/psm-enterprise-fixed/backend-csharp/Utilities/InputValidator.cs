using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace PSM.Api.Utilities;

/// <summary>
/// Input validation and sanitization utilities for OWASP Top 10 prevention.
/// Implements strict input validation for SQL injection, XSS, and injection attack prevention.
/// </summary>
public static class InputValidator
{
    // Whitelist for collection names - prevents SQL injection via collection parameter
    private static readonly HashSet<string> ALLOWED_COLLECTIONS = new(StringComparer.OrdinalIgnoreCase)
    {
        // PSM Module Collections
        "hazop", "rca", "competency", "training", "contractor", "psi", "mechanical_integrity",
        "emergency", "participation", "culture", "stakeholder", "standard", "metric",
        "management_review", "incident", "barrier", "hazop_chain", "lopa", "bowtie",
        "workflow", "document", "action_register", "permit", "integration", "license",
        "change_management", "audit_log", "notification", "record", "user", "role",
        "dashboard", "kpi"
    };

    // Allowed status values
    private static readonly HashSet<string> ALLOWED_STATUSES = new(StringComparer.OrdinalIgnoreCase)
    {
        "draft", "pending", "approved", "rejected", "in_progress", "completed",
        "open", "closed", "active", "inactive", "archived"
    };

    /// <summary>
    /// Validates and sanitizes collection names to prevent SQL injection.
    /// Only allows whitelisted collection names.
    /// </summary>
    public static bool IsValidCollection(string? collection)
    {
        if (string.IsNullOrWhiteSpace(collection))
            return false;

        // Only allow alphanumeric and underscore
        if (!Regex.IsMatch(collection, @"^[a-zA-Z0-9_]+$"))
            return false;

        // Check whitelist
        return ALLOWED_COLLECTIONS.Contains(collection);
    }

    /// <summary>
    /// Validates status values against whitelist.
    /// </summary>
    public static bool IsValidStatus(string? status)
    {
        if (string.IsNullOrWhiteSpace(status))
            return true; // Status is optional

        return ALLOWED_STATUSES.Contains(status);
    }

    /// <summary>
    /// Validates unit identifiers to prevent injection attacks.
    /// </summary>
    public static bool IsValidUnit(string? unit)
    {
        if (string.IsNullOrWhiteSpace(unit))
            return true; // Unit is optional

        // Allow alphanumeric, hyphens, underscores, max 50 chars
        return unit.Length <= 50 && Regex.IsMatch(unit, @"^[a-zA-Z0-9\-_]+$");
    }

    /// <summary>
    /// Validates IDs to prevent injection attacks.
    /// </summary>
    public static bool IsValidId(string? id)
    {
        if (string.IsNullOrWhiteSpace(id))
            return false;

        // Allow alphanumeric, hyphens, underscores, max 255 chars
        return id.Length <= 255 && Regex.IsMatch(id, @"^[a-zA-Z0-9\-_]+$");
    }

    /// <summary>
    /// Validates search queries to prevent injection and limit resource usage.
    /// </summary>
    public static bool IsValidSearchQuery(string? query, int maxLength = 500)
    {
        if (string.IsNullOrWhiteSpace(query))
            return false;

        // Prevent excessively long queries that could cause DoS
        if (query.Length > maxLength)
            return false;

        // Reject queries with SQL keywords to prevent injection
        var sqlKeywords = new[] { "DROP", "DELETE", "INSERT", "UPDATE", "EXEC", "EXECUTE", "SCRIPT" };
        if (sqlKeywords.Any(kw => query.Contains(kw, StringComparison.OrdinalIgnoreCase)))
            return false;

        return true;
    }

    /// <summary>
    /// Sanitizes text input to prevent XSS attacks.
    /// Removes potentially dangerous HTML/JavaScript.
    /// </summary>
    public static string SanitizeInput(string? input, int maxLength = 5000)
    {
        if (string.IsNullOrWhiteSpace(input))
            return string.Empty;

        input = input.Trim();

        // Limit length to prevent DoS
        if (input.Length > maxLength)
            input = input[..maxLength];

        // Remove null bytes
        input = input.Replace("\0", "");

        // Remove control characters except common whitespace
        input = Regex.Replace(input, @"[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]", "");

        return input;
    }

    /// <summary>
    /// HTML-encodes output to prevent XSS when displaying user input.
    /// </summary>
    public static string HtmlEncode(string? text)
    {
        if (string.IsNullOrEmpty(text))
            return string.Empty;

        return System.Net.WebUtility.HtmlEncode(text);
    }

    /// <summary>
    /// Validates pagination parameters to prevent abuse.
    /// </summary>
    public static (int limit, int offset) ValidatePagination(int limit, int offset)
    {
        // Maximum 2000 records per request
        const int maxLimit = 2000;
        const int minLimit = 1;
        const int maxOffset = int.MaxValue;

        limit = Math.Max(minLimit, Math.Min(limit, maxLimit));
        offset = Math.Max(0, Math.Min(offset, maxOffset));

        return (limit, offset);
    }

    /// <summary>
    /// Validates email format.
    /// </summary>
    public static bool IsValidEmail(string? email)
    {
        if (string.IsNullOrWhiteSpace(email))
            return false;

        try
        {
            var addr = new System.Net.Mail.MailAddress(email);
            return addr.Address == email;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Validates password strength.
    /// </summary>
    public static (bool isValid, string message) ValidatePassword(string? password)
    {
        if (string.IsNullOrWhiteSpace(password))
            return (false, "Password cannot be empty");

        if (password.Length < 12)
            return (false, "Password must be at least 12 characters");

        if (!Regex.IsMatch(password, @"[A-Z]"))
            return (false, "Password must contain uppercase letters");

        if (!Regex.IsMatch(password, @"[a-z]"))
            return (false, "Password must contain lowercase letters");

        if (!Regex.IsMatch(password, @"[0-9]"))
            return (false, "Password must contain numbers");

        if (!Regex.IsMatch(password, @"[!@#$%^&*\-_]"))
            return (false, "Password must contain special characters");

        return (true, "");
    }
}
