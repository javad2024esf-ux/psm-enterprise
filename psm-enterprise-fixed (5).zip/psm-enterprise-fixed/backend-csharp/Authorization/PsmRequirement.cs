using Microsoft.AspNetCore.Authorization;
using PSM.Api.Middleware;
using PSM.Api.Repositories;

namespace PSM.Api.Authorization;

/// <summary>
/// Requirement حاوی ماژول PSM و نوع دسترسی مورد نیاز.
/// </summary>
public sealed class PsmRequirement : IAuthorizationRequirement
{
    public string Module { get; }
    public PsmAction Action { get; }

    public PsmRequirement(string module, PsmAction action)
    {
        Module = module;
        Action = action;
    }
}

/// <summary>
/// Handler: role کاربر را از Claim می‌خواند، سپس در role_permissions چک می‌کند.
/// </summary>
public sealed class PsmRequirementHandler : AuthorizationHandler<PsmRequirement>
{
    private readonly IRoleRepository _roles;

    public PsmRequirementHandler(IRoleRepository roles) => _roles = roles;

    protected override async Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        PsmRequirement requirement)
    {
        var role = context.User.GetRole();
        if (string.IsNullOrEmpty(role))
        {
            context.Fail();
            return;
        }

        var granted = await _roles.HasPermissionAsync(role, requirement.Module, requirement.Action);
        if (granted)
            context.Succeed(requirement);
        else
            context.Fail();
    }
}

/// <summary>
/// نوع دسترسی — مطابق ستون‌های جدول role_permissions.
/// </summary>
public enum PsmAction { Read, Write, Approve, Delete }
