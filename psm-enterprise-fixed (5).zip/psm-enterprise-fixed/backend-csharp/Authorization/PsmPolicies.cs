namespace PSM.Api.Authorization;

/// <summary>
/// ثابت‌های نام Policy — یک‌بار تعریف، همه‌جا استفاده.
/// </summary>
public static class PsmPolicies
{
    // ── کار مجوز کار (Permits) ────────────────────────────────────────────────
    public const string CanReadPermits     = "CanReadPermits";
    public const string CanWritePermits    = "CanWritePermits";
    public const string CanApprovePermit   = "CanApprovePermit";
    public const string CanDeletePermit    = "CanDeletePermit";

    // ── HAZOP ─────────────────────────────────────────────────────────────────
    public const string CanReadHazop       = "CanReadHazop";
    public const string CanWriteHazop      = "CanWriteHazop";
    public const string CanDeleteHazop     = "CanDeleteHazop";
    public const string CanCloseHazop      = "CanCloseHazop";

    // ── LOPA ──────────────────────────────────────────────────────────────────
    public const string CanReadLopa        = "CanReadLopa";
    public const string CanWriteLopa       = "CanWriteLopa";
    public const string CanDeleteLopa      = "CanDeleteLopa";
    public const string CanApproveLopa     = "CanApproveLopa";

    // ── BowTie ────────────────────────────────────────────────────────────────
    public const string CanReadBowTie      = "CanReadBowTie";
    public const string CanWriteBowTie     = "CanWriteBowTie";

    // ── Documents ─────────────────────────────────────────────────────────────
    public const string CanReadDocuments   = "CanReadDocuments";
    public const string CanWriteDocuments  = "CanWriteDocuments";

    // ── Integration ───────────────────────────────────────────────────────────
    public const string CanReadIntegration  = "CanReadIntegration";
    public const string CanWriteIntegration = "CanWriteIntegration";
    public const string CanDeleteIntegration= "CanDeleteIntegration";

    // ── Action Register ───────────────────────────────────────────────────────
    public const string CanReadActions     = "CanReadActions";
    public const string CanWriteActions    = "CanWriteActions";
    public const string CanDeleteActions   = "CanDeleteActions";

    // ── Workflow ──────────────────────────────────────────────────────────────
    public const string CanReadWorkflow    = "CanReadWorkflow";
    public const string CanWriteWorkflow   = "CanWriteWorkflow";
    public const string CanAdminWorkflow   = "CanAdminWorkflow";

    // ── MOC (مدیریت تغییر) ────────────────────────────────────────────────────
    public const string CanReviewMOC       = "CanReviewMOC";
    public const string CanApproveMOC      = "CanApproveMOC";

    // ── Change Management (ChangeManagementController) ────────────────────────
    public const string CanCreateChange    = "CanCreateChange";
    public const string CanAdvanceWorkflow = "CanAdvanceWorkflow";
    public const string CanRejectWorkflow  = "CanRejectWorkflow";
    public const string CanAssignTraining  = "CanAssignTraining";
    public const string CanVerifyPSSR      = "CanVerifyPSSR";
    public const string CanApproveStartup  = "CanApproveStartup";
    public const string CanRejectStartup   = "CanRejectStartup";

    // ── PSSR ──────────────────────────────────────────────────────────────────
    public const string CanApprovePSSR     = "CanApprovePSSR";

    // ── حوادث ─────────────────────────────────────────────────────────────────
    public const string CanCloseIncident   = "CanCloseIncident";

    // ── مدیریت کاربران ────────────────────────────────────────────────────────
    public const string CanManageUsers     = "CanManageUsers";
    public const string CanDeleteUsers     = "CanDeleteUsers";

    // ── پلتفرم هوش مصنوعی ────────────────────────────────────────────────────
    public const string CanUseAI           = "CanUseAI";
    public const string CanAdminAI         = "CanAdminAI";
    public const string CanUseBowTieModule = "CanUseBowTieModule";
    public const string CanUseHazopModule  = "CanUseHazopModule";
    public const string CanUseLopaModule   = "CanUseLopaModule";

    // ── Audit ─────────────────────────────────────────────────────────────────
    public const string CanReadAudit       = "CanReadAudit";
    public const string CanReadAuditFull   = "CanReadAuditFull";

    // ── ماژول‌های عمومی (ModulesControllers) ──────────────────────────────────
    public const string CanReadHira               = "CanReadHira";
    public const string CanWriteHira              = "CanWriteHira";
    public const string CanReadRca                = "CanReadRca";
    public const string CanWriteRca               = "CanWriteRca";
    public const string CanReadCompetency         = "CanReadCompetency";
    public const string CanWriteCompetency        = "CanWriteCompetency";
    public const string CanReadTraining           = "CanReadTraining";
    public const string CanWriteTraining          = "CanWriteTraining";
    public const string CanReadContractors        = "CanReadContractors";
    public const string CanWriteContractors       = "CanWriteContractors";
    public const string CanReadPsi                = "CanReadPsi";
    public const string CanWritePsi               = "CanWritePsi";
    public const string CanReadMechanicalIntegrity= "CanReadMechanicalIntegrity";
    public const string CanWriteMechanicalIntegrity="CanWriteMechanicalIntegrity";
    public const string CanReadEmergency          = "CanReadEmergency";
    public const string CanWriteEmergency         = "CanWriteEmergency";
    public const string CanReadParticipation      = "CanReadParticipation";
    public const string CanWriteParticipation     = "CanWriteParticipation";
    public const string CanReadCulture            = "CanReadCulture";
    public const string CanWriteCulture           = "CanWriteCulture";
    public const string CanReadStakeholders       = "CanReadStakeholders";
    public const string CanWriteStakeholders      = "CanWriteStakeholders";
    public const string CanReadStandards          = "CanReadStandards";
    public const string CanWriteStandards         = "CanWriteStandards";
    public const string CanReadMetrics            = "CanReadMetrics";
    public const string CanWriteMetrics           = "CanWriteMetrics";
    public const string CanReadManagementReview   = "CanReadManagementReview";
    public const string CanWriteManagementReview  = "CanWriteManagementReview";

    public const string CanReadIncidents   = "CanReadIncidents";
    public const string CanWriteIncidents  = "CanWriteIncidents";

    // ── Barriers (یکپارچه‌سازی HAZOP/LOPA/BowTie) ────────────────────────────
    public const string CanReadBarriers          = "CanReadBarriers";
    public const string CanWriteBarriers         = "CanWriteBarriers";
    public const string CanApproveBarrierStatus  = "CanApproveBarrierStatus";
    public const string CanDeleteBarriers        = "CanDeleteBarriers";
}
