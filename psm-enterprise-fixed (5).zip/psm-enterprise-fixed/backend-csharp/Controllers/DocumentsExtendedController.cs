using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

/// <summary>
/// Extended Documents Controller with Attachment and Versioning support.
/// Provides endpoints for managing document attachments, versions, previews,
/// and access tracking across all modules.
///
/// Modules supported:
/// - HAZOP
/// - LOPA
/// - BowTie
/// - Incident
/// - Permit
/// - MOC (Change Management)
/// - Workflow
/// - Action Register
/// </summary>
[ApiController]
[Route("api/documents")]
[Authorize]
public class DocumentsExtendedController : ControllerBase
{
    private readonly IDocumentAttachmentService _attachmentSvc;
    private readonly ILogger<DocumentsExtendedController> _log;

    public DocumentsExtendedController(
        IDocumentAttachmentService attachmentSvc,
        ILogger<DocumentsExtendedController> log)
    {
        _attachmentSvc = attachmentSvc;
        _log = log;
    }

    private string RequireUserId() =>
        User.GetUserId() ?? throw new InvalidOperationException("User ID claim missing.");

    private string GetClientIp()
    {
        return HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";
    }

    private string GetUserAgent()
    {
        return HttpContext.Request.Headers.TryGetValue("User-Agent", out var ua) 
            ? ua.ToString() 
            : "unknown";
    }

    // ════════════════════════════════════════════════════════════════════════════
    // Attachments - Link documents to module records
    // ════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Attach a document to a module record.
    /// POST /api/documents/attach
    /// </summary>
    [HttpPost("attach")]
    [Authorize(Policy = PsmPolicies.CanWriteDocuments)]
    public async Task<IActionResult> AttachDocument([FromBody] AttachDocumentRequest request)
    {
        try
        {
            if (string.IsNullOrEmpty(request.DocumentId) || 
                string.IsNullOrEmpty(request.Module) || 
                string.IsNullOrEmpty(request.RecordId))
                return BadRequest(new { success = false, error = "Missing required fields" });

            var userId = RequireUserId();
            var attachment = await _attachmentSvc.AttachDocumentAsync(request, userId);

            return StatusCode(201, new { success = true, data = attachment });
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error attaching document");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// Detach a document from a module record.
    /// DELETE /api/documents/{attachmentId}/detach
    /// </summary>
    [HttpDelete("{attachmentId}/detach")]
    [Authorize(Policy = PsmPolicies.CanWriteDocuments)]
    public async Task<IActionResult> DetachDocument(string attachmentId)
    {
        try
        {
            var userId = RequireUserId();
            var success = await _attachmentSvc.DetachDocumentAsync(attachmentId, userId);

            if (!success)
                return NotFound(new { success = false, error = "Attachment not found" });

            return Ok(new { success = true, message = "Document detached successfully" });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error detaching document {AttachmentId}", attachmentId);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// Get all attachments for a module record.
    /// GET /api/documents/attachments?module=HAZOP&recordId=abc123
    /// </summary>
    [HttpGet("attachments")]
    [Authorize(Policy = PsmPolicies.CanReadDocuments)]
    public async Task<IActionResult> GetAttachments(
        [FromQuery] string? module = null,
        [FromQuery] string? recordId = null)
    {
        try
        {
            if (string.IsNullOrEmpty(module) || string.IsNullOrEmpty(recordId))
                return BadRequest(new { success = false, error = "module and recordId are required" });

            var attachments = await _attachmentSvc.GetAttachmentsAsync(module, recordId);

            return Ok(new
            {
                success = true,
                data = attachments,
                count = attachments.Count,
            });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error getting attachments for {Module}/{RecordId}", module, recordId);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// Get all attachments for a specific document.
    /// GET /api/documents/{documentId}/attachments
    /// </summary>
    [HttpGet("{documentId}/attachments")]
    [Authorize(Policy = PsmPolicies.CanReadDocuments)]
    public async Task<IActionResult> GetDocumentAttachments(string documentId)
    {
        try
        {
            var attachments = await _attachmentSvc.GetDocumentAttachmentsAsync(documentId);

            return Ok(new
            {
                success = true,
                data = attachments,
                count = attachments.Count,
            });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error getting attachments for document {DocumentId}", documentId);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// Reorder attachments for a module record.
    /// PUT /api/documents/attachments/reorder
    /// </summary>
    [HttpPut("attachments/reorder")]
    [Authorize(Policy = PsmPolicies.CanWriteDocuments)]
    public async Task<IActionResult> ReorderAttachments(
        [FromBody] ReorderAttachmentsRequest request)
    {
        try
        {
            if (string.IsNullOrEmpty(request.Module) || string.IsNullOrEmpty(request.RecordId))
                return BadRequest(new { success = false, error = "Missing required fields" });

            var userId = RequireUserId();
            var success = await _attachmentSvc.ReorderAttachmentsAsync(
                request.Module, request.RecordId, request.SortOrders, userId);

            if (!success)
                return StatusCode(500, new { success = false, error = "Failed to reorder attachments" });

            return Ok(new { success = true, message = "Attachments reordered successfully" });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error reordering attachments");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // ════════════════════════════════════════════════════════════════════════════
    // Versions - Document revision tracking
    // ════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Upload a new version of a document.
    /// POST /api/documents/{documentId}/versions
    /// </summary>
    [HttpPost("{documentId}/versions")]
    [Authorize(Policy = PsmPolicies.CanWriteDocuments)]
    [RequestSizeLimit(104_857_600)]
    [RequestFormLimits(MultipartBodyLengthLimit = 104_857_600)]
    public async Task<IActionResult> UploadVersion(
        string documentId,
        [FromForm] IFormFile? file,
        [FromForm] string? changeSummary = null,
        [FromForm] string? changeType = null)
    {
        try
        {
            if (file is null || file.Length == 0)
                return BadRequest(new { success = false, error = "File is required" });

            var userId = RequireUserId();
            var request = new UploadDocumentVersionRequest
            {
                DocumentId = documentId,
                ChangeSummary = changeSummary,
                ChangeType = changeType ?? "updated",
            };

            var version = await _attachmentSvc.UploadVersionAsync(documentId, file, request, userId);

            return StatusCode(201, new { success = true, data = version });
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error uploading version for document {DocumentId}", documentId);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// Get all versions of a document.
    /// GET /api/documents/{documentId}/versions
    /// </summary>
    [HttpGet("{documentId}/versions")]
    [Authorize(Policy = PsmPolicies.CanReadDocuments)]
    public async Task<IActionResult> GetVersions(string documentId)
    {
        try
        {
            var versions = await _attachmentSvc.GetVersionsAsync(documentId);

            return Ok(new
            {
                success = true,
                data = versions,
                count = versions.Count,
            });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error getting versions for document {DocumentId}", documentId);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// Get a specific version of a document.
    /// GET /api/documents/versions/{versionId}
    /// </summary>
    [HttpGet("versions/{versionId}")]
    [Authorize(Policy = PsmPolicies.CanReadDocuments)]
    public async Task<IActionResult> GetVersion(string versionId)
    {
        try
        {
            var version = await _attachmentSvc.GetVersionAsync(versionId);

            if (version is null)
                return NotFound(new { success = false, error = "Version not found" });

            return Ok(new { success = true, data = version });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error getting version {VersionId}", versionId);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// Restore a document to a previous version.
    /// POST /api/documents/{documentId}/versions/{versionNumber}/restore
    /// </summary>
    [HttpPost("{documentId}/versions/{versionNumber}/restore")]
    [Authorize(Policy = PsmPolicies.CanWriteDocuments)]
    public async Task<IActionResult> RestoreVersion(string documentId, int versionNumber)
    {
        try
        {
            var userId = RequireUserId();
            var success = await _attachmentSvc.RestoreVersionAsync(documentId, versionNumber, userId);

            if (!success)
                return NotFound(new { success = false, error = "Version not found" });

            return Ok(new { success = true, message = $"Document restored to version {versionNumber}" });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error restoring version {VersionNumber} for document {DocumentId}", 
                versionNumber, documentId);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // ════════════════════════════════════════════════════════════════════════════
    // Previews - Document preview metadata
    // ════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Get preview metadata for a document.
    /// GET /api/documents/{documentId}/preview
    /// </summary>
    [HttpGet("{documentId}/preview")]
    [Authorize(Policy = PsmPolicies.CanReadDocuments)]
    public async Task<IActionResult> GetPreview(
        string documentId,
        [FromQuery] string? previewType = null)
    {
        try
        {
            var preview = await _attachmentSvc.GetPreviewAsync(documentId, previewType);

            if (preview is null)
                return NotFound(new { success = false, error = "Preview not available" });

            // Log access
            await _attachmentSvc.LogAccessAsync(
                documentId,
                User.GetUserId(),
                "preview",
                GetClientIp(),
                GetUserAgent());

            return Ok(new { success = true, data = preview });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error getting preview for document {DocumentId}", documentId);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// Generate or update preview metadata for a document.
    /// POST /api/documents/{documentId}/preview
    /// </summary>
    [HttpPost("{documentId}/preview")]
    [Authorize(Policy = PsmPolicies.CanWriteDocuments)]
    public async Task<IActionResult> GeneratePreview(
        string documentId,
        [FromBody] GeneratePreviewRequest request)
    {
        try
        {
            var preview = await _attachmentSvc.GeneratePreviewAsync(
                documentId,
                request.PreviewType ?? "thumbnail",
                request.ThumbnailPath,
                request.PageCount);

            return StatusCode(201, new { success = true, data = preview });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error generating preview for document {DocumentId}", documentId);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // ════════════════════════════════════════════════════════════════════════════
    // Access Tracking - Document usage auditing
    // ════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Get access history for a document.
    /// GET /api/documents/{documentId}/access-history
    /// </summary>
    [HttpGet("{documentId}/access-history")]
    [Authorize(Policy = PsmPolicies.CanReadDocuments)]
    public async Task<IActionResult> GetAccessHistory(
        string documentId,
        [FromQuery] int limit = 100)
    {
        try
        {
            var history = await _attachmentSvc.GetAccessHistoryAsync(documentId, limit);

            return Ok(new
            {
                success = true,
                data = history,
                count = history.Count,
            });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error getting access history for document {DocumentId}", documentId);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // ════════════════════════════════════════════════════════════════════════════
    // Module Document Summaries
    // ════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Get complete document summary for a module record.
    /// GET /api/documents/summary?module=HAZOP&recordId=abc123
    /// </summary>
    [HttpGet("summary")]
    [Authorize(Policy = PsmPolicies.CanReadDocuments)]
    public async Task<IActionResult> GetModuleDocumentSummary(
        [FromQuery] string? module = null,
        [FromQuery] string? recordId = null)
    {
        try
        {
            if (string.IsNullOrEmpty(module) || string.IsNullOrEmpty(recordId))
                return BadRequest(new { success = false, error = "module and recordId are required" });

            var summary = await _attachmentSvc.GetModuleDocumentSummaryAsync(module, recordId);

            return Ok(new { success = true, data = summary });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error getting document summary for {Module}/{RecordId}", module, recordId);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// Get all documents with attachments and versions for a module record.
    /// GET /api/documents/complete?module=HAZOP&recordId=abc123
    /// </summary>
    [HttpGet("complete")]
    [Authorize(Policy = PsmPolicies.CanReadDocuments)]
    public async Task<IActionResult> GetCompleteDocumentData(
        [FromQuery] string? module = null,
        [FromQuery] string? recordId = null)
    {
        try
        {
            if (string.IsNullOrEmpty(module) || string.IsNullOrEmpty(recordId))
                return BadRequest(new { success = false, error = "module and recordId are required" });

            var documents = await _attachmentSvc.GetCompleteDocumentDataAsync(module, recordId);

            return Ok(new
            {
                success = true,
                data = documents,
                count = documents.Count,
            });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error getting complete document data for {Module}/{RecordId}", 
                module, recordId);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Request DTOs
// ════════════════════════════════════════════════════════════════════════════

public class ReorderAttachmentsRequest
{
    public string Module { get; set; } = "";
    public string RecordId { get; set; } = "";
    public Dictionary<string, int> SortOrders { get; set; } = new();
}

public class GeneratePreviewRequest
{
    public string? PreviewType { get; set; }
    public string? ThumbnailPath { get; set; }
    public int? PageCount { get; set; }
}
