using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

/// <summary>
/// Action Register Management — Dedicated API for tracking follow-up actions
/// from multiple sources (MOC, Incidents, HAZOP, Audits, PSSR, etc.)
///
/// This controller manages the action_register dedicated table with:
/// - RBAC integration for read/write/delete permissions
/// - Audit trail integration for all modifications
/// - Pagination and filtering support
/// - Full-text search capabilities
/// - Dashboard statistics and overdue tracking
///
/// Routes:
///   GET    /api/actions              — List with filtering & pagination
///   GET    /api/actions/{id}         — Get single action
///   POST   /api/actions              — Create action
///   PUT    /api/actions/{id}         — Update action
///   DELETE /api/actions/{id}         — Delete action (soft-delete)
///   GET    /api/actions/stats        — Dashboard statistics
///   GET    /api/actions/overdue      — Get overdue actions
///   GET    /api/actions/search       — Full-text search
/// </summary>
[ApiController]
[Route("api/actions")]
[Authorize]
public class ActionRegisterController : ControllerBase
{
    private readonly IActionRegisterService _service;
    private readonly ILogger<ActionRegisterController> _logger;

    public ActionRegisterController(
        IActionRegisterService service,
        ILogger<ActionRegisterController> logger)
    {
        _service = service ?? throw new ArgumentNullException(nameof(service));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // RBAC Helpers
    // ─────────────────────────────────────────────────────────────────────────────

    /// <summary>
    /// Checks if the current user has permission to perform a specific action.
    /// Admins always have access; other users are checked via RBAC.
    /// </summary>

    /// <summary>
    /// Gets the current user's ID from the JWT claim.
    /// Throws if not found (should not happen if auth middleware is configured correctly).
    /// </summary>
    private string GetCurrentUserId() =>
        User.GetUserId() ?? throw new UnauthorizedAccessException("User ID claim is missing.");

    // ─────────────────────────────────────────────────────────────────────────────
    // LIST: GET /api/actions
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Lists all action register records with support for filtering and pagination.
    /// 
    /// Query Parameters:
    ///   - source (optional): Filter by source (MOC, Incident, HAZOP, Audit, PSSR, Management Review, Inspection, Other)
    ///   - unit (optional): Filter by process unit
    ///   - status (optional): Filter by status (Open, In Progress, Overdue, Done, Verified, Closed)
    ///   - priority (optional): Filter by priority (Critical, High, Medium, Low)
    ///   - page (optional, default=1): 1-based page number
    ///   - limit (optional, default=20): Records per page (max 100)
    /// </summary>
    [HttpGet]
    [Authorize(Policy = PsmPolicies.CanReadActions)]
    [ProducesResponseType(typeof(ActionRegisterListResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> List(
        [FromQuery] string? source = null,
        [FromQuery] string? unit = null,
        [FromQuery] string? status = null,
        [FromQuery] string? priority = null,
        [FromQuery] int page = 1,
        [FromQuery] int limit = 20)
    {

        try
        {
            var result = await _service.ListAsync(source, unit, status, priority, page, limit);
            return Ok(new
            {
                success = true,
                data = result.Data,
                pagination = new
                {
                    page = result.Page,
                    limit = result.Limit,
                    total = result.Total,
                    pages = (result.Total + result.Limit - 1) / result.Limit,
                },
                timestamp = DateTime.UtcNow,
            });
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Invalid arguments for listing actions");
            return BadRequest(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing action register records");
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام دریافت اطلاعات رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // GET BY ID: GET /api/actions/{id}
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Retrieves a single action register record by ID.
    /// </summary>
    /// <param name="id">The action register record ID</param>
    [HttpGet("{id}")]
    [Authorize(Policy = PsmPolicies.CanReadActions)]
    [ProducesResponseType(typeof(ActionRegisterDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GetById(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
            return BadRequest(new { success = false, error = "ID الزامی است" });

        try
        {
            var action = await _service.GetAsync(id);
            if (action is null)
            {
                _logger.LogInformation("Action register record {Id} not found", id);
                return NotFound(new { success = false, error = $"اقدام '{id}' یافت نشد" });
            }

            return Ok(new { success = true, data = action });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching action register {Id}", id);
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام دریافت اطلاعات رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // CREATE: POST /api/actions
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Creates a new action register record.
    /// 
    /// Required Fields:
    ///   - title (string): Action title/name
    ///   - source (string): Origin of action (MOC, Incident, HAZOP, Audit, PSSR, Management Review, Inspection, Other)
    ///
    /// Optional Fields:
    ///   - description, sourceId, sourceRef, unit, responsible, dueDate, status, priority, tags
    /// </summary>
    [HttpPost]
    [Authorize(Policy = PsmPolicies.CanWriteActions)]
    [ProducesResponseType(typeof(ActionRegisterDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> Create([FromBody] CreateActionRegisterRequest req)
    {
        if (req == null)
            return BadRequest(new { success = false, error = "درخواست نامعتبر" });

        try
        {
            var userId = GetCurrentUserId();
            var createdAction = await _service.CreateAsync(req, userId);

            _logger.LogInformation("Action register created by {UserId}: {ActionId}",
                userId, createdAction.Id);

            return StatusCode(201, new
            {
                success = true,
                data = createdAction,
                message = "اقدام با موفقیت ایجاد شد",
            });
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Validation error creating action register");
            return BadRequest(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating action register");
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام ایجاد اقدام رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // CREATE FROM INCIDENT: POST /api/actions/from-incident
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Creates a new action register record from an Incident recommendation.
    /// Automatically links action to incident via Source=Incident, SourceId=incidentId.
    /// 
    /// Required Fields:
    ///   - incidentId (string): ID of the incident
    ///   - recommendationText (string): The recommendation to convert to action
    ///   - recommendationType (string): Type of recommendation (immediate|corrective|preventive)
    ///
    /// Optional Fields:
    ///   - priority (string): Critical, High, Medium, Low (default: High)
    ///   - responsible (string): Person responsible for the action
    ///   - dueDate (datetime): When action should be completed
    /// </summary>
    [HttpPost("from-incident")]
    [Authorize(Policy = PsmPolicies.CanWriteActions)]
    [ProducesResponseType(typeof(ActionRegisterDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> CreateFromIncident([FromBody] CreateActionFromIncidentRequest req)
    {
        if (req == null)
            return BadRequest(new { success = false, error = "درخواست نامعتبر" });

        try
        {
            var userId = GetCurrentUserId();
            var createdAction = await _service.CreateFromIncidentRecommendationAsync(req, userId);

            _logger.LogInformation("Action register created from incident by {UserId}: ActionId={ActionId}, IncidentId={IncidentId}",
                userId, createdAction.Id, req.IncidentId);

            return StatusCode(201, new
            {
                success = true,
                data = createdAction,
                message = "اقدام از توصیه حادثه با موفقیت ایجاد شد",
            });
        }
        catch (KeyNotFoundException ex)
        {
            _logger.LogWarning(ex, "Incident not found: {IncidentId}", req.IncidentId);
            return NotFound(new { success = false, error = ex.Message });
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Validation error creating action from incident");
            return BadRequest(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating action from incident {IncidentId}", req.IncidentId);
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام ایجاد اقدام از حادثه رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // CREATE FROM HAZOP: POST /api/actions/from-hazop
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Creates a new action register record from a HAZOP deviation recommendation.
    /// Automatically links action to HAZOP study via Source=HAZOP, SourceId=studyId.
    /// 
    /// Required Fields:
    ///   - deviationId (string): ID of the HAZOP deviation
    ///
    /// Optional Fields:
    ///   - recommendationText (string): Override the deviation's recommendations
    ///   - priority (string): Critical, High, Medium, Low (default: High)
    ///   - responsible (string): Person responsible for the action
    ///   - dueDate (datetime): When action should be completed
    /// </summary>
    [HttpPost("from-hazop")]
    [Authorize(Policy = PsmPolicies.CanWriteActions)]
    [ProducesResponseType(typeof(ActionRegisterDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> CreateFromHazop([FromBody] CreateActionFromHazopRequest req)
    {
        if (req == null)
            return BadRequest(new { success = false, error = "درخواست نامعتبر" });

        try
        {
            var userId = GetCurrentUserId();
            var createdAction = await _service.CreateFromHazopDeviationAsync(req, userId);

            _logger.LogInformation("Action register created from HAZOP by {UserId}: ActionId={ActionId}, DeviationId={DeviationId}",
                userId, createdAction.Id, req.DeviationId);

            return StatusCode(201, new
            {
                success = true,
                data = createdAction,
                message = "اقدام از توصیه HAZOP با موفقیت ایجاد شد",
            });
        }
        catch (KeyNotFoundException ex)
        {
            _logger.LogWarning(ex, "HAZOP deviation not found: {DeviationId}", req.DeviationId);
            return NotFound(new { success = false, error = ex.Message });
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Validation error creating action from HAZOP");
            return BadRequest(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating action from HAZOP {DeviationId}", req.DeviationId);
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام ایجاد اقدام از HAZOP رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // UPDATE: PUT /api/actions/{id}
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Updates an existing action register record.
    /// All fields are optional; only provided fields will be updated.
    /// </summary>
    /// <param name="id">The action register record ID</param>
    [HttpPut("{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteActions)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> Update(string id, [FromBody] UpdateActionRegisterRequest req)
    {
        if (string.IsNullOrWhiteSpace(id))
            return BadRequest(new { success = false, error = "ID الزامی است" });

        if (req == null)
            return BadRequest(new { success = false, error = "درخواست نامعتبر" });

        try
        {
            var userId = GetCurrentUserId();
            var updated = await _service.UpdateAsync(id, req, userId);

            if (!updated)
            {
                _logger.LogInformation("Action register {Id} not found for update", id);
                return NotFound(new { success = false, error = $"اقدام '{id}' یافت نشد" });
            }

            _logger.LogInformation("Action register updated by {UserId}: {ActionId}",
                userId, id);

            return Ok(new
            {
                success = true,
                message = "اقدام با موفقیت بروزرسانی شد",
                timestamp = DateTime.UtcNow,
            });
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Validation error updating action {Id}", id);
            return BadRequest(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating action register {Id}", id);
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام بروزرسانی اقدام رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // DELETE: DELETE /api/actions/{id}
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Deletes (soft-deletes) an action register record.
    /// The record is marked as deleted but not removed from the database.
    /// </summary>
    /// <param name="id">The action register record ID</param>
    [HttpDelete("{id}")]
    [Authorize(Policy = PsmPolicies.CanDeleteActions)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> Delete(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
            return BadRequest(new { success = false, error = "ID الزامی است" });

        try
        {
            var userId = GetCurrentUserId();
            var deleted = await _service.DeleteAsync(id, userId);

            if (!deleted)
            {
                _logger.LogInformation("Action register {Id} not found for deletion", id);
                return NotFound(new { success = false, error = $"اقدام '{id}' یافت نشد" });
            }

            _logger.LogInformation("Action register deleted by {UserId}: {ActionId}",
                userId, id);

            return Ok(new
            {
                success = true,
                message = "اقدام با موفقیت حذف شد",
                timestamp = DateTime.UtcNow,
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting action register {Id}", id);
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام حذف اقدام رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // STATS: GET /api/actions/stats
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Retrieves dashboard statistics for action register records.
    /// Includes counts by status, priority, and source.
    /// </summary>
    [HttpGet("stats")]
    [Authorize(Policy = PsmPolicies.CanReadActions)]
    [ProducesResponseType(typeof(ActionRegisterStats), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GetStats()
    {

        try
        {
            var stats = await _service.GetStatsAsync();
            return Ok(new
            {
                success = true,
                data = stats,
                timestamp = DateTime.UtcNow,
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching action register statistics");
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام دریافت آمار رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // OVERDUE: GET /api/actions/overdue
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Retrieves all overdue actions that have not yet been completed.
    /// Useful for dashboard alerts and escalation workflows.
    /// </summary>
    [HttpGet("overdue")]
    [Authorize(Policy = PsmPolicies.CanReadActions)]
    [ProducesResponseType(typeof(IEnumerable<ActionRegisterDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GetOverdue()
    {

        try
        {
            var actions = await _service.GetOverdueAsync();
            return Ok(new
            {
                success = true,
                data = actions,
                count = actions.Count(),
                timestamp = DateTime.UtcNow,
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching overdue actions");
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام دریافت اقدامات معوق رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SEARCH: GET /api/actions/search
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Searches action register records by title, description, and tags.
    /// Performs full-text search with ILIKE (case-insensitive).
    /// 
    /// Query Parameters:
    ///   - q (required): Search term (minimum 2 characters)
    ///   - limit (optional, default=50): Maximum results (max 200)
    /// </summary>
    [HttpGet("search")]
    [Authorize(Policy = PsmPolicies.CanReadActions)]
    [ProducesResponseType(typeof(IEnumerable<ActionRegisterDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> Search(
        [FromQuery] string? q = null,
        [FromQuery] int limit = 50)
    {

        if (string.IsNullOrWhiteSpace(q))
            return BadRequest(new { success = false, error = "عبارت جستجو الزامی است" });

        if (q.Length < 2)
            return BadRequest(new { success = false, error = "عبارت جستجو باید حداقل ۲ کاراکتر داشته باشد" });

        try
        {
            var results = await _service.SearchAsync(q, limit);
            return Ok(new
            {
                success = true,
                data = results,
                count = results.Count(),
                query = q,
                timestamp = DateTime.UtcNow,
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error searching action register with query: {Query}", q);
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام جستجو رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }
}
