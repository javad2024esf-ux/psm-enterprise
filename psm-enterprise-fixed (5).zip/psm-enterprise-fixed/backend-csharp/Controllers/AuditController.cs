using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.Middleware;
using PSM.Api.Models;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

[ApiController]
[Route("api/audit")]
[Authorize]
public class AuditController : ControllerBase
{
    private readonly IAuditService _audit;

    public AuditController(IAuditService audit) => _audit = audit;

    // GET /api/audit
    [HttpGet]
    [Authorize(Policy = PsmPolicies.CanReadAudit)]
    public async Task<IActionResult> GetLogs(
        [FromQuery] int       limit    = 100,
        [FromQuery] int       offset   = 0,
        [FromQuery] string?   userId   = null,
        [FromQuery] string?   module   = null,
        [FromQuery] string?   action   = null,
        [FromQuery] string?   severity = null,
        [FromQuery] string?   recordId = null,
        [FromQuery] string?   outcome  = null,
        [FromQuery] DateTime? from     = null,
        [FromQuery] DateTime? to       = null,
        [FromQuery] string?   search   = null)
    {
        var page = await _audit.QueryAsync(new AuditQuery
        {
            Limit    = limit,
            Offset   = offset,
            UserId   = userId,
            Module   = module,
            Action   = action,
            Severity = severity,
            RecordId = recordId,
            Outcome  = outcome,
            From     = from,
            To       = to,
            Search   = search,
        });

        return Ok(new { success = true, data = page.Data, total = page.Total,
                        limit = page.Limit, offset = page.Offset });
    }

    // GET /api/audit/record/:id  — تمام تغییرات یک رکورد خاص (timeline)
    [HttpGet("record/{id}")]
    [Authorize(Policy = PsmPolicies.CanReadAudit)]
    public async Task<IActionResult> GetRecordHistory(string id,
        [FromQuery] int limit = 50)
    {
        var page = await _audit.QueryAsync(new AuditQuery { RecordId = id, Limit = limit });
        return Ok(new { success = true, data = page.Data, total = page.Total });
    }

    // GET /api/audit/user/:id  — تاریخچه کامل یک کاربر
    [HttpGet("user/{id}")]
    [Authorize(Policy = PsmPolicies.CanManageUsers)]
    public async Task<IActionResult> GetUserHistory(string id,
        [FromQuery] int limit = 100)
    {
        var page = await _audit.QueryAsync(new AuditQuery { UserId = id, Limit = limit });
        return Ok(new { success = true, data = page.Data, total = page.Total });
    }

    // GET /api/audit/critical  — فقط رویدادهای CRITICAL / DENIED
    [HttpGet("critical")]
    [Authorize(Policy = PsmPolicies.CanReadAuditFull)]
    public async Task<IActionResult> GetCritical(
        [FromQuery] DateTime? from  = null,
        [FromQuery] int       limit = 200)
    {
        var critical = await _audit.QueryAsync(new AuditQuery
            { Severity = AuditSeverity.Critical, From = from, Limit = limit });
        var denied   = await _audit.QueryAsync(new AuditQuery
            { Outcome = "DENIED", From = from, Limit = limit });

        var merged = critical.Data
            .Concat(denied.Data)
            .DistinctBy(e => e.Id)
            .OrderByDescending(e => e.CreatedAt)
            .Take(limit);

        return Ok(new { success = true, data = merged });
    }

    // GET /api/audit/stats  — آمار خلاصه برای dashboard
    [HttpGet("stats")]
    [Authorize(Policy = PsmPolicies.CanReadAudit)]
    public async Task<IActionResult> GetStats([FromQuery] DateTime? from = null)
    {
        var since = from ?? DateTime.UtcNow.AddDays(-30);

        var tasks = new[]
        {
            _audit.QueryAsync(new AuditQuery { From = since, Limit = 1 }),
            _audit.QueryAsync(new AuditQuery { Severity = AuditSeverity.Critical,
                                               From = since, Limit = 1 }),
            _audit.QueryAsync(new AuditQuery { Outcome = "DENIED",
                                               From = since, Limit = 1 }),
            _audit.QueryAsync(new AuditQuery { Action = AuditAction.Login,
                                               From = since, Limit = 1 }),
        };
        var results = await Task.WhenAll(tasks);

        return Ok(new
        {
            success = true,
            data = new
            {
                totalEvents    = results[0].Total,
                criticalEvents = results[1].Total,
                deniedAccess   = results[2].Total,
                loginEvents    = results[3].Total,
                since,
            }
        });
    }
}
