using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

[ApiController]
[Route("api/documents")]
[Authorize]
public class DocumentsController : ControllerBase
{
    private readonly IDocumentService _svc;
    private readonly ILogger<DocumentsController> _log;

    public DocumentsController(IDocumentService svc, ILogger<DocumentsController> log)
    {
        _svc = svc;
        _log = log;
    }

    private string RequireUserId() =>
        User.GetUserId() ?? throw new InvalidOperationException("User ID claim missing.");

    [HttpGet]
    [Authorize(Policy = PsmPolicies.CanReadDocuments)]
    public async Task<IActionResult> List(
        [FromQuery] string? module = null,
        [FromQuery] string? tag    = null,
        [FromQuery] int     page   = 1,
        [FromQuery] int     limit  = 20)
    {
        try
        {
            var result = await _svc.ListAsync(module, tag, page, limit);
            return Ok(new
            {
                success    = true,
                data       = result.Data,
                documents  = result.Data,
                pagination = new { page = result.Page, limit = result.Limit, total = result.Total },
            });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error listing documents");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    [HttpGet("{id}")]
    [Authorize(Policy = PsmPolicies.CanReadDocuments)]
    public async Task<IActionResult> GetById(string id)
    {
        try
        {
            var doc = await _svc.GetAsync(id);
            if (doc is null)
                return NotFound(new { success = false, error = $"سند '{id}' یافت نشد" });
            return Ok(new { success = true, data = doc });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error fetching document {Id}", id);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    [HttpPost("upload")]
    [Authorize(Policy = PsmPolicies.CanWriteDocuments)]
    [RequestSizeLimit(104_857_600)]
    [RequestFormLimits(MultipartBodyLengthLimit = 104_857_600)]
    public async Task<IActionResult> Upload(
        [FromForm] IFormFile?  file,
        [FromForm] string?     module = null,
        [FromForm] string?     tags   = null)
    {
        if (file is null || file.Length == 0)
            return BadRequest(new { success = false, error = "فایلی ارسال نشده است" });
        try
        {
            var userId   = RequireUserId();
            var tagArray = tags?.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            var doc = await _svc.UploadAsync(file, module, tagArray, userId);
            return StatusCode(201, new { success = true, data = doc });
        }
        catch (ArgumentException ex) { return BadRequest(new { success = false, error = ex.Message }); }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error uploading document");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    [HttpGet("{id}/download")]
    [Authorize(Policy = PsmPolicies.CanReadDocuments)]
    public async Task<IActionResult> Download(string id)
    {
        try
        {
            var resolved = await _svc.ResolveDownloadAsync(id);
            if (resolved is null)
                return NotFound(new { success = false, error = "فایل یافت نشد یا حذف شده است" });

            var (absPath, mime, name) = resolved.Value;
            var inline = mime is "application/pdf"
                or "image/jpeg" or "image/png" or "image/gif"
                or "image/webp" or "image/svg+xml";

            Response.Headers["Content-Disposition"] = inline
                ? $"inline; filename=\"{Uri.EscapeDataString(name)}\""
                : $"attachment; filename=\"{Uri.EscapeDataString(name)}\"";

            return PhysicalFile(absPath, mime, enableRangeProcessing: true);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error downloading document {Id}", id);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    [HttpGet("{id}/content")]
    [Authorize(Policy = PsmPolicies.CanReadDocuments)]
    public async Task<IActionResult> GetContent(string id)
    {
        try
        {
            var doc = await _svc.GetAsync(id);
            if (doc is null)
                return NotFound(new { success = false, error = "سند یافت نشد" });

            return Ok(new
            {
                success     = true,
                id          = doc.Id,
                name        = doc.Name,
                mimeType    = doc.MimeType,
                fileSize    = doc.FileSize,
                downloadUrl = $"/api/documents/{doc.Id}/download",
            });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error fetching content for document {Id}", id);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    [HttpDelete("{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteDocuments)]
    public async Task<IActionResult> Delete(string id)
    {
        try
        {
            var userId = RequireUserId();
            var found  = await _svc.DeleteAsync(id, userId);
            if (!found)
                return NotFound(new { success = false, error = $"سند '{id}' یافت نشد" });
            return Ok(new { success = true, message = "سند با موفقیت حذف شد" });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error deleting document {Id}", id);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }
}
