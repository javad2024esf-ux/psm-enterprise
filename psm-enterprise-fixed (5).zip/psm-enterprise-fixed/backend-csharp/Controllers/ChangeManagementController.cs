using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Services;
using PSM.Api.Middleware;
using PSM.Api.Configuration;
using PSM.Api.Models;

namespace PSM.Api.Controllers;
[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ChangeManagementController : ControllerBase
{
    private readonly IChangeManagementService _changeService;
    private readonly ICurrentUserService _currentUserService;

    public ChangeManagementController(
        IChangeManagementService changeService,
        ICurrentUserService currentUserService)
    {
        _changeService = changeService;
        _currentUserService = currentUserService;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Change Request Management
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Create new change request
    /// </summary>
    [HttpPost("requests")]
    [Authorize(Policy = PsmPolicies.CanCreateChange)]
    public async Task<ActionResult<ApiResponse<string>>> CreateChangeRequest([FromBody] CreateChangeRequestDto dto)
    {
        try
        {
            var userId = _currentUserService.GetUserId();
            var changeId = await _changeService.CreateChangeRequestAsync(dto, userId);
            
            return Ok(new ApiResponse<string>
            {
                Success = true,
                Data = changeId,
                Message = "Change request created successfully"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<string> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Get change request details
    /// </summary>
    [HttpGet("requests/{changeId}")]
    public async Task<ActionResult<ApiResponse<ChangeRequestDto>>> GetChangeRequest(string changeId)
    {
        try
        {
            var change = await _changeService.GetChangeRequestAsync(changeId);
            if (change == null)
                return NotFound(new ApiResponse<ChangeRequestDto> { Success = false, Message = "Change not found" });

            return Ok(new ApiResponse<ChangeRequestDto> { Success = true, Data = change });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<ChangeRequestDto> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// List change requests with filtering
    /// </summary>
    [HttpPost("requests/search")]
    public async Task<ActionResult<ApiResponse<List<ChangeRequestDto>>>> SearchChangeRequests([FromBody] ChangeRequestFilterDto filter)
    {
        try
        {
            var changes = await _changeService.GetChangeRequestsAsync(filter);
            return Ok(new ApiResponse<List<ChangeRequestDto>>
            {
                Success = true,
                Data = changes,
                Message = $"Found {changes.Count} changes"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<List<ChangeRequestDto>> { Success = false, Message = ex.Message });
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Workflow Progression
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Advance change to next workflow stage
    /// </summary>
    [HttpPost("requests/{changeId}/advance-stage")]
    [Authorize(Policy = PsmPolicies.CanAdvanceWorkflow)]
    public async Task<ActionResult<ApiResponse<object>>> AdvanceWorkflowStage(string changeId, [FromBody] AdvanceWorkflowDto dto)
    {
        try
        {
            var userId = _currentUserService.GetUserId();
            await _changeService.AdvanceWorkflowStageAsync(changeId, dto.NextStage, userId, dto.Comment);

            return Ok(new ApiResponse<object>
            {
                Success = true,
                Message = $"Change advanced to {dto.NextStage}"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<object> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Return change to previous workflow stage
    /// </summary>
    [HttpPost("requests/{changeId}/return-stage")]
    [Authorize(Policy = PsmPolicies.CanRejectWorkflow)]
    public async Task<ActionResult<ApiResponse<object>>> ReturnWorkflowStage(string changeId, [FromBody] Dictionary<string, string> request)
    {
        try
        {
            var userId = _currentUserService.GetUserId();
            var previousStage = request["previousStage"];
            var reason = request["reason"];

            await _changeService.ReturnWorkflowStageAsync(changeId, previousStage, userId, reason);

            return Ok(new ApiResponse<object>
            {
                Success = true,
                Message = $"Change returned to {previousStage}"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<object> { Success = false, Message = ex.Message });
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Stage Actions
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Add action item to workflow stage
    /// </summary>
    [HttpPost("stages/actions")]
    public async Task<ActionResult<ApiResponse<object>>> AddStageAction([FromBody] CreateStageActionDto dto)
    {
        try
        {
            await _changeService.AddStageActionAsync(dto);
            return Ok(new ApiResponse<object> { Success = true, Message = "Action added successfully" });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<object> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Complete action item
    /// </summary>
    [HttpPost("stages/actions/{actionId}/complete")]
    public async Task<ActionResult<ApiResponse<object>>> CompleteAction(string actionId, [FromBody] Dictionary<string, string> request)
    {
        try
        {
            var userId = _currentUserService.GetUserId();
            var notes = request.ContainsKey("notes") ? request["notes"] : "";

            await _changeService.CompleteStageActionAsync(actionId, userId, notes);

            return Ok(new ApiResponse<object>
            {
                Success = true,
                Message = "Action completed successfully"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<object> { Success = false, Message = ex.Message });
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // HAZOP/LOPA Linkage
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Link HAZOP to change request
    /// </summary>
    [HttpPost("requests/{changeId}/link-hazop")]
    public async Task<ActionResult<ApiResponse<object>>> LinkHazop(string changeId, [FromBody] Dictionary<string, string> request)
    {
        try
        {
            var hazopId = request["hazopId"];
            var userId = _currentUserService.GetUserId();

            await _changeService.LinkHazopAsync(changeId, hazopId, userId);

            return Ok(new ApiResponse<object>
            {
                Success = true,
                Message = "HAZOP linked successfully"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<object> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Link LOPA to change request
    /// </summary>
    [HttpPost("requests/{changeId}/link-lopa")]
    public async Task<ActionResult<ApiResponse<object>>> LinkLopa(string changeId, [FromBody] Dictionary<string, string> request)
    {
        try
        {
            var lopaId = request["lopaId"];
            var userId = _currentUserService.GetUserId();

            await _changeService.LinkLopaAsync(changeId, lopaId, userId);

            return Ok(new ApiResponse<object>
            {
                Success = true,
                Message = "LOPA linked successfully"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<object> { Success = false, Message = ex.Message });
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Training Management
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Create training record
    /// </summary>
    [HttpPost("training")]
    [Authorize(Policy = PsmPolicies.CanAssignTraining)]
    public async Task<ActionResult<ApiResponse<object>>> CreateTraining([FromBody] CreateTrainingRecordDto dto)
    {
        try
        {
            await _changeService.AddTrainingRecordAsync(dto);
            return Ok(new ApiResponse<object> { Success = true, Message = "Training assigned successfully" });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<object> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Complete training
    /// </summary>
    [HttpPost("training/{trainingId}/complete")]
    public async Task<ActionResult<ApiResponse<object>>> CompleteTraining(string trainingId, [FromBody] CompleteTrainingDto dto)
    {
        try
        {
            await _changeService.CompleteTrainingAsync(trainingId, dto.CertificateUrl, dto.Notes);

            return Ok(new ApiResponse<object>
            {
                Success = true,
                Message = "Training completed successfully"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<object> { Success = false, Message = ex.Message });
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PSSR Checklist
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Add PSSR checklist item
    /// </summary>
    [HttpPost("requests/{changeId}/pssr-items")]
    public async Task<ActionResult<ApiResponse<object>>> AddPssrItem(string changeId, [FromBody] Dictionary<string, string> request)
    {
        try
        {
            var item = request["item"];
            var category = request["category"];

            await _changeService.AddPssrItemAsync(changeId, item, category);

            return Ok(new ApiResponse<object>
            {
                Success = true,
                Message = "PSSR item added successfully"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<object> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Verify PSSR item
    /// </summary>
    [HttpPost("pssr-items/{itemId}/verify")]
    [Authorize(Policy = PsmPolicies.CanVerifyPSSR)]
    public async Task<ActionResult<ApiResponse<object>>> VerifyPssrItem(string itemId, [FromBody] VerifyPssrItemDto dto)
    {
        try
        {
            var userId = _currentUserService.GetUserId();
            await _changeService.VerifyPssrItemAsync(itemId, userId, dto.VerificationNotes);

            return Ok(new ApiResponse<object>
            {
                Success = true,
                Message = "PSSR item verified successfully"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<object> { Success = false, Message = ex.Message });
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Startup Approval Gate (CRITICAL)
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Check startup readiness
    /// CRITICAL: Returns all blocking issues preventing startup approval
    /// </summary>
    [HttpGet("requests/{changeId}/startup-status")]
    public async Task<ActionResult<ApiResponse<StartupGateStatusDto>>> GetStartupStatus(string changeId)
    {
        try
        {
            var status = await _changeService.EvaluateStartupReadinessAsync(changeId);
            if (status == null)
                return NotFound(new ApiResponse<StartupGateStatusDto> { Success = false, Message = "Gate not found" });

            return Ok(new ApiResponse<StartupGateStatusDto>
            {
                Success = true,
                Data = status
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<StartupGateStatusDto> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Validate if startup can be approved
    /// CRITICAL: Returns false if ANY requirement is not met
    /// </summary>
    [HttpGet("requests/{changeId}/can-approve-startup")]
    public async Task<ActionResult<ApiResponse<object>>> CanApproveStartup(string changeId)
    {
        try
        {
            var canApprove = await _changeService.CanApproveStartupAsync(changeId);

            if (!canApprove)
            {
                var status = await _changeService.EvaluateStartupReadinessAsync(changeId);
                return Ok(new ApiResponse<object>
                {
                    Success = false,
                    Data = new { canApprove = false, blockingIssues = status.BlockingIssues },
                    Message = "Cannot approve startup due to blocking issues"
                });
            }

            return Ok(new ApiResponse<object>
            {
                Success = true,
                Data = new { canApprove = true },
                Message = "Startup can be approved"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<object> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Approve startup
    /// CRITICAL: Only succeeds if all gates are satisfied
    /// </summary>
    [HttpPost("requests/{changeId}/approve-startup")]
    [Authorize(Policy = PsmPolicies.CanApproveStartup)]
    public async Task<ActionResult<ApiResponse<object>>> ApproveStartup(string changeId, [FromBody] ApproveStartupDto dto)
    {
        try
        {
            var userId = _currentUserService.GetUserId();

            // Double-check startup readiness before approval
            var canApprove = await _changeService.CanApproveStartupAsync(changeId);
            if (!canApprove)
            {
                var status = await _changeService.EvaluateStartupReadinessAsync(changeId);
                var issues = string.Join(", ", status.BlockingIssues);
                return BadRequest(new ApiResponse<object>
                {
                    Success = false,
                    Message = $"Cannot approve startup. Blocking issues: {issues}"
                });
            }

            await _changeService.ApproveStartupAsync(changeId, userId, dto.ApprovalComment);

            return Ok(new ApiResponse<object>
            {
                Success = true,
                Message = "Startup approved successfully"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<object> { Success = false, Message = ex.Message });
        }
    }

    /// <summary>
    /// Reject startup
    /// </summary>
    [HttpPost("requests/{changeId}/reject-startup")]
    [Authorize(Policy = PsmPolicies.CanRejectStartup)]
    public async Task<ActionResult<ApiResponse<object>>> RejectStartup(string changeId, [FromBody] RejectStartupDto dto)
    {
        try
        {
            await _changeService.RejectStartupAsync(changeId, dto.RejectionReason);

            return Ok(new ApiResponse<object>
            {
                Success = true,
                Message = "Startup rejected"
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<object> { Success = false, Message = ex.Message });
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Dashboard & Indicators
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Get change management dashboard metrics
    /// </summary>
    [HttpGet("dashboard")]
    public async Task<ActionResult<ApiResponse<ChangeDashboardMetricsDto>>> GetDashboard()
    {
        try
        {
            var metrics = await _changeService.GetDashboardAsync();
            return Ok(new ApiResponse<ChangeDashboardMetricsDto>
            {
                Success = true,
                Data = metrics
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<ChangeDashboardMetricsDto> { Success = false, Message = ex.Message });
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Audit Trail
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Get audit trail for change
    /// </summary>
    [HttpGet("requests/{changeId}/audit-trail")]
    public async Task<ActionResult<ApiResponse<List<WorkflowAuditDto>>>> GetAuditTrail(string changeId)
    {
        try
        {
            var audit = await _changeService.GetAuditTrailAsync(changeId);
            return Ok(new ApiResponse<List<WorkflowAuditDto>>
            {
                Success = true,
                Data = audit
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<List<WorkflowAuditDto>> { Success = false, Message = ex.Message });
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Notifications
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Get user notifications
    /// </summary>
    [HttpGet("notifications")]
    public async Task<ActionResult<ApiResponse<List<ChangeNotificationDto>>>> GetNotifications()
    {
        try
        {
            var userId = _currentUserService.GetUserId();
            var notifications = await _changeService.GetUserNotificationsAsync(userId);

            return Ok(new ApiResponse<List<ChangeNotificationDto>>
            {
                Success = true,
                Data = notifications
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new ApiResponse<List<ChangeNotificationDto>> { Success = false, Message = ex.Message });
        }
    }
}
