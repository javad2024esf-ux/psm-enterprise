using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;

namespace PSM.Api.Controllers;
/// <summary>
/// AI Integration Controller - Unified AI endpoints for all modules
/// Extends AIController with module-specific AI operations
/// 
/// Routes:
/// POST /api/ai/hazop/* - HAZOP AI suggestions
/// POST /api/ai/lopa/* - LOPA AI suggestions  
/// POST /api/ai/bowtie/* - BowTie AI suggestions
/// POST /api/ai/risk/* - Risk Assessment AI analysis
/// POST /api/ai/documents/* - Document AI analysis
/// POST /api/ai/recommendations/* - Recommendations generation
/// POST /api/ai/cross-module/* - Cross-module analysis
/// </summary>
[ApiController]
[Route("api/ai")]
[Authorize]
public class AIIntegrationController : ControllerBase
{
    private readonly IAiAssistService _aiService;
    private readonly IAuditService _auditService;
    private readonly IHazopService _hazopService;
    private readonly ILopaService _lopaService;
    private readonly IBowTieService _bowTieService;
    private readonly IIntegratedRiskService _riskService;
    private readonly IDocumentService _documentService;
    private readonly ILogger<AIIntegrationController> _logger;

    private const string MODULE_NAME = "AI-Integration";

    public AIIntegrationController(
        IAiAssistService aiService,
        IAuditService auditService,
        IHazopService hazopService,
        ILopaService lopaService,
        IBowTieService bowTieService,
        IIntegratedRiskService riskService,
        IDocumentService documentService,
        ILogger<AIIntegrationController> logger)
    {
        _aiService = aiService ?? throw new ArgumentNullException(nameof(aiService));
        _auditService = auditService ?? throw new ArgumentNullException(nameof(auditService));
        _hazopService = hazopService ?? throw new ArgumentNullException(nameof(hazopService));
        _lopaService = lopaService ?? throw new ArgumentNullException(nameof(lopaService));
        _bowTieService = bowTieService ?? throw new ArgumentNullException(nameof(bowTieService));
        _riskService = riskService ?? throw new ArgumentNullException(nameof(riskService));
        _documentService = documentService ?? throw new ArgumentNullException(nameof(documentService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    private string GetCurrentUserId() =>
        User.GetUserId() ?? throw new UnauthorizedAccessException("User ID claim is missing");

    // ═════════════════════════════════════════════════════════════════════════════
    // BOWTIE AI ENDPOINTS
    // ═════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// POST /api/ai/bowtie/suggest-top-event
    /// AI suggestion for BowTie top event
    /// </summary>
    [HttpPost("bowtie/suggest-top-event")]
    [Authorize(Policy = PsmPolicies.CanUseBowTieModule)]
    [ProducesResponseType(typeof(SuggestBowTieTopEventResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> SuggestBowTieTopEvent([FromBody] SuggestBowTieTopEventDto request)
    {
        try
        {
            var result = await _aiService.SuggestBowTieTopEventAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_BOWTIE_TOP_EVENT_SUGGESTED",
                module: MODULE_NAME);

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error suggesting BowTie top event");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// POST /api/ai/bowtie/suggest-threats
    /// AI suggestion for BowTie threats
    /// </summary>
    [HttpPost("bowtie/suggest-threats")]
    [Authorize(Policy = PsmPolicies.CanUseBowTieModule)]
    [ProducesResponseType(typeof(SuggestBowTieThreatsResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> SuggestBowTieThreats([FromBody] SuggestBowTieThreatsDto request)
    {
        try
        {
            var result = await _aiService.SuggestBowTieThreatsAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_BOWTIE_THREATS_SUGGESTED",
                module: MODULE_NAME);

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error suggesting BowTie threats");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// POST /api/ai/bowtie/suggest-consequences
    /// AI suggestion for BowTie consequences
    /// </summary>
    [HttpPost("bowtie/suggest-consequences")]
    [Authorize(Policy = PsmPolicies.CanUseBowTieModule)]
    [ProducesResponseType(typeof(SuggestBowTieConsequencesResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> SuggestBowTieConsequences([FromBody] SuggestBowTieConsequencesDto request)
    {
        try
        {
            var result = await _aiService.SuggestBowTieConsequencesAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_BOWTIE_CONSEQUENCES_SUGGESTED",
                module: MODULE_NAME);

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error suggesting BowTie consequences");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// POST /api/ai/bowtie/suggest-barriers
    /// AI suggestion for BowTie barriers
    /// </summary>
    [HttpPost("bowtie/suggest-barriers")]
    [Authorize(Policy = PsmPolicies.CanUseBowTieModule)]
    [ProducesResponseType(typeof(SuggestBowTieBarriersResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> SuggestBowTieBarriers([FromBody] SuggestBowTieBarriersDto request)
    {
        try
        {
            var result = await _aiService.SuggestBowTieBarriersAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_BOWTIE_BARRIERS_SUGGESTED",
                module: MODULE_NAME);

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error suggesting BowTie barriers");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// POST /api/ai/bowtie/assess-integrity
    /// AI assessment of BowTie diagram integrity
    /// </summary>
    [HttpPost("bowtie/assess-integrity")]
    [Authorize(Policy = PsmPolicies.CanUseBowTieModule)]
    [ProducesResponseType(typeof(AssessBowTieIntegrityResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> AssessBowTieIntegrity([FromBody] AssessBowTieIntegrityDto request)
    {
        try
        {
            var result = await _aiService.AssessBowTieIntegrityAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_BOWTIE_INTEGRITY_ASSESSED",
                module: MODULE_NAME);

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error assessing BowTie integrity");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // RISK ASSESSMENT AI ENDPOINTS
    // ═════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// POST /api/ai/risk/assess-integrated
    /// AI integrated risk assessment across all modules
    /// </summary>
    [HttpPost("risk/assess-integrated")]
    [Authorize(Policy = PsmPolicies.CanUseAI)]
    [ProducesResponseType(typeof(AssessIntegratedRiskResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> AssessIntegratedRisk([FromBody] AssessIntegratedRiskDto request)
    {
        try
        {
            var result = await _aiService.AssessIntegratedRiskAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_RISK_INTEGRATED_ASSESSED",
                module: MODULE_NAME);

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error assessing integrated risk");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// POST /api/ai/risk/recommend-controls
    /// AI recommendation of risk controls
    /// </summary>
    [HttpPost("risk/recommend-controls")]
    [Authorize(Policy = PsmPolicies.CanUseAI)]
    [ProducesResponseType(typeof(RecommendRiskControlsResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> RecommendRiskControls([FromBody] RecommendRiskControlsDto request)
    {
        try
        {
            var result = await _aiService.RecommendRiskControlsAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_RISK_CONTROLS_RECOMMENDED",
                module: MODULE_NAME);

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error recommending risk controls");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// POST /api/ai/risk/analyze-trends
    /// AI analysis of risk trends from incident history
    /// </summary>
    [HttpPost("risk/analyze-trends")]
    [Authorize(Policy = PsmPolicies.CanUseAI)]
    [ProducesResponseType(typeof(AnalyzeRiskTrendsResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> AnalyzeRiskTrends([FromBody] AnalyzeRiskTrendsDto request)
    {
        try
        {
            var result = await _aiService.AnalyzeRiskTrendsAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_RISK_TRENDS_ANALYZED",
                module: MODULE_NAME,
                details: $"Analyzed {request.HistoricalIncidents.Count} incidents");

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error analyzing risk trends");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // DOCUMENT AI ENDPOINTS
    // ═════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// POST /api/ai/documents/analyze
    /// AI analysis of document content
    /// </summary>
    [HttpPost("documents/analyze")]
    [Authorize(Policy = PsmPolicies.CanUseAI)]
    [ProducesResponseType(typeof(AnalyzeDocumentResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> AnalyzeDocument([FromBody] AnalyzeDocumentDto request)
    {
        try
        {
            var result = await _aiService.AnalyzeDocumentAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_DOCUMENT_ANALYZED",
                module: MODULE_NAME,
                details: $"Document: {request.DocumentTitle}, Type: {request.DocumentType}");

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error analyzing document");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// POST /api/ai/documents/generate-recommendations
    /// Generate AI recommendations from document analysis
    /// </summary>
    [HttpPost("documents/generate-recommendations")]
    [Authorize(Policy = PsmPolicies.CanUseAI)]
    [ProducesResponseType(typeof(GenerateDocumentRecommendationsResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GenerateDocumentRecommendations([FromBody] GenerateDocumentRecommendationsDto request)
    {
        try
        {
            var result = await _aiService.GenerateDocumentRecommendationsAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_DOCUMENT_RECOMMENDATIONS_GENERATED",
                module: MODULE_NAME);

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating document recommendations");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// POST /api/ai/documents/extract-data
    /// AI extraction of structured data from documents
    /// </summary>
    [HttpPost("documents/extract-data")]
    [Authorize(Policy = PsmPolicies.CanUseAI)]
    [ProducesResponseType(typeof(ExtractDocumentDataResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> ExtractDocumentData([FromBody] ExtractDocumentDataDto request)
    {
        try
        {
            var result = await _aiService.ExtractDocumentDataAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_DOCUMENT_DATA_EXTRACTED",
                module: MODULE_NAME);

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error extracting document data");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // RECOMMENDATIONS GENERATION ENDPOINTS
    // ═════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// POST /api/ai/recommendations/hazop
    /// Generate AI recommendations from HAZOP findings
    /// </summary>
    [HttpPost("recommendations/hazop")]
    [Authorize(Policy = PsmPolicies.CanUseHazopModule)]
    [ProducesResponseType(typeof(GenerateHazopRecommendationsResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GenerateHazopRecommendations([FromBody] GenerateHazopRecommendationsDto request)
    {
        try
        {
            var result = await _aiService.GenerateHazopRecommendationsAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_HAZOP_RECOMMENDATIONS_GENERATED",
                module: MODULE_NAME,
                details: $"HAZOP Study: {request.HazopStudyId}");

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating HAZOP recommendations");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// POST /api/ai/recommendations/lopa
    /// Generate AI recommendations to close LOPA IPL gaps
    /// </summary>
    [HttpPost("recommendations/lopa")]
    [Authorize(Policy = PsmPolicies.CanUseLopaModule)]
    [ProducesResponseType(typeof(GenerateLopaRecommendationsResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GenerateLopaRecommendations([FromBody] GenerateLopaRecommendationsDto request)
    {
        try
        {
            var result = await _aiService.GenerateLopaRecommendationsAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_LOPA_RECOMMENDATIONS_GENERATED",
                module: MODULE_NAME,
                details: $"LOPA Study: {request.LopaStudyId}");

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating LOPA recommendations");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    /// <summary>
    /// POST /api/ai/recommendations/prioritize
    /// AI prioritization of actions across modules
    /// </summary>
    [HttpPost("recommendations/prioritize")]
    [Authorize(Policy = PsmPolicies.CanUseAI)]
    [ProducesResponseType(typeof(PrioritizeActionsResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> PrioritizeActions([FromBody] PrioritizeActionsDto request)
    {
        try
        {
            var result = await _aiService.PrioritizeActionsAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_ACTIONS_PRIORITIZED",
                module: MODULE_NAME,
                details: $"Prioritized {request.Actions.Count} actions");

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error prioritizing actions");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // CROSS-MODULE ANALYSIS ENDPOINTS
    // ═════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// POST /api/ai/cross-module/analyze-consistency
    /// AI analysis of consistency across HAZOP, LOPA, and BowTie
    /// </summary>
    [HttpPost("cross-module/analyze-consistency")]
    [Authorize(Policy = PsmPolicies.CanUseAI)]
    [ProducesResponseType(typeof(AnalyzeCrossModuleConsistencyResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> AnalyzeCrossModuleConsistency([FromBody] AnalyzeCrossModuleConsistencyDto request)
    {
        try
        {
            var result = await _aiService.AnalyzeCrossModuleConsistencyAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_CROSS_MODULE_CONSISTENCY_ANALYZED",
                module: MODULE_NAME);

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error analyzing cross-module consistency");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // BULK ANALYSIS ENDPOINTS
    // ═════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// POST /api/ai/bulk/analyze
    /// Perform bulk AI analysis on multiple studies
    /// </summary>
    [HttpPost("bulk/analyze")]
    [Authorize(Policy = PsmPolicies.CanUseAI)]
    [ProducesResponseType(typeof(BulkAiAnalysisResponseDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> BulkAnalyze([FromBody] BulkAiAnalysisDto request)
    {
        try
        {
            var result = await _aiService.BulkAnalyzeAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_BULK_ANALYSIS_COMPLETED",
                module: MODULE_NAME,
                details: $"Module: {request.ModuleType}, Count: {request.ModuleIds.Count}, Success: {result.SuccessCount}, Failure: {result.FailureCount}");

            return Ok(new { success = true, data = result, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error performing bulk analysis");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // INTEGRATION STATUS ENDPOINT
    // ═════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// GET /api/ai/integration/status
    /// Get status of AI integration with all modules
    /// </summary>
    [HttpGet("integration/status")]
    [Authorize(Policy = PsmPolicies.CanUseAI)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetIntegrationStatus()
    {
        try
        {
            var health = await _aiService.GetHealthAsync();

            var status = new
            {
                aiPlatform = new
                {
                    status = health.Status,
                    connected = health.ApiConnected,
                    responseTimeMs = health.ResponseTimeMs
                },
                modules = new
                {
                    hazop = new { available = true, aiCapabilities = new[] { "suggest-causes", "suggest-consequences", "suggest-safeguards", "suggest-actions", "assess-risk" } },
                    lopa = new { available = true, aiCapabilities = new[] { "suggest-ipl", "estimate-ipl", "recommend-sil" } },
                    bowtie = new { available = true, aiCapabilities = new[] { "suggest-top-event", "suggest-threats", "suggest-consequences", "suggest-barriers", "assess-integrity" } },
                    riskAssessment = new { available = true, aiCapabilities = new[] { "assess-integrated-risk", "recommend-controls", "analyze-trends" } },
                    documents = new { available = true, aiCapabilities = new[] { "analyze-document", "generate-recommendations", "extract-data" } },
                    recommendations = new { available = true, aiCapabilities = new[] { "generate-hazop", "generate-lopa", "prioritize-actions" } }
                },
                crossModule = new
                {
                    available = true,
                    capabilities = new[] { "analyze-consistency", "bulk-analysis" }
                }
            };

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_INTEGRATION_STATUS_CHECKED",
                module: MODULE_NAME);

            return Ok(new { success = true, data = status, timestamp = DateTime.UtcNow });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting integration status");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }
}
