using PSM.Api.Data;
using PSM.Api.Middleware;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace PSM.Api.Controllers;

[ApiController]
[Route("api/settings")]
[Authorize]
public class SettingsController : ControllerBase
{
    private readonly IDbHelper _db;
    public SettingsController(IDbHelper db) => _db = db;

    // ─── کلیدهای ثابت در جدول settings ────────────────────────────────────────
    private static readonly string[] KnownKeys = new[]
    {
        "companyName", "customUnits", "userName", "userTitle",
        "activeModules", "theme", "language"
    };

    // GET /api/settings  —  همه settings را برمی‌گرداند
    // POST /api/settings  —  مقادیر ارسال‌شده را ذخیره می‌کند (upsert)
    [HttpGet]
    [HttpPost]
    public async Task<IActionResult> Settings([FromBody] JsonElement? body)
    {
        // ── اگر POST با بدنه است: ذخیره کن ────────────────────────────────────
        if (HttpContext.Request.Method == "POST" && body.HasValue &&
            body.Value.ValueKind == JsonValueKind.Object)
        {
            foreach (var prop in body.Value.EnumerateObject())
            {
                var val = prop.Value.ValueKind == JsonValueKind.String
                    ? prop.Value.GetString() ?? ""
                    : prop.Value.GetRawText();

                await _db.ExecuteAsync(@"
                    INSERT INTO settings (key, value, updated_at)
                    VALUES (@key, @value, NOW())
                    ON CONFLICT (key) DO UPDATE
                        SET value = EXCLUDED.value,
                            updated_at = NOW()",
                    new { key = prop.Name, value = val });
            }
        }

        // ── همیشه state فعلی را برگردان ────────────────────────────────────────
        var rows = await _db.QueryAsync<(string key, string value)>(
            "SELECT key, value FROM settings");

        var dict = new Dictionary<string, object?>();

        // مقادیر پیش‌فرض
        dict["companyName"]    = "";
        dict["customUnits"]    = Array.Empty<string>();
        dict["userName"]       = "";
        dict["userTitle"]      = "";
        dict["activeModules"]  = new Dictionary<string, bool>();
        dict["theme"]          = "light";
        dict["language"]       = "fa";

        foreach (var (key, value) in rows)
        {
            // JSON arrays/objects را parse کن
            if (value.TrimStart().StartsWith('[') || value.TrimStart().StartsWith('{'))
            {
                try { dict[key] = JsonSerializer.Deserialize<JsonElement>(value); continue; }
                catch { /* fallback to string */ }
            }
            dict[key] = value;
        }

        // metadata ثابت که frontend انتظار دارد
        dict["app"] = new
        {
            name    = "PSM Enterprise",
            version = "5.0",
            environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production"
        };

        return Ok(new { success = true, data = dict });
    }

    // ─── Backup / maintenance stubs ─────────────────────────────────────────────

    [HttpGet("backup/create")]
    [HttpPost("backup/create")]
    public IActionResult CreateBackup() =>
        Ok(new { success = false, error = "Backup not yet implemented", status = "planned" });

    [HttpGet("backup/list")]
    public IActionResult ListBackups() =>
        Ok(new { success = false, error = "Backup not yet implemented", status = "planned", backups = Array.Empty<object>() });

    [HttpGet("backup/import")]
    [HttpPost("backup/import")]
    public IActionResult ImportBackup() =>
        Ok(new { success = false, error = "Backup not yet implemented", status = "planned" });

    [HttpGet("clear-all-data")]
    [HttpPost("clear-all-data")]
    public IActionResult ClearAllData()
    {
        var env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production";
        if (env != "Development")
            return BadRequest(new { success = false, error = "Only available in Development mode" });
        return Ok(new { success = false, error = "Not implemented — requires explicit confirmation" });
    }
}
