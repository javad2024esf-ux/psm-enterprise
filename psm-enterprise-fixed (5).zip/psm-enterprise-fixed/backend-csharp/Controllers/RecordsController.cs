using PSM.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;
using PSM.Api.Utilities;

namespace PSM.Api.Controllers;

[ApiController]
[Route("api")]
[Authorize]
public class RecordsController : ControllerBase
{
    private readonly IRecordService     _records;
    private readonly IPermissionService _perms;
    private readonly IAuditService      _audit;

    public RecordsController(IRecordService records, IPermissionService perms, IAuditService audit)
    {
        _records = records;
        _perms   = perms;
        _audit   = audit;
    }

    // GET /api/records?element=hazop&unit=A&limit=100
    [HttpGet("records")]
    public async Task<IActionResult> List(
        [FromQuery] string? element,
        [FromQuery] string? unit,
        [FromQuery] string? status,
        [FromQuery] int limit  = 200,
        [FromQuery] int offset = 0)
    {
        // Validate required parameters
        if (string.IsNullOrEmpty(element))
            return BadRequest(new { success = false, error = "پارامتر element الزامی است" });

        // Validate collection name against whitelist (prevents SQL injection)
        if (!InputValidator.IsValidCollection(element))
            return BadRequest(new { success = false, error = "نام element نامعتبر است" });

        // Validate optional unit
        if (!InputValidator.IsValidUnit(unit))
            return BadRequest(new { success = false, error = "نام unit نامعتبر است" });

        // Validate status if provided
        if (!InputValidator.IsValidStatus(status))
            return BadRequest(new { success = false, error = "وضعیت نامعتبر است" });

        // Validate pagination parameters
        (limit, offset) = InputValidator.ValidatePagination(limit, offset);

        var role     = User.GetRole();
        var userUnit = User.GetUnit();

        if (!await _perms.CheckPermissionAsync(role, element, PsmAction.Read))
            return StatusCode(403, new { success = false, error = "دسترسی ندارید" });

        var effectiveUnit = _perms.IsUnitRestricted(role, element)
            ? (unit ?? userUnit)
            : unit;

        var (rows, total) = await _records.ListAsync(element, effectiveUnit, status, limit, offset, role, userUnit);
        return Ok(new { success = true, data = rows, total, count = total });
    }

    // GET /api/records/search
    [HttpGet("records/search")]
    public async Task<IActionResult> Search(
        [FromQuery] string? element,
        [FromQuery] string? q,
        [FromQuery] int limit = 50)
    {
        if (string.IsNullOrEmpty(element) || string.IsNullOrEmpty(q))
            return BadRequest(new { success = false, error = "element و q الزامی است" });

        // Validate collection name
        if (!InputValidator.IsValidCollection(element))
            return BadRequest(new { success = false, error = "نام element نامعتبر است" });

        // Validate search query (prevents injection and DoS)
        if (!InputValidator.IsValidSearchQuery(q))
            return BadRequest(new { success = false, error = "درخواست جستجو نامعتبر است" });

        // Validate limit
        limit = Math.Min(Math.Max(limit, 1), 100);

        var rows = await _records.SearchAsync(element, q, limit);
        return Ok(new { success = true, data = rows });
    }

    // GET /api/records/count
    [HttpGet("records/count")]
    public async Task<IActionResult> Count([FromQuery] string? element)
    {
        if (string.IsNullOrEmpty(element))
            return BadRequest(new { success = false, error = "element الزامی است" });

        // Validate collection name
        if (!InputValidator.IsValidCollection(element))
            return BadRequest(new { success = false, error = "نام element نامعتبر است" });

        var count = await _records.CountAsync(element);
        return Ok(new { success = true, count });
    }

    // POST /api/records
    [HttpPost("records")]
    public async Task<IActionResult> Create([FromBody] CreateRecordRequest req)
    {
        var userId     = User.GetUserId()!;
        var role       = User.GetRole();
        var collection = req.ResolvedCollection;

        if (string.IsNullOrEmpty(collection))
            return BadRequest(new { success = false, error = "پارامتر element یا collection الزامی است" });

        if (!await _perms.CheckPermissionAsync(role, collection, PsmAction.Write))
            return StatusCode(403, new { success = false, error = "دسترسی ندارید" });

        var id = await _records.CreateAsync(req, userId, role);
        await _audit.WriteAsync(userId, "CREATE_RECORD", collection, id);
        return StatusCode(201, new { success = true, data = new { id } });
    }

    // PATCH /api/records/:id
    [HttpPatch("records/{id}")]
    public async Task<IActionResult> Update(string id, [FromBody] UpdateRecordRequest req)
    {
        var userId     = User.GetUserId()!;
        var role       = User.GetRole();
        var collection = req.Collection ?? "records";

        if (!await _perms.CheckPermissionAsync(role, collection, PsmAction.Write))
            return StatusCode(403, new { success = false, error = "دسترسی ندارید" });

        var error = await _records.UpdateAsync(id, req, userId);
        if (error is not null) return NotFound(new { success = false, error });

        await _audit.WriteAsync(userId, "UPDATE_RECORD", collection, id);
        return Ok(new { success = true });
    }

    // DELETE /api/records/:id
    [HttpDelete("records/{id}")]
    public async Task<IActionResult> Delete(string id, [FromQuery] string? element)
    {
        var userId     = User.GetUserId()!;
        var role       = User.GetRole();
        var collection = element ?? "records";

        if (!await _perms.CheckPermissionAsync(role, collection, PsmAction.Delete))
            return StatusCode(403, new { success = false, error = "دسترسی ندارید" });

        var error = await _records.DeleteAsync(id, userId);
        if (error is not null) return NotFound(new { success = false, error });

        await _audit.WriteAsync(userId, "DELETE_RECORD", collection, id);
        return Ok(new { success = true });
    }

    // GET /api/dashboard/stats
    [HttpGet("dashboard/stats")]
    public async Task<IActionResult> DashboardStats()
    {
        var collections = new[] { "hazop", "lopa", "pssr", "work_permit", "incident",
                                   "audit", "training", "mechanical_integrity", "moc" };
        var stats = new Dictionary<string, long>();
        foreach (var c in collections)
            stats[c] = await _records.CountAsync(c);

        return Ok(new { success = true, data = stats });
    }

    // ── Workflow-specific endpoints with Policy-Based Authorization ────────────

    // POST /api/work-permits/:id/approve  →  CanApprovePermit
    [HttpPost("work-permits/{id}/approve")]
    [Authorize(Policy = PsmPolicies.CanApprovePermit)]
    public async Task<IActionResult> ApproveWorkPermit(string id)
    {
        var userId = User.GetUserId()!;
        var error  = await _records.UpdateStatusAsync(id, "APPROVED", userId);
        if (error is not null) return NotFound(new { success = false, error });

        await _audit.WriteAsync(userId, "APPROVE_WORK_PERMIT", "work_permit", id);
        return Ok(new { success = true });
    }

    // POST /api/hazop/:id/close  →  CanCloseHazop
    [HttpPost("hazop/{id}/close")]
    [Authorize(Policy = PsmPolicies.CanCloseHazop)]
    public async Task<IActionResult> CloseHazop(string id)
    {
        var userId = User.GetUserId()!;
        var error  = await _records.UpdateStatusAsync(id, "CLOSED", userId);
        if (error is not null) return NotFound(new { success = false, error });

        await _audit.WriteAsync(userId, "CLOSE_HAZOP", "hazop", id);
        return Ok(new { success = true });
    }

    // POST /api/moc/:id/review  →  CanReviewMOC
    [HttpPost("moc/{id}/review")]
    [Authorize(Policy = PsmPolicies.CanReviewMOC)]
    public async Task<IActionResult> ReviewMoc(string id)
    {
        var userId = User.GetUserId()!;
        var error  = await _records.UpdateStatusAsync(id, "UNDER_REVIEW", userId);
        if (error is not null) return NotFound(new { success = false, error });

        await _audit.WriteAsync(userId, "REVIEW_MOC", "moc", id);
        return Ok(new { success = true });
    }

    // POST /api/moc/:id/approve  →  CanApproveMOC
    [HttpPost("moc/{id}/approve")]
    [Authorize(Policy = PsmPolicies.CanApproveMOC)]
    public async Task<IActionResult> ApproveMoc(string id)
    {
        var userId = User.GetUserId()!;
        var error  = await _records.UpdateStatusAsync(id, "APPROVED", userId);
        if (error is not null) return NotFound(new { success = false, error });

        await _audit.WriteAsync(userId, "APPROVE_MOC", "moc", id);
        return Ok(new { success = true });
    }

    // POST /api/pssr/:id/approve  →  CanApprovePSSR
    [HttpPost("pssr/{id}/approve")]
    [Authorize(Policy = PsmPolicies.CanApprovePSSR)]
    public async Task<IActionResult> ApprovePssr(string id)
    {
        var userId = User.GetUserId()!;
        var error  = await _records.UpdateStatusAsync(id, "APPROVED", userId);
        if (error is not null) return NotFound(new { success = false, error });

        await _audit.WriteAsync(userId, "APPROVE_PSSR", "pssr", id);
        return Ok(new { success = true });
    }

    // POST /api/incidents/:id/close  →  CanCloseIncident
    [HttpPost("incidents/{id}/close")]
    [Authorize(Policy = PsmPolicies.CanCloseIncident)]
    public async Task<IActionResult> CloseIncident(string id)
    {
        var userId = User.GetUserId()!;
        var error  = await _records.UpdateStatusAsync(id, "CLOSED", userId);
        if (error is not null) return NotFound(new { success = false, error });

        await _audit.WriteAsync(userId, "CLOSE_INCIDENT", "incident", id);
        return Ok(new { success = true });
    }
}
