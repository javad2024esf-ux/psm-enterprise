using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

/// <summary>
/// کنترلر کامل زنجیره HAZOP:
/// Study → Node → Deviation → Cause → Consequence → Safeguard
///       → Recommendation → Action Register → Workflow → Notification → Audit
/// </summary>
[ApiController]
[Route("api/hazop/chain")]
[Authorize]
public class HazopChainController : ControllerBase
{
    private readonly IHazopChainService              _svc;
    private readonly ILogger<HazopChainController>   _log;

    private string UserId   => User.GetUserId()   ?? "unknown";
    private string UserName => User.GetUsername() ?? "unknown";

    public HazopChainController(IHazopChainService svc, ILogger<HazopChainController> log)
    {
        _svc = svc;
        _log = log;
    }

    // ════════════════════════════════════════════════════════════════════════
    // ① Causes — علل انحراف
    // ════════════════════════════════════════════════════════════════════════

    /// <summary>GET /api/hazop/chain/deviations/{deviationId}/causes</summary>
    [HttpGet("deviations/{deviationId}/causes")]
    [Authorize(Policy = PsmPolicies.CanReadHazop)]
    public async Task<IActionResult> ListCauses(string deviationId)
    {
        try { return Ok(await _svc.ListCausesAsync(deviationId)); }
        catch (Exception e) { return E500(e); }
    }

    /// <summary>POST /api/hazop/chain/deviations/{deviationId}/causes</summary>
    [HttpPost("deviations/{deviationId}/causes")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> CreateCause(string deviationId, [FromBody] CreateHazopCauseRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.description))
            return BadRequest(new { error = "توضیح علت الزامی است" });
        req.deviation_id = deviationId;
        try { return StatusCode(201, await _svc.CreateCauseAsync(req, UserId)); }
        catch (Exception e) { return E500(e); }
    }

    /// <summary>PUT /api/hazop/chain/causes/{id}</summary>
    [HttpPut("causes/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> UpdateCause(string id, [FromBody] UpdateHazopCauseRequest req)
    {
        try
        {
            var result = await _svc.UpdateCauseAsync(id, req, UserId);
            return result is null ? NotFound() : Ok(result);
        }
        catch (Exception e) { return E500(e); }
    }

    /// <summary>DELETE /api/hazop/chain/causes/{id}</summary>
    [HttpDelete("causes/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> DeleteCause(string id)
    {
        try { return (await _svc.DeleteCauseAsync(id, UserId)) ? Ok(new { success = true }) : NotFound(); }
        catch (Exception e) { return E500(e); }
    }

    // ════════════════════════════════════════════════════════════════════════
    // ② Consequences — پیامدها
    // ════════════════════════════════════════════════════════════════════════

    [HttpGet("deviations/{deviationId}/consequences")]
    [Authorize(Policy = PsmPolicies.CanReadHazop)]
    public async Task<IActionResult> ListConsequences(string deviationId)
    {
        try { return Ok(await _svc.ListConsequencesAsync(deviationId)); }
        catch (Exception e) { return E500(e); }
    }

    [HttpPost("deviations/{deviationId}/consequences")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> CreateConsequence(string deviationId, [FromBody] CreateHazopConsequenceRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.description))
            return BadRequest(new { error = "توضیح پیامد الزامی است" });
        req.deviation_id = deviationId;
        try { return StatusCode(201, await _svc.CreateConsequenceAsync(req, UserId)); }
        catch (Exception e) { return E500(e); }
    }

    [HttpPut("consequences/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> UpdateConsequence(string id, [FromBody] UpdateHazopConsequenceRequest req)
    {
        try
        {
            var result = await _svc.UpdateConsequenceAsync(id, req, UserId);
            return result is null ? NotFound() : Ok(result);
        }
        catch (Exception e) { return E500(e); }
    }

    [HttpDelete("consequences/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> DeleteConsequence(string id)
    {
        try { return (await _svc.DeleteConsequenceAsync(id, UserId)) ? Ok(new { success = true }) : NotFound(); }
        catch (Exception e) { return E500(e); }
    }

    // ════════════════════════════════════════════════════════════════════════
    // ③ Safeguards — حفاظ‌ها
    // ════════════════════════════════════════════════════════════════════════

    [HttpGet("deviations/{deviationId}/safeguards")]
    [Authorize(Policy = PsmPolicies.CanReadHazop)]
    public async Task<IActionResult> ListSafeguards(string deviationId)
    {
        try { return Ok(await _svc.ListSafeguardsAsync(deviationId)); }
        catch (Exception e) { return E500(e); }
    }

    [HttpPost("deviations/{deviationId}/safeguards")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> CreateSafeguard(string deviationId, [FromBody] CreateHazopSafeguardRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.description))
            return BadRequest(new { error = "توضیح حفاظ الزامی است" });
        req.deviation_id = deviationId;
        try { return StatusCode(201, await _svc.CreateSafeguardAsync(req, UserId)); }
        catch (Exception e) { return E500(e); }
    }

    [HttpPut("safeguards/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> UpdateSafeguard(string id, [FromBody] UpdateHazopSafeguardRequest req)
    {
        try
        {
            var result = await _svc.UpdateSafeguardAsync(id, req, UserId);
            return result is null ? NotFound() : Ok(result);
        }
        catch (Exception e) { return E500(e); }
    }

    [HttpDelete("safeguards/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> DeleteSafeguard(string id)
    {
        try { return (await _svc.DeleteSafeguardAsync(id, UserId)) ? Ok(new { success = true }) : NotFound(); }
        catch (Exception e) { return E500(e); }
    }

    // ════════════════════════════════════════════════════════════════════════
    // ④ Recommendations — توصیه‌ها
    // ════════════════════════════════════════════════════════════════════════

    [HttpGet("studies/{studyId}/recommendations")]
    [Authorize(Policy = PsmPolicies.CanReadHazop)]
    public async Task<IActionResult> ListRecommendations(string studyId)
    {
        try { return Ok(await _svc.ListRecommendationsAsync(studyId)); }
        catch (Exception e) { return E500(e); }
    }

    [HttpGet("deviations/{deviationId}/recommendations")]
    [Authorize(Policy = PsmPolicies.CanReadHazop)]
    public async Task<IActionResult> ListRecommendationsByDeviation(string deviationId)
    {
        try { return Ok(await _svc.ListRecommendationsByDeviationAsync(deviationId)); }
        catch (Exception e) { return E500(e); }
    }

    [HttpPost("recommendations")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> CreateRecommendation([FromBody] CreateHazopRecommendationRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.recommendation_text))
            return BadRequest(new { error = "متن توصیه الزامی است" });
        if (string.IsNullOrWhiteSpace(req.deviation_id))
            return BadRequest(new { error = "deviation_id الزامی است" });
        try { return StatusCode(201, await _svc.CreateRecommendationAsync(req, UserId)); }
        catch (Exception e) { return E500(e); }
    }

    [HttpPut("recommendations/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> UpdateRecommendation(string id, [FromBody] UpdateHazopRecommendationRequest req)
    {
        try
        {
            var result = await _svc.UpdateRecommendationAsync(id, req, UserId);
            return result is null ? NotFound() : Ok(result);
        }
        catch (Exception e) { return E500(e); }
    }

    [HttpDelete("recommendations/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> DeleteRecommendation(string id)
    {
        try { return (await _svc.DeleteRecommendationAsync(id, UserId)) ? Ok(new { success = true }) : NotFound(); }
        catch (Exception e) { return E500(e); }
    }

    // ════════════════════════════════════════════════════════════════════════
    // ⑤ Action Register — ثبت اقدامات
    // ════════════════════════════════════════════════════════════════════════

    [HttpGet("studies/{studyId}/actions")]
    [Authorize(Policy = PsmPolicies.CanReadHazop)]
    public async Task<IActionResult> ListActions(string studyId)
    {
        try { return Ok(await _svc.ListActionsAsync(studyId)); }
        catch (Exception e) { return E500(e); }
    }

    /// <summary>تبدیل توصیه به اقدام در Action Register</summary>
    [HttpPost("recommendations/{recommendationId}/promote-to-action")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> PromoteToAction(string recommendationId,
        [FromBody] CreateActionFromHazopRequest? req = null)
    {
        try
        {
            var action = await _svc.CreateActionFromRecommendationAsync(
                recommendationId,
                req?.Responsible,
                req?.DueDate,
                UserId);
            return StatusCode(201, action);
        }
        catch (KeyNotFoundException e) { return NotFound(new { error = e.Message }); }
        catch (Exception e)            { return E500(e); }
    }

    [HttpPut("actions/{id}/status")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> UpdateActionStatus(string id,
        [FromBody] UpdateActionStatusRequest req)
    {
        try
        {
            var result = await _svc.UpdateActionStatusAsync(id, req.status,
                req.completed_date, req.verified_by, req.verification_note, UserId);
            return result is null ? NotFound() : Ok(result);
        }
        catch (Exception e) { return E500(e); }
    }

    [HttpDelete("actions/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> DeleteAction(string id)
    {
        try { return (await _svc.DeleteActionAsync(id, UserId)) ? Ok(new { success = true }) : NotFound(); }
        catch (Exception e) { return E500(e); }
    }

    // ════════════════════════════════════════════════════════════════════════
    // ⑥ Workflow — گردش کار
    // ════════════════════════════════════════════════════════════════════════

    [HttpGet("workflow/{entityType}/{entityId}")]
    [Authorize(Policy = PsmPolicies.CanReadWorkflow)]
    public async Task<IActionResult> GetWorkflow(string entityType, string entityId)
    {
        try
        {
            var inst = await _svc.GetWorkflowAsync(entityType, entityId);
            return inst is null ? NotFound() : Ok(inst);
        }
        catch (Exception e) { return E500(e); }
    }

    [HttpPost("workflow/start")]
    [Authorize(Policy = PsmPolicies.CanWriteWorkflow)]
    public async Task<IActionResult> StartWorkflow([FromBody] StartHazopWorkflowRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.entity_id))
            return BadRequest(new { error = "entity_id الزامی است" });
        try { return StatusCode(201, await _svc.StartWorkflowAsync(req, UserId)); }
        catch (Exception e) { return E500(e); }
    }

    [HttpPost("workflow/transition")]
    [Authorize(Policy = PsmPolicies.CanWriteWorkflow)]
    public async Task<IActionResult> Transition([FromBody] HazopWorkflowTransitionRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.entity_id) || string.IsNullOrWhiteSpace(req.action))
            return BadRequest(new { error = "entity_id و action الزامی است" });
        try
        {
            var result = await _svc.TransitionWorkflowAsync(req, UserId, UserName);
            return result is null ? NotFound() : Ok(result);
        }
        catch (ArgumentException e) { return BadRequest(new { error = e.Message }); }
        catch (Exception e)         { return E500(e); }
    }

    [HttpGet("workflow/pending")]
    [Authorize(Policy = PsmPolicies.CanReadWorkflow)]
    public async Task<IActionResult> PendingWorkflows([FromQuery] bool my_items = false)
    {
        try { return Ok(await _svc.ListPendingWorkflowsAsync(my_items ? UserId : null)); }
        catch (Exception e) { return E500(e); }
    }

    // ════════════════════════════════════════════════════════════════════════
    // ⑦ Full Chain — زنجیره کامل یک انحراف
    // ════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// GET /api/hazop/chain/deviations/{deviationId}/full
    /// دریافت کامل زنجیره یک انحراف:
    /// Deviation + Causes + Consequences + Safeguards + Recommendations + Actions + Workflow + Audit
    /// </summary>
    [HttpGet("deviations/{deviationId}/full")]
    [Authorize(Policy = PsmPolicies.CanReadHazop)]
    public async Task<IActionResult> GetDeviationFullChain(string deviationId)
    {
        try
        {
            var chain = await _svc.GetDeviationFullChainAsync(deviationId);
            return chain is null ? NotFound(new { error = "انحراف یافت نشد" }) : Ok(chain);
        }
        catch (Exception e) { return E500(e); }
    }

    // ════════════════════════════════════════════════════════════════════════
    // ⑧ Analytics — آمار کامل زنجیره
    // ════════════════════════════════════════════════════════════════════════

    [HttpGet("analytics")]
    [Authorize(Policy = PsmPolicies.CanReadHazop)]
    public async Task<IActionResult> ChainAnalytics([FromQuery] string? study_id = null)
    {
        try { return Ok(await _svc.GetChainAnalyticsAsync(study_id)); }
        catch (Exception e) { return E500(e); }
    }

    // ─── Private ─────────────────────────────────────────────────────────────
    private ObjectResult E500(Exception e)
    {
        _log.LogError(e, "HazopChain error");
        return StatusCode(500, new { error = e.Message });
    }
}

// DTO کمکی
public class UpdateActionStatusRequest
{
    public string    status            { get; set; } = "Open";
    public DateTime? completed_date    { get; set; }
    public string?   verified_by       { get; set; }
    public string?   verification_note { get; set; }
}
