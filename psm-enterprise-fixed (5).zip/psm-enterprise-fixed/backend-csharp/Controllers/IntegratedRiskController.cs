using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

// ════════════════════════════════════════════════════════════════════════════════════
// BARRIER CONTROLLER
// ════════════════════════════════════════════════════════════════════════════════════

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class BarriersController : ControllerBase
{
    private readonly IBarrierService _barrierService;
    private readonly ILogger<BarriersController> _logger;

    public BarriersController(IBarrierService barrierService, ILogger<BarriersController> logger)
    {
        _barrierService = barrierService;
        _logger = logger;
    }

    /// <summary>
    /// List all barriers with optional filtering and linked analysis counts
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<BarrierDto>>> ListBarriers(
        [FromQuery] string? status = null)
    {
        try
        {
            var barriers = await _barrierService.ListBarriersAsync(status);
            return Ok(barriers);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing barriers");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// List barriers with linked HAZOP, LOPA, BowTie and incident counts
    /// </summary>
    [HttpGet("with-analysis")]
    public async Task<ActionResult<IEnumerable<BarrierWithRelatedAnalysisDto>>> ListBarriersWithAnalysis()
    {
        try
        {
            var barriers = await _barrierService.ListBarriersWithAnalysisAsync();
            return Ok(barriers);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing barriers with analysis");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Get a specific barrier by ID
    /// </summary>
    [HttpGet("{id}")]
    public async Task<ActionResult<BarrierDto>> GetBarrier(string id)
    {
        try
        {
            var barrier = await _barrierService.GetBarrierAsync(id);
            if (barrier == null)
                return NotFound(new { message = "Barrier not found" });

            return Ok(barrier);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting barrier");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Get barrier by LOPA IPL ID
    /// </summary>
    [HttpGet("by-lopa-ipl/{lopaIplId}")]
    public async Task<ActionResult<BarrierDto>> GetBarrierByLopaIpl(string lopaIplId)
    {
        try
        {
            var barrier = await _barrierService.GetBarrierByLopaIplAsync(lopaIplId);
            if (barrier == null)
                return NotFound(new { message = "Barrier not found for this LOPA IPL" });

            return Ok(barrier);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting barrier by LOPA IPL");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Create a new barrier (typically from LOPA IPL)
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<BarrierDto>> CreateBarrier([FromBody] CreateBarrierRequest req)
    {
        try
        {
            if (string.IsNullOrEmpty(req.lopa_ipl_id))
                return BadRequest(new { error = "lopa_ipl_id is required" });

            var barrier = await _barrierService.CreateBarrierAsync(req);
            return CreatedAtAction(nameof(GetBarrier), new { id = barrier.Id }, barrier);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating barrier");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Update barrier details
    /// </summary>
    [HttpPut("{id}")]
    public async Task<ActionResult> UpdateBarrier(string id, [FromBody] UpdateBarrierRequest req)
    {
        try
        {
            var barrier = await _barrierService.GetBarrierAsync(id);
            if (barrier == null)
                return NotFound(new { message = "Barrier not found" });

            await _barrierService.UpdateBarrierAsync(id, req);
            return Ok(new { message = "Barrier updated successfully" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating barrier");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Update barrier status with cascade to BowTie and LOPA
    /// </summary>
    [HttpPut("{id}/status")]
    public async Task<ActionResult> UpdateBarrierStatus(string id, [FromBody] UpdateBarrierStatusRequest req)
    {
        try
        {
            var userId = User.FindFirst("sub")?.Value;
            var (success, message) = await _barrierService.UpdateBarrierStatusAsync(id, req, userId);

            if (!success)
                return BadRequest(new { error = message });

            return Ok(new { message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating barrier status");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Get barrier status change history
    /// </summary>
    [HttpGet("{id}/status-history")]
    public async Task<ActionResult<IEnumerable<BarrierStatusHistoryDto>>> GetBarrierStatusHistory(string id)
    {
        try
        {
            var history = await _barrierService.GetBarrierStatusHistoryAsync(id);
            return Ok(history);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting barrier status history");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Get barrier status distribution
    /// </summary>
    [HttpGet("analytics/status-distribution")]
    public async Task<ActionResult<Dictionary<string, int>>> GetStatusDistribution()
    {
        try
        {
            var distribution = await _barrierService.GetBarrierStatusDistributionAsync();
            return Ok(distribution);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting barrier status distribution");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Get count of critical barriers
    /// </summary>
    [HttpGet("analytics/critical-count")]
    public async Task<ActionResult<int>> GetCriticalBarrierCount()
    {
        try
        {
            var count = await _barrierService.GetCriticalBarrierCountAsync();
            return Ok(new { critical_barriers = count });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting critical barrier count");
            return StatusCode(500, new { error = ex.Message });
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT CONTROLLER
// ════════════════════════════════════════════════════════════════════════════════════

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class IncidentsController : ControllerBase
{
    private readonly IIncidentService _incidentService;
    private readonly IIntegratedRiskService _integratedRiskService;
    private readonly ILogger<IncidentsController> _logger;

    public IncidentsController(
        IIncidentService incidentService,
        IIntegratedRiskService integratedRiskService,
        ILogger<IncidentsController> logger)
    {
        _incidentService = incidentService;
        _integratedRiskService = integratedRiskService;
        _logger = logger;
    }

    /// <summary>
    /// List incidents with optional filtering
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<IncidentDto>>> ListIncidents(
        [FromQuery] string? status = null,
        [FromQuery] int page = 1)
    {
        try
        {
            var incidents = await _incidentService.ListIncidentsAsync(status, page);
            return Ok(incidents);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing incidents");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Get a specific incident by ID
    /// </summary>
    [HttpGet("{id}")]
    public async Task<ActionResult<IncidentDto>> GetIncident(string id)
    {
        try
        {
            var incident = await _incidentService.GetIncidentAsync(id);
            if (incident == null)
                return NotFound(new { message = "Incident not found" });

            return Ok(incident);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting incident");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Create a new incident
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<IncidentDto>> CreateIncident([FromBody] CreateIncidentRequest req)
    {
        try
        {
            if (string.IsNullOrEmpty(req.title))
                return BadRequest(new { error = "title is required" });

            var incident = await _incidentService.CreateIncidentAsync(req);
            return CreatedAtAction(nameof(GetIncident), new { id = incident.Id }, incident);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating incident");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Update incident details
    /// </summary>
    [HttpPut("{id}")]
    public async Task<ActionResult> UpdateIncident(string id, [FromBody] UpdateIncidentRequest req)
    {
        try
        {
            var incident = await _incidentService.GetIncidentAsync(id);
            if (incident == null)
                return NotFound(new { message = "Incident not found" });

            await _incidentService.UpdateIncidentAsync(id, req);
            return Ok(new { message = "Incident updated successfully" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating incident");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Close an incident with lessons learned
    /// </summary>
    [HttpPut("{id}/close")]
    public async Task<ActionResult> CloseIncident(string id, [FromBody] CloseIncidentRequest req)
    {
        try
        {
            var success = await _incidentService.CloseIncidentAsync(id, req);
            if (!success)
                return NotFound(new { message = "Incident not found" });

            return Ok(new { message = "Incident closed successfully" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error closing incident");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Create actions from all recommendations in an incident.
    /// Automatically creates separate actions for: Immediate, Corrective, and Preventive recommendations.
    /// Each action is linked to the incident via Source=Incident, SourceId=incidentId.
    /// </summary>
    [HttpPost("{id}/create-actions")]
    [Authorize(Policy = PsmPolicies.CanWriteActions)]
    public async Task<ActionResult> CreateActionsFromRecommendations(string id)
    {
        try
        {
            var userId = User.GetUserId() ?? "unknown";
            var createdActions = await _incidentService.CreateActionsFromRecommendationsAsync(id, userId);

            if (!createdActions.Any())
            {
                return Ok(new 
                { 
                    message = "هیچ توصیه ای برای تبدیل به اقدام یافت نشد",
                    createdActions = createdActions
                });
            }

            _logger.LogInformation("Actions created from incident {IncidentId} by {UserId}: Count={Count}",
                id, userId, createdActions.Count());

            return Ok(new 
            { 
                success = true,
                message = $"{createdActions.Count()} اقدام با موفقیت ایجاد شد",
                createdActions = createdActions
            });
        }
        catch (KeyNotFoundException ex)
        {
            _logger.LogWarning(ex, "Incident not found: {IncidentId}", id);
            return NotFound(new { message = "حادثه یافت نشد" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating actions from incident {IncidentId}", id);
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Link a barrier to an incident
    /// </summary>
    [HttpPost("{id}/barriers")]
    public async Task<ActionResult<IncidentBarrierDto>> LinkBarrier(
        string id, [FromBody] CreateIncidentBarrierRequest req)
    {
        try
        {
            req.incident_id = id;
            var result = await _incidentService.LinkBarrierAsync(req);
            return CreatedAtAction(nameof(GetIncident), new { id }, result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error linking barrier to incident");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Get barriers linked to an incident
    /// </summary>
    [HttpGet("{id}/barriers")]
    public async Task<ActionResult<IEnumerable<IncidentBarrierDto>>> GetIncidentBarriers(string id)
    {
        try
        {
            var barriers = await _incidentService.GetIncidentBarriersAsync(id);
            return Ok(barriers);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting incident barriers");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Get comprehensive impact analysis for an incident
    /// </summary>
    [HttpGet("{id}/impact-analysis")]
    public async Task<ActionResult<IncidentDetailedAnalysisDto>> GetIncidentImpact(string id)
    {
        try
        {
            var analysis = await _integratedRiskService.GetIncidentImpactAnalysisAsync(id);
            return Ok(analysis);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting incident impact analysis");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Batch link barriers to an incident
    /// </summary>
    [HttpPost("{id}/barriers/batch")]
    public async Task<ActionResult<BatchOperationResultDto>> BatchLinkBarriers(
        string id, [FromBody] BatchCreateIncidentBarriersRequest req)
    {
        try
        {
            req.incident_id = id;
            var result = await _integratedRiskService.BatchLinkBarriersToIncidentAsync(req);
            return Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error batch linking barriers");
            return StatusCode(500, new { error = ex.Message });
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INTEGRATED RISK ANALYSIS CONTROLLER
// ════════════════════════════════════════════════════════════════════════════════════

[ApiController]
[Route("api/risk-analysis")]
[Authorize]
public class IntegratedRiskAnalysisController : ControllerBase
{
    private readonly IIntegratedRiskService _integratedRiskService;
    private readonly ILogger<IntegratedRiskAnalysisController> _logger;

    public IntegratedRiskAnalysisController(
        IIntegratedRiskService integratedRiskService,
        ILogger<IntegratedRiskAnalysisController> logger)
    {
        _integratedRiskService = integratedRiskService;
        _logger = logger;
    }

    /// <summary>
    /// Get comprehensive impact when a barrier fails
    /// Shows affected HAZOP, LOPA, and BowTie analyses
    /// </summary>
    [HttpGet("barrier-impact/{barrierId}")]
    public async Task<ActionResult<BarrierFailureImpactDto>> GetBarrierImpact(string barrierId)
    {
        try
        {
            var impact = await _integratedRiskService.GetBarrierImpactAsync(barrierId);
            return Ok(impact);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting barrier impact");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Get comprehensive incident analysis
    /// Shows linked barriers, HAZOP, LOPA, and BowTie diagrams
    /// </summary>
    [HttpGet("incident-impact/{incidentId}")]
    public async Task<ActionResult<IncidentDetailedAnalysisDto>> GetIncidentImpact(string incidentId)
    {
        try
        {
            var impact = await _integratedRiskService.GetIncidentImpactAnalysisAsync(incidentId);
            return Ok(impact);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting incident impact");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Handle barrier failure with cascade updates
    /// </summary>
    [HttpPost("barrier-failure/{barrierId}")]
    public async Task<ActionResult<BarrierFailureImpactDto>> HandleBarrierFailure(
        string barrierId, [FromBody] UpdateBarrierStatusRequest req)
    {
        try
        {
            var userId = User.FindFirst("sub")?.Value;
            var impact = await _integratedRiskService.HandleBarrierFailureAsync(
                barrierId, req.reason ?? "Barrier failure", userId);
            return Ok(impact);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error handling barrier failure");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Find all incidents related to a specific analysis
    /// </summary>
    [HttpGet("find-related-incidents")]
    public async Task<ActionResult<IEnumerable<IncidentDto>>> FindRelatedIncidents(
        [FromQuery] string? hazopId = null,
        [FromQuery] string? lopaId = null,
        [FromQuery] string? bowTieId = null)
    {
        try
        {
            var incidents = await _integratedRiskService.FindRelatedIncidentsAsync(hazopId, lopaId, bowTieId);
            return Ok(incidents);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error finding related incidents");
            return StatusCode(500, new { error = ex.Message });
        }
    }

    /// <summary>
    /// Batch update barrier statuses with cascade
    /// </summary>
    [HttpPost("batch-update-barriers")]
    public async Task<ActionResult<BatchOperationResultDto>> BatchUpdateBarrierStatus(
        [FromBody] BatchUpdateBarrierStatusRequest req)
    {
        try
        {
            var userId = User.FindFirst("sub")?.Value;
            var result = await _integratedRiskService.BatchUpdateBarrierStatusAsync(req, userId);
            return Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error batch updating barrier statuses");
            return StatusCode(500, new { error = ex.Message });
        }
    }
}
