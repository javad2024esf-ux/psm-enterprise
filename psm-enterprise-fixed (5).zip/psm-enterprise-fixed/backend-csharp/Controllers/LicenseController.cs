using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.DTOs;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

[ApiController]
[Route("api/license")]
public class LicenseController : ControllerBase
{
    private readonly ILicenseService _license;

    public LicenseController(ILicenseService license)
    {
        _license = license ?? throw new ArgumentNullException(nameof(license));
    }

    /// <summary>
    /// GET /api/license/status
    /// Returns current license activation status
    /// </summary>
    [HttpGet("status")]
    [AllowAnonymous]
    public async Task<IActionResult> GetStatus()
    {
        try
        {
            var status = await _license.GetStatusAsync();

            if (status == null)
            {
                return Ok(new
                {
                    success = true,
                    data = new
                    {
                        status = "inactive",
                        message = "No active license found. System in trial mode.",
                        isExpired = true,
                        daysRemaining = 0
                    }
                });
            }

            return Ok(new
            {
                success = true,
                data = status
            });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new
            {
                success = false,
                error = "Failed to retrieve license status",
                details = ex.Message
            });
        }
    }

    /// <summary>
    /// POST /api/license/activate
    /// Activate a new license with validation
    /// </summary>
    [HttpPost("activate")]
    [AllowAnonymous]
    public async Task<IActionResult> Activate([FromBody] ActivateLicenseDto request)
    {
        if (request == null)
        {
            return BadRequest(new
            {
                success = false,
                error = "Request body is required"
            });
        }

        if (string.IsNullOrWhiteSpace(request.LicenseKey))
        {
            return BadRequest(new
            {
                success = false,
                error = "License key is required"
            });
        }

        if (string.IsNullOrWhiteSpace(request.Organization))
        {
            return BadRequest(new
            {
                success = false,
                error = "Organization name is required"
            });
        }

        if (string.IsNullOrWhiteSpace(request.ContactEmail))
        {
            return BadRequest(new
            {
                success = false,
                error = "Contact email is required"
            });
        }

        if (!IsValidEmail(request.ContactEmail))
        {
            return BadRequest(new
            {
                success = false,
                error = "Invalid email format"
            });
        }

        try
        {
            var result = await _license.ActivateAsync(request);

            if (!result.Success)
            {
                return BadRequest(new
                {
                    success = false,
                    error = result.Message
                });
            }

            return Ok(new
            {
                success = true,
                message = result.Message,
                data = result.LicenseStatus
            });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new
            {
                success = false,
                error = "License activation failed",
                details = ex.Message
            });
        }
    }

    /// <summary>
    /// POST /api/license/deactivate
    /// Deactivate the current license
    /// </summary>
    [HttpPost("deactivate")]
    [AllowAnonymous]
    public async Task<IActionResult> Deactivate()
    {
        try
        {
            var result = await _license.DeactivateAsync();

            if (!result.Success)
            {
                return BadRequest(new
                {
                    success = false,
                    error = result.Message
                });
            }

            return Ok(new
            {
                success = true,
                message = result.Message
            });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new
            {
                success = false,
                error = "License deactivation failed",
                details = ex.Message
            });
        }
    }

    private static bool IsValidEmail(string email)
    {
        try
        {
            var addr = new System.Net.Mail.MailAddress(email);
            return addr.Address == email;
        }
        catch
        {
            return false;
        }
    }
}
