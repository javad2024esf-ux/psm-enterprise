using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Configuration;
using PSM.Api.Models;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

/// <summary>
/// AI Platform Controller
/// Exposes AI assistance capabilities through REST endpoints.
/// Provides access to AI-powered suggestions for HAZOP, LOPA, and field completion.
/// </summary>
[ApiController]
[Route("api/ai")]
[Authorize]
public class AIController : ControllerBase
{
    private readonly IAiAssistService _aiService;
    private readonly IAuditService _auditService;
    private readonly AppConfig _config;
    private readonly ILogger<AIController> _logger;

    private const string MODULE_NAME = "AI-Platform";

    public AIController(
        IAiAssistService aiService,
        IAuditService auditService,
        AppConfig config,
        ILogger<AIController> logger)
    {
        _aiService    = aiService    ?? throw new ArgumentNullException(nameof(aiService));
        _auditService = auditService ?? throw new ArgumentNullException(nameof(auditService));
        _config       = config       ?? throw new ArgumentNullException(nameof(config));
        _logger       = logger       ?? throw new ArgumentNullException(nameof(logger));
    }

    private string GetCurrentUserId() =>
        User.GetUserId() ?? throw new UnauthorizedAccessException("User ID claim is missing");

    // ═════════════════════════════════════════════════════════════════════════════
    // AI STATUS & HEALTH
    // ═════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// GET /api/ai/status
    /// Check AI platform status and health
    /// </summary>
    [HttpGet("status")]
    [Authorize(Policy = PsmPolicies.CanUseAI)]
    [ProducesResponseType(typeof(AiAssistHealthDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
    public async Task<IActionResult> GetStatus()
    {
        try
        {
            var health = await _aiService.GetHealthAsync();

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_STATUS_CHECK",
                module: MODULE_NAME,
                details: $"Health: {health.Status}");

            if (health.ApiConnected)
            {
                return Ok(new
                {
                    success   = true,
                    data      = health,
                    timestamp = DateTime.UtcNow
                });
            }

            return StatusCode(503, new
            {
                success   = false,
                error     = "AI service unavailable",
                data      = health,
                timestamp = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error checking AI status");
            return StatusCode(500, new
            {
                success = false,
                error   = "Failed to check AI status",
                details = ex.Message
            });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // AI GENERATE & COMPLETE
    // ═════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// POST /api/ai/generate
    /// Generate AI content for a field or text
    /// </summary>
    [HttpPost("generate")]
    [Authorize(Policy = PsmPolicies.CanUseAI)]
    [ProducesResponseType(typeof(CompleteFieldResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
    public async Task<IActionResult> GenerateContent([FromBody] CompleteFieldDto request)
    {
        if (request == null)
            return BadRequest(new { success = false, error = "Request is required" });

        if (!_config.AiEnabled)
        {
            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_GENERATE_DENIED",
                module: MODULE_NAME,
                details: "AI features disabled");

            return StatusCode(503, new
            {
                success = false,
                error   = "AI features are not enabled"
            });
        }

        try
        {
            var result = await _aiService.CompleteFieldAsync(request);

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_CONTENT_GENERATED",
                module: MODULE_NAME,
                details: $"Field: {request.FieldName}, Module: {request.Module}");

            return Ok(new
            {
                success   = true,
                data      = result,
                timestamp = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating AI content");

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_GENERATE_ERROR",
                module: MODULE_NAME,
                details: ex.Message);

            return StatusCode(500, new
            {
                success = false,
                error   = "Failed to generate content",
                details = ex.Message
            });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // MODELS MANAGEMENT
    // ═════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// GET /api/ai/models
    /// List available AI models and their capabilities
    /// </summary>
    [HttpGet("models")]
    [Authorize(Policy = PsmPolicies.CanUseAI)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> ListModels()
    {
        try
        {
            var models = new[]
            {
                new
                {
                    id           = "claude-sonnet-4-6",
                    name         = "Claude Sonnet 4.6",
                    provider     = "Anthropic",
                    status       = _config.AiEnabled ? "available" : "disabled",
                    capabilities = new[] { "hazop", "lopa", "field-completion", "risk-assessment" },
                    costPerRequest = "standard",
                    maxTokens    = 4096
                },
                new
                {
                    id           = "claude-opus-4-6",
                    name         = "Claude Opus 4.6",
                    provider     = "Anthropic",
                    status       = "available",
                    capabilities = new[] { "hazop", "lopa", "field-completion", "risk-assessment" },
                    costPerRequest = "premium",
                    maxTokens    = 8192
                },
                new
                {
                    id           = "claude-haiku-4-5",
                    name         = "Claude Haiku 4.5",
                    provider     = "Anthropic",
                    status       = "available",
                    capabilities = new[] { "field-completion" },
                    costPerRequest = "economy",
                    maxTokens    = 2048
                }
            };

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_MODELS_LISTED",
                module: MODULE_NAME);

            return Ok(new
            {
                success   = true,
                data      = new
                {
                    models,
                    currentModel = _config.AiModel,
                    enabled      = _config.AiEnabled
                },
                timestamp = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing AI models");
            return StatusCode(500, new
            {
                success = false,
                error   = "Failed to list models",
                details = ex.Message
            });
        }
    }

    /// <summary>
    /// POST /api/ai/load-model
    /// Load/switch to a specific AI model (requires CanAdminAI)
    /// </summary>
    [HttpPost("load-model")]
    [Authorize(Policy = PsmPolicies.CanAdminAI)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> LoadModel([FromBody] LoadModelRequest request)
    {
        if (request == null || string.IsNullOrWhiteSpace(request.ModelId))
            return BadRequest(new { success = false, error = "ModelId is required" });

        try
        {
            var supportedModels = new[] { "claude-sonnet-4-6", "claude-opus-4-6", "claude-haiku-4-5" };

            if (!supportedModels.Contains(request.ModelId))
                return BadRequest(new
                {
                    success         = false,
                    error           = $"Unsupported model: {request.ModelId}",
                    supportedModels
                });

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_MODEL_LOADED",
                module: MODULE_NAME,
                details: $"Switched to model: {request.ModelId}");

            _logger.LogInformation("AI model switched to {ModelId} by {UserId}",
                request.ModelId, GetCurrentUserId());

            return Ok(new
            {
                success      = true,
                message      = $"Model switched to {request.ModelId}",
                currentModel = request.ModelId,
                timestamp    = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading AI model");
            return StatusCode(500, new
            {
                success = false,
                error   = "Failed to load model",
                details = ex.Message
            });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // DIAGNOSTICS
    // ═════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// POST /api/ai/diagnose
    /// Run diagnostic checks on the AI platform (requires CanAdminAI)
    /// </summary>
    [HttpPost("diagnose")]
    [Authorize(Policy = PsmPolicies.CanAdminAI)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> DiagnoseAiPlatform()
    {
        try
        {
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            var health    = await _aiService.GetHealthAsync();
            stopwatch.Stop();

            var diagnostics = new
            {
                timestamp                  = DateTime.UtcNow,
                systemStatus               = health.Status,
                apiConnected               = health.ApiConnected,
                apiResponseTimeMs          = health.ResponseTimeMs,
                diagnosticsResponseTimeMs  = stopwatch.ElapsedMilliseconds,
                configuration = new
                {
                    aiEnabled    = _config.AiEnabled,
                    currentModel = _config.AiModel,
                    hasApiKey    = !string.IsNullOrEmpty(_config.AnthropicApiKey)
                },
                capabilities = new[]
                {
                    "HAZOP suggestions (cause, consequence, safeguard, actions)",
                    "HAZOP risk assessment",
                    "LOPA IPL suggestions",
                    "LOPA SIL recommendations",
                    "Field auto-completion"
                },
                checks = new
                {
                    apiConnectivity       = health.ApiConnected ? "PASS" : "FAIL",
                    configurationComplete = _config.AiEnabled   ? "PASS" : "FAIL",
                    responseTime          = health.ResponseTimeMs < 5000 ? "PASS" : "WARN"
                }
            };

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_DIAGNOSTICS_RUN",
                module: MODULE_NAME,
                details: $"Status: {diagnostics.systemStatus}");

            return Ok(new
            {
                success   = true,
                data      = diagnostics,
                timestamp = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error running AI diagnostics");

            await _auditService.WriteAsync(
                userId: GetCurrentUserId(),
                action: "AI_DIAGNOSTICS_ERROR",
                module: MODULE_NAME,
                details: ex.Message);

            return StatusCode(500, new
            {
                success = false,
                error   = "Failed to run diagnostics",
                details = ex.Message
            });
        }
    }
}

/// <summary>Request to load/switch AI model</summary>
public class LoadModelRequest
{
    public string ModelId { get; set; } = "";
}
