using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

/// <summary>
/// Provides the LOPA → BowTie leg of the HAZOP → LOPA → BowTie integration chain.
///
/// POST  /api/lopa/{lopaScenarioId}/bowtie/create
///       Creates a BowTie diagram from an approved LOPA Scenario.
///       Risk values (MitigatedFrequency, ConsequenceSeverity, SilRequired …)
///       flow from LOPA into the new diagram and its consequence node.
///       LOPA IPLs are optionally imported as prevention barriers.
///
/// GET   /api/lopa/{lopaScenarioId}/bowtie
///       Returns the BowTie diagram already linked to a LOPA Scenario.
///
/// GET   /api/lopa/studies/{lopaStudyId}/bowtie/summary
///       Coverage summary: how many scenarios in the study have a BowTie.
/// </summary>
[ApiController]
[Route("api/lopa")]
[Authorize]
public class LopaBowTieIntegrationController : ControllerBase
{
    private readonly ILopaBowTieIntegrationService _integrationService;
    private readonly ILopaService                  _lopaService;
    private readonly IAuditService                 _auditService;
    private readonly ILogger<LopaBowTieIntegrationController> _logger;

    public LopaBowTieIntegrationController(
        ILopaBowTieIntegrationService integrationService,
        ILopaService lopaService,
        IAuditService auditService,
        ILogger<LopaBowTieIntegrationController> logger)
    {
        _integrationService = integrationService;
        _lopaService        = lopaService;
        _auditService       = auditService;
        _logger             = logger;
    }

    private string GetUserId()    => this.GetCurrentUser() ?? "unknown";
    private string? GetIpAddress() => HttpContext.Connection.RemoteIpAddress?.ToString();
    private string? GetUserAgent() => Request.Headers["User-Agent"].ToString();

    // ═════════════════════════════════════════════════════════════════════
    // POST /api/lopa/{lopaScenarioId}/bowtie/create
    // Create a BowTie diagram from a LOPA Scenario
    // ═════════════════════════════════════════════════════════════════════

    [HttpPost("{lopaScenarioId}/bowtie/create")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<ActionResult<CreateBowTieFromLopaScenarioResultDto>> CreateBowTieFromLopaScenario(
        [FromRoute] string lopaScenarioId,
        [FromBody]  CreateBowTieFromLopaScenarioRequest request)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(lopaScenarioId))
                return BadRequest(new { error = "lopaScenarioId route parameter is required" });

            // Ensure the scenario exists (returns 404 before touching BowTie layer)
            var scenario = await _lopaService.GetScenarioAsync(lopaScenarioId);
            if (scenario == null)
                return NotFound(new { error = $"LOPA Scenario {lopaScenarioId} not found" });

            // Inject route value so the service doesn't need the caller to repeat it
            request.lopa_scenario_id = lopaScenarioId;

            var userId    = GetUserId();
            var ipAddress = GetIpAddress();
            var userAgent = GetUserAgent();

            var result = await _integrationService.CreateBowTieFromLopaScenarioAsync(
                request, userId, ipAddress, userAgent);

            await _auditService.LogAsync(
                module:  "LOPA-BowTie",
                action:  "CREATE_BOWTIE_FROM_LOPA",
                details: $"BowTie {result.BowTieDiagramId} created from LOPA Scenario {lopaScenarioId}",
                userId:  userId);

            return CreatedAtAction(
                nameof(GetLinkedBowTieDiagram),
                new { lopaScenarioId },
                result);
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning("Invalid argument: {Message}", ex.Message);
            return BadRequest(new { error = ex.Message });
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogWarning("Business rule violation: {Message}", ex.Message);
            return Conflict(new { error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating BowTie from LOPA Scenario {Id}", lopaScenarioId);
            return StatusCode(500, new { error = "Internal server error", details = ex.Message });
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // GET /api/lopa/{lopaScenarioId}/bowtie
    // Get the BowTie diagram linked to a LOPA Scenario
    // ═════════════════════════════════════════════════════════════════════

    [HttpGet("{lopaScenarioId}/bowtie")]
    [Authorize(Policy = PsmPolicies.CanReadBowTie)]
    public async Task<ActionResult<BowTieDiagramDetailDto>> GetLinkedBowTieDiagram(
        [FromRoute] string lopaScenarioId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(lopaScenarioId))
                return BadRequest(new { error = "lopaScenarioId is required" });

            var diagram = await _integrationService.GetLinkedBowTieDiagramAsync(lopaScenarioId);
            if (diagram == null)
                return NotFound(new
                {
                    lopa_scenario_id = lopaScenarioId,
                    message = "No BowTie diagram is linked to this LOPA Scenario yet. " +
                              "Use POST /api/lopa/{id}/bowtie/create to generate one.",
                });

            return Ok(diagram);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving BowTie for LOPA Scenario {Id}", lopaScenarioId);
            return StatusCode(500, new { error = "Internal server error" });
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // GET /api/lopa/studies/{lopaStudyId}/bowtie/summary
    // Integration coverage summary for a LOPA Study
    // ═════════════════════════════════════════════════════════════════════

    [HttpGet("studies/{lopaStudyId}/bowtie/summary")]
    [Authorize(Policy = PsmPolicies.CanReadBowTie)]
    public async Task<ActionResult<LopaBowTieIntegrationSummaryDto>> GetIntegrationSummary(
        [FromRoute] string lopaStudyId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(lopaStudyId))
                return BadRequest(new { error = "lopaStudyId is required" });

            var summary = await _integrationService.GetIntegrationSummaryAsync(lopaStudyId);
            return Ok(summary);
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(new { error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving LOPA-BowTie summary for {Id}", lopaStudyId);
            return StatusCode(500, new { error = "Internal server error" });
        }
    }
}
