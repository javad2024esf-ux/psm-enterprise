using PSM.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

[ApiController]
[Route("api/hazop")]
[Authorize]
public class HazopController : ControllerBase
{
    private readonly IHazopService _hazopSvc;
    private readonly IActionRegisterService _actionSvc;
    private readonly ILogger<HazopController> _logger;

    public HazopController(
        IHazopService hazopSvc,
        IActionRegisterService actionSvc,
        ILogger<HazopController> logger)
    {
        _hazopSvc = hazopSvc;
        _actionSvc = actionSvc;
        _logger = logger;
    }

    // ─── Studies ────────────────────────────────────────────────────────────
    [HttpGet("studies")]
    [Authorize(Policy = PsmPolicies.CanReadHazop)]
    public async Task<IActionResult> ListStudies()
    {
        try { return Ok(await _hazopSvc.ListStudiesAsync()); }
        catch (Exception e) { return StatusCode(500, new { error = e.Message }); }
    }

    [HttpGet("studies/{id}")]
    [Authorize(Policy = PsmPolicies.CanReadHazop)]
    public async Task<IActionResult> GetStudy(string id)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(id))
                return BadRequest(new { error = "شناسه مطالعه الزامی است" });
            
            var study = await _hazopSvc.GetStudyAsync(id);
            if (study is null) return NotFound(new { error = "مطالعه یافت نشد" });
            return Ok(study);
        }
        catch (Exception e) { return StatusCode(500, new { error = e.Message }); }
    }

    [HttpPost("studies")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> CreateStudy([FromBody] CreateHazopStudyRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.title))
            return BadRequest(new { error = "عنوان الزامی است" });
        try
        {
            var study = await _hazopSvc.CreateStudyAsync(req, User.GetUserId());
            return StatusCode(201, study);
        }
        catch (Exception e) { return StatusCode(500, new { error = e.Message }); }
    }

    [HttpPut("studies/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> UpdateStudy(string id, [FromBody] UpdateHazopStudyRequest req)
    {
        try
        {
            var (found, study) = await _hazopSvc.UpdateStudyAsync(id, req);
            if (!found) return NotFound(new { error = "مطالعه یافت نشد" });
            return Ok(study);
        }
        catch (Exception e) { return StatusCode(500, new { error = e.Message }); }
    }

    [HttpDelete("studies/{id}")]
    [Authorize(Policy = PsmPolicies.CanDeleteHazop)]
    public async Task<IActionResult> DeleteStudy(string id)
    {
        try
        {
            if (!await _hazopSvc.DeleteStudyAsync(id)) return NotFound(new { error = "مطالعه یافت نشد" });
            return Ok(new { success = true });
        }
        catch (Exception e) { return StatusCode(500, new { error = e.Message }); }
    }

    // ─── Nodes ──────────────────────────────────────────────────────────────
    [HttpGet("studies/{studyId}/nodes")]
    [Authorize(Policy = PsmPolicies.CanReadHazop)]
    public async Task<IActionResult> ListNodes(string studyId)
    {
        try { return Ok(await _hazopSvc.ListNodesAsync(studyId)); }
        catch (Exception e) { return StatusCode(500, new { error = e.Message }); }
    }

    [HttpPost("studies/{studyId}/nodes")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> CreateNode(string studyId, [FromBody] CreateHazopNodeRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.node_number) || string.IsNullOrWhiteSpace(req.description))
            return BadRequest(new { error = "شماره گره و توضیح الزامی است" });
        try
        {
            var node = await _hazopSvc.CreateNodeAsync(studyId, req);
            return StatusCode(201, node);
        }
        catch (Exception e) { return StatusCode(500, new { error = e.Message }); }
    }

    [HttpPut("nodes/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> UpdateNode(string id, [FromBody] UpdateHazopNodeRequest req)
    {
        try
        {
            var (found, node) = await _hazopSvc.UpdateNodeAsync(id, req);
            if (!found) return NotFound(new { error = "گره یافت نشد" });
            return Ok(node);
        }
        catch (Exception e) { return StatusCode(500, new { error = e.Message }); }
    }

    [HttpDelete("nodes/{id}")]
    [Authorize(Policy = PsmPolicies.CanDeleteHazop)]
    public async Task<IActionResult> DeleteNode(string id)
    {
        try
        {
            if (!await _hazopSvc.DeleteNodeAsync(id)) return NotFound(new { error = "گره یافت نشد" });
            return Ok(new { success = true });
        }
        catch (Exception e) { return StatusCode(500, new { error = e.Message }); }
    }

    // ─── Deviations ─────────────────────────────────────────────────────────
    [HttpGet("studies/{studyId}/deviations")]
    [Authorize(Policy = PsmPolicies.CanReadHazop)]
    public async Task<IActionResult> ListDeviationsByStudy(string studyId)
    {
        try { return Ok(await _hazopSvc.ListDeviationsByStudyAsync(studyId)); }
        catch (Exception e) { return StatusCode(500, new { error = e.Message }); }
    }

    [HttpGet("nodes/{nodeId}/deviations")]
    [Authorize(Policy = PsmPolicies.CanReadHazop)]
    public async Task<IActionResult> ListDeviationsByNode(string nodeId)
    {
        try { return Ok(await _hazopSvc.ListDeviationsByNodeAsync(nodeId)); }
        catch (Exception e) { return StatusCode(500, new { error = e.Message }); }
    }

    [HttpPost("nodes/{nodeId}/deviations")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> CreateDeviation(string nodeId, [FromBody] CreateHazopDeviationRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.guide_word) || string.IsNullOrWhiteSpace(req.parameter) || string.IsNullOrWhiteSpace(req.deviation))
            return BadRequest(new { error = "guide_word، parameter و deviation الزامی است" });
        try
        {
            var (found, deviation) = await _hazopSvc.CreateDeviationAsync(nodeId, req);
            if (!found) return NotFound(new { error = "گره یافت نشد" });
            return StatusCode(201, deviation);
        }
        catch (Exception e) { return StatusCode(500, new { error = e.Message }); }
    }

    [HttpPut("deviations/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]
    public async Task<IActionResult> UpdateDeviation(string id, [FromBody] UpdateHazopDeviationRequest req)
    {
        try
        {
            var (found, deviation) = await _hazopSvc.UpdateDeviationAsync(id, req);
            if (!found) return NotFound(new { error = "انحراف یافت نشد" });
            return Ok(deviation);
        }
        catch (Exception e) { return StatusCode(500, new { error = e.Message }); }
    }

    [HttpDelete("deviations/{id}")]
    [Authorize(Policy = PsmPolicies.CanDeleteHazop)]
    public async Task<IActionResult> DeleteDeviation(string id)
    {
        try
        {
            if (!await _hazopSvc.DeleteDeviationAsync(id)) return NotFound(new { error = "انحراف یافت نشد" });
            return Ok(new { success = true });
        }
        catch (Exception e) { return StatusCode(500, new { error = e.Message }); }
    }

    // ─── Analytics ──────────────────────────────────────────────────────────
    [HttpGet("analytics")]
    [Authorize(Policy = PsmPolicies.CanReadHazop)]
    public async Task<IActionResult> Analytics()
    {
        try
        {
            var data = await _hazopSvc.GetAnalyticsAsync();
            return Ok(new { success = true, data, timestamp = DateTime.UtcNow.ToString("o") });
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    // ════════════════════════════════════════════════════════════════════════════
    // NEW: HAZOP → Action Register Integration
    // ════════════════════════════════════════════════════════════════════════════
    // This endpoint converts a HAZOP deviation/recommendation into an Action Register item.
    //
    // POST /api/hazop/deviations/{id}/create-action
    // ════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Creates an Action Register item from a HAZOP deviation/recommendation.
    ///
    /// This endpoint facilitates the workflow:
    /// HAZOP Study → Find High-Risk Deviation → Create Action → Track in Action Register
    ///
    /// The created action will have:
    /// - Source: "HAZOP"
    /// - SourceId: {studyId} (for cross-linking)
    /// - SourceRef: {deviationId} (for traceability)
    /// - Unit: Inherited from the HAZOP study
    /// - Title: Auto-constructed from study title + recommendation
    /// - Description: Full context (facility, node, causes, consequences, etc.)
    ///
    /// Requires BOTH:
    /// - CanWriteHazop (to read deviation)
    /// - CanWriteActions (to create action)
    ///
    /// URL: POST /api/hazop/deviations/{id}/create-action
    /// Content-Type: application/json
    ///
    /// Example Request Body:
    /// {
    ///   "recommendationText": "ابزارهای حفاظتی را نصب کنید",
    ///   "priority": "High",
    ///   "dueDate": "2026-08-27T00:00:00Z",
    ///   "responsible": "علی احمدی"
    /// }
    ///
    /// Response (201 Created):
    /// {
    ///   "id": "act_abc123...",
    ///   "title": "[HAZOP] میز پمپاژ - ابزارهای حفاظتی را نصب کنید",
    ///   "source": "HAZOP",
    ///   "sourceId": "study_xyz...",
    ///   "sourceRef": "dev_abc123...",
    ///   "status": "Open",
    ///   "priority": "High",
    ///   "dueDate": "2026-08-27T00:00:00Z",
    ///   ...
    /// }
    /// </summary>
    [HttpPost("deviations/{id}/create-action")]
    [Authorize(Policy = PsmPolicies.CanWriteHazop)]  // Also implicitly requires CanWriteActions
    [ProducesResponseType(typeof(ActionRegisterDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> CreateActionFromDeviation(
        string id,
        [FromBody] CreateActionFromHazopRequest req)
    {
        try
        {
            // ─── Validate Input ────────────────────────────────────────────────
            if (string.IsNullOrWhiteSpace(id))
                return BadRequest(new { error = "انحراف ID الزامی است" });

            if (req == null)
                return BadRequest(new { error = "درخواست نامعتبر است" });

            // Set the deviation ID from the URL parameter
            req.DeviationId = id;

            var userId = User.GetUserId();
            if (string.IsNullOrWhiteSpace(userId))
                return Unauthorized(new { error = "شناسه کاربر یافت نشد" });

            // ─── Create Action from Deviation ─────────────────────────────────
            var action = await _actionSvc.CreateFromHazopDeviationAsync(req, userId);

            _logger.LogInformation(
                "Action created from HAZOP deviation: ActionId={ActionId}, DeviationId={DeviationId}, UserId={UserId}",
                action.Id, id, userId);

            return StatusCode(201, new
            {
                success = true,
                message = "اقدام با موفقیت از انحراف HAZOP ایجاد شد",
                data = action
            });
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning("Invalid argument creating action from deviation {DeviationId}: {Message}",
                id, ex.Message);
            return BadRequest(new { error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating action from HAZOP deviation {DeviationId}", id);
            return StatusCode(500, new { error = $"خطا در ایجاد اقدام: {ex.Message}" });
        }
    }
}
