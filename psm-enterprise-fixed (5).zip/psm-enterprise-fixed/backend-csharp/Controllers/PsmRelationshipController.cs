using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.DTOs;
using PSM.Api.Configuration;
using PSM.Api.Models;
using PSM.Api.Services;
using PSM.Api.Middleware;

namespace PSM.Api.Controllers;

/// <summary>
/// API Controller for PSM Relationship Engine.
/// Manages relationships between PSM domain entities and provides cross-module integration.
/// </summary>
[ApiController]
[Route("api/v1/relationships")]
[Authorize]
public class PsmRelationshipController : ControllerBase
{
    private readonly IPsmRelationshipService _relationshipService;
    private readonly IPsmDomainEntityService _entityService;
    private readonly ICrossModuleIntegrationService _integrationService;
    private readonly ILogger<PsmRelationshipController> _logger;

    public PsmRelationshipController(
        IPsmRelationshipService relationshipService,
        IPsmDomainEntityService entityService,
        ICrossModuleIntegrationService integrationService,
        ILogger<PsmRelationshipController> logger)
    {
        _relationshipService = relationshipService;
        _entityService = entityService;
        _integrationService = integrationService;
        _logger = logger;
    }

    /// <summary>
    /// Creates a new relationship between two PSM entities.
    /// </summary>
    /// <remarks>
    /// Example relationship types:
    /// - PsiToHazop: PSI study generates hazops
    /// - HazopToLopa: HAZOP findings lead to LOPA
    /// - HazopToBowTie: HAZOP scenario mapped to BowTie
    /// - IncidentToBowTie: Incident validates/invalidates BowTie
    /// - MocToPSSR: MOC triggers PSSR
    /// </remarks>
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ApiResponse<string>>> CreateRelationship(
        [FromBody] CreateRelationshipDto dto)
    {
        try
        {
            var userId = User.GetUserId();
            var id = await _relationshipService.CreateRelationshipAsync(dto, userId);

            return CreatedAtAction(nameof(GetRelationship), new { id },
                new ApiResponse<string>(id, "Relationship created successfully"));
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new ApiResponse<string>(null, $"Invalid relationship: {ex.Message}"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating relationship");
            return StatusCode(500, new ApiResponse<string>(null, "Error creating relationship"));
        }
    }

    /// <summary>
    /// Updates an existing relationship.
    /// </summary>
    [HttpPut("{id}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<object>>> UpdateRelationship(
        string id,
        [FromBody] UpdateRelationshipDto dto)
    {
        try
        {
            var userId = User.GetUserId();
            await _relationshipService.UpdateRelationshipAsync(id, dto, userId);

            return Ok(new ApiResponse<object>(null, "Relationship updated successfully"));
        }
        catch (InvalidOperationException)
        {
            return NotFound(new ApiResponse<object>(null, "Relationship not found"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating relationship {id}", id);
            return StatusCode(500, new ApiResponse<object>(null, "Error updating relationship"));
        }
    }

    /// <summary>
    /// Deletes a relationship (soft delete).
    /// </summary>
    [HttpDelete("{id}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> DeleteRelationship(string id)
    {
        try
        {
            var userId = User.GetUserId();
            await _relationshipService.DeleteRelationshipAsync(id, userId);
            return NoContent();
        }
        catch (InvalidOperationException)
        {
            return NotFound(new ApiResponse<object>(null, "Relationship not found"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting relationship {id}", id);
            return StatusCode(500, new ApiResponse<object>(null, "Error deleting relationship"));
        }
    }

    /// <summary>
    /// Gets a specific relationship by ID.
    /// </summary>
    [HttpGet("{id}")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<PsmRelationshipDto>>> GetRelationship(string id)
    {
        var relationship = await _relationshipService.GetRelationshipAsync(id);
        if (relationship == null)
            return NotFound(new ApiResponse<PsmRelationshipDto>(null, "Relationship not found"));

        return Ok(new ApiResponse<PsmRelationshipDto>(relationship, "Relationship retrieved successfully"));
    }

    /// <summary>
    /// Gets all relationships for an entity (inbound and outbound).
    /// </summary>
    [HttpGet("entity/{entityType}/{entityId}")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<List<PsmRelationshipDto>>>> GetEntityRelationships(
        string entityType,
        string entityId)
    {
        var relationships = await _relationshipService.GetEntityRelationshipsAsync(entityId, entityType);
        return Ok(new ApiResponse<List<PsmRelationshipDto>>(relationships, "Entity relationships retrieved successfully"));
    }

    /// <summary>
    /// Gets the relationship graph for an entity (including transitive relationships).
    /// </summary>
    [HttpGet("graph/{entityType}/{entityId}")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<RelationshipQueryDto>>> GetRelationshipGraph(
        string entityType,
        string entityId,
        [FromQuery] int maxDepth = 3)
    {
        var graph = await _relationshipService.GetRelationshipGraphAsync(entityId, entityType, maxDepth);
        return Ok(new ApiResponse<RelationshipQueryDto>(graph, "Relationship graph retrieved successfully"));
    }

    /// <summary>
    /// Gets all relationships of a specific type.
    /// Example: GET /api/v1/relationships/type/HazopToLopa
    /// </summary>
    [HttpGet("type/{relationshipType}")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<List<PsmRelationshipDto>>>> GetRelationshipsByType(
        string relationshipType)
    {
        var relationships = await _relationshipService.GetRelationshipsByTypeAsync(relationshipType);
        return Ok(new ApiResponse<List<PsmRelationshipDto>>(relationships, "Relationships retrieved successfully"));
    }

    /// <summary>
    /// Creates multiple relationships in a single operation.
    /// Useful for bulk linking after imports or migrations.
    /// </summary>
    [HttpPost("bulk-create")]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ApiResponse<BulkCreateRelationshipsResultDto>>> BulkCreateRelationships(
        [FromBody] BulkCreateRelationshipsDto dto)
    {
        try
        {
            var userId = User.GetUserId();
            var result = await _relationshipService.BulkCreateRelationshipsAsync(
                dto.Relationships, userId, dto.BatchDescription);

            return CreatedAtAction(nameof(GetRelationship), null,
                new ApiResponse<BulkCreateRelationshipsResultDto>(result, "Relationships created successfully"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in bulk relationship creation");
            return BadRequest(new ApiResponse<BulkCreateRelationshipsResultDto>(null, $"Bulk creation failed: {ex.Message}"));
        }
    }

    /// <summary>
    /// Validates a relationship before creation.
    /// Returns warnings and errors if any.
    /// </summary>
    [HttpPost("validate")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<RelationshipValidationResultDto>>> ValidateRelationship(
        [FromBody] CreateRelationshipDto dto)
    {
        var validation = await _relationshipService.ValidateRelationshipAsync(dto);
        return Ok(new ApiResponse<RelationshipValidationResultDto>(validation, "Validation complete"));
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // ► Impact Analysis & Analytics
    // ═════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Analyzes the impact of modifying or deleting an entity.
    /// Shows all directly and indirectly affected entities.
    /// </summary>
    [HttpGet("impact/{entityType}/{entityId}")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<ImpactAnalysisResultDto>>> AnalyzeImpact(
        string entityType,
        string entityId)
    {
        var impact = await _relationshipService.AnalyzeImpactAsync(entityId, entityType);
        return Ok(new ApiResponse<ImpactAnalysisResultDto>(impact, "Impact analysis complete"));
    }

    /// <summary>
    /// Checks if an entity is compliant with relationship requirements.
    /// </summary>
    [HttpGet("compliance/{entityType}/{entityId}")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EntityComplianceCheckDto>>> CheckCompliance(
        string entityType,
        string entityId)
    {
        var compliance = await _relationshipService.CheckComplianceAsync(entityId, entityType);
        return Ok(new ApiResponse<EntityComplianceCheckDto>(compliance, "Compliance check complete"));
    }

    /// <summary>
    /// Gets overall relationship statistics across all modules.
    /// </summary>
    [HttpGet("statistics")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<RelationshipStatisticsDto>>> GetStatistics()
    {
        var stats = await _relationshipService.GetStatisticsAsync();
        return Ok(new ApiResponse<RelationshipStatisticsDto>(stats, "Statistics retrieved successfully"));
    }

    /// <summary>
    /// Gets integration health between specific modules.
    /// </summary>
    [HttpGet("integration-health")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<List<IntegrationHealthDto>>>> GetIntegrationHealth()
    {
        var health = await _relationshipService.GetIntegrationHealthAsync();
        return Ok(new ApiResponse<List<IntegrationHealthDto>>(health, "Integration health retrieved successfully"));
    }

    /// <summary>
    /// Gets cross-module data flow between two modules.
    /// </summary>
    [HttpGet("cross-module-flow")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<CrossModuleFlowDto>>> GetCrossModuleFlow(
        [FromQuery] string sourceModule,
        [FromQuery] string targetModule)
    {
        var flow = await _relationshipService.GetCrossModuleFlowAsync(sourceModule, targetModule);
        return Ok(new ApiResponse<CrossModuleFlowDto>(flow, "Cross-module flow retrieved successfully"));
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // ► Cross-Module Integration
    // ═════════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Links a HAZOP study to a LOPA analysis.
    /// </summary>
    [HttpPost("link-hazop-to-lopa")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<object>>> LinkHazopToLopa(
        [FromBody] (string hazopId, string lopaId) request)
    {
        try
        {
            var userId = User.GetUserId();
            await _integrationService.LinkHazopToLopaAsync(request.hazopId, request.lopaId, userId);
            return Ok(new ApiResponse<object>(null, "HAZOP linked to LOPA successfully"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error linking HAZOP to LOPA");
            return BadRequest(new ApiResponse<object>(null, $"Error: {ex.Message}"));
        }
    }

    /// <summary>
    /// Links a HAZOP study to a BowTie analysis.
    /// </summary>
    [HttpPost("link-hazop-to-bowtie")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<object>>> LinkHazopToBowTie(
        [FromBody] (string hazopId, string bowTieId) request)
    {
        try
        {
            var userId = User.GetUserId();
            await _integrationService.LinkHazopToBowTieAsync(request.hazopId, request.bowTieId, userId);
            return Ok(new ApiResponse<object>(null, "HAZOP linked to BowTie successfully"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error linking HAZOP to BowTie");
            return BadRequest(new ApiResponse<object>(null, $"Error: {ex.Message}"));
        }
    }

    /// <summary>
    /// Links an incident to a BowTie analysis to validate barrier effectiveness.
    /// </summary>
    [HttpPost("link-incident-to-bowtie")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<object>>> LinkIncidentToBowTie(
        [FromBody] (string incidentId, string bowTieId) request)
    {
        try
        {
            var userId = User.GetUserId();
            await _integrationService.LinkIncidentToBowTieAsync(request.incidentId, request.bowTieId, userId);
            return Ok(new ApiResponse<object>(null, "Incident linked to BowTie successfully"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error linking incident to BowTie");
            return BadRequest(new ApiResponse<object>(null, $"Error: {ex.Message}"));
        }
    }

    /// <summary>
    /// Links an audit to multiple action items.
    /// </summary>
    [HttpPost("link-audit-to-actions")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<object>>> LinkAuditToActions(
        [FromBody] (string auditId, List<string> actionIds) request)
    {
        try
        {
            var userId = User.GetUserId();
            var count = await _integrationService.LinkAuditToActionsAsync(
                request.auditId, request.actionIds, userId);
            return Ok(new ApiResponse<object>(count, $"{count} action items linked to audit successfully"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error linking audit to actions");
            return BadRequest(new ApiResponse<object>(null, $"Error: {ex.Message}"));
        }
    }

    /// <summary>
    /// Links a MOC to a PSSR.
    /// </summary>
    [HttpPost("link-moc-to-pssr")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<object>>> LinkMocToPSSR(
        [FromBody] (string mocId, string pssrId) request)
    {
        try
        {
            var userId = User.GetUserId();
            await _integrationService.LinkMocToPSSRAsync(request.mocId, request.pssrId, userId);
            return Ok(new ApiResponse<object>(null, "MOC linked to PSSR successfully"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error linking MOC to PSSR");
            return BadRequest(new ApiResponse<object>(null, $"Error: {ex.Message}"));
        }
    }

    /// <summary>
    /// Syncs action items from a source module (e.g., HAZOP findings -> Action Items).
    /// </summary>
    [HttpPost("sync-actions")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<object>>> SyncActionItems(
        [FromBody] (string sourceId, string sourceModule) request)
    {
        try
        {
            var userId = User.GetUserId();
            var count = await _integrationService.SyncActionItemsAsync(
                request.sourceId, request.sourceModule, userId);
            return Ok(new ApiResponse<object>(count, $"{count} action items synced successfully"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error syncing action items");
            return BadRequest(new ApiResponse<object>(null, $"Error: {ex.Message}"));
        }
    }
}

/// <summary>
/// API Controller for PSM Domain Entities.
/// Manages creation and retrieval of core PSM entities.
/// </summary>
[ApiController]
[Route("api/v1/psm-entities")]
[Authorize]
public class PsmDomainEntityController : ControllerBase
{
    private readonly IPsmDomainEntityService _entityService;
    private readonly ILogger<PsmDomainEntityController> _logger;

    public PsmDomainEntityController(
        IPsmDomainEntityService entityService,
        ILogger<PsmDomainEntityController> logger)
    {
        _entityService = entityService;
        _logger = logger;
    }

    // ─── Assets ─────────────────────────────────────────────────────────────────

    /// <summary>
    /// Creates a new asset (equipment/system).
    /// </summary>
    [HttpPost("assets")]
    [ProducesResponseType(StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<string>>> CreateAsset([FromBody] CreateAssetDto dto)
    {
        try
        {
            var userId = User.GetUserId();
            var id = await _entityService.CreateAssetAsync(dto, userId);
            return CreatedAtAction(nameof(GetAsset), new { id },
                new ApiResponse<string>(id, "Asset created successfully"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating asset");
            return BadRequest(new ApiResponse<string>(null, $"Error: {ex.Message}"));
        }
    }

    /// <summary>
    /// Gets a specific asset by ID.
    /// </summary>
    [HttpGet("assets/{id}")]
    [AllowAnonymous]
    public async Task<ActionResult<ApiResponse<AssetDto>>> GetAsset(string id)
    {
        var asset = await _entityService.GetAssetAsync(id);
        if (asset == null)
            return NotFound(new ApiResponse<AssetDto>(null, "Asset not found"));

        return Ok(new ApiResponse<AssetDto>(asset, "Asset retrieved successfully"));
    }

    /// <summary>
    /// Lists all assets, optionally filtered by unit.
    /// </summary>
    [HttpGet("assets")]
    [AllowAnonymous]
    public async Task<ActionResult<ApiResponse<List<AssetDto>>>> ListAssets([FromQuery] string? unit = null)
    {
        var assets = await _entityService.ListAssetsAsync(unit);
        return Ok(new ApiResponse<List<AssetDto>>(assets, "Assets retrieved successfully"));
    }

    // ─── Hazards ────────────────────────────────────────────────────────────────

    /// <summary>
    /// Creates a new hazard.
    /// </summary>
    [HttpPost("hazards")]
    [ProducesResponseType(StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<string>>> CreateHazard([FromBody] HazardDto dto)
    {
        try
        {
            var userId = User.GetUserId();
            var id = await _entityService.CreateHazardAsync(dto, userId);
            return CreatedAtAction(nameof(GetHazard), new { id },
                new ApiResponse<string>(id, "Hazard created successfully"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating hazard");
            return BadRequest(new ApiResponse<string>(null, $"Error: {ex.Message}"));
        }
    }

    /// <summary>
    /// Gets a specific hazard by ID.
    /// </summary>
    [HttpGet("hazards/{id}")]
    [AllowAnonymous]
    public async Task<ActionResult<ApiResponse<HazardDto>>> GetHazard(string id)
    {
        var hazard = await _entityService.GetHazardAsync(id);
        if (hazard == null)
            return NotFound(new ApiResponse<HazardDto>(null, "Hazard not found"));

        return Ok(new ApiResponse<HazardDto>(hazard, "Hazard retrieved successfully"));
    }

    /// <summary>
    /// Lists all hazards, optionally filtered by process unit.
    /// </summary>
    [HttpGet("hazards")]
    [AllowAnonymous]
    public async Task<ActionResult<ApiResponse<List<HazardDto>>>> ListHazards([FromQuery] string? processUnitId = null)
    {
        var hazards = await _entityService.ListHazardsAsync(processUnitId);
        return Ok(new ApiResponse<List<HazardDto>>(hazards, "Hazards retrieved successfully"));
    }

    // ─── Action Items ───────────────────────────────────────────────────────────

    /// <summary>
    /// Creates a new action item.
    /// </summary>
    [HttpPost("action-items")]
    [ProducesResponseType(StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<string>>> CreateActionItem([FromBody] ActionItemDto dto)
    {
        try
        {
            var userId = User.GetUserId();
            var id = await _entityService.CreateActionItemAsync(dto, userId);
            return CreatedAtAction(nameof(GetActionItem), new { id },
                new ApiResponse<string>(id, "Action item created successfully"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating action item");
            return BadRequest(new ApiResponse<string>(null, $"Error: {ex.Message}"));
        }
    }

    /// <summary>
    /// Gets a specific action item by ID.
    /// </summary>
    [HttpGet("action-items/{id}")]
    [AllowAnonymous]
    public async Task<ActionResult<ApiResponse<ActionItemDto>>> GetActionItem(string id)
    {
        var actionItem = await _entityService.GetActionItemAsync(id);
        if (actionItem == null)
            return NotFound(new ApiResponse<ActionItemDto>(null, "Action item not found"));

        return Ok(new ApiResponse<ActionItemDto>(actionItem, "Action item retrieved successfully"));
    }

    /// <summary>
    /// Lists all action items, optionally filtered by source module or status.
    /// </summary>
    [HttpGet("action-items")]
    [AllowAnonymous]
    public async Task<ActionResult<ApiResponse<List<ActionItemDto>>>> ListActionItems(
        [FromQuery] string? sourceModule = null,
        [FromQuery] string? status = null)
    {
        var actionItems = await _entityService.ListActionItemsAsync(sourceModule, status);
        return Ok(new ApiResponse<List<ActionItemDto>>(actionItems, "Action items retrieved successfully"));
    }
}
