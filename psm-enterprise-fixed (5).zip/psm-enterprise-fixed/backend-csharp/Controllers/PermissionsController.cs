using PSM.Api.Middleware;
using PSM.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

[ApiController]
[Route("api/permissions")]
[Authorize]
public class PermissionsController : ControllerBase
{
    private readonly IPermissionService _permissions;

    public PermissionsController(IPermissionService permissions)
    {
        _permissions = permissions;
    }

    /// <summary>
    /// GET /api/permissions/matrix
    /// Get permission matrix for the current user
    /// Used by frontend for RBAC decision-making
    /// </summary>
    [HttpGet("matrix")]
    public async Task<IActionResult> GetPermissionsMatrix()
    {
        try
        {
            var userId   = User.FindFirst("sub")?.Value;
            var userRole = User.FindFirst("role")?.Value ?? "User";

            var permissions = await _permissions.GetPermissionsByRoleAsync(userRole);

            var matrix = new
            {
                canReadHAZOP     = permissions.Contains("HAZOP:Read"),
                canWriteHAZOP    = permissions.Contains("HAZOP:Write"),
                canApproveHAZOP  = permissions.Contains("HAZOP:Approve"),

                canReadLOPA      = permissions.Contains("LOPA:Read"),
                canWriteLOPA     = permissions.Contains("LOPA:Write"),
                canApproveLOPA   = permissions.Contains("LOPA:Approve"),

                canReadBowTie    = permissions.Contains("BOWTIE:Read"),
                canWriteBowTie   = permissions.Contains("BOWTIE:Write"),

                canReadMOC       = permissions.Contains("MOC:Read"),
                canWriteMOC      = permissions.Contains("MOC:Write"),
                canApproveMOC    = permissions.Contains("MOC:Approve"),

                canReadPSSR      = permissions.Contains("PSSR:Read"),
                canWritePSSR     = permissions.Contains("PSSR:Write"),
                canApprovePSSR   = permissions.Contains("PSSR:Approve"),

                canReadWorkPermit    = permissions.Contains("WORK_PERMIT:Read"),
                canApproveWorkPermit = permissions.Contains("WORK_PERMIT:Approve"),

                // مدیریت کاربران از permissions می‌آید، نه hardcoded role
                canManageUsers   = permissions.Contains("Users:Manage"),
                canDeleteUsers   = permissions.Contains("Users:Delete"),
                canViewAudit     = permissions.Contains("Audit:Read"),
                canExportData    = permissions.Contains("Export:Execute"),

                // دسترسی AI
                canUseAI         = permissions.Contains("AI-Platform:Read"),
                canAdminAI       = permissions.Contains("AI-Platform:Approve"),

                userRole,
                userId
            };

            return Ok(new { success = true, permissions = matrix });
        }
        catch (Exception ex)
        {
            return BadRequest(new { success = false, error = ex.Message });
        }
    }
}
