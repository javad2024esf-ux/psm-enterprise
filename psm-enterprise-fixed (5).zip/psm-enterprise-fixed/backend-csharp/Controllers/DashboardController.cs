using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.DTOs;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

/// <summary>
/// Dashboard KPI Aggregation API
/// Provides unified view of all PSM module metrics
/// </summary>
[Authorize]
[ApiController]
[Route("api/[controller]")]
public class DashboardController : ControllerBase
{
    private readonly IDashboardService _dashboardService;
    private readonly ILogger<DashboardController> _logger;

    public DashboardController(IDashboardService dashboardService, ILogger<DashboardController> logger)
    {
        _dashboardService = dashboardService;
        _logger = logger;
    }

    /// <summary>
    /// Get all KPIs for dashboard (aggregated from all modules)
    /// </summary>
    /// <returns>Complete dashboard KPI set</returns>
    [HttpGet("kpis")]
    [ProducesResponseType(typeof(DashboardKpisDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAllKpis()
    {
        try
        {
            _logger.LogInformation("Dashboard KPI request from user");
            var kpis = await _dashboardService.GetAllKpisAsync();
            return Ok(kpis);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving dashboard KPIs");
            return StatusCode(500, new { error = "Failed to retrieve KPIs" });
        }
    }

    /// <summary>
    /// Get HAZOP module KPIs
    /// </summary>
    [HttpGet("kpis/hazop")]
    [ProducesResponseType(typeof(HazopKpisDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetHazopKpis()
    {
        var kpis = await _dashboardService.GetHazopKpisAsync();
        return Ok(kpis);
    }

    /// <summary>
    /// Get LOPA module KPIs
    /// </summary>
    [HttpGet("kpis/lopa")]
    [ProducesResponseType(typeof(LopaKpisDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetLopaKpis()
    {
        var kpis = await _dashboardService.GetLopaKpisAsync();
        return Ok(kpis);
    }

    /// <summary>
    /// Get Incident Management KPIs
    /// </summary>
    [HttpGet("kpis/incident")]
    [ProducesResponseType(typeof(IncidentKpisDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetIncidentKpis()
    {
        var kpis = await _dashboardService.GetIncidentKpisAsync();
        return Ok(kpis);
    }

    /// <summary>
    /// Get Work Permit Management KPIs
    /// </summary>
    [HttpGet("kpis/permit")]
    [ProducesResponseType(typeof(PermitKpisDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetPermitKpis()
    {
        var kpis = await _dashboardService.GetPermitKpisAsync();
        return Ok(kpis);
    }

    /// <summary>
    /// Get Workflow KPIs
    /// </summary>
    [HttpGet("kpis/workflow")]
    [ProducesResponseType(typeof(WorkflowKpisDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetWorkflowKpis()
    {
        var kpis = await _dashboardService.GetWorkflowKpisAsync();
        return Ok(kpis);
    }

    /// <summary>
    /// Get Action Register KPIs
    /// </summary>
    [HttpGet("kpis/actions")]
    [ProducesResponseType(typeof(ActionRegisterKpisDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetActionRegisterKpis()
    {
        var kpis = await _dashboardService.GetActionRegisterKpisAsync();
        return Ok(kpis);
    }

    /// <summary>
    /// Get Audit Trail KPIs
    /// </summary>
    [HttpGet("kpis/audit")]
    [ProducesResponseType(typeof(AuditKpisDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAuditKpis()
    {
        var kpis = await _dashboardService.GetAuditKpisAsync();
        return Ok(kpis);
    }

    /// <summary>
    /// Get dashboard summary (risk overview, compliance status, system health)
    /// </summary>
    [HttpGet("summary")]
    [ProducesResponseType(typeof(DashboardSummaryDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetDashboardSummary()
    {
        var kpis = await _dashboardService.GetAllKpisAsync();
        return Ok(kpis.Summary);
    }

    /// <summary>
    /// Get recent KPI update events for real-time notifications
    /// </summary>
    /// <param name="limitMinutes">Include updates from last N minutes (default 5)</param>
    [HttpGet("updates/recent")]
    [ProducesResponseType(typeof(IEnumerable<KpiUpdateEventDto>), StatusCodes.Status200OK)]
    public IActionResult GetRecentUpdates([FromQuery] int limitMinutes = 5)
    {
        var updates = _dashboardService.GetRecentUpdates(limitMinutes);
        return Ok(updates);
    }

    /// <summary>
    /// Force refresh of all KPI cache
    /// </summary>
    [HttpPost("refresh")]
    [ProducesResponseType(typeof(object), StatusCodes.Status200OK)]
    public async Task<IActionResult> RefreshKpis()
    {
        try
        {
            await _dashboardService.InvalidateCacheAsync();
            var kpis = await _dashboardService.GetAllKpisAsync();
            return Ok(new { message = "KPIs refreshed successfully", kpis });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error refreshing KPIs");
            return StatusCode(500, new { error = "Failed to refresh KPIs" });
        }
    }

    /// <summary>
    /// Get cache statistics and performance metrics
    /// </summary>
    [HttpGet("cache/stats")]
    [ProducesResponseType(typeof(KpiCacheStatsDto), StatusCodes.Status200OK)]
    public IActionResult GetCacheStats()
    {
        var stats = _dashboardService.GetCacheStats();
        return Ok(stats);
    }

    /// <summary>
    /// Health check endpoint (ensures dashboard is responsive)
    /// </summary>
    [HttpGet("health")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(object), StatusCodes.Status200OK)]
    public IActionResult GetHealth()
    {
        return Ok(new
        {
            status = "healthy",
            timestamp = DateTime.UtcNow,
            version = "1.0.0"
        });
    }
}
