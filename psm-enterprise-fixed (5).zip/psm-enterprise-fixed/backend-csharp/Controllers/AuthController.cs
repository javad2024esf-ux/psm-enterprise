using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Models;
using PSM.Api.Repositories;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly IAuthService    _auth;
    private readonly IUserRepository _users;
    private readonly IUserService    _userService;
    private readonly IAuditService   _audit;

    public AuthController(IAuthService auth, IUserRepository users, IUserService userService, IAuditService audit)
    {
        _auth        = auth;
        _users       = users;
        _userService = userService;
        _audit       = audit;
    }

    // POST /api/auth/login
    [HttpPost("login")]
    [EnableRateLimiting(RateLimitPolicies.Auth)]
    public async Task<IActionResult> Login([FromBody] LoginRequest req)
    {
        if (string.IsNullOrEmpty(req.Username) || string.IsNullOrEmpty(req.Password))
            return BadRequest(new { success = false, error = "نام کاربری و رمز عبور الزامی است" });

        var (user, error) = await _auth.ValidateCredentialsAsync(req.Username, req.Password);
        if (user is null)
        {
            await _audit.ForRequest(HttpContext)
                .Action(AuditAction.LoginFailed)
                .Severity(AuditSeverity.Warning)
                .Outcome("FAILURE", error)
                .Meta(new { attemptedUsername = req.Username })
                .WriteAsync(_audit);

            return Unauthorized(new { success = false, error });
        }

        var (accessToken, refreshToken) = await _auth.IssueTokensAsync(user);

        await _audit.ForRequest(HttpContext)
            .Action(AuditAction.Login)
            .User(user.Id, user.Username, user.FullName, user.Role)
            .Module("auth")
            .WriteAsync(_audit);

        return Ok(new
        {
            success = true,
            token   = accessToken,
            refreshToken,
            user    = SafeUser.From(user),
        });
    }

    // POST /api/auth/refresh
    [HttpPost("refresh")]
    [EnableRateLimiting(RateLimitPolicies.Auth)]
    public async Task<IActionResult> Refresh([FromBody] RefreshRequest req)
    {
        var (access, refresh, error) = await _auth.RefreshAsync(req.Token);
        if (error is not null)
            return Unauthorized(new { success = false, error });

        return Ok(new { success = true, token = access, refreshToken = refresh });
    }

    // GET /api/auth/me
    [HttpGet("me")]
    [Authorize]
    public async Task<IActionResult> Me()
    {
        var id   = User.GetUserId();
        var user = id is null ? null : await _users.GetByIdAsync(id);
        if (user is null) return Unauthorized(new { success = false, error = "کاربر یافت نشد" });
        return Ok(new { success = true, user = SafeUser.From(user) });
    }

    // POST /api/auth/change-password
    [HttpPost("change-password")]
    [Authorize]
    public async Task<IActionResult> ChangePassword(
        [FromBody] ChangePasswordRequest req,
        [FromServices] IPasswordHasher hasher)
    {
        var id   = User.GetUserId();
        var user = id is null ? null : await _users.GetByIdAsync(id);
        if (user is null) return Unauthorized();

        if (!hasher.Verify(req.ResolvedCurrentPassword, user.PasswordHash))
        {
            await _audit.ForRequest(HttpContext)
                .Action(AuditAction.ChangePassword)
                .Severity(AuditSeverity.Warning)
                .User(id, User.GetUsername(), User.GetFullName(), User.GetRole())
                .Module("auth")
                .Outcome("FAILURE", "رمز عبور فعلی اشتباه است")
                .WriteAsync(_audit);

            return BadRequest(new { success = false, error = "رمز عبور فعلی اشتباه است" });
        }

        if (string.IsNullOrWhiteSpace(req.NewPassword) || req.NewPassword.Length < 8)
            return BadRequest(new { success = false, error = "رمز عبور جدید باید حداقل ۸ کاراکتر باشد" });

        // ✅ Fix: Include MustChangePassword = false to clear the flag after password change
        await _userService.UpdateAsync(id!, new UpdateUserRequest(
            FullName:   user.FullName,
            Email:      user.Email,
            Role:       user.Role,
            Department: user.Department,
            Unit:       user.Unit,
            Status:     user.Status,
            Password:   req.NewPassword,
            MustChangePassword: false // ✅ Explicitly clear the flag
        ));

        await _audit.ForRequest(HttpContext)
            .Action(AuditAction.ChangePassword)
            .Severity(AuditSeverity.Warning)
            .User(id, User.GetUsername(), User.GetFullName(), User.GetRole())
            .Module("auth")
            .WriteAsync(_audit);

        return Ok(new { success = true });
    }

    // POST /api/auth/logout
    [HttpPost("logout")]
    [Authorize]
    public async Task<IActionResult> Logout([FromBody] RefreshRequest? req)
    {
        if (req?.Token is not null)
            await _auth.RevokeRefreshTokenAsync(req.Token);

        await _audit.ForRequest(HttpContext)
            .Action(AuditAction.Logout)
            .User(User.GetUserId(), User.GetUsername(), User.GetFullName(), User.GetRole())
            .Module("auth")
            .WriteAsync(_audit);

        return Ok(new { success = true });
    }

    // POST /api/auth/logout-all
    [HttpPost("logout-all")]
    [Authorize]
    public async Task<IActionResult> LogoutAll()
    {
        var id = User.GetUserId();
        if (id is not null)
            await _auth.RevokeAllTokensAsync(id);

        await _audit.ForRequest(HttpContext)
            .Action(AuditAction.LogoutAll)
            .Severity(AuditSeverity.Warning)
            .User(id, User.GetUsername(), User.GetFullName(), User.GetRole())
            .Module("auth")
            .WriteAsync(_audit);

        return Ok(new { success = true });
    }
}

file static class AuditBuilderExtensions
{
    public static Task WriteAsync(this AuditBuilder builder, IAuditService svc) =>
        svc.WriteEntryAsync(builder.Build());
}
