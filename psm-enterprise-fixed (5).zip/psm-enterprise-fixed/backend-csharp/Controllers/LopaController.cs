using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

[ApiController]
[Route("api/lopa")]
[Authorize]
public class LopaController : ControllerBase
{
    private readonly ILopaService _svc;

    public LopaController(ILopaService svc) => _svc = svc;

    // ─── Studies ────────────────────────────────────────────────────────────

    [HttpGet("studies")]
    [Authorize(Policy = PsmPolicies.CanReadLopa)]
    public async Task<IActionResult> ListStudies([FromQuery] string? hazop_study_id)
    {
        try
        {
            var data = await _svc.ListStudiesAsync(hazop_study_id);
            return Ok(new { success = true, data });
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    [HttpGet("studies/{id}")]
    [Authorize(Policy = PsmPolicies.CanReadLopa)]
    public async Task<IActionResult> GetStudy(string id)
    {
        try
        {
            var study = await _svc.GetStudyAsync(id);
            if (study is null) return NotFound(new { success = false, error = "مطالعه LOPA یافت نشد" });
            return Ok(study);
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    [HttpPost("studies")]
    [Authorize(Policy = PsmPolicies.CanWriteLopa)]
    public async Task<IActionResult> CreateStudy([FromBody] CreateLopaStudyRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.title))
            return BadRequest(new { success = false, error = "عنوان الزامی است" });
        try
        {
            var study = await _svc.CreateStudyAsync(req, User.GetUserId());
            return StatusCode(201, study);
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    [HttpPut("studies/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteLopa)]
    public async Task<IActionResult> UpdateStudy(string id, [FromBody] UpdateLopaStudyRequest req)
    {
        try
        {
            var (found, study) = await _svc.UpdateStudyAsync(id, req);
            if (!found) return NotFound(new { success = false, error = "مطالعه LOPA یافت نشد" });
            return Ok(study);
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    [HttpDelete("studies/{id}")]
    [Authorize(Policy = PsmPolicies.CanDeleteLopa)]
    public async Task<IActionResult> DeleteStudy(string id)
    {
        try
        {
            if (!await _svc.DeleteStudyAsync(id))
                return NotFound(new { success = false, error = "مطالعه LOPA یافت نشد" });
            return Ok(new { success = true });
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    // ─── Scenarios ──────────────────────────────────────────────────────────

    [HttpGet("studies/{studyId}/scenarios")]
    [Authorize(Policy = PsmPolicies.CanReadLopa)]
    public async Task<IActionResult> ListScenarios(string studyId)
    {
        try
        {
            var data = await _svc.ListScenariosAsync(studyId);
            return Ok(new { success = true, data });
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    [HttpGet("scenarios/{id}")]
    [Authorize(Policy = PsmPolicies.CanReadLopa)]
    public async Task<IActionResult> GetScenario(string id)
    {
        try
        {
            var scenario = await _svc.GetScenarioAsync(id);
            if (scenario is null) return NotFound(new { success = false, error = "سناریو یافت نشد" });
            return Ok(scenario);
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    [HttpPost("studies/{studyId}/scenarios")]
    [Authorize(Policy = PsmPolicies.CanWriteLopa)]
    public async Task<IActionResult> CreateScenario(string studyId, [FromBody] CreateLopaScenarioRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.initiating_event))
            return BadRequest(new { success = false, error = "رویداد آغازین الزامی است" });
        try
        {
            var (found, scenario) = await _svc.CreateScenarioAsync(studyId, req);
            if (!found) return NotFound(new { success = false, error = "مطالعه LOPA یافت نشد" });
            return StatusCode(201, scenario);
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    [HttpPut("scenarios/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteLopa)]
    public async Task<IActionResult> UpdateScenario(string id, [FromBody] UpdateLopaScenarioRequest req)
    {
        try
        {
            var (found, scenario) = await _svc.UpdateScenarioAsync(id, req);
            if (!found) return NotFound(new { success = false, error = "سناریو یافت نشد" });
            return Ok(scenario);
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    [HttpDelete("scenarios/{id}")]
    [Authorize(Policy = PsmPolicies.CanDeleteLopa)]
    public async Task<IActionResult> DeleteScenario(string id)
    {
        try
        {
            if (!await _svc.DeleteScenarioAsync(id))
                return NotFound(new { success = false, error = "سناریو یافت نشد" });
            return Ok(new { success = true });
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    // ─── IPLs ───────────────────────────────────────────────────────────────

    [HttpGet("scenarios/{scenarioId}/ipls")]
    [Authorize(Policy = PsmPolicies.CanReadLopa)]
    public async Task<IActionResult> ListIpls(string scenarioId)
    {
        try
        {
            var data = await _svc.ListIplsAsync(scenarioId);
            return Ok(new { success = true, data });
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    [HttpPost("scenarios/{scenarioId}/ipls")]
    [Authorize(Policy = PsmPolicies.CanWriteLopa)]
    public async Task<IActionResult> CreateIpl(string scenarioId, [FromBody] CreateLopaIplRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.ipl_name))
            return BadRequest(new { success = false, error = "نام IPL الزامی است" });
        try
        {
            var (found, ipl) = await _svc.CreateIplAsync(scenarioId, req);
            if (!found) return NotFound(new { success = false, error = "سناریو یافت نشد" });
            return StatusCode(201, ipl);
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    [HttpPut("ipls/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteLopa)]
    public async Task<IActionResult> UpdateIpl(string id, [FromBody] UpdateLopaIplRequest req)
    {
        try
        {
            var (found, ipl) = await _svc.UpdateIplAsync(id, req);
            if (!found) return NotFound(new { success = false, error = "IPL یافت نشد" });
            return Ok(ipl);
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    [HttpDelete("ipls/{id}")]
    [Authorize(Policy = PsmPolicies.CanDeleteLopa)]
    public async Task<IActionResult> DeleteIpl(string id)
    {
        try
        {
            if (!await _svc.DeleteIplAsync(id))
                return NotFound(new { success = false, error = "IPL یافت نشد" });
            return Ok(new { success = true });
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    // ─── Dashboard & Integration ─────────────────────────────────────────────

    [HttpGet("summary")]
    [Authorize(Policy = PsmPolicies.CanReadLopa)]
    public async Task<IActionResult> GetSummary()
    {
        try
        {
            var data = await _svc.GetDashboardSummaryAsync();
            return Ok(new { success = true, data });
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    [HttpGet("hazop-studies")]
    [Authorize(Policy = PsmPolicies.CanReadLopa)]
    public async Task<IActionResult> GetHazopStudies()
    {
        try
        {
            var data = await _svc.GetHazopStudiesBriefAsync();
            return Ok(new { success = true, data });
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    [HttpGet("hazop-deviations/{hazopStudyId}")]
    [Authorize(Policy = PsmPolicies.CanReadLopa)]
    public async Task<IActionResult> GetHazopDeviations(string hazopStudyId)
    {
        try
        {
            var data = await _svc.GetHazopDeviationsAsync(hazopStudyId);
            return Ok(new { success = true, data });
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }

    // ─── Generate from HAZOP ────────────────────────────────────────────────

    [HttpPost("generate-from-hazop")]
    [Authorize(Policy = PsmPolicies.CanWriteLopa)]
    public async Task<IActionResult> GenerateFromHazop([FromBody] GenerateLopaFromHazopRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.hazop_study_id))
            return BadRequest(new { success = false, error = "hazop_study_id الزامی است" });
        try
        {
            var createReq = new CreateLopaStudyRequest
            {
                title            = $"LOPA from HAZOP {req.hazop_study_id[..Math.Min(8, req.hazop_study_id.Length)]}",
                hazop_study_id   = req.hazop_study_id,
                status           = "Draft",
                data             = req.deviation_data
            };
            var study = await _svc.CreateStudyAsync(createReq, User.GetUserId());

            if (!string.IsNullOrWhiteSpace(req.hazop_deviation_id))
            {
                var scenarioReq = new CreateLopaScenarioRequest
                {
                    scenario_number      = "S-001",
                    initiating_event     = req.deviation_data?.ContainsKey("deviation") == true
                                            ? req.deviation_data["deviation"]?.ToString()
                                            : "See HAZOP deviation",
                    initiating_frequency = 1e-2,
                    consequence_severity = 3,
                    target_risk          = 1e-5,
                    notes               = $"Auto-generated from HAZOP deviation {req.hazop_deviation_id}"
                };
                await _svc.CreateScenarioAsync(study.Id!, scenarioReq);
            }

            return StatusCode(201, new { success = true, data = study });
        }
        catch (Exception e) { return StatusCode(500, new { success = false, error = e.Message }); }
    }
}
