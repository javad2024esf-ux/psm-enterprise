using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

[ApiController]
[Route("workflow")]
[Authorize]
public class WorkflowController : ControllerBase
{
    private readonly IWorkflowService _svc;
    private readonly IAuditService    _audit;
    private readonly ILogger<WorkflowController> _log;

    public WorkflowController(
        IWorkflowService svc,
        IAuditService    audit,
        ILogger<WorkflowController> log)
    {
        _svc   = svc;
        _audit = audit;
        _log   = log;
    }

    private string UserId   => User.GetUserId()   ?? "unknown";
    private string UserRole => User.GetRole();

    // ════════════════════════════════════════════════════════════════════════
    // Definitions
    // ════════════════════════════════════════════════════════════════════════

    [HttpGet("definitions")]
    [Authorize(Policy = PsmPolicies.CanReadWorkflow)]
    public async Task<IActionResult> ListDefinitions()
    {
        try
        {
            var defs = await _svc.ListDefinitionsAsync();
            return Ok(defs);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "ListDefinitions failed");
            return StatusCode(500, Error(ex.Message));
        }
    }

    [HttpGet("definitions/{module}")]
    [Authorize(Policy = PsmPolicies.CanReadWorkflow)]
    public async Task<IActionResult> GetDefinitionForModule(string module)
    {
        try
        {
            var def = await _svc.GetDefinitionForModuleAsync(module);
            if (def is null)
                return NotFound(Error($"No active workflow definition for module '{module}'."));
            return Ok(def);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "GetDefinitionForModule {Module} failed", module);
            return StatusCode(500, Error(ex.Message));
        }
    }

    [HttpPost("definitions")]
    [Authorize(Policy = PsmPolicies.CanAdminWorkflow)]
    public IActionResult CreateDefinition([FromBody] CreateWorkflowDefinitionRequest req)
    {
        return StatusCode(501, Error("Workflow definition creation via API is not yet implemented. " +
                                     "Apply a database migration to add definitions."));
    }

    // ════════════════════════════════════════════════════════════════════════
    // Instance lifecycle
    // ════════════════════════════════════════════════════════════════════════

    [HttpPost("start")]
    [Authorize(Policy = PsmPolicies.CanWriteWorkflow)]
    public async Task<IActionResult> StartWorkflow([FromBody] StartWorkflowRequest req)
    {
        try
        {
            var detail = await _svc.StartWorkflowAsync(req, UserId);
            return StatusCode(201, detail);
        }
        catch (ArgumentException ex)           { return BadRequest(Error(ex.Message)); }
        catch (KeyNotFoundException ex)        { return NotFound(Error(ex.Message)); }
        catch (InvalidOperationException ex)   { return Conflict(Error(ex.Message)); }
        catch (Exception ex)
        {
            _log.LogError(ex, "StartWorkflow failed for record {RecordId}", req.recordId);
            return StatusCode(500, Error(ex.Message));
        }
    }

    [HttpGet("instance/{recordId}")]
    [Authorize(Policy = PsmPolicies.CanReadWorkflow)]
    public async Task<IActionResult> GetInstance(string recordId)
    {
        try
        {
            var detail = await _svc.GetInstanceDetailAsync(recordId, UserRole);
            if (detail is null)
                return NotFound(Error($"No workflow instance found for record '{recordId}'."));
            return Ok(detail);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "GetInstance failed for record {RecordId}", recordId);
            return StatusCode(500, Error(ex.Message));
        }
    }

    [HttpDelete("instance/{recordId}")]
    [Authorize(Policy = PsmPolicies.CanAdminWorkflow)]
    public async Task<IActionResult> DeleteInstance(string recordId)
    {
        try
        {
            await _svc.DeleteInstanceAsync(recordId, UserId);
            return Ok(new { success = true });
        }
        catch (KeyNotFoundException ex) { return NotFound(Error(ex.Message)); }
        catch (Exception ex)
        {
            _log.LogError(ex, "DeleteInstance failed for record {RecordId}", recordId);
            return StatusCode(500, Error(ex.Message));
        }
    }

    [HttpPost("transition")]
    [Authorize(Policy = PsmPolicies.CanWriteWorkflow)]
    public async Task<IActionResult> DoTransition([FromBody] TransitionRequest req)
    {
        try
        {
            var detail = await _svc.DoTransitionAsync(req, UserId, UserRole);
            return Ok(detail);
        }
        catch (ArgumentException ex)           { return BadRequest(Error(ex.Message)); }
        catch (KeyNotFoundException ex)        { return NotFound(Error(ex.Message)); }
        catch (UnauthorizedAccessException ex) { return StatusCode(403, Error(ex.Message)); }
        catch (InvalidOperationException ex)   { return Conflict(Error(ex.Message)); }
        catch (Exception ex)
        {
            _log.LogError(ex, "DoTransition failed for record {RecordId}, action {Action}",
                req.recordId, req.action);
            return StatusCode(500, Error(ex.Message));
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // History
    // ════════════════════════════════════════════════════════════════════════

    [HttpGet("history/{recordId}")]
    [Authorize(Policy = PsmPolicies.CanReadWorkflow)]
    public async Task<IActionResult> GetHistory(string recordId)
    {
        try
        {
            var history = await _svc.GetHistoryAsync(recordId);
            return Ok(history);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "GetHistory failed for record {RecordId}", recordId);
            return StatusCode(500, Error(ex.Message));
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // Dashboard & Analytics
    // ════════════════════════════════════════════════════════════════════════

    [HttpGet("dashboard-summary")]
    [Authorize(Policy = PsmPolicies.CanReadWorkflow)]
    public async Task<IActionResult> GetDashboardSummary()
    {
        try
        {
            var dashboard = await _svc.GetDashboardAsync(UserId, UserRole);
            return Ok(dashboard);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "GetDashboardSummary failed");
            return StatusCode(500, Error(ex.Message));
        }
    }

    [HttpGet("analytics")]
    [Authorize(Policy = PsmPolicies.CanReadWorkflow)]
    public async Task<IActionResult> GetAnalytics()
    {
        try
        {
            var analytics = await _svc.GetAnalyticsAsync();
            return Ok(analytics);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "GetAnalytics failed");
            return StatusCode(500, Error(ex.Message));
        }
    }

    private static object Error(string message) => new { success = false, error = message };
}
