using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

/// <summary>
/// Permit To Work (PTW) — dedicated controller.
/// Route: /api/permits
/// </summary>
[ApiController]
[Route("api/permits")]
[Authorize]
public class PermitsController : ControllerBase
{
    private readonly IPermitService _svc;
    private readonly ILogger<PermitsController> _log;

    public PermitsController(IPermitService svc, ILogger<PermitsController> log)
    {
        _svc = svc;
        _log = log;
    }

    // GET /api/permits
    [HttpGet]
    [Authorize(Policy = PsmPolicies.CanReadPermits)]
    public async Task<IActionResult> List(
        [FromQuery] string? state,
        [FromQuery] string? permitType,
        [FromQuery] string? riskLevel,
        [FromQuery] string? tenantId,
        [FromQuery] int limit  = 50,
        [FromQuery] int offset = 0)
    {

        try
        {
            var (rows, total) = await _svc.ListAsync(state, permitType, riskLevel, tenantId, limit, offset);
            return Ok(new { success = true, data = rows, total, count = total });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error listing permits");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // GET /api/permits/{id}
    [HttpGet("{id}")]
    [Authorize(Policy = PsmPolicies.CanReadPermits)]
    public async Task<IActionResult> GetById(string id)
    {

        try
        {
            var permit = await _svc.GetAsync(id, User.GetRole());
            if (permit is null)
                return NotFound(new { success = false, error = $"مجوز '{id}' یافت نشد" });

            return Ok(new { success = true, data = permit });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error fetching permit {Id}", id);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // POST /api/permits
    [HttpPost]
    [Authorize(Policy = PsmPolicies.CanWritePermits)]
    public async Task<IActionResult> Create([FromBody] CreatePermitRequest req)
    {

        if (string.IsNullOrWhiteSpace(req.PermitType))
            return BadRequest(new { success = false, error = "permitType الزامی است" });
        if (string.IsNullOrWhiteSpace(req.JobTitle))
            return BadRequest(new { success = false, error = "jobTitle الزامی است" });
        if (string.IsNullOrWhiteSpace(req.Location))
            return BadRequest(new { success = false, error = "location الزامی است" });
        if (string.IsNullOrWhiteSpace(req.ContractorName))
            return BadRequest(new { success = false, error = "contractorName الزامی است" });
        if (string.IsNullOrWhiteSpace(req.Supervisor))
            return BadRequest(new { success = false, error = "supervisor الزامی است" });

        try
        {
            var userId = User.GetUserId() ?? "unknown";
            var permit = await _svc.CreateAsync(req, userId, User.GetRole());
            return StatusCode(201, new { success = true, data = permit });
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error creating permit");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // PUT /api/permits/{id}
    [HttpPut("{id}")]
    [Authorize(Policy = PsmPolicies.CanWritePermits)]
    public async Task<IActionResult> Update(string id, [FromBody] UpdatePermitRequest req)
    {

        try
        {
            var userId = User.GetUserId() ?? "unknown";
            var permit = await _svc.UpdateAsync(id, req, userId, User.GetRole());
            return Ok(new { success = true, data = permit });
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error updating permit {Id}", id);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // DELETE /api/permits/{id}  — نیاز به CanDeletePermit دارد
    [HttpDelete("{id}")]
    [Authorize(Policy = PsmPolicies.CanDeletePermit)]
    public async Task<IActionResult> Delete(string id)
    {
        try
        {
            var userId = User.GetUserId() ?? "unknown";
            await _svc.DeleteAsync(id, userId);
            return Ok(new { success = true, message = "مجوز با موفقیت حذف شد" });
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error deleting permit {Id}", id);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // POST /api/permits/{id}/approve
    [HttpPost("{id}/approve")]
    [Authorize(Policy = PsmPolicies.CanApprovePermit)]
    public async Task<IActionResult> Approve(string id, [FromBody] ApprovePermitRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.Level))
            return BadRequest(new { success = false, error = "level الزامی است (supervisor | hse | area_manager)" });

        try
        {
            var userId = User.GetUserId() ?? "unknown";
            var permit = await _svc.ApproveAsync(id, req, userId, User.GetRole());
            return Ok(new { success = true, data = permit });
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(new { success = false, error = ex.Message });
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(new { success = false, error = ex.Message });
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error approving permit {Id}", id);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // POST /api/permits/{id}/close
    [HttpPost("{id}/close")]
    [Authorize(Policy = PsmPolicies.CanWritePermits)]
    public async Task<IActionResult> Close(string id, [FromBody] ClosePermitRequest req)
    {

        try
        {
            var userId = User.GetUserId() ?? "unknown";
            var permit = await _svc.CloseAsync(id, req, userId);
            return Ok(new { success = true, data = permit });
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(new { success = false, error = ex.Message });
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error closing permit {Id}", id);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // POST /api/permits/{id}/crew
    [HttpPost("{id}/crew")]
    [Authorize(Policy = PsmPolicies.CanWritePermits)]
    public async Task<IActionResult> AddCrewMember(string id, [FromBody] CreateCrewMemberRequest req)
    {

        try
        {
            var userId = User.GetUserId() ?? "unknown";
            var permit = await _svc.AddCrewMemberAsync(id, req, userId);
            return Ok(new { success = true, data = permit });
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error adding crew member to permit {Id}", id);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // POST /api/permits/{id}/safety-records
    [HttpPost("{id}/safety-records")]
    [Authorize(Policy = PsmPolicies.CanWritePermits)]
    public async Task<IActionResult> AddSafetyRecord(string id, [FromBody] AddSafetyRecordRequest req)
    {

        try
        {
            var userId = User.GetUserId() ?? "unknown";
            var permit = await _svc.AddSafetyRecordAsync(id, req, userId);
            return Ok(new { success = true, data = permit });
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error adding safety record to permit {Id}", id);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // POST /api/permits/{id}/lessons
    [HttpPost("{id}/lessons")]
    [Authorize(Policy = PsmPolicies.CanWritePermits)]
    public async Task<IActionResult> AddLesson(string id, [FromBody] AddLessonRequest req)
    {

        try
        {
            var userId = User.GetUserId() ?? "unknown";
            var permit = await _svc.AddLessonAsync(id, req, userId);
            return Ok(new { success = true, data = permit });
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error adding lesson to permit {Id}", id);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }
}
