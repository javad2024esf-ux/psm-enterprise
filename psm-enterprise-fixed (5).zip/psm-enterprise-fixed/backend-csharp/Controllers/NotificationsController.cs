using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Middleware;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

/// <summary>
/// Notifications — real PostgreSQL-backed implementation.
/// Replaces the previous stub (no mock data, no hard-coded returns).
///
/// Routes:
///   GET    /api/notifications              — paged list for current user
///   GET    /api/notifications/unread       — unread list (shorthand)
///   POST   /api/notifications/read-all    — mark all read (kept for frontend compat)
///   PUT    /api/notifications/{id}/read   — mark one read
///   POST   /api/notifications/{id}/read   — same (frontend sends both verbs)
///   DELETE /api/notifications/{id}        — delete
/// </summary>
[ApiController]
[Route("api/notifications")]
[Authorize]
public class NotificationsController : ControllerBase
{
    private readonly INotificationService _svc;
    private readonly ILogger<NotificationsController> _log;

    public NotificationsController(
        INotificationService svc,
        ILogger<NotificationsController> log)
    {
        _svc = svc;
        _log = log;
    }

    // ── Current user helper ───────────────────────────────────────────────────
    private string RequireUserId() =>
        User.GetUserId() ?? throw new InvalidOperationException("User ID claim missing.");

    // =========================================================================
    // GET /api/notifications
    // Query: unreadOnly (bool), page (int, 1-based), limit (int)
    // =========================================================================
    [HttpGet]
    public async Task<IActionResult> List(
        [FromQuery] bool unreadOnly = false,
        [FromQuery] int  page       = 1,
        [FromQuery] int  limit      = 20)
    {
        try
        {
            var userId = RequireUserId();
            var result = await _svc.ListAsync(userId, unreadOnly, page, limit);
            return Ok(new
            {
                success      = true,
                data         = result.Data,
                notifications= result.Data,   // alias for frontend compat
                pagination   = new
                {
                    page         = result.Page,
                    limit        = result.Limit,
                    total        = result.Total,
                    unread       = result.UnreadCount,
                },
            });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error listing notifications");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // =========================================================================
    // GET /api/notifications/unread
    // Convenience endpoint — returns only unread notifications (no pagination params needed)
    // =========================================================================
    [HttpGet("unread")]
    public async Task<IActionResult> Unread([FromQuery] int limit = 50)
    {
        try
        {
            var userId = RequireUserId();
            var result = await _svc.ListAsync(userId, unreadOnly: true, page: 1, limit: limit);
            return Ok(new
            {
                success = true,
                data    = result.Data,
                count   = result.UnreadCount,
            });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error fetching unread notifications");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // =========================================================================
    // PUT /api/notifications/{id}/read
    // POST /api/notifications/{id}/read  (frontend sends PATCH and POST both)
    // =========================================================================
    [HttpPut("{id}/read")]
    [HttpPost("{id}/read")]
    [HttpPatch("{id}/read")]
    public async Task<IActionResult> MarkRead(string id)
    {
        try
        {
            var userId = RequireUserId();
            var found  = await _svc.MarkReadAsync(id, userId);
            if (!found)
                return NotFound(new { success = false, error = "اعلان یافت نشد" });

            return Ok(new { success = true, message = "اعلان به‌عنوان خوانده‌شده علامت‌گذاری شد" });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error marking notification {Id} as read", id);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // =========================================================================
    // POST /api/notifications/read-all  (kept for frontend backward compat)
    // =========================================================================
    [HttpPost("read-all")]
    public async Task<IActionResult> MarkAllRead()
    {
        try
        {
            var userId  = RequireUserId();
            var updated = await _svc.MarkAllReadAsync(userId);
            return Ok(new
            {
                success      = true,
                message      = "همه اعلان‌ها به‌عنوان خوانده‌شده علامت‌گذاری شدند",
                updatedCount = updated,
            });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error marking all notifications as read");
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }

    // =========================================================================
    // DELETE /api/notifications/{id}
    // =========================================================================
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id)
    {
        try
        {
            var userId = RequireUserId();
            var found  = await _svc.DeleteAsync(id, userId);
            if (!found)
                return NotFound(new { success = false, error = "اعلان یافت نشد" });

            return Ok(new { success = true, message = "اعلان حذف شد" });
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Error deleting notification {Id}", id);
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }
}
