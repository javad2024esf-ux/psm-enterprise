using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

/// <summary>
/// مراقبة وإدارة حدود معدل الطلب
/// Rate limiting monitoring and management controller
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Authorize]
public class RateLimitController : ControllerBase
{
    private readonly IRateLimitService _rateLimitService;
    private readonly ILogger<RateLimitController> _logger;

    public RateLimitController(IRateLimitService rateLimitService, ILogger<RateLimitController> logger)
    {
        _rateLimitService = rateLimitService;
        _logger = logger;
    }

    /// <summary>
    /// الحصول على إحصائيات حد المعدل للفترة المحددة
    /// Get rate limiting statistics for a time period
    /// </summary>
    /// <param name="from">تاريخ البداية (From date)</param>
    /// <param name="to">تاريخ النهاية (To date)</param>
    /// <returns>إحصائيات حد المعدل (Rate limit statistics)</returns>
    [HttpGet("statistics")]
    [Authorize(Policy = "CanReadAudit")]
    public async Task<IActionResult> GetStatistics(
        [FromQuery] DateTime from,
        [FromQuery] DateTime to)
    {
        if (from == default || to == default)
        {
            return BadRequest(new { error = "تاريخ البداية والنهاية مطلوبة - From and To dates are required" });
        }

        if (from > to)
        {
            return BadRequest(new { error = "تاريخ البداية يجب أن يكون قبل تاريخ النهاية - From date must be before To date" });
        }

        try
        {
            var stats = await _rateLimitService.GetStatisticsAsync(from, to);
            _logger.LogInformation("Rate limit statistics retrieved: {TotalRequests} requests in period {From}-{To}",
                stats.TotalRequests, from, to);
            return Ok(stats);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "خطأ في الحصول على إحصائيات حد المعدل - Error getting rate limit statistics");
            return StatusCode(500, new { error = "خطأ داخلي في الخادم - Internal server error" });
        }
    }

    /// <summary>
    /// الحصول على أحدث انتهاكات حد المعدل
    /// Get recent rate limit violations
    /// </summary>
    /// <param name="limit">عدد السجلات للإرجاع (Number of records to return)</param>
    /// <returns>قائمة انتهاكات حد المعدل (List of rate limit violations)</returns>
    [HttpGet("violations")]
    [Authorize(Policy = "CanReadAudit")]
    public async Task<IActionResult> GetViolations([FromQuery] int limit = 50)
    {
        if (limit <= 0 || limit > 500)
        {
            return BadRequest(new { error = "الحد الأقصى يجب أن يكون بين 1 و 500 - Limit must be between 1 and 500" });
        }

        try
        {
            var violations = await _rateLimitService.GetRecentViolationsAsync(limit);
            _logger.LogInformation("Rate limit violations retrieved: {Count} violations", violations.Count);
            return Ok(new { count = violations.Count, violations });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "خطأ في الحصول على انتهاكات حد المعدل - Error getting rate limit violations");
            return StatusCode(500, new { error = "خطأ داخلي في الخادم - Internal server error" });
        }
    }

    /// <summary>
    /// فحص حالة حدود معدل الطلب
    /// Health check for rate limiting system
    /// </summary>
    /// <returns>حالة نظام تحديد المعدل (Rate limiting system status)</returns>
    [HttpGet("health")]
    [AllowAnonymous]
    public IActionResult HealthCheck()
    {
        return Ok(new
        {
            status = "healthy",
            message = "نظام تحديد معدل الطلب يعمل بشكل صحيح - Rate limiting system is operational",
            timestamp = DateTime.UtcNow
        });
    }

    /// <summary>
    /// الحصول على معلومات الحد الحالية للمستخدم
    /// Get current rate limit info for authenticated user
    /// </summary>
    /// <returns>معلومات حد المعدل الحالي (Current rate limit info)</returns>
    [HttpGet("current-user")]
    public IActionResult GetCurrentUserLimitInfo()
    {
        var userId = User.FindFirst("sub")?.Value 
                  ?? User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

        return Ok(new
        {
            userId = userId ?? "anonymous",
            message = "معدل الحد الحالي: 100 طلب في الدقيقة - Current rate limit: 100 requests per minute",
            limits = new
            {
                authenticatedUser = 100,
                unit = "requests per minute"
            }
        });
    }
}
