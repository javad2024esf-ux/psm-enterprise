using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace PSM.Api.Controllers;

// ════════════════════════════════════════════════════════════════════════════
// HIRA Controller
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/hira")]
[Authorize]
public class HiraController : ControllerBase
{
    private readonly IHiraService _svc;
    public HiraController(IHiraService svc) => _svc = svc;

    [Authorize(Policy = PsmPolicies.CanReadHira)]
    [HttpGet] public async Task<IActionResult> List() { try { return Ok(await _svc.ListAsync()); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanReadHira)]
    [HttpGet("{id}")] public async Task<IActionResult> Get(string id) { try { var item = await _svc.GetAsync(id); return item is null ? NotFound(new { error = "یافت نشد" }) : Ok(item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteHira)]
    [HttpPost] public async Task<IActionResult> Create([FromBody] CreateHiraRequest req) { try { return StatusCode(201, await _svc.CreateAsync(req, User.GetUserId())); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteHira)]
    [HttpPut("{id}")] public async Task<IActionResult> Update(string id, [FromBody] UpdateHiraRequest req) { try { var (found, item) = await _svc.UpdateAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteHira)]
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(string id) { try { return await _svc.DeleteAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }

    [Authorize(Policy = PsmPolicies.CanReadHira)]
    [HttpGet("{hiraId}/hazards")] public async Task<IActionResult> ListHazards(string hiraId) { try { return Ok(await _svc.ListHazardsAsync(hiraId)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteHira)]
    [HttpPost("{hiraId}/hazards")] public async Task<IActionResult> CreateHazard(string hiraId, [FromBody] CreateHiraHazardRequest req) { try { var item = await _svc.CreateHazardAsync(hiraId, req); return item is null ? NotFound(new { error = "HIRA یافت نشد" }) : StatusCode(201, item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteHira)]
    [HttpPut("hazards/{id}")] public async Task<IActionResult> UpdateHazard(string id, [FromBody] UpdateHiraHazardRequest req) { try { var (found, item) = await _svc.UpdateHazardAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteHira)]
    [HttpDelete("hazards/{id}")] public async Task<IActionResult> DeleteHazard(string id) { try { return await _svc.DeleteHazardAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
}

// ════════════════════════════════════════════════════════════════════════════
// RCA Controller
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/rca")]
[Authorize]
public class RcaController : ControllerBase
{
    private readonly IRcaService _svc;
    public RcaController(IRcaService svc) => _svc = svc;

    [Authorize(Policy = PsmPolicies.CanReadRca)]
    [HttpGet] public async Task<IActionResult> List() { try { return Ok(await _svc.ListAsync()); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanReadRca)]
    [HttpGet("{id}")] public async Task<IActionResult> Get(string id) { try { var item = await _svc.GetAsync(id); return item is null ? NotFound(new { error = "یافت نشد" }) : Ok(item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteRca)]
    [HttpPost] public async Task<IActionResult> Create([FromBody] CreateRcaRequest req) { try { return StatusCode(201, await _svc.CreateAsync(req, User.GetUserId())); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteRca)]
    [HttpPut("{id}")] public async Task<IActionResult> Update(string id, [FromBody] UpdateRcaRequest req) { try { var (found, item) = await _svc.UpdateAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteRca)]
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(string id) { try { return await _svc.DeleteAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }

    [Authorize(Policy = PsmPolicies.CanReadRca)]
    [HttpGet("{rcaId}/causes")] public async Task<IActionResult> ListCauses(string rcaId) { try { return Ok(await _svc.ListCausesAsync(rcaId)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteRca)]
    [HttpPost("{rcaId}/causes")] public async Task<IActionResult> CreateCause(string rcaId, [FromBody] CreateRcaCauseRequest req) { try { var item = await _svc.CreateCauseAsync(rcaId, req); return item is null ? NotFound(new { error = "RCA یافت نشد" }) : StatusCode(201, item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteRca)]
    [HttpPut("causes/{id}")] public async Task<IActionResult> UpdateCause(string id, [FromBody] UpdateRcaCauseRequest req) { try { var (found, item) = await _svc.UpdateCauseAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteRca)]
    [HttpDelete("causes/{id}")] public async Task<IActionResult> DeleteCause(string id) { try { return await _svc.DeleteCauseAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
}

// ════════════════════════════════════════════════════════════════════════════
// Competency Controller
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/competency")]
[Authorize]
public class CompetencyController : ControllerBase
{
    private readonly ICompetencyService _svc;
    public CompetencyController(ICompetencyService svc) => _svc = svc;

    [Authorize(Policy = PsmPolicies.CanReadCompetency)]
    [HttpGet] public async Task<IActionResult> List() { try { return Ok(await _svc.ListAsync()); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanReadCompetency)]
    [HttpGet("{id}")] public async Task<IActionResult> Get(string id) { try { var item = await _svc.GetAsync(id); return item is null ? NotFound(new { error = "یافت نشد" }) : Ok(item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteCompetency)]
    [HttpPost] public async Task<IActionResult> Create([FromBody] CreateCompetencyRequest req) { try { return StatusCode(201, await _svc.CreateAsync(req)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteCompetency)]
    [HttpPut("{id}")] public async Task<IActionResult> Update(string id, [FromBody] UpdateCompetencyRequest req) { try { var (found, item) = await _svc.UpdateAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteCompetency)]
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(string id) { try { return await _svc.DeleteAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }

    [Authorize(Policy = PsmPolicies.CanReadCompetency)]
    [HttpGet("{competencyId}/assessments")] public async Task<IActionResult> ListAssessments(string competencyId) { try { return Ok(await _svc.ListAssessmentsAsync(competencyId)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteCompetency)]
    [HttpPost("{competencyId}/assessments")] public async Task<IActionResult> CreateAssessment(string competencyId, [FromBody] CreateCompetencyAssessmentRequest req) { try { return StatusCode(201, await _svc.CreateAssessmentAsync(competencyId, req)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteCompetency)]
    [HttpDelete("assessments/{id}")] public async Task<IActionResult> DeleteAssessment(string id) { try { return await _svc.DeleteAssessmentAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
}

// ════════════════════════════════════════════════════════════════════════════
// Training Controller
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/training")]
[Authorize]
public class TrainingController : ControllerBase
{
    private readonly ITrainingService _svc;
    public TrainingController(ITrainingService svc) => _svc = svc;

    [Authorize(Policy = PsmPolicies.CanReadTraining)]
    [HttpGet] public async Task<IActionResult> List() { try { return Ok(await _svc.ListAsync()); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanReadTraining)]
    [HttpGet("{id}")] public async Task<IActionResult> Get(string id) { try { var item = await _svc.GetAsync(id); return item is null ? NotFound(new { error = "یافت نشد" }) : Ok(item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteTraining)]
    [HttpPost] public async Task<IActionResult> Create([FromBody] CreateTrainingRequest req) { try { return StatusCode(201, await _svc.CreateAsync(req, User.GetUserId())); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteTraining)]
    [HttpPut("{id}")] public async Task<IActionResult> Update(string id, [FromBody] UpdateTrainingRequest req) { try { var (found, item) = await _svc.UpdateAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteTraining)]
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(string id) { try { return await _svc.DeleteAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }

    [Authorize(Policy = PsmPolicies.CanReadTraining)]
    [HttpGet("{trainingId}/participants")] public async Task<IActionResult> ListParticipants(string trainingId) { try { return Ok(await _svc.ListParticipantsAsync(trainingId)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteTraining)]
    [HttpPost("{trainingId}/participants")] public async Task<IActionResult> AddParticipant(string trainingId, [FromBody] CreateTrainingParticipantRequest req) { try { return StatusCode(201, await _svc.AddParticipantAsync(trainingId, req)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteTraining)]
    [HttpDelete("participants/{id}")] public async Task<IActionResult> RemoveParticipant(string id) { try { return await _svc.RemoveParticipantAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
}

// ════════════════════════════════════════════════════════════════════════════
// Contractors Controller
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/contractors")]
[Authorize]
public class ContractorsController : ControllerBase
{
    private readonly IContractorService _svc;
    public ContractorsController(IContractorService svc) => _svc = svc;

    [Authorize(Policy = PsmPolicies.CanReadContractors)]
    [HttpGet] public async Task<IActionResult> List() { try { return Ok(await _svc.ListAsync()); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanReadContractors)]
    [HttpGet("{id}")] public async Task<IActionResult> Get(string id) { try { var item = await _svc.GetAsync(id); return item is null ? NotFound(new { error = "یافت نشد" }) : Ok(item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteContractors)]
    [HttpPost] public async Task<IActionResult> Create([FromBody] CreateContractorRequest req) { try { return StatusCode(201, await _svc.CreateAsync(req, User.GetUserId())); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteContractors)]
    [HttpPut("{id}")] public async Task<IActionResult> Update(string id, [FromBody] UpdateContractorRequest req) { try { var (found, item) = await _svc.UpdateAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteContractors)]
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(string id) { try { return await _svc.DeleteAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
}

// ════════════════════════════════════════════════════════════════════════════
// PSI Controller
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/psi")]
[Authorize]
public class PsiController : ControllerBase
{
    private readonly IPsiService _svc;
    public PsiController(IPsiService svc) => _svc = svc;

    [Authorize(Policy = PsmPolicies.CanReadPsi)]
    [HttpGet] public async Task<IActionResult> List() { try { return Ok(await _svc.ListAsync()); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanReadPsi)]
    [HttpGet("{id}")] public async Task<IActionResult> Get(string id) { try { var item = await _svc.GetAsync(id); return item is null ? NotFound(new { error = "یافت نشد" }) : Ok(item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWritePsi)]
    [HttpPost] public async Task<IActionResult> Create([FromBody] CreatePsiRequest req) { try { return StatusCode(201, await _svc.CreateAsync(req, User.GetUserId())); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWritePsi)]
    [HttpPut("{id}")] public async Task<IActionResult> Update(string id, [FromBody] UpdatePsiRequest req) { try { var (found, item) = await _svc.UpdateAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWritePsi)]
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(string id) { try { return await _svc.DeleteAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
}

// ════════════════════════════════════════════════════════════════════════════
// Mechanical Integrity Controller
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/mechanical-integrity")]
[Authorize]
public class MechanicalIntegrityController : ControllerBase
{
    private readonly IMechanicalIntegrityService _svc;
    public MechanicalIntegrityController(IMechanicalIntegrityService svc) => _svc = svc;

    [Authorize(Policy = PsmPolicies.CanReadMechanicalIntegrity)]
    [HttpGet("equipment")] public async Task<IActionResult> ListEquipment() { try { return Ok(await _svc.ListEquipmentAsync()); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanReadMechanicalIntegrity)]
    [HttpGet("equipment/{id}")] public async Task<IActionResult> GetEquipment(string id) { try { var item = await _svc.GetEquipmentAsync(id); return item is null ? NotFound(new { error = "یافت نشد" }) : Ok(item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteMechanicalIntegrity)]
    [HttpPost("equipment")] public async Task<IActionResult> CreateEquipment([FromBody] CreateMiEquipmentRequest req) { try { return StatusCode(201, await _svc.CreateEquipmentAsync(req)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteMechanicalIntegrity)]
    [HttpPut("equipment/{id}")] public async Task<IActionResult> UpdateEquipment(string id, [FromBody] UpdateMiEquipmentRequest req) { try { var (found, item) = await _svc.UpdateEquipmentAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteMechanicalIntegrity)]
    [HttpDelete("equipment/{id}")] public async Task<IActionResult> DeleteEquipment(string id) { try { return await _svc.DeleteEquipmentAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }

    [Authorize(Policy = PsmPolicies.CanReadMechanicalIntegrity)]
    [HttpGet("equipment/{equipmentId}/inspections")] public async Task<IActionResult> ListInspections(string equipmentId) { try { return Ok(await _svc.ListInspectionsAsync(equipmentId)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteMechanicalIntegrity)]
    [HttpPost("equipment/{equipmentId}/inspections")] public async Task<IActionResult> CreateInspection(string equipmentId, [FromBody] CreateMiInspectionRequest req) { try { var item = await _svc.CreateInspectionAsync(equipmentId, req); return item is null ? NotFound(new { error = "تجهیز یافت نشد" }) : StatusCode(201, item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteMechanicalIntegrity)]
    [HttpDelete("inspections/{id}")] public async Task<IActionResult> DeleteInspection(string id) { try { return await _svc.DeleteInspectionAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
}

// ════════════════════════════════════════════════════════════════════════════
// Emergency Controller
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/emergency")]
[Authorize]
public class EmergencyController : ControllerBase
{
    private readonly IEmergencyService _svc;
    public EmergencyController(IEmergencyService svc) => _svc = svc;

    [Authorize(Policy = PsmPolicies.CanReadEmergency)]
    [HttpGet] public async Task<IActionResult> List() { try { return Ok(await _svc.ListAsync()); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanReadEmergency)]
    [HttpGet("{id}")] public async Task<IActionResult> Get(string id) { try { var item = await _svc.GetAsync(id); return item is null ? NotFound(new { error = "یافت نشد" }) : Ok(item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteEmergency)]
    [HttpPost] public async Task<IActionResult> Create([FromBody] CreateEmergencyPlanRequest req) { try { return StatusCode(201, await _svc.CreateAsync(req, User.GetUserId())); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteEmergency)]
    [HttpPut("{id}")] public async Task<IActionResult> Update(string id, [FromBody] UpdateEmergencyPlanRequest req) { try { var (found, item) = await _svc.UpdateAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteEmergency)]
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(string id) { try { return await _svc.DeleteAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
}

// ════════════════════════════════════════════════════════════════════════════
// Participation Controller
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/participation")]
[Authorize]
public class ParticipationController : ControllerBase
{
    private readonly IParticipationService _svc;
    public ParticipationController(IParticipationService svc) => _svc = svc;

    [Authorize(Policy = PsmPolicies.CanReadParticipation)]
    [HttpGet] public async Task<IActionResult> List() { try { return Ok(await _svc.ListAsync()); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanReadParticipation)]
    [HttpGet("{id}")] public async Task<IActionResult> Get(string id) { try { var item = await _svc.GetAsync(id); return item is null ? NotFound(new { error = "یافت نشد" }) : Ok(item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteParticipation)]
    [HttpPost] public async Task<IActionResult> Create([FromBody] CreateParticipationRequest req) { try { return StatusCode(201, await _svc.CreateAsync(req, User.GetUserId())); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteParticipation)]
    [HttpPut("{id}")] public async Task<IActionResult> Update(string id, [FromBody] UpdateParticipationRequest req) { try { var (found, item) = await _svc.UpdateAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteParticipation)]
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(string id) { try { return await _svc.DeleteAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
}

// ════════════════════════════════════════════════════════════════════════════
// Culture Controller
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/culture")]
[Authorize]
public class CultureController : ControllerBase
{
    private readonly ICultureService _svc;
    public CultureController(ICultureService svc) => _svc = svc;

    [Authorize(Policy = PsmPolicies.CanReadCulture)]
    [HttpGet] public async Task<IActionResult> List() { try { return Ok(await _svc.ListAsync()); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanReadCulture)]
    [HttpGet("{id}")] public async Task<IActionResult> Get(string id) { try { var item = await _svc.GetAsync(id); return item is null ? NotFound(new { error = "یافت نشد" }) : Ok(item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteCulture)]
    [HttpPost] public async Task<IActionResult> Create([FromBody] CreateCultureAssessmentRequest req) { try { return StatusCode(201, await _svc.CreateAsync(req, User.GetUserId())); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteCulture)]
    [HttpPut("{id}")] public async Task<IActionResult> Update(string id, [FromBody] UpdateCultureAssessmentRequest req) { try { var (found, item) = await _svc.UpdateAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteCulture)]
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(string id) { try { return await _svc.DeleteAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }

    [Authorize(Policy = PsmPolicies.CanReadCulture)]
    [HttpGet("{assessmentId}/responses")] public async Task<IActionResult> ListResponses(string assessmentId) { try { return Ok(await _svc.ListResponsesAsync(assessmentId)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteCulture)]
    [HttpPost("{assessmentId}/responses")] public async Task<IActionResult> CreateResponse(string assessmentId, [FromBody] CreateCultureResponseRequest req) { try { return StatusCode(201, await _svc.CreateResponseAsync(assessmentId, req)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
}

// ════════════════════════════════════════════════════════════════════════════
// Stakeholders Controller
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/stakeholders")]
[Authorize]
public class StakeholdersController : ControllerBase
{
    private readonly IStakeholderService _svc;
    public StakeholdersController(IStakeholderService svc) => _svc = svc;

    [Authorize(Policy = PsmPolicies.CanReadStakeholders)]
    [HttpGet] public async Task<IActionResult> List() { try { return Ok(await _svc.ListAsync()); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanReadStakeholders)]
    [HttpGet("{id}")] public async Task<IActionResult> Get(string id) { try { var item = await _svc.GetAsync(id); return item is null ? NotFound(new { error = "یافت نشد" }) : Ok(item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteStakeholders)]
    [HttpPost] public async Task<IActionResult> Create([FromBody] CreateStakeholderRequest req) { try { return StatusCode(201, await _svc.CreateAsync(req, User.GetUserId())); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteStakeholders)]
    [HttpPut("{id}")] public async Task<IActionResult> Update(string id, [FromBody] UpdateStakeholderRequest req) { try { var (found, item) = await _svc.UpdateAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteStakeholders)]
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(string id) { try { return await _svc.DeleteAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
}

// ════════════════════════════════════════════════════════════════════════════
// Standards Controller
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/standards")]
[Authorize]
public class StandardsController : ControllerBase
{
    private readonly IStandardService _svc;
    public StandardsController(IStandardService svc) => _svc = svc;

    [Authorize(Policy = PsmPolicies.CanReadStandards)]
    [HttpGet] public async Task<IActionResult> List() { try { return Ok(await _svc.ListAsync()); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanReadStandards)]
    [HttpGet("{id}")] public async Task<IActionResult> Get(string id) { try { var item = await _svc.GetAsync(id); return item is null ? NotFound(new { error = "یافت نشد" }) : Ok(item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteStandards)]
    [HttpPost] public async Task<IActionResult> Create([FromBody] CreateStandardRequest req) { try { return StatusCode(201, await _svc.CreateAsync(req, User.GetUserId())); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteStandards)]
    [HttpPut("{id}")] public async Task<IActionResult> Update(string id, [FromBody] UpdateStandardRequest req) { try { var (found, item) = await _svc.UpdateAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteStandards)]
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(string id) { try { return await _svc.DeleteAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
}

// ════════════════════════════════════════════════════════════════════════════
// Metrics Controller
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/metrics")]
[Authorize]
public class MetricsController : ControllerBase
{
    private readonly IMetricService _svc;
    public MetricsController(IMetricService svc) => _svc = svc;

    [Authorize(Policy = PsmPolicies.CanReadMetrics)]
    [HttpGet] public async Task<IActionResult> List() { try { return Ok(await _svc.ListAsync()); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanReadMetrics)]
    [HttpGet("{id}")] public async Task<IActionResult> Get(string id) { try { var item = await _svc.GetAsync(id); return item is null ? NotFound(new { error = "یافت نشد" }) : Ok(item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteMetrics)]
    [HttpPost] public async Task<IActionResult> Create([FromBody] CreateMetricRequest req) { try { return StatusCode(201, await _svc.CreateAsync(req, User.GetUserId())); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteMetrics)]
    [HttpPut("{id}")] public async Task<IActionResult> Update(string id, [FromBody] UpdateMetricRequest req) { try { var (found, item) = await _svc.UpdateAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteMetrics)]
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(string id) { try { return await _svc.DeleteAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }

    [Authorize(Policy = PsmPolicies.CanReadMetrics)]
    [HttpGet("{metricId}/entries")] public async Task<IActionResult> ListEntries(string metricId) { try { return Ok(await _svc.ListEntriesAsync(metricId)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteMetrics)]
    [HttpPost("{metricId}/entries")] public async Task<IActionResult> CreateEntry(string metricId, [FromBody] CreateMetricEntryRequest req) { try { return StatusCode(201, await _svc.CreateEntryAsync(metricId, req)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteMetrics)]
    [HttpDelete("entries/{id}")] public async Task<IActionResult> DeleteEntry(string id) { try { return await _svc.DeleteEntryAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
}

// ════════════════════════════════════════════════════════════════════════════
// Management Review Controller
// ════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/management-review")]
[Authorize]
public class ManagementReviewController : ControllerBase
{
    private readonly IManagementReviewService _svc;
    public ManagementReviewController(IManagementReviewService svc) => _svc = svc;

    [Authorize(Policy = PsmPolicies.CanReadManagementReview)]
    [HttpGet] public async Task<IActionResult> List() { try { return Ok(await _svc.ListAsync()); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanReadManagementReview)]
    [HttpGet("{id}")] public async Task<IActionResult> Get(string id) { try { var item = await _svc.GetAsync(id); return item is null ? NotFound(new { error = "یافت نشد" }) : Ok(item); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteManagementReview)]
    [HttpPost] public async Task<IActionResult> Create([FromBody] CreateManagementReviewRequest req) { try { return StatusCode(201, await _svc.CreateAsync(req, User.GetUserId())); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteManagementReview)]
    [HttpPut("{id}")] public async Task<IActionResult> Update(string id, [FromBody] UpdateManagementReviewRequest req) { try { var (found, item) = await _svc.UpdateAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteManagementReview)]
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(string id) { try { return await _svc.DeleteAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }

    [Authorize(Policy = PsmPolicies.CanReadManagementReview)]
    [HttpGet("{reviewId}/action-items")] public async Task<IActionResult> ListActionItems(string reviewId) { try { return Ok(await _svc.ListActionItemsAsync(reviewId)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteManagementReview)]
    [HttpPost("{reviewId}/action-items")] public async Task<IActionResult> CreateActionItem(string reviewId, [FromBody] CreateMrActionItemRequest req) { try { return StatusCode(201, await _svc.CreateActionItemAsync(reviewId, req)); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteManagementReview)]
    [HttpPut("action-items/{id}")] public async Task<IActionResult> UpdateActionItem(string id, [FromBody] CreateMrActionItemRequest req) { try { var (found, item) = await _svc.UpdateActionItemAsync(id, req); return found ? Ok(item) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
    [Authorize(Policy = PsmPolicies.CanWriteManagementReview)]
    [HttpDelete("action-items/{id}")] public async Task<IActionResult> DeleteActionItem(string id) { try { return await _svc.DeleteActionItemAsync(id) ? Ok(new { success = true }) : NotFound(new { error = "یافت نشد" }); } catch (Exception e) { return StatusCode(500, new { error = e.Message }); } }
}
