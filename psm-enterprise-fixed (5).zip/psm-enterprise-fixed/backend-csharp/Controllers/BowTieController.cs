using PSM.Api.Configuration;
using PSM.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;
using PSM.Api.Authorization;

namespace PSM.Api.Controllers;
[ApiController]
[Route("api/bowtie")]
[Authorize]
public class BowTieController : ControllerBase
{
    private readonly IBowTieService _service;

    public BowTieController(IBowTieService service)
    {
        _service = service ?? throw new ArgumentNullException(nameof(service));
    }

    // ── DIAGRAMS ──────────────────────────────────────────────────────────

    [HttpGet("diagrams")]
    [Authorize(Policy = PsmPolicies.CanReadBowTie)]
    public async Task<ActionResult<ApiResponse<List<BowTieDiagramDto>>>> GetDiagrams(
        [FromQuery] string? hazopStudyId = null,
        [FromQuery] string? lopaStudyId = null)
    {
        try
        {
            var diagrams = await _service.GetDiagramsAsync(hazopStudyId, lopaStudyId);
            return Ok(new ApiResponse<List<BowTieDiagramDto>>(true, diagrams));
        }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpGet("diagrams/{id}")]
    [Authorize(Policy = PsmPolicies.CanReadBowTie)]
    public async Task<ActionResult<ApiResponse<BowTieDiagramDetailDto>>> GetDiagram(string id)
    {
        try
        {
            var diagram = await _service.GetDiagramAsync(id);
            if (diagram == null)
                return NotFound(new ApiResponse<object>(false, null, "Diagram not found"));
            return Ok(new ApiResponse<BowTieDiagramDetailDto>(true, diagram));
        }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpPost("diagrams")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<ActionResult<ApiResponse<object>>> CreateDiagram([FromBody] CreateBowTieDiagramDto dto)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        try
        {
            var id = await _service.CreateDiagramAsync(dto, this.GetCurrentUser());
            return CreatedAtAction(nameof(GetDiagram), new { id },
                new ApiResponse<object>(true, new { id }));
        }
        catch (ArgumentException ex) { return BadRequest(new ApiResponse<object>(false, null, ex.Message)); }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpPut("diagrams/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<ActionResult<ApiResponse<object>>> UpdateDiagram(string id, [FromBody] UpdateBowTieDiagramDto dto)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        try
        {
            await _service.UpdateDiagramAsync(id, dto, this.GetCurrentUser());
            return Ok(new ApiResponse<object>(true, new { id }));
        }
        catch (KeyNotFoundException) { return NotFound(new ApiResponse<object>(false, null, "Diagram not found")); }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpDelete("diagrams/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<IActionResult> DeleteDiagram(string id)
    {
        try
        {
            await _service.DeleteDiagramAsync(id);
            return NoContent();
        }
        catch (KeyNotFoundException) { return NotFound(new ApiResponse<object>(false, null, "Diagram not found")); }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    // ── CAUSES ────────────────────────────────────────────────────────────

    [HttpGet("diagrams/{diagramId}/causes")]
    [Authorize(Policy = PsmPolicies.CanReadBowTie)]
    public async Task<ActionResult<ApiResponse<List<BowTieCauseDto>>>> GetCauses(string diagramId)
    {
        try
        {
            var causes = await _service.GetCausesAsync(diagramId);
            return Ok(new ApiResponse<List<BowTieCauseDto>>(true, causes));
        }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpPost("diagrams/{diagramId}/causes")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<ActionResult<ApiResponse<object>>> CreateCause(string diagramId, [FromBody] CreateBowTieCauseDto dto)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        try
        {
            dto.DiagramId = diagramId;
            var id = await _service.CreateCauseAsync(dto, this.GetCurrentUser());
            return CreatedAtAction(nameof(GetCauses), new { diagramId },
                new ApiResponse<object>(true, new { id }));
        }
        catch (ArgumentException ex) { return BadRequest(new ApiResponse<object>(false, null, ex.Message)); }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpPut("causes/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<ActionResult<ApiResponse<object>>> UpdateCause(string id, [FromBody] UpdateBowTieCauseDto dto)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        try
        {
            await _service.UpdateCauseAsync(id, dto, this.GetCurrentUser());
            return Ok(new ApiResponse<object>(true, new { id }));
        }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpDelete("causes/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<IActionResult> DeleteCause(string id)
    {
        try
        {
            await _service.DeleteCauseAsync(id);
            return NoContent();
        }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    // ── CONSEQUENCES ──────────────────────────────────────────────────────

    [HttpGet("diagrams/{diagramId}/consequences")]
    [Authorize(Policy = PsmPolicies.CanReadBowTie)]
    public async Task<ActionResult<ApiResponse<List<BowTieConsequenceDto>>>> GetConsequences(string diagramId)
    {
        try
        {
            var consequences = await _service.GetConsequencesAsync(diagramId);
            return Ok(new ApiResponse<List<BowTieConsequenceDto>>(true, consequences));
        }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpPost("diagrams/{diagramId}/consequences")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<ActionResult<ApiResponse<object>>> CreateConsequence(string diagramId, [FromBody] CreateBowTieConsequenceDto dto)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        try
        {
            dto.DiagramId = diagramId;
            var id = await _service.CreateConsequenceAsync(dto, this.GetCurrentUser());
            return CreatedAtAction(nameof(GetConsequences), new { diagramId },
                new ApiResponse<object>(true, new { id }));
        }
        catch (ArgumentException ex) { return BadRequest(new ApiResponse<object>(false, null, ex.Message)); }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpPut("consequences/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<ActionResult<ApiResponse<object>>> UpdateConsequence(string id, [FromBody] UpdateBowTieConsequenceDto dto)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        try
        {
            await _service.UpdateConsequenceAsync(id, dto, this.GetCurrentUser());
            return Ok(new ApiResponse<object>(true, new { id }));
        }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpDelete("consequences/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<IActionResult> DeleteConsequence(string id)
    {
        try
        {
            await _service.DeleteConsequenceAsync(id);
            return NoContent();
        }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    // ── BARRIERS ──────────────────────────────────────────────────────────

    [HttpGet("diagrams/{diagramId}/barriers")]
    [Authorize(Policy = PsmPolicies.CanReadBowTie)]
    public async Task<ActionResult<ApiResponse<List<BowTieBarrierDto>>>> GetBarriers(string diagramId)
    {
        try
        {
            var barriers = await _service.GetBarriersAsync(diagramId);
            return Ok(new ApiResponse<List<BowTieBarrierDto>>(true, barriers));
        }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpPost("diagrams/{diagramId}/barriers")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<ActionResult<ApiResponse<object>>> CreateBarrier(string diagramId, [FromBody] CreateBowTieBarrierDto dto)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        try
        {
            dto.DiagramId = diagramId;
            var id = await _service.CreateBarrierAsync(dto, this.GetCurrentUser());
            return CreatedAtAction(nameof(GetBarriers), new { diagramId },
                new ApiResponse<object>(true, new { id }));
        }
        catch (ArgumentException ex) { return BadRequest(new ApiResponse<object>(false, null, ex.Message)); }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpPut("barriers/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<ActionResult<ApiResponse<object>>> UpdateBarrier(string id, [FromBody] UpdateBowTieBarrierDto dto)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        try
        {
            await _service.UpdateBarrierAsync(id, dto, this.GetCurrentUser());
            return Ok(new ApiResponse<object>(true, new { id }));
        }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpDelete("barriers/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<IActionResult> DeleteBarrier(string id)
    {
        try
        {
            await _service.DeleteBarrierAsync(id);
            return NoContent();
        }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    // ── CONTROLS ──────────────────────────────────────────────────────────

    [HttpPost("barriers/{barrierId}/controls")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<ActionResult<ApiResponse<object>>> CreateControl(string barrierId, [FromBody] CreateBowTieControlDto dto)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        try
        {
            dto.BarrierId = barrierId;
            var id = await _service.CreateControlAsync(dto, this.GetCurrentUser());
            return CreatedAtAction(nameof(GetBarriers), null,
                new ApiResponse<object>(true, new { id }));
        }
        catch (ArgumentException ex) { return BadRequest(new ApiResponse<object>(false, null, ex.Message)); }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpPut("controls/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<ActionResult<ApiResponse<object>>> UpdateControl(string id, [FromBody] UpdateBowTieControlDto dto)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        try
        {
            await _service.UpdateControlAsync(id, dto, this.GetCurrentUser());
            return Ok(new ApiResponse<object>(true, new { id }));
        }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    [HttpDelete("controls/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteBowTie)]
    public async Task<IActionResult> DeleteControl(string id)
    {
        try
        {
            await _service.DeleteControlAsync(id);
            return NoContent();
        }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }

    // ── SUMMARY ───────────────────────────────────────────────────────────

    [HttpGet("summary")]
    [Authorize(Policy = PsmPolicies.CanReadBowTie)]
    public async Task<ActionResult<ApiResponse<BowTieSummaryDto>>> GetSummary()
    {
        try
        {
            var summary = await _service.GetSummaryAsync();
            return Ok(new ApiResponse<BowTieSummaryDto>(true, summary));
        }
        catch (Exception ex) { return StatusCode(500, new ApiResponse<object>(false, null, ex.Message)); }
    }
}
