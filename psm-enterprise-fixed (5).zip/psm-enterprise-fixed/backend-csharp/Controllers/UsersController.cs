using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Models;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

[ApiController]
[Route("api/users")]
[Authorize]
public class UsersController : ControllerBase
{
    private readonly IUserService  _users;
    private readonly IAuditService _audit;

    public UsersController(IUserService users, IAuditService audit)
    {
        _users = users;
        _audit = audit;
    }

    // GET /api/users
    [HttpGet]
    [Authorize(Policy = PsmPolicies.CanManageUsers)]
    public async Task<IActionResult> GetAll()
    {
        var users = await _users.GetAllAsync();
        return Ok(new { success = true, data = users, users });
    }

    // POST /api/users
    [HttpPost]
    [Authorize(Policy = PsmPolicies.CanManageUsers)]
    public async Task<IActionResult> Create([FromBody] CreateUserRequest req)
    {
        var callerRole = User.GetRole();
        var (user, error) = await _users.CreateAsync(req, callerRole);
        if (error is not null) return StatusCode(error.Contains("فقط") ? 403 : 400,
            new { success = false, error });

        await _audit.ForRequest(HttpContext)
            .Action(AuditAction.CreateUser)
            .Severity(AuditSeverity.Warning)
            .User(User.GetUserId(), User.GetUsername(), User.GetFullName(), callerRole)
            .Module("users")
            .Record(user!.Id, user.FullName)
            .Meta(new { newUsername = user.Username, newRole = user.Role, department = user.Department })
            .WriteAsync(_audit);

        return StatusCode(201, new { success = true, data = user });
    }

    // PATCH /api/users/:id
    [HttpPatch("{id}")]
    public async Task<IActionResult> Update(string id, [FromBody] UpdateUserRequest req)
    {
        var callerRole = User.GetRole();
        var callerId   = User.GetUserId();

        // کاربر می‌تواند فقط خودش را ویرایش کند؛ مدیران همه را
        var canManage = await IsAuthorizedToManageUsersAsync();
        if (!canManage && callerId != id)
            return StatusCode(403, new { success = false, error = "دسترسی ندارید" });

        var before = await _users.GetByIdAsync(id);
        if (before is null) return NotFound(new { success = false, error = "کاربر یافت نشد" });

        var (user, error) = await _users.UpdateAsync(id, req);
        if (error is not null) return NotFound(new { success = false, error });

        bool roleChanged = req.Role is not null && req.Role != before.Role;

        await _audit.ForRequest(HttpContext)
            .Action(roleChanged ? AuditAction.RoleChanged : AuditAction.UpdateUser)
            .Severity(roleChanged ? AuditSeverity.Critical : AuditSeverity.Warning)
            .User(callerId, User.GetUsername(), User.GetFullName(), callerRole)
            .Module("users")
            .Record(id, before.FullName)
            .Diff(before, user)
            .WriteAsync(_audit);

        return Ok(new { success = true, data = user });
    }

    // DELETE /api/users/:id
    [HttpDelete("{id}")]
    [Authorize(Policy = PsmPolicies.CanDeleteUsers)]
    public async Task<IActionResult> Delete(string id)
    {
        var target = await _users.GetByIdAsync(id);
        var error  = await _users.DeleteAsync(id);
        if (error is not null) return NotFound(new { success = false, error });

        await _audit.ForRequest(HttpContext)
            .Action(AuditAction.DeleteUser)
            .Severity(AuditSeverity.Critical)
            .User(User.GetUserId(), User.GetUsername(), User.GetFullName(), User.GetRole())
            .Module("users")
            .Record(id, target?.FullName)
            .Meta(new { deletedUsername = target?.Username, deletedRole = target?.Role })
            .WriteAsync(_audit);

        return Ok(new { success = true });
    }

    // POST /api/users/:id/unlock
    [HttpPost("{id}/unlock")]
    [Authorize(Policy = PsmPolicies.CanManageUsers)]
    public async Task<IActionResult> Unlock(string id)
    {
        var error = await _users.UnlockAsync(id);
        if (error is not null) return NotFound(new { success = false, error });

        await _audit.ForRequest(HttpContext)
            .Action(AuditAction.UnlockUser)
            .Severity(AuditSeverity.Warning)
            .User(User.GetUserId(), User.GetUsername(), User.GetFullName(), User.GetRole())
            .Module("users")
            .Record(id)
            .WriteAsync(_audit);

        return Ok(new { success = true });
    }

    // ─── Helper: بررسی Policy بدون inject کردن IAuthorizationService ─────────
    private Task<bool> IsAuthorizedToManageUsersAsync()
    {
        // CanManageUsers در Program.cs به Admin و PSMManager داده شده است.
        // چون اینجا نمی‌توان به صورت inline از [Authorize(Policy=...)] استفاده کرد،
        // از همان claim role که در JWT است استفاده می‌کنیم.
        var role = User.GetRole();
        return Task.FromResult(role is "Admin" or "PSMManager");
    }
}

file static class AuditBuilderExtensions
{
    public static Task WriteAsync(this AuditBuilder builder, IAuditService svc) =>
        svc.WriteEntryAsync(builder.Build());
}
