using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.Authorization;
using PSM.Api.DTOs;
using PSM.Api.Middleware;
using PSM.Api.Services;

namespace PSM.Api.Controllers;

/// <summary>
/// Integration Engine Controller — RESTful API for system integrations
///
/// Manages integration rules that automatically respond to events across modules.
/// When an event occurs (e.g., MOC approved, Incident created), matching rules
/// trigger actions in other modules (e.g., create Action Register, start workflow).
///
/// Routes:
///   GET    /integration/rules              — List all integration rules
///   POST   /integration/rules              — Create new rule
///   PUT    /integration/rules/{id}         — Update existing rule
///   DELETE /integration/rules/{id}         — Delete rule
///   GET    /integration/events             — List recent integration events
///   POST   /integration/execute            — Manually trigger rule execution
///   GET    /integration/stats              — System health and statistics
/// </summary>
[ApiController]
[Route("integration")]
[Authorize]
public class IntegrationController : ControllerBase
{
    private readonly IIntegrationService _service;
    private readonly ILogger<IntegrationController> _logger;

    public IntegrationController(
        IIntegrationService service,
        ILogger<IntegrationController> logger)
    {
        _service = service ?? throw new ArgumentNullException(nameof(service));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    private string GetCurrentUserId() =>
        User.GetUserId() ?? throw new UnauthorizedAccessException("User ID claim is missing.");

    // ═════════════════════════════════════════════════════════════════════════════
    // RULES MANAGEMENT
    // ═════════════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────────────
    // LIST RULES: GET /integration/rules
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Lists all integration rules with optional filtering.
    /// 
    /// Query Parameters:
    ///   - sourceModule (optional): Filter by source module
    ///   - targetModule (optional): Filter by target module
    ///   - isActive (optional): Filter by active status
    ///   - page (optional, default=1): Page number
    ///   - limit (optional, default=20): Records per page
    /// </summary>
    [HttpGet("rules")]
    [Authorize(Policy = PsmPolicies.CanReadIntegration)]
    [ProducesResponseType(typeof(IntegrationRuleListResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> ListRules(
        [FromQuery] string? sourceModule = null,
        [FromQuery] string? targetModule = null,
        [FromQuery] bool? isActive = null,
        [FromQuery] int page = 1,
        [FromQuery] int limit = 20)
    {

        try
        {
            var result = await _service.ListRulesAsync(
                sourceModule, targetModule, isActive, page, limit);

            return Ok(new
            {
                success = true,
                data = result.Data,
                pagination = new
                {
                    page = result.Page,
                    limit = result.Limit,
                    total = result.Total,
                    pages = (result.Total + result.Limit - 1) / result.Limit,
                },
                timestamp = DateTime.UtcNow,
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing integration rules");
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام دریافت قوانین یکپارچه‌سازی رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // CREATE RULE: POST /integration/rules
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Creates a new integration rule that defines how to respond to events.
    /// 
    /// Required Fields:
    ///   - name: Rule name
    ///   - sourceModule: Module where event occurs
    ///   - triggerEvent: Type of event (STATUS_CHANGE, RECORD_CREATED, etc.)
    ///   - targetModule: Module to apply action to
    ///   - actionType: Action to perform (CREATE_RECORD, UPDATE_RECORD, etc.)
    /// </summary>
    [HttpPost("rules")]
    [Authorize(Policy = PsmPolicies.CanWriteIntegration)]
    [ProducesResponseType(typeof(IntegrationRuleDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> CreateRule([FromBody] CreateIntegrationRuleRequest req)
    {
        if (req == null)
            return BadRequest(new { success = false, error = "درخواست نامعتبر" });

        try
        {
            var userId = GetCurrentUserId();
            var createdRule = await _service.CreateRuleAsync(req, userId);

            _logger.LogInformation("Integration rule created by {UserId}: {RuleId} ({RuleName})",
                userId, createdRule.Id, createdRule.Name);

            return StatusCode(201, new
            {
                success = true,
                data = createdRule,
                message = "قانون یکپارچه‌سازی با موفقیت ایجاد شد",
            });
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Validation error creating integration rule");
            return BadRequest(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating integration rule");
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام ایجاد قانون رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // UPDATE RULE: PUT /integration/rules/{id}
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Updates an existing integration rule.
    /// Only provided fields are updated; omitted fields are left unchanged.
    /// </summary>
    /// <param name="id">The integration rule ID</param>
    [HttpPut("rules/{id}")]
    [Authorize(Policy = PsmPolicies.CanWriteIntegration)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> UpdateRule(string id, [FromBody] UpdateIntegrationRuleRequest req)
    {
        if (string.IsNullOrWhiteSpace(id))
            return BadRequest(new { success = false, error = "ID الزامی است" });

        if (req == null)
            return BadRequest(new { success = false, error = "درخواست نامعتبر" });

        try
        {
            var userId = GetCurrentUserId();
            var updated = await _service.UpdateRuleAsync(id, req, userId);

            if (!updated)
            {
                _logger.LogInformation("Integration rule {Id} not found for update", id);
                return NotFound(new { success = false, error = $"قانون '{id}' یافت نشد" });
            }

            _logger.LogInformation("Integration rule updated by {UserId}: {RuleId}", userId, id);

            return Ok(new
            {
                success = true,
                message = "قانون با موفقیت بروزرسانی شد",
                timestamp = DateTime.UtcNow,
            });
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Validation error updating rule {Id}", id);
            return BadRequest(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating integration rule {Id}", id);
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام بروزرسانی قانون رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // DELETE RULE: DELETE /integration/rules/{id}
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Deletes an integration rule by ID.
    /// The rule will no longer be used for event processing.
    /// </summary>
    /// <param name="id">The integration rule ID</param>
    [HttpDelete("rules/{id}")]
    [Authorize(Policy = PsmPolicies.CanDeleteIntegration)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> DeleteRule(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
            return BadRequest(new { success = false, error = "ID الزامی است" });

        try
        {
            var userId = GetCurrentUserId();
            var deleted = await _service.DeleteRuleAsync(id, userId);

            if (!deleted)
            {
                _logger.LogInformation("Integration rule {Id} not found for deletion", id);
                return NotFound(new { success = false, error = $"قانون '{id}' یافت نشد" });
            }

            _logger.LogInformation("Integration rule deleted by {UserId}: {RuleId}",
                userId, id);

            return Ok(new
            {
                success = true,
                message = "قانون با موفقیت حذف شد",
                timestamp = DateTime.UtcNow,
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting integration rule {Id}", id);
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام حذف قانون رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════════
    // EVENTS MANAGEMENT
    // ═════════════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────────────
    // LIST EVENTS: GET /integration/events
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Lists integration events with optional filtering.
    /// 
    /// Query Parameters:
    ///   - sourceModule (optional): Filter by source module
    ///   - eventType (optional): Filter by event type
    ///   - status (optional): Filter by status (pending, processing, done, failed)
    ///   - page (optional, default=1): Page number
    ///   - limit (optional, default=20): Records per page
    /// </summary>
    [HttpGet("events")]
    [Authorize(Policy = PsmPolicies.CanReadIntegration)]
    [ProducesResponseType(typeof(IntegrationEventListResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> ListEvents(
        [FromQuery] string? sourceModule = null,
        [FromQuery] string? eventType = null,
        [FromQuery] string? status = null,
        [FromQuery] int page = 1,
        [FromQuery] int limit = 20)
    {

        try
        {
            var result = await _service.ListEventsAsync(
                sourceModule, eventType, status, page, limit);

            return Ok(new
            {
                success = true,
                data = result.Data,
                pagination = new
                {
                    page = result.Page,
                    limit = result.Limit,
                    total = result.Total,
                    pages = (result.Total + result.Limit - 1) / result.Limit,
                },
                timestamp = DateTime.UtcNow,
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing integration events");
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام دریافت رویدادها رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // EXECUTE INTEGRATION: POST /integration/execute
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Manually triggers integration rule execution for an event.
    /// Can execute all matching rules or specific rules.
    /// 
    /// Body Parameters:
    ///   - eventId (required): The event to process
    ///   - ruleIds (optional): Specific rule IDs to execute. If null, all matching rules execute.
    /// </summary>
    [HttpPost("execute")]
    [Authorize(Policy = PsmPolicies.CanWriteIntegration)]
    [ProducesResponseType(typeof(IntegrationExecutionResultsResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> ExecuteIntegration([FromBody] ExecuteIntegrationRequest req)
    {
        if (req == null || string.IsNullOrWhiteSpace(req.EventId))
            return BadRequest(new { success = false, error = "شناسه رویداد الزامی است" });

        try
        {
            var userId = GetCurrentUserId();
            var result = await _service.ExecuteIntegrationAsync(req.EventId, req.RuleIds, userId);

            _logger.LogInformation(
                "Integration executed by {UserId} for event {EventId}: {Successful} successful, {Failed} failed, {Skipped} skipped",
                userId, req.EventId, result.Successful, result.Failed, result.Skipped);

            return Ok(new
            {
                success = true,
                data = result,
                timestamp = DateTime.UtcNow,
            });
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Event not found for execution: {EventId}", req.EventId);
            return NotFound(new { success = false, error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing integration for event {EventId}", req.EventId);
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام اجرای یکپارچه‌سازی رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // STATISTICS: GET /integration/stats
    // ─────────────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Retrieves integration system health and activity statistics.
    /// </summary>
    [HttpGet("stats")]
    [Authorize(Policy = PsmPolicies.CanReadIntegration)]
    [ProducesResponseType(typeof(IntegrationStatsDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GetStats()
    {

        try
        {
            var stats = await _service.GetStatsAsync();
            return Ok(new
            {
                success = true,
                data = stats,
                timestamp = DateTime.UtcNow,
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching integration statistics");
            return StatusCode(500, new
            {
                success = false,
                error = "خطایی هنگام دریافت آمار رخ داد",
                requestId = HttpContext.TraceIdentifier,
            });
        }
    }
}
