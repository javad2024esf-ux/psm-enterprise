using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PSM.Api.DTOs;
using PSM.Api.Services;
using PSM.Api.Middleware;

namespace PSM.Api.Controllers;

[ApiController]
[Route("api/hazop/{id}/lopa")]
[Authorize]
public class HazopLopaIntegrationController : ControllerBase
{
    private readonly IHazopLopaIntegrationService _integrationService;
    private readonly IHazopService _hazopService;
    private readonly ILopaService _lopaService;
    private readonly IAuditService _auditService;
    private readonly ILogger<HazopLopaIntegrationController> _logger;

    public HazopLopaIntegrationController(
        IHazopLopaIntegrationService integrationService,
        IHazopService hazopService,
        ILopaService lopaService,
        IAuditService auditService,
        ILogger<HazopLopaIntegrationController> logger)
    {
        _integrationService = integrationService;
        _hazopService = hazopService;
        _lopaService = lopaService;
        _auditService = auditService;
        _logger = logger;
    }

    private string GetUserId() => this.GetCurrentUser() ?? "unknown";
    private string? GetIpAddress() => HttpContext.Connection.RemoteIpAddress?.ToString();
    private string? GetUserAgent() => Request.Headers["User-Agent"].ToString();

    // ═════════════════════════════════════════════════════════════════════════
    // POST /api/hazop/{id}/create-lopa
    // Create a new LOPA Study from existing HAZOP Study
    // ═════════════════════════════════════════════════════════════════════════
    [HttpPost("create")]
    public async Task<ActionResult<LopaStudyDto>> CreateLopaStudyFromHazop(
        [FromRoute] string id,
        [FromBody] CreateLopaFromHazopRequest request)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(id))
                return BadRequest("Hazop Study ID is required");

            request.hazop_study_id = id;

            var userId = GetUserId();
            var ipAddress = GetIpAddress();
            var userAgent = GetUserAgent();

            var lopaStudy = await _integrationService.CreateLopaStudyFromHazopAsync(
                request, userId, ipAddress, userAgent);

            await _auditService.LogAsync(
                module: "HAZOP-LOPA",
                action: "CREATE_LOPA_FROM_HAZOP",
                details: $"Created LOPA Study {lopaStudy.Id} from HAZOP Study {id}",
                userId: userId);

            return CreatedAtAction(
                nameof(GetLopaStudiesLinkedToHazop),
                new { id },
                lopaStudy);
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning($"Invalid argument: {ex.Message}");
            return BadRequest(new { error = ex.Message });
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogWarning($"Invalid operation: {ex.Message}");
            return NotFound(new { error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating LOPA from HAZOP");
            return StatusCode(500, new { error = "Internal server error", details = ex.Message });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // GET /api/hazop/{id}/lopa
    // Get all LOPA Studies linked to a HAZOP Study
    // ═════════════════════════════════════════════════════════════════════════
    [HttpGet]
    public async Task<ActionResult<List<LopaStudyWithHazopTracingDto>>> GetLopaStudiesLinkedToHazop(
        [FromRoute] string id)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(id))
                return BadRequest("Hazop Study ID is required");

            var lopaStudies = await _integrationService.GetLopaStudiesWithHazopTracingAsync(id);

            return Ok(new
            {
                hazop_study_id = id,
                total_linked_lopa_studies = lopaStudies.Count,
                studies = lopaStudies
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving LOPA studies linked to HAZOP");
            return StatusCode(500, new { error = "Internal server error" });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // GET /api/hazop/{id}/lopa/summary
    // Get HAZOP-LOPA integration summary with coverage metrics
    // ═════════════════════════════════════════════════════════════════════════
    [HttpGet("summary")]
    public async Task<ActionResult<HazopLopaIntegrationSummaryDto>> GetIntegrationSummary(
        [FromRoute] string id)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(id))
                return BadRequest("Hazop Study ID is required");

            var summary = await _integrationService.GetIntegrationSummaryAsync(id);

            return Ok(summary);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving integration summary");
            return StatusCode(500, new { error = "Internal server error" });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // POST /api/hazop/{id}/lopa/scenarios/create-from-deviation
    // Create a LOPA Scenario from a HAZOP Deviation
    // ═════════════════════════════════════════════════════════════════════════
    [HttpPost("scenarios/create-from-deviation")]
    public async Task<ActionResult<LopaScenarioWithTracingDto>> CreateLopaScenarioFromDeviation(
        [FromRoute] string id,
        [FromBody] CreateLopaScenarioFromHazopDeviationRequest request)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(id))
                return BadRequest("Hazop Study ID is required");

            if (string.IsNullOrWhiteSpace(request.hazop_deviation_id))
                return BadRequest("hazop_deviation_id is required");

            if (string.IsNullOrWhiteSpace(request.lopa_study_id))
                return BadRequest("lopa_study_id is required");

            request.hazop_study_id = id;

            var userId = GetUserId();
            var ipAddress = GetIpAddress();
            var userAgent = GetUserAgent();

            var lopaScenario = await _integrationService.CreateLopaScenarioFromHazopDeviationAsync(
                request, userId, ipAddress, userAgent);

            var scenarioWithTracing = await _integrationService.GetLopaScenarioWithTracingAsync(lopaScenario.Id!);

            await _auditService.LogAsync(
                module: "HAZOP-LOPA",
                action: "CREATE_LOPA_SCENARIO_FROM_DEVIATION",
                details: $"Created LOPA Scenario {lopaScenario.Id} from HAZOP Deviation {request.hazop_deviation_id}",
                userId: userId);

            return CreatedAtAction(
                nameof(GetLopaScenarioWithTracing),
                new { lopaScenarioId = lopaScenario.Id },
                scenarioWithTracing);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(new { error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating LOPA scenario from HAZOP deviation");
            return StatusCode(500, new { error = "Internal server error" });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // GET /api/lopa/{lopaScenarioId}/hazop
    // Get HAZOP Deviation reference for a LOPA Scenario
    // ═════════════════════════════════════════════════════════════════════════
    [HttpGet("{lopaScenarioId}/hazop")]
    public async Task<ActionResult<LopaScenarioWithTracingDto>> GetLopaScenarioWithTracing(
        [FromRoute] string lopaScenarioId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(lopaScenarioId))
                return BadRequest("LOPA Scenario ID is required");

            var scenario = await _integrationService.GetLopaScenarioWithTracingAsync(lopaScenarioId);

            return Ok(scenario);
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(new { error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving LOPA scenario with tracing");
            return StatusCode(500, new { error = "Internal server error" });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // GET /api/lopa/{id}/hazop/scenarios
    // Get all LOPA Scenarios linked to a HAZOP Deviation
    // ═════════════════════════════════════════════════════════════════════════
    [HttpGet("deviation/{deviationId}/scenarios")]
    public async Task<ActionResult<List<LopaScenarioDto>>> GetLopaScenariosByDeviation(
        [FromRoute] string id,
        [FromRoute] string deviationId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(deviationId))
                return BadRequest("Hazop Deviation ID is required");

            var scenarios = await _integrationService.GetLopaScenariosByHazopDeviationAsync(deviationId);
            var scenariosList = scenarios?.ToList() ?? new List<LopaScenarioDto>();

            return Ok(new
            {
                hazop_deviation_id = deviationId,
                total_scenarios = scenariosList.Count,
                scenarios = scenariosList
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving LOPA scenarios by deviation");
            return StatusCode(500, new { error = "Internal server error" });
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // GET /api/hazop/{id}/lopa/audit-trail
    // Get audit trail of HAZOP-LOPA integration actions
    // ═════════════════════════════════════════════════════════════════════════
    [HttpGet("audit-trail")]
    public async Task<ActionResult> GetIntegrationAuditTrail(
        [FromRoute] string id,
        [FromQuery] int limit = 100,
        [FromQuery] int offset = 0)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(id))
                return BadRequest("Hazop Study ID is required");

            var auditTrail = await _integrationService.GetIntegrationAuditTrailAsync(
                hazopStudyId: id,
                limit: limit,
                offset: offset);

            var totalCount = await _integrationService.GetIntegrationAuditTrailCountAsync(hazopStudyId: id);

            return Ok(new
            {
                hazop_study_id = id,
                total_count = totalCount,
                limit = limit,
                offset = offset,
                audit_trail = auditTrail
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving audit trail");
            return StatusCode(500, new { error = "Internal server error" });
        }
    }
}

// ═════════════════════════════════════════════════════════════════════════════
// LOPA Controller Extended Routes for HAZOP References
// ═════════════════════════════════════════════════════════════════════════════
[ApiController]
[Route("api/lopa")]
[Authorize]
public class LopaHazopReferenceController : ControllerBase
{
    private readonly IHazopLopaIntegrationService _integrationService;
    private readonly ILogger<LopaHazopReferenceController> _logger;

    public LopaHazopReferenceController(
        IHazopLopaIntegrationService integrationService,
        ILogger<LopaHazopReferenceController> logger)
    {
        _integrationService = integrationService;
        _logger = logger;
    }

    // ═════════════════════════════════════════════════════════════════════════
    // GET /api/lopa/{id}/hazop
    // Get HAZOP Study and Deviation references for a LOPA Study
    // ═════════════════════════════════════════════════════════════════════════
    [HttpGet("{id}/hazop")]
    public ActionResult<HazopLopaIntegrationSummaryDto> GetHazopReferencesForLopa(
        [FromRoute] string id)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(id))
                return BadRequest("LOPA Study ID is required");

            // This endpoint would need additional implementation in the service
            // For now, returning a placeholder response structure
            return Ok(new
            {
                lopa_study_id = id,
                message = "Hazop references retrieved successfully"
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving HAZOP references for LOPA");
            return StatusCode(500, new { error = "Internal server error" });
        }
    }
}
