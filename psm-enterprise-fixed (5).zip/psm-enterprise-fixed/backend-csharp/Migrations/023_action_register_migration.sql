-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║  PSM Enterprise — Migration 023: Action Register Data Migration         ║
-- ║  Enhanced Validation & Data Integrity from Records → action_register    ║
-- ║  Ensures backward compatibility with records table                      ║
-- ╚══════════════════════════════════════════════════════════════════════════╝

-- ─────────────────────────────────────────────────────────────────────────────
-- 1. Validate table structure
-- ─────────────────────────────────────────────────────────────────────────────
DO $$
BEGIN
  -- Check if action_register table exists
  IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'action_register') THEN
    RAISE EXCEPTION 'action_register table does not exist. Run migration 022 first.';
  END IF;

  -- Check required columns exist
  IF NOT EXISTS (
    SELECT FROM information_schema.columns
    WHERE table_name = 'action_register' AND column_name = 'id'
  ) THEN
    RAISE EXCEPTION 'action_register table is missing required columns.';
  END IF;

  RAISE NOTICE 'Action Register table structure validated successfully.';
END $$;

-- ─────────────────────────────────────────────────────────────────────────────
-- 2. Data Migration: Records (Action-Register) → action_register
-- ─────────────────────────────────────────────────────────────────────────────
DO $$
DECLARE
  v_migrated_count INT := 0;
  v_skipped_count INT := 0;
  v_error_count INT := 0;
BEGIN
  RAISE NOTICE 'Starting Action Register data migration...';

  -- Check if records table exists and has action_register records
  IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'records') THEN
    IF EXISTS (
      SELECT 1 FROM records WHERE collection = 'action_register' AND deleted = false
    ) THEN
      -- Migrate records that don't exist in action_register
      INSERT INTO action_register (
        id, title, description, source, source_id, source_ref,
        unit, responsible, due_date, status, priority,
        completion_date, verified_by, verification_note, tags,
        created_at, updated_at, created_by, deleted
      )
      SELECT
        r.id,
        COALESCE(r.data->>'title', 'Migrated Action'),
        r.data->>'description',
        COALESCE(r.data->>'source', 'Other'),
        r.data->>'sourceId',
        r.data->>'sourceRef',
        r.unit,
        r.data->>'responsible',
        CASE
          WHEN r.data->>'dueDate' IS NOT NULL AND r.data->>'dueDate' ~ '^\d{4}-\d{2}-\d{2}$'
          THEN TO_DATE(r.data->>'dueDate', 'YYYY-MM-DD')::date
          ELSE NULL
        END,
        COALESCE(r.status, r.data->>'status', 'Open'),
        COALESCE(r.data->>'priority', 'Medium'),
        CASE
          WHEN r.data->>'completionDate' IS NOT NULL AND r.data->>'completionDate' ~ '^\d{4}-\d{2}-\d{2}$'
          THEN TO_DATE(r.data->>'completionDate', 'YYYY-MM-DD')::date
          ELSE NULL
        END,
        r.data->>'verifiedBy',
        r.data->>'verificationNote',
        CASE
          WHEN r.data->>'tags' IS NOT NULL THEN string_to_array(r.data->>'tags', ',')
          ELSE NULL
        END,
        COALESCE(r.created_at, NOW()),
        COALESCE(r.updated_at, NOW()),
        r.created_by,
        r.deleted
      FROM records r
      WHERE r.collection = 'action_register'
        AND NOT EXISTS (
          SELECT 1 FROM action_register ar WHERE ar.id = r.id
        )
      ON CONFLICT (id) DO NOTHING;

      GET DIAGNOSTICS v_migrated_count = ROW_COUNT;
      RAISE NOTICE 'Migrated % records from records table', v_migrated_count;
    ELSE
      RAISE NOTICE 'No action_register records found in records table to migrate.';
    END IF;
  ELSE
    RAISE NOTICE 'Records table does not exist. Skipping data migration.';
  END IF;

  RAISE NOTICE 'Data migration completed. Migrated: %, Skipped: %, Errors: %',
    v_migrated_count, v_skipped_count, v_error_count;
END $$;

-- ─────────────────────────────────────────────────────────────────────────────
-- 3. Data Validation & Cleanup
-- ─────────────────────────────────────────────────────────────────────────────

-- Validate enum values
DO $$
DECLARE
  v_count INT;
BEGIN
  -- Update invalid statuses to 'Open'
  UPDATE action_register
  SET status = 'Open'
  WHERE status NOT IN ('Open', 'In Progress', 'Overdue', 'Done', 'Verified', 'Closed')
    AND deleted = false;

  GET DIAGNOSTICS v_count = ROW_COUNT;
  IF v_count > 0 THEN
    RAISE NOTICE 'Fixed % records with invalid status values', v_count;
  END IF;

  -- Update invalid priorities to 'Medium'
  UPDATE action_register
  SET priority = 'Medium'
  WHERE priority NOT IN ('Critical', 'High', 'Medium', 'Low')
    AND deleted = false;

  GET DIAGNOSTICS v_count = ROW_COUNT;
  IF v_count > 0 THEN
    RAISE NOTICE 'Fixed % records with invalid priority values', v_count;
  END IF;

  -- Update invalid sources to 'Other'
  UPDATE action_register
  SET source = 'Other'
  WHERE source NOT IN ('MOC', 'Incident', 'HAZOP', 'Audit', 'PSSR', 'Management Review', 'Inspection', 'Other')
    AND deleted = false;

  GET DIAGNOSTICS v_count = ROW_COUNT;
  IF v_count > 0 THEN
    RAISE NOTICE 'Fixed % records with invalid source values', v_count;
  END IF;

  -- Ensure created_at is never null
  UPDATE action_register
  SET created_at = COALESCE(created_at, NOW())
  WHERE created_at IS NULL;

  GET DIAGNOSTICS v_count = ROW_COUNT;
  IF v_count > 0 THEN
    RAISE NOTICE 'Fixed % records with missing created_at', v_count;
  END IF;
END $$;

-- ─────────────────────────────────────────────────────────────────────────────
-- 4. Backward Compatibility: Update records table
-- ─────────────────────────────────────────────────────────────────────────────

-- Mark all migrated records as soft-deleted in the records table
-- This maintains backward compatibility while directing traffic to action_register
DO $$
DECLARE
  v_count INT;
BEGIN
  IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'records') THEN
    UPDATE records
    SET
      deleted = true,
      updated_at = NOW()
    WHERE
      collection = 'action_register'
      AND deleted = false;

    GET DIAGNOSTICS v_count = ROW_COUNT;
    RAISE NOTICE 'Marked % migrated action_register records as deleted in records table', v_count;
  END IF;
END $$;

-- ─────────────────────────────────────────────────────────────────────────────
-- 5. Index Optimization
-- ─────────────────────────────────────────────────────────────────────────────

-- Create or replace indexes for query performance
CREATE INDEX IF NOT EXISTS idx_action_register_status
  ON action_register (status)
  WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_action_register_source
  ON action_register (source)
  WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_action_register_unit
  ON action_register (unit)
  WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_action_register_responsible
  ON action_register (responsible)
  WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_action_register_due_date
  ON action_register (due_date)
  WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_action_register_priority
  ON action_register (priority)
  WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_action_register_created_at
  ON action_register (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_action_register_deleted
  ON action_register (deleted);

CREATE INDEX IF NOT EXISTS idx_action_register_source_id
  ON action_register (source_id)
  WHERE deleted = false AND source_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_action_register_composite
  ON action_register (status, unit, deleted);

CREATE INDEX IF NOT EXISTS idx_action_register_tags
  ON action_register USING GIN (tags);

-- Text search index for title and description
CREATE INDEX IF NOT EXISTS idx_action_register_text_search
  ON action_register USING GIN (
    to_tsvector('english', COALESCE(title, '') || ' ' || COALESCE(description, ''))
  )
  WHERE deleted = false;

-- REINDEX removed (cannot run in transaction; index just created)

-- ─────────────────────────────────────────────────────────────────────────────
-- 6. Migration Status Tracking
-- ─────────────────────────────────────────────────────────────────────────────

-- Record migration completion
INSERT INTO settings (key, value, updated_at)
VALUES ('action_register_migration_v023_completed', NOW()::TEXT, NOW())
ON CONFLICT (key) DO UPDATE
SET value = NOW()::TEXT, updated_at = NOW();

-- Log summary statistics
DO $$
DECLARE
  v_total INT;
  v_active INT;
  v_deleted INT;
BEGIN
  SELECT COUNT(*) INTO v_total FROM action_register;
  SELECT COUNT(*) INTO v_active FROM action_register WHERE deleted = false;
  SELECT COUNT(*) INTO v_deleted FROM action_register WHERE deleted = true;

  INSERT INTO settings (key, value, updated_at)
  VALUES (
    'action_register_stats',
    FORMAT('Total: %s, Active: %s, Deleted: %s', v_total, v_active, v_deleted),
    NOW()
  )
  ON CONFLICT (key) DO UPDATE
  SET value = FORMAT('Total: %s, Active: %s, Deleted: %s', v_total, v_active, v_deleted),
      updated_at = NOW();

  RAISE NOTICE 'Migration Summary - Total: %, Active: %, Deleted: %',
    v_total, v_active, v_deleted;
END $$;

-- ─────────────────────────────────────────────────────────────────────────────
-- 7. Validation Report
-- ─────────────────────────────────────────────────────────────────────────────

DO $$
DECLARE
  v_record RECORD;
BEGIN
  RAISE NOTICE '═══════════════════════════════════════════════════════════';
  RAISE NOTICE 'Action Register Migration Summary Report';
  RAISE NOTICE '═══════════════════════════════════════════════════════════';

  -- Summary stats
  FOR v_record IN
    SELECT
      status,
      COUNT(*) as cnt
    FROM action_register
    WHERE deleted = false
    GROUP BY status
    ORDER BY cnt DESC
  LOOP
    RAISE NOTICE 'Status: % = %', v_record.status, v_record.cnt;
  END LOOP;

  RAISE NOTICE '───────────────────────────────────────────────────────────';

  FOR v_record IN
    SELECT
      priority,
      COUNT(*) as cnt
    FROM action_register
    WHERE deleted = false
    GROUP BY priority
    ORDER BY cnt DESC
  LOOP
    RAISE NOTICE 'Priority: % = %', v_record.priority, v_record.cnt;
  END LOOP;

  RAISE NOTICE '═══════════════════════════════════════════════════════════';
  RAISE NOTICE 'Migration completed successfully.';
END $$;
