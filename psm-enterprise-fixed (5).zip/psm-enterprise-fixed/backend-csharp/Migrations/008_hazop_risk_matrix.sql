BEGIN;

CREATE TABLE IF NOT EXISTS hazop_risk_matrix (
  id          TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  study_id    TEXT,
  severity    INTEGER     NOT NULL CHECK (severity BETWEEN 1 AND 5),
  likelihood  VARCHAR(1)  NOT NULL CHECK (likelihood IN ('A','B','C','D','E')),
  risk_rank   VARCHAR(50),
  risk_color  VARCHAR(50),
  description TEXT,
  UNIQUE(study_id, severity, likelihood)
);

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_deviations') THEN
    ALTER TABLE hazop_deviations ADD COLUMN IF NOT EXISTS severity_score      INTEGER DEFAULT 1 CHECK (severity_score BETWEEN 1 AND 5);
    ALTER TABLE hazop_deviations ADD COLUMN IF NOT EXISTS likelihood_score    VARCHAR(1) DEFAULT 'E' CHECK (likelihood_score IN ('A','B','C','D','E'));
    ALTER TABLE hazop_deviations ADD COLUMN IF NOT EXISTS risk_score          INTEGER;
    ALTER TABLE hazop_deviations ADD COLUMN IF NOT EXISTS risk_color          VARCHAR(50);
    ALTER TABLE hazop_deviations ADD COLUMN IF NOT EXISTS mitigation_required BOOLEAN DEFAULT FALSE;
    CREATE INDEX IF NOT EXISTS idx_deviations_risk_score ON hazop_deviations(risk_score);
    CREATE INDEX IF NOT EXISTS idx_deviations_severity   ON hazop_deviations(severity_score);
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_studies') THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.table_constraints
      WHERE table_name = 'hazop_risk_matrix' AND constraint_name = 'fk_risk_matrix_study'
    ) THEN
      ALTER TABLE hazop_risk_matrix
        ADD CONSTRAINT fk_risk_matrix_study
        FOREIGN KEY (study_id) REFERENCES hazop_studies(id) ON DELETE CASCADE;
    END IF;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_risk_matrix_study ON hazop_risk_matrix(study_id);

INSERT INTO schema_migrations (version, applied_at)
VALUES ('008_hazop_risk_matrix', NOW())
ON CONFLICT DO NOTHING;

COMMIT;
