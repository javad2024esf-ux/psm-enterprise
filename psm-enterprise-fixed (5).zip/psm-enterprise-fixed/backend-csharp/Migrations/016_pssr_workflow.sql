-- FIXED during refactor: idx_audit_action / idx_notifications_recipient collided with
-- identically-named indexes already created by 015_work_permit_workflow.sql
-- (Postgres index names are unique per-schema, not per-table). Renamed to
-- idx_pssr_audit_action / idx_pssr_notifications_recipient.

-- ═══════════════════════════════════════════════════════════════════════════
-- Migration: PSSR Workflow Tables
-- نسخه: 016
-- توضیح: جداول کامل برای PSSR (Pre-Startup Safety Review)
-- ═══════════════════════════════════════════════════════════════════════════

-- جدول اصلی PSSR
CREATE TABLE IF NOT EXISTS pssr_records (
  id VARCHAR(64) PRIMARY KEY,
  tenant_id VARCHAR(64) NOT NULL,
  
  -- معلومات واحد
  unit_name VARCHAR(255) NOT NULL,
  process_description TEXT,
  startup_date DATE NOT NULL,
  
  -- مسئولان
  project_manager VARCHAR(255) NOT NULL,
  pssr_team_lead VARCHAR(255) NOT NULL,
  
  -- وضعیت
  state VARCHAR(50) DEFAULT 'Draft', 
  -- Draft, Walkdown, Punch-Management, Engineering-Review, 
  -- HSE-Review, Final-Approval, Ready-for-Startup, Closed
  state_changed_at TIMESTAMP DEFAULT NOW(),
  
  -- داده‌های فرم
  form_data JSONB DEFAULT '{}',
  
  -- نتایج Walkdown
  walkdown_date DATE,
  walkdown_team TEXT,
  walkdown_observations TEXT,
  critical_findings TEXT,
  
  -- مدیریت Punch
  total_punch_items INTEGER DEFAULT 0,
  type_a_count INTEGER DEFAULT 0,
  type_b_count INTEGER DEFAULT 0,
  punch_closed_count INTEGER DEFAULT 0,
  
  -- بررسی مهندسی
  design_compliance VARCHAR(50), -- Compliant, Compliant with Notes, Non-Compliant
  engineering_approval BOOLEAN DEFAULT FALSE,
  quality_checklist_complete BOOLEAN DEFAULT FALSE,
  
  -- بررسی HSE
  hse_approval BOOLEAN DEFAULT FALSE,
  operator_training_status VARCHAR(50), -- Not Started, In Progress, Complete, Complete with Certifications
  risk_assessment_complete BOOLEAN DEFAULT FALSE,
  
  -- تأیید نهایی
  all_approvals_complete BOOLEAN DEFAULT FALSE,
  management_review_date DATE,
  approver_name VARCHAR(255),
  
  -- آمادگی برای راه‌اندازی
  startup_readiness_sign_off BOOLEAN DEFAULT FALSE,
  startup_authorization_date TIMESTAMP,
  authorized_by VARCHAR(255),
  
  -- بسته‌شدن
  actual_startup_date TIMESTAMP,
  startup_summary TEXT,
  initial_operation_status VARCHAR(50), -- Smooth, Minor Issues, Issues Resolved, Major Issues
  
  -- مسئولان
  created_by VARCHAR(64),
  created_at TIMESTAMP DEFAULT NOW(),
  last_modified_by VARCHAR(64),
  updated_at TIMESTAMP DEFAULT NOW(),
  
  -- متادیتا
  tags TEXT[],
  custom_fields JSONB DEFAULT '{}',
  
  CONSTRAINT fk_pssr_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

-- ایندکس‌های عملکردی
CREATE INDEX idx_pssr_tenant ON pssr_records(tenant_id);
CREATE INDEX idx_pssr_state ON pssr_records(state);
CREATE INDEX idx_pssr_startup_date ON pssr_records(startup_date);
CREATE INDEX idx_pssr_created_at ON pssr_records(created_at DESC);

-- جدول Punch Items
CREATE TABLE IF NOT EXISTS pssr_punch_items (
  id VARCHAR(64) PRIMARY KEY,
  pssr_id VARCHAR(64) NOT NULL,
  description TEXT NOT NULL,
  category VARCHAR(20) NOT NULL, -- Type-A, Type-B
  responsible VARCHAR(255),
  target_date DATE,
  status VARCHAR(50) DEFAULT 'Open', -- Open, In-Progress, Closed
  closed_date TIMESTAMP,
  close_note TEXT,
  closed_by VARCHAR(64),
  
  created_by VARCHAR(64),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  
  priority VARCHAR(20) DEFAULT 'Normal', -- Low, Normal, High, Critical
  category_detail VARCHAR(100), -- Safety, Design, Quality, etc.
  
  CONSTRAINT fk_punch_pssr FOREIGN KEY (pssr_id) REFERENCES pssr_records(id) ON DELETE CASCADE
);

-- ایندکس‌های Punch
CREATE INDEX idx_punch_pssr ON pssr_punch_items(pssr_id);
CREATE INDEX idx_punch_status ON pssr_punch_items(status);
CREATE INDEX idx_punch_category ON pssr_punch_items(category);
CREATE INDEX idx_punch_created_at ON pssr_punch_items(created_at DESC);

-- جدول تیم Walkdown
CREATE TABLE IF NOT EXISTS pssr_walkdown_team (
  id SERIAL PRIMARY KEY,
  pssr_id VARCHAR(64) NOT NULL,
  team_member_name VARCHAR(255),
  team_member_id VARCHAR(64),
  discipline VARCHAR(100), -- Operations, Engineering, HSE, Maintenance, etc.
  added_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT fk_walkdown_pssr FOREIGN KEY (pssr_id) REFERENCES pssr_records(id) ON DELETE CASCADE
);

CREATE INDEX idx_walkdown_pssr ON pssr_walkdown_team(pssr_id);

-- جدول مناطق بازدید
CREATE TABLE IF NOT EXISTS pssr_inspection_areas (
  id SERIAL PRIMARY KEY,
  pssr_id VARCHAR(64) NOT NULL,
  area_name VARCHAR(255),
  area_code VARCHAR(50),
  inspection_status VARCHAR(50), -- Not Started, In Progress, Complete
  inspector_name VARCHAR(255),
  inspection_date DATE,
  observations TEXT,
  findings TEXT,
  
  CONSTRAINT fk_inspection_pssr FOREIGN KEY (pssr_id) REFERENCES pssr_records(id) ON DELETE CASCADE
);

CREATE INDEX idx_inspection_pssr ON pssr_inspection_areas(pssr_id);

-- جدول ردیابی SLA
CREATE TABLE IF NOT EXISTS pssr_sla_tracking (
  id SERIAL PRIMARY KEY,
  pssr_id VARCHAR(64) NOT NULL,
  state VARCHAR(50) NOT NULL,
  target_hours NUMERIC(10, 2) NOT NULL,
  entered_at TIMESTAMP DEFAULT NOW(),
  exited_at TIMESTAMP,
  exceeded BOOLEAN DEFAULT FALSE,
  
  CONSTRAINT fk_sla_pssr FOREIGN KEY (pssr_id) REFERENCES pssr_records(id) ON DELETE CASCADE
);

CREATE INDEX idx_sla_pssr ON pssr_sla_tracking(pssr_id);

-- جدول اعلان‌های PSSR
CREATE TABLE IF NOT EXISTS pssr_notifications (
  id SERIAL PRIMARY KEY,
  pssr_id VARCHAR(64) NOT NULL,
  recipient_id VARCHAR(64),
  notification_type VARCHAR(50), -- WALKDOWN_START, PUNCH_MANAGEMENT, APPROVAL_PENDING, etc.
  subject VARCHAR(255),
  message TEXT,
  sent_at TIMESTAMP DEFAULT NOW(),
  read_at TIMESTAMP,
  action_url VARCHAR(500),
  
  CONSTRAINT fk_notifications_pssr FOREIGN KEY (pssr_id) REFERENCES pssr_records(id) ON DELETE CASCADE
);

CREATE INDEX idx_notifications_pssr ON pssr_notifications(pssr_id);
CREATE INDEX idx_pssr_notifications_recipient ON pssr_notifications(recipient_id);

-- جدول تاریخچة بازبینی
CREATE TABLE IF NOT EXISTS pssr_audit_trail (
  id SERIAL PRIMARY KEY,
  pssr_id VARCHAR(64) NOT NULL,
  action VARCHAR(50), -- CREATE, UPDATE, TRANSITION, APPROVE, PUNCH_CREATED, PUNCH_CLOSED
  user_id VARCHAR(64),
  user_name VARCHAR(255),
  changes JSONB,
  timestamp TIMESTAMP DEFAULT NOW(),
  ip_address VARCHAR(45),
  details TEXT,
  
  CONSTRAINT fk_audit_pssr FOREIGN KEY (pssr_id) REFERENCES pssr_records(id) ON DELETE CASCADE
);

CREATE INDEX idx_audit_pssr ON pssr_audit_trail(pssr_id);
CREATE INDEX idx_pssr_audit_action ON pssr_audit_trail(action);
CREATE INDEX idx_pssr_audit_timestamp ON pssr_audit_trail(timestamp DESC);

-- جدول تصریحات تأیید
CREATE TABLE IF NOT EXISTS pssr_approvals (
  id SERIAL PRIMARY KEY,
  pssr_id VARCHAR(64) NOT NULL,
  approval_type VARCHAR(50), -- Project Manager, Engineering, HSE, Operations, Plant Manager
  approver_name VARCHAR(255),
  approver_id VARCHAR(64),
  approval_status VARCHAR(50) DEFAULT 'Pending', -- Pending, Approved, Rejected
  approval_date TIMESTAMP,
  approval_comments TEXT,
  
  CONSTRAINT fk_approvals_pssr FOREIGN KEY (pssr_id) REFERENCES pssr_records(id) ON DELETE CASCADE
);

CREATE INDEX idx_approvals_pssr ON pssr_approvals(pssr_id);
CREATE INDEX idx_approvals_status ON pssr_approvals(approval_status);

-- جدول آموزش اپراتور
CREATE TABLE IF NOT EXISTS pssr_operator_training (
  id SERIAL PRIMARY KEY,
  pssr_id VARCHAR(64) NOT NULL,
  operator_name VARCHAR(255),
  operator_id VARCHAR(64),
  training_subject VARCHAR(100),
  training_date DATE,
  training_duration INTEGER, -- hours
  trainer_name VARCHAR(255),
  certification_received BOOLEAN DEFAULT FALSE,
  certification_date DATE,
  
  CONSTRAINT fk_training_pssr FOREIGN KEY (pssr_id) REFERENCES pssr_records(id) ON DELETE CASCADE
);

CREATE INDEX idx_training_pssr ON pssr_operator_training(pssr_id);

-- جدول درس‌های آموخته شده
CREATE TABLE IF NOT EXISTS pssr_lessons_learned (
  id SERIAL PRIMARY KEY,
  pssr_id VARCHAR(64) NOT NULL,
  lesson_title VARCHAR(255),
  description TEXT,
  lesson_category VARCHAR(100), -- Safety, Process, Equipment, Procedure, etc.
  shared_organization_wide BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW(),
  created_by VARCHAR(64),
  
  CONSTRAINT fk_lessons_pssr FOREIGN KEY (pssr_id) REFERENCES pssr_records(id) ON DELETE CASCADE
);

CREATE INDEX idx_lessons_pssr ON pssr_lessons_learned(pssr_id);

-- نمایش خلاصة Punch
CREATE OR REPLACE VIEW pssr_punch_summary AS
SELECT
  pssr_id,
  COUNT(*) as total_punches,
  COUNT(CASE WHEN category = 'Type-A' THEN 1 END) as type_a_total,
  COUNT(CASE WHEN category = 'Type-B' THEN 1 END) as type_b_total,
  COUNT(CASE WHEN status = 'Closed' THEN 1 END) as closed_count,
  COUNT(CASE WHEN status = 'Open' THEN 1 END) as open_count,
  COUNT(CASE WHEN status = 'In-Progress' THEN 1 END) as in_progress_count,
  COUNT(CASE WHEN category = 'Type-A' AND status = 'Closed' THEN 1 END) as type_a_closed,
  COUNT(CASE WHEN category = 'Type-B' AND status = 'Closed' THEN 1 END) as type_b_closed,
  ROUND(100.0 * COUNT(CASE WHEN status = 'Closed' THEN 1 END) / COUNT(*), 2) as closure_percentage
FROM pssr_punch_items
GROUP BY pssr_id;

-- نمایش خلاصة PSSR
CREATE OR REPLACE VIEW pssr_summary AS
SELECT
  p.tenant_id,
  p.unit_name,
  p.state,
  COUNT(*) as total_pssr,
  COUNT(CASE WHEN p.state = 'Closed' THEN 1 END) as completed_pssr,
  COUNT(CASE WHEN p.hse_approval = true THEN 1 END) as hse_approved,
  COUNT(CASE WHEN p.engineering_approval = true THEN 1 END) as engineering_approved,
  AVG(EXTRACT(DAY FROM (COALESCE(p.actual_startup_date, NOW()) - p.created_at))) as avg_duration_days
FROM pssr_records p
WHERE p.created_at >= CURRENT_DATE - INTERVAL '180 days'
GROUP BY p.tenant_id, p.unit_name, p.state;

-- TRIGGER: بروزرسانی updated_at
CREATE OR REPLACE FUNCTION update_pssr_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tr_pssr_updated_at ON pssr_records;
CREATE TRIGGER tr_pssr_updated_at
BEFORE UPDATE ON pssr_records
FOR EACH ROW
EXECUTE FUNCTION update_pssr_updated_at();

-- TRIGGER: بروزرسانی آمار Punch
CREATE OR REPLACE FUNCTION update_pssr_punch_stats()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE pssr_records SET 
      total_punch_items = total_punch_items + 1,
      type_a_count = type_a_count + CASE WHEN NEW.category = 'Type-A' THEN 1 ELSE 0 END,
      type_b_count = type_b_count + CASE WHEN NEW.category = 'Type-B' THEN 1 ELSE 0 END
    WHERE id = NEW.pssr_id;
  ELSIF TG_OP = 'UPDATE' AND OLD.status != NEW.status AND NEW.status = 'Closed' THEN
    UPDATE pssr_records SET punch_closed_count = punch_closed_count + 1
    WHERE id = NEW.pssr_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tr_punch_stats ON pssr_punch_items;
CREATE TRIGGER tr_punch_stats
AFTER INSERT OR UPDATE ON pssr_punch_items
FOR EACH ROW
EXECUTE FUNCTION update_pssr_punch_stats();

-- Seed: نمونه داده
INSERT INTO pssr_records (
  id, tenant_id, unit_name, process_description, startup_date,
  project_manager, pssr_team_lead, state, created_by
) VALUES (
  'pssr_sample_001', 'tenant_1', 'واحد تقطیر جدید', 
  'واحد تقطیر با ظرفیت 100 بشکه در روز',
  CURRENT_DATE + INTERVAL '30 days',
  'محمد علی', 'علیرضا حسنی',
  'Draft', 'admin'
) ON CONFLICT DO NOTHING;
