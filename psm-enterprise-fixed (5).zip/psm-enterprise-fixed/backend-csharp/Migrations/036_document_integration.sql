-- ════════════════════════════════════════════════════════════════════════════════
-- 036_document_integration.sql
-- Document Integration: Attachments & Versioning for all modules
--
-- Modules supported:
--   - HAZOP
--   - LOPA
--   - BowTie
--   - Incident
--   - Permit
--   - MOC (Change Management)
--   - Workflow
--   - Action Register
--
-- Features:
--   1. Attachments - Link documents to module records
--   2. Versions - Track document revisions
--   3. Preview - Metadata for preview generation
--   4. Download - Full document retrieval with access tracking
-- ════════════════════════════════════════════════════════════════════════════════

-- ─── Document Attachments Table ────────────────────────────────────────────────
-- Links documents to module records with relationship tracking
CREATE TABLE IF NOT EXISTS document_attachments (
  id              TEXT PRIMARY KEY,
  document_id     TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  module          TEXT NOT NULL,
  record_id       TEXT NOT NULL,
  attachment_type TEXT,
  attachment_category TEXT,
  description     TEXT,
  sort_order      INT DEFAULT 0,
  created_by      TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  
  -- Composite index for fast lookups by module and record
  CONSTRAINT unique_attachment_per_record UNIQUE(document_id, module, record_id)
);

CREATE INDEX IF NOT EXISTS idx_attachments_module ON document_attachments (module);
CREATE INDEX IF NOT EXISTS idx_attachments_record ON document_attachments (module, record_id);
CREATE INDEX IF NOT EXISTS idx_attachments_document ON document_attachments (document_id);
CREATE INDEX IF NOT EXISTS idx_attachments_created ON document_attachments (created_at DESC);

-- ─── Document Versions Table ───────────────────────────────────────────────────
-- Tracks document revision history and version management
CREATE TABLE IF NOT EXISTS document_versions (
  id              TEXT PRIMARY KEY,
  document_id     TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  version_number  INT NOT NULL,
  previous_id     TEXT REFERENCES document_versions(id) ON DELETE SET NULL,
  file_path       TEXT,
  file_size       BIGINT,
  mime_type       TEXT,
  change_summary  TEXT,
  change_type     TEXT CHECK (change_type IN ('initial', 'updated', 'restored', 'minor', 'major')),
  created_by      TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  
  -- Unique constraint per document per version number
  CONSTRAINT unique_version_per_document UNIQUE(document_id, version_number)
);

CREATE INDEX IF NOT EXISTS idx_versions_document ON document_versions (document_id);
CREATE INDEX IF NOT EXISTS idx_versions_created ON document_versions (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_versions_change_type ON document_versions (change_type);

-- ─── Document Preview Metadata ─────────────────────────────────────────────────
-- Stores preview generation metadata for fast preview retrieval
CREATE TABLE IF NOT EXISTS document_previews (
  id              TEXT PRIMARY KEY,
  document_id     TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  preview_type    TEXT,
  thumbnail_path  TEXT,
  page_count      INT,
  preview_url     TEXT,
  generated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at      TIMESTAMPTZ,
  
  CONSTRAINT unique_preview_per_document UNIQUE(document_id, preview_type)
);

CREATE INDEX IF NOT EXISTS idx_preview_document ON document_previews (document_id);
CREATE INDEX IF NOT EXISTS idx_preview_type ON document_previews (preview_type);

-- ─── Document Access Tracking ──────────────────────────────────────────────────
-- Tracks document access for audit purposes
CREATE TABLE IF NOT EXISTS document_access_log (
  id              TEXT PRIMARY KEY,
  document_id     TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  user_id         TEXT,
  action_type     TEXT CHECK (action_type IN ('view', 'download', 'preview', 'delete', 'version_check')),
  access_time     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ip_address      TEXT,
  user_agent      TEXT
);

CREATE INDEX IF NOT EXISTS idx_access_document ON document_access_log (document_id);
CREATE INDEX IF NOT EXISTS idx_access_user ON document_access_log (user_id);
CREATE INDEX IF NOT EXISTS idx_access_action ON document_access_log (action_type);
CREATE INDEX IF NOT EXISTS idx_access_time ON document_access_log (access_time DESC);

-- ─── Update documents table with additional columns ───────────────────────────
-- Add columns to support enhanced document management
ALTER TABLE documents ADD COLUMN IF NOT EXISTS
  current_version_id TEXT REFERENCES document_versions(id) ON DELETE SET NULL;

ALTER TABLE documents ADD COLUMN IF NOT EXISTS
  attachment_count INT DEFAULT 0;

ALTER TABLE documents ADD COLUMN IF NOT EXISTS
  version_count INT DEFAULT 1;

ALTER TABLE documents ADD COLUMN IF NOT EXISTS
  last_accessed TIMESTAMPTZ;

ALTER TABLE documents ADD COLUMN IF NOT EXISTS
  access_count INT DEFAULT 0;

ALTER TABLE documents ADD COLUMN IF NOT EXISTS
  is_pinned BOOLEAN DEFAULT FALSE;

-- ─── Module-specific constraints ───────────────────────────────────────────────
-- Add comment constraints for documentation
COMMENT ON TABLE document_attachments IS 
  'Links documents to module records (HAZOP, LOPA, BowTie, Incident, Permit, MOC, Workflow, Action Register)';

COMMENT ON TABLE document_versions IS 
  'Tracks document revision history with change tracking and rollback support';

COMMENT ON TABLE document_previews IS 
  'Caches preview metadata and thumbnail paths for performance';

COMMENT ON TABLE document_access_log IS 
  'Audit trail for document access and download activities';

-- ─── Trigger to update updated_at timestamp ───────────────────────────────────
CREATE OR REPLACE FUNCTION update_attachment_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_attachment_updated_at
  BEFORE UPDATE ON document_attachments
  FOR EACH ROW
  EXECUTE FUNCTION update_attachment_timestamp();

-- ─── Helper function to get attachment count ───────────────────────────────────
CREATE OR REPLACE FUNCTION get_attachment_count(p_document_id TEXT)
RETURNS INT AS $$
DECLARE
  v_count INT;
BEGIN
  SELECT COUNT(*) INTO v_count FROM document_attachments WHERE document_id = p_document_id;
  RETURN COALESCE(v_count, 0);
END;
$$ LANGUAGE plpgsql;

-- ─── Helper function to get version count ──────────────────────────────────────
CREATE OR REPLACE FUNCTION get_version_count(p_document_id TEXT)
RETURNS INT AS $$
DECLARE
  v_count INT;
BEGIN
  SELECT COUNT(*) INTO v_count FROM document_versions WHERE document_id = p_document_id;
  RETURN COALESCE(v_count, 0);
END;
$$ LANGUAGE plpgsql;
