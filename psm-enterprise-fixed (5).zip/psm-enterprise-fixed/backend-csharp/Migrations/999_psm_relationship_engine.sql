-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║  PSM Enterprise — Migration: Centralized Relationship Engine              ║
-- ║  Description: Core tables for PSM domain entities and relationships       ║
-- ║  Module Integration: PSI, HAZOP, LOPA, MOC, PSSR, RCA, BowTie            ║
-- ╚══════════════════════════════════════════════════════════════════════════╝

-- ─────────────────────────────────────────────────────────────────────────────
-- ► Domain Entity Tables
-- ─────────────────────────────────────────────────────────────────────────────

-- ASSET: Physical or logical equipment/system in the process
CREATE TABLE IF NOT EXISTS psm_assets (
    id                  TEXT        PRIMARY KEY,
    name                TEXT        NOT NULL,
    description         TEXT,
    category            TEXT,        -- Equipment, Instrumentation, Control System
    manufacturer        TEXT,
    model_number        TEXT,
    serial_number       TEXT,
    unit                TEXT,        -- Facility unit/area
    installation_date   DATE,
    last_maintenance    TIMESTAMPTZ,
    status              TEXT        DEFAULT 'Active',
    design_code         TEXT,
    criticality         TEXT,        -- High, Medium, Low
    drawing_reference   TEXT,
    metadata            JSONB       DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          TEXT,
    updated_by          TEXT,
    deleted             BOOLEAN     NOT NULL DEFAULT FALSE,
    CONSTRAINT ck_asset_status CHECK (status IN ('Active', 'Inactive', 'In-Maintenance', 'Decommissioned'))
);

CREATE INDEX IF NOT EXISTS idx_psm_assets_unit ON psm_assets(unit);
CREATE INDEX IF NOT EXISTS idx_psm_assets_category ON psm_assets(category);
CREATE INDEX IF NOT EXISTS idx_psm_assets_criticality ON psm_assets(criticality);
CREATE INDEX IF NOT EXISTS idx_psm_assets_status ON psm_assets(status);
CREATE INDEX IF NOT EXISTS idx_psm_assets_deleted ON psm_assets(deleted);

-- PROCESS UNIT: Operational unit combining multiple assets
CREATE TABLE IF NOT EXISTS psm_process_units (
    id                  TEXT        PRIMARY KEY,
    name                TEXT        NOT NULL,
    description         TEXT,
    unit_type           TEXT,        -- Reactor, Distillation, Separation, etc.
    location            TEXT,
    operating_mode      TEXT,        -- Continuous, Batch, Startup
    design_temperature  NUMERIC(10,2),
    design_pressure     NUMERIC(10,2),
    pressure_unit       TEXT,        -- bar, psi, MPa
    status              TEXT        DEFAULT 'Operating',
    startup_date        DATE,
    last_major_revamp   DATE,
    responsible_person  TEXT,
    metadata            JSONB       DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          TEXT,
    updated_by          TEXT,
    deleted             BOOLEAN     NOT NULL DEFAULT FALSE,
    CONSTRAINT ck_unit_status CHECK (status IN ('Operating', 'Idle', 'Under-Maintenance', 'Decommissioned'))
);

CREATE INDEX IF NOT EXISTS idx_psm_process_units_unit_type ON psm_process_units(unit_type);
CREATE INDEX IF NOT EXISTS idx_psm_process_units_status ON psm_process_units(status);
CREATE INDEX IF NOT EXISTS idx_psm_process_units_deleted ON psm_process_units(deleted);

-- HAZARD: Potential source of harm or dangerous situation
CREATE TABLE IF NOT EXISTS psm_hazards (
    id                  TEXT        PRIMARY KEY,
    name                TEXT        NOT NULL,
    description         TEXT,
    hazard_category     TEXT        NOT NULL,  -- Pressure, Temperature, Chemical, Mechanical
    hazard_source       TEXT,
    severity            TEXT,                  -- Catastrophic, Critical, Major, Minor
    probability         TEXT,                  -- High, Medium, Low, Remote
    risk_level          TEXT,
    status              TEXT        DEFAULT 'Identified',
    process_unit_id     TEXT        REFERENCES psm_process_units(id),
    identified_date     DATE,
    identified_by       TEXT,
    metadata            JSONB       DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          TEXT,
    updated_by          TEXT,
    deleted             BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_psm_hazards_category ON psm_hazards(hazard_category);
CREATE INDEX IF NOT EXISTS idx_psm_hazards_severity ON psm_hazards(severity);
CREATE INDEX IF NOT EXISTS idx_psm_hazards_risk_level ON psm_hazards(risk_level);
CREATE INDEX IF NOT EXISTS idx_psm_hazards_process_unit_id ON psm_hazards(process_unit_id);
CREATE INDEX IF NOT EXISTS idx_psm_hazards_status ON psm_hazards(status);

-- SCENARIO: Specific incident sequence or accident scenario
CREATE TABLE IF NOT EXISTS psm_scenarios (
    id                  TEXT        PRIMARY KEY,
    name                TEXT        NOT NULL,
    description         TEXT,
    scenario_type       TEXT,        -- Loss of Containment, Overpressure, etc.
    triggering_event    TEXT,
    consequences        TEXT,
    sequence_of_events  TEXT,
    severity            TEXT,        -- Minor, Moderate, Severe, Catastrophic
    likelihood          TEXT,        -- Remote, Low, Medium, High
    risk_level          TEXT,
    status              TEXT        DEFAULT 'Potential',
    hazard_id           TEXT        REFERENCES psm_hazards(id),
    process_unit_id     TEXT        REFERENCES psm_process_units(id),
    created_date        TIMESTAMPTZ,
    metadata            JSONB       DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          TEXT,
    updated_by          TEXT,
    deleted             BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_psm_scenarios_hazard_id ON psm_scenarios(hazard_id);
CREATE INDEX IF NOT EXISTS idx_psm_scenarios_process_unit_id ON psm_scenarios(process_unit_id);
CREATE INDEX IF NOT EXISTS idx_psm_scenarios_severity ON psm_scenarios(severity);
CREATE INDEX IF NOT EXISTS idx_psm_scenarios_risk_level ON psm_scenarios(risk_level);

-- BARRIER: Technical, administrative, or procedural control
CREATE TABLE IF NOT EXISTS psm_barriers (
    id                      TEXT        PRIMARY KEY,
    name                    TEXT        NOT NULL,
    description             TEXT,
    barrier_type            TEXT        NOT NULL,  -- Prevention, Mitigation, Detection
    control_type            TEXT,                  -- Engineering, Administrative, PPE
    function_description    TEXT,
    independence_level      TEXT,                  -- Independent, Semi-Independent, Dependent
    effectiveness           TEXT,                  -- High, Medium, Low, Unknown
    status                  TEXT        DEFAULT 'Active',
    owner                   TEXT,
    implementation_date     DATE,
    last_verification_date  DATE,
    verification_frequency  TEXT,                  -- Annual, Quarterly, etc.
    standard_or_requirement TEXT,
    metadata                JSONB       DEFAULT '{}',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by              TEXT,
    updated_by              TEXT,
    deleted                 BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_psm_barriers_type ON psm_barriers(barrier_type);
CREATE INDEX IF NOT EXISTS idx_psm_barriers_effectiveness ON psm_barriers(effectiveness);
CREATE INDEX IF NOT EXISTS idx_psm_barriers_status ON psm_barriers(status);
CREATE INDEX IF NOT EXISTS idx_psm_barriers_owner ON psm_barriers(owner);

-- ACTION ITEM: Corrective, preventive, or improvement actions
CREATE TABLE IF NOT EXISTS psm_action_items (
    id                  TEXT        PRIMARY KEY,
    title               TEXT        NOT NULL,
    description         TEXT,
    action_type         TEXT,        -- Corrective, Preventive, Improvement
    priority            TEXT        DEFAULT 'Medium',
    status              TEXT        DEFAULT 'Open',
    owner               TEXT,
    due_date            DATE        NOT NULL,
    completion_date     DATE,
    source_module       TEXT,        -- HAZOP, LOPA, RCA, MOC, Audit
    source_id           TEXT,
    evidence            TEXT,
    verified_by         TEXT,
    verification_date   DATE,
    priority_sil        INT,
    metadata            JSONB       DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          TEXT,
    updated_by          TEXT,
    deleted             BOOLEAN     NOT NULL DEFAULT FALSE,
    CONSTRAINT ck_action_priority CHECK (priority IN ('High', 'Medium', 'Low')),
    CONSTRAINT ck_action_status CHECK (status IN ('Open', 'In-Progress', 'Completed', 'Closed', 'Cancelled'))
);

CREATE INDEX IF NOT EXISTS idx_psm_action_items_status ON psm_action_items(status);
CREATE INDEX IF NOT EXISTS idx_psm_action_items_priority ON psm_action_items(priority);
CREATE INDEX IF NOT EXISTS idx_psm_action_items_due_date ON psm_action_items(due_date);
CREATE INDEX IF NOT EXISTS idx_psm_action_items_owner ON psm_action_items(owner);
CREATE INDEX IF NOT EXISTS idx_psm_action_items_source ON psm_action_items(source_module, source_id);

-- CHANGE REQUEST: Formal request for modification following MOC procedure
CREATE TABLE IF NOT EXISTS psm_change_requests (
    id                          TEXT        PRIMARY KEY,
    title                       TEXT        NOT NULL,
    description                 TEXT,
    change_type                 TEXT        NOT NULL,  -- Technical, Operational, Organizational, Temporary
    severity                    TEXT        DEFAULT 'Medium',
    status                      TEXT        DEFAULT 'Proposed',
    justification               TEXT,
    proposed_by                 TEXT,
    proposed_date               TIMESTAMPTZ NOT NULL,
    reviewed_by                 TEXT,
    review_date                 TIMESTAMPTZ,
    approved_by                 TEXT,
    approval_date               TIMESTAMPTZ,
    implemented_by              TEXT,
    implementation_date         TIMESTAMPTZ,
    planned_completion_date     DATE,
    actual_completion_date      DATE,
    impact_assessment           TEXT,
    operational_equivalence     TEXT,
    risk_assessment             TEXT,
    pssr_required               TEXT,  -- Yes, No, Partial
    pssr_id                     TEXT,
    metadata                    JSONB       DEFAULT '{}',
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by                  TEXT,
    updated_by                  TEXT,
    deleted                     BOOLEAN     NOT NULL DEFAULT FALSE,
    CONSTRAINT ck_change_status CHECK (status IN ('Proposed', 'Reviewed', 'Approved', 'Implemented', 'Closed', 'Rejected'))
);

CREATE INDEX IF NOT EXISTS idx_psm_change_requests_status ON psm_change_requests(status);
CREATE INDEX IF NOT EXISTS idx_psm_change_requests_change_type ON psm_change_requests(change_type);
CREATE INDEX IF NOT EXISTS idx_psm_change_requests_severity ON psm_change_requests(severity);
CREATE INDEX IF NOT EXISTS idx_psm_change_requests_proposed_by ON psm_change_requests(proposed_by);

-- PSM DOCUMENTS: Centralized document management
CREATE TABLE IF NOT EXISTS psm_documents (
    id                  TEXT        PRIMARY KEY,
    title               TEXT        NOT NULL,
    description         TEXT,
    document_type       TEXT        NOT NULL,  -- Report, Procedure, Checklist, etc.
    module              TEXT,                  -- HAZOP, LOPA, MOC, RCA, etc.
    file_path           TEXT,
    file_size           BIGINT,
    mime_type           TEXT,
    version             TEXT,
    revision_date       DATE,
    approved_by         TEXT,
    approval_date       DATE,
    expiry_date         DATE,
    is_archived         BOOLEAN     DEFAULT FALSE,
    tags                TEXT[],
    access_level        TEXT        DEFAULT 'Internal',  -- Public, Internal, Confidential
    metadata            JSONB       DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          TEXT,
    updated_by          TEXT,
    deleted             BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_psm_documents_module ON psm_documents(module);
CREATE INDEX IF NOT EXISTS idx_psm_documents_document_type ON psm_documents(document_type);
CREATE INDEX IF NOT EXISTS idx_psm_documents_is_archived ON psm_documents(is_archived);
CREATE INDEX IF NOT EXISTS idx_psm_documents_tags ON psm_documents USING GIN (tags);

-- INCIDENTS: Historical incident/accident tracking
CREATE TABLE IF NOT EXISTS psm_incidents (
    id                          TEXT        PRIMARY KEY,
    title                       TEXT        NOT NULL,
    description                 TEXT,
    incident_date               TIMESTAMPTZ NOT NULL,
    reported_date               TIMESTAMPTZ,
    reported_by                 TEXT,
    incident_type               TEXT        NOT NULL,  -- Near-Miss, Lost-Time, Environmental, etc.
    severity                    TEXT        DEFAULT 'Minor',
    location                    TEXT,
    affected_process_unit       TEXT,
    root_cause_analysis_id      TEXT,
    injuries_count              INT,
    environmental_impact        TEXT,
    immediate_corrections_taken BOOLEAN     DEFAULT FALSE,
    immediate_corrections       TEXT,
    status                      TEXT        DEFAULT 'Reported',
    investigation_lead          TEXT,
    investigation_start_date    DATE,
    investigation_completion   DATE,
    metadata                    JSONB       DEFAULT '{}',
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by                  TEXT,
    updated_by                  TEXT,
    deleted                     BOOLEAN     NOT NULL DEFAULT FALSE,
    CONSTRAINT ck_incident_type CHECK (incident_type IN ('Near-Miss', 'Lost-Time', 'Environmental', 'Property-Damage', 'Fatality'))
);

CREATE INDEX IF NOT EXISTS idx_psm_incidents_incident_type ON psm_incidents(incident_type);
CREATE INDEX IF NOT EXISTS idx_psm_incidents_severity ON psm_incidents(severity);
CREATE INDEX IF NOT EXISTS idx_psm_incidents_incident_date ON psm_incidents(incident_date);
CREATE INDEX IF NOT EXISTS idx_psm_incidents_affected_unit ON psm_incidents(affected_process_unit);

-- ─────────────────────────────────────────────────────────────────────────────
-- ► Relationship Management Tables
-- ─────────────────────────────────────────────────────────────────────────────

-- CORE RELATIONSHIPS: Flexible, extensible relationship linking
CREATE TABLE IF NOT EXISTS psm_relationships (
    id                      TEXT        PRIMARY KEY,
    relationship_type       TEXT        NOT NULL,
    source_entity_type      TEXT        NOT NULL,
    source_entity_id        TEXT        NOT NULL,
    target_entity_type      TEXT        NOT NULL,
    target_entity_id        TEXT        NOT NULL,
    direction               TEXT        DEFAULT 'OneWay',
    weight                  INT,
    status                  TEXT        DEFAULT 'Active',
    context                 TEXT,
    notes                   TEXT,
    established_date        TIMESTAMPTZ NOT NULL,
    planned_end_date        TIMESTAMPTZ,
    metadata                JSONB       DEFAULT '{}',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by              TEXT,
    updated_by              TEXT,
    deleted                 BOOLEAN     NOT NULL DEFAULT FALSE,
    CONSTRAINT ck_rel_direction CHECK (direction IN ('OneWay', 'TwoWay')),
    CONSTRAINT ck_rel_status CHECK (status IN ('Active', 'Dormant', 'Archived', 'Superseded'))
);

-- Critical composite index for efficient querying
CREATE INDEX IF NOT EXISTS idx_psm_relationships_source 
    ON psm_relationships(source_entity_type, source_entity_id, status);
CREATE INDEX IF NOT EXISTS idx_psm_relationships_target 
    ON psm_relationships(target_entity_type, target_entity_id, status);
CREATE INDEX IF NOT EXISTS idx_psm_relationships_type 
    ON psm_relationships(relationship_type, status);
CREATE INDEX IF NOT EXISTS idx_psm_relationships_established 
    ON psm_relationships(established_date DESC);
CREATE INDEX IF NOT EXISTS idx_psm_relationships_deleted 
    ON psm_relationships(deleted);

-- RELATIONSHIP CHANGES: Audit log for relationship lifecycle
CREATE TABLE IF NOT EXISTS psm_relationship_changes (
    id                  TEXT        PRIMARY KEY,
    relationship_id     TEXT        NOT NULL REFERENCES psm_relationships(id),
    change_type         TEXT        NOT NULL,  -- Created, Updated, Deleted, StatusChanged
    field_changed       TEXT,
    old_value           TEXT,
    new_value           TEXT,
    reason              TEXT,
    changed_by          TEXT,
    change_timestamp    TIMESTAMPTZ NOT NULL,
    reviewed_by         TEXT,
    review_date         TIMESTAMPTZ,
    approved_by         TEXT,
    approval_date       TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted             BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_psm_rel_changes_relationship_id 
    ON psm_relationship_changes(relationship_id);
CREATE INDEX IF NOT EXISTS idx_psm_rel_changes_change_timestamp 
    ON psm_relationship_changes(change_timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_psm_rel_changes_changed_by 
    ON psm_relationship_changes(changed_by);

-- RELATIONSHIP LINEAGE: Track hierarchical dependency paths
CREATE TABLE IF NOT EXISTS psm_relationship_lineage (
    id                      TEXT        PRIMARY KEY,
    root_entity_type        TEXT        NOT NULL,
    root_entity_id          TEXT        NOT NULL,
    downstream_entity_type  TEXT        NOT NULL,
    downstream_entity_id    TEXT        NOT NULL,
    path_length             INT         NOT NULL,
    path_description        TEXT        NOT NULL,
    criticality_level       TEXT,       -- High, Medium, Low
    intermediate_entity_ids TEXT[],
    calculated_date         TIMESTAMPTZ NOT NULL,
    is_active               BOOLEAN     DEFAULT TRUE,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted                 BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_psm_rel_lineage_root 
    ON psm_relationship_lineage(root_entity_type, root_entity_id);
CREATE INDEX IF NOT EXISTS idx_psm_rel_lineage_downstream 
    ON psm_relationship_lineage(downstream_entity_type, downstream_entity_id);
CREATE INDEX IF NOT EXISTS idx_psm_rel_lineage_criticality 
    ON psm_relationship_lineage(criticality_level);

-- ENTITY REFERENCES: Cross-module reference tracking
CREATE TABLE IF NOT EXISTS psm_entity_references (
    id                      TEXT        PRIMARY KEY,
    referencing_entity_type TEXT        NOT NULL,
    referencing_entity_id   TEXT        NOT NULL,
    referenced_entity_type  TEXT        NOT NULL,
    referenced_entity_id    TEXT        NOT NULL,
    reference_context       TEXT,
    reference_count         INT         DEFAULT 1,
    last_referenced_date    TIMESTAMPTZ NOT NULL,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted                 BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_psm_entity_refs_referencing 
    ON psm_entity_references(referencing_entity_type, referencing_entity_id);
CREATE INDEX IF NOT EXISTS idx_psm_entity_refs_referenced 
    ON psm_entity_references(referenced_entity_type, referenced_entity_id);

-- RELATIONSHIP CACHE: Performance optimization
CREATE TABLE IF NOT EXISTS psm_relationship_cache (
    id                          TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
    entity_id                   TEXT        NOT NULL,
    entity_type                 TEXT        NOT NULL,
    inbound_relationship_count  INT         DEFAULT 0,
    outbound_relationship_count INT         DEFAULT 0,
    total_dependent_records     INT         DEFAULT 0,
    last_updated                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    cache_expires_at            TIMESTAMPTZ,
    UNIQUE(entity_id, entity_type)
);

CREATE INDEX IF NOT EXISTS idx_psm_rel_cache_entity 
    ON psm_relationship_cache(entity_id, entity_type);
CREATE INDEX IF NOT EXISTS idx_psm_rel_cache_expiry 
    ON psm_relationship_cache(cache_expires_at);

-- ─────────────────────────────────────────────────────────────────────────────
-- ► Integration Tables
-- ─────────────────────────────────────────────────────────────────────────────

-- CROSS-MODULE INTEGRATION MAPS: Predefined integration patterns
CREATE TABLE IF NOT EXISTS psm_integration_maps (
    id                  TEXT        PRIMARY KEY,
    source_module       TEXT        NOT NULL,
    target_module       TEXT        NOT NULL,
    mapping_rule        TEXT        NOT NULL,
    transformation_logic TEXT,
    is_automatic        BOOLEAN     DEFAULT FALSE,
    execution_order     INT         NOT NULL,
    created_date        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_active           BOOLEAN     DEFAULT TRUE,
    UNIQUE(source_module, target_module)
);

CREATE INDEX IF NOT EXISTS idx_psm_integration_maps_modules 
    ON psm_integration_maps(source_module, target_module);
CREATE INDEX IF NOT EXISTS idx_psm_integration_maps_is_active 
    ON psm_integration_maps(is_active);

-- ─────────────────────────────────────────────────────────────────────────────
-- ► Track Migration Status
-- ─────────────────────────────────────────────────────────────────────────────

INSERT INTO schema_migrations (version) VALUES ('999_psm_relationship_engine')
    ON CONFLICT DO NOTHING;
