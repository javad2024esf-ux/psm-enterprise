-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║  Migration 021 : psm_audit_entries — Enterprise Audit Trail              ║
-- ╚══════════════════════════════════════════════════════════════════════════╝
-- جایگزین audit_log / audit_trail / audit_logs پراکنده.
-- جداول قدیمی دست‌نخورده می‌مانند (داده تاریخی حفظ می‌شود).
-- تمام write‌های جدید فقط در این جدول انجام می‌شود.

CREATE TABLE IF NOT EXISTS psm_audit_entries (
    id              BIGSERIAL    PRIMARY KEY,

    -- شناسه یکتای رویداد (برای ردیابی cross-service)
    event_id        TEXT         NOT NULL UNIQUE,

    -- نوع عملیات
    action          TEXT         NOT NULL,  -- LOGIN | UPDATE_USER | APPROVE_PERMIT | ...
    severity        TEXT         NOT NULL DEFAULT 'INFO',  -- INFO | WARNING | CRITICAL

    -- کاربر عامل
    user_id         TEXT,
    username        TEXT,
    user_full_name  TEXT,
    user_role       TEXT,

    -- context درخواست
    ip_address      TEXT,
    user_agent      TEXT,

    -- هدف عملیات
    module          TEXT,        -- hazop | moc | work_permit | auth | users | ...
    record_id       TEXT,        -- شناسه رکورد تغییریافته
    record_title    TEXT,        -- عنوان خلاصه برای نمایش (بدون JOIN)

    -- diff کامل
    old_values      JSONB,       -- snapshot کامل قبل از تغییر
    new_values      JSONB,       -- snapshot کامل بعد از تغییر
    changed_fields  JSONB,       -- [{field, oldValue, newValue}, ...]

    -- نتیجه
    outcome         TEXT         DEFAULT 'SUCCESS',  -- SUCCESS | FAILURE | DENIED
    failure_reason  TEXT,

    -- اطلاعات اضافه context-specific
    metadata        JSONB,

    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ── ایندکس‌های پرکاربرد ───────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_psm_audit_user       ON psm_audit_entries (user_id);
CREATE INDEX IF NOT EXISTS idx_psm_audit_action     ON psm_audit_entries (action);
CREATE INDEX IF NOT EXISTS idx_psm_audit_module     ON psm_audit_entries (module);
CREATE INDEX IF NOT EXISTS idx_psm_audit_record     ON psm_audit_entries (record_id);
CREATE INDEX IF NOT EXISTS idx_psm_audit_severity   ON psm_audit_entries (severity);
CREATE INDEX IF NOT EXISTS idx_psm_audit_outcome    ON psm_audit_entries (outcome);
CREATE INDEX IF NOT EXISTS idx_psm_audit_created    ON psm_audit_entries (created_at DESC);
-- ایندکس ترکیبی برای فیلتر رایج dashboard
CREATE INDEX IF NOT EXISTS idx_psm_audit_module_ts  ON psm_audit_entries (module, created_at DESC);
-- GIN برای جستجوی full-text داخل JSONB
CREATE INDEX IF NOT EXISTS idx_psm_audit_changes_gin ON psm_audit_entries USING GIN (changed_fields);
CREATE INDEX IF NOT EXISTS idx_psm_audit_meta_gin    ON psm_audit_entries USING GIN (metadata);

-- ── View برای سازگاری با کدهای قدیمی که از audit_logs می‌خواندند ────────────
CREATE OR REPLACE VIEW audit_logs_compat AS
SELECT
    event_id              AS id,
    user_id,
    action,
    module,
    COALESCE(failure_reason, metadata::text) AS details,
    ip_address,
    created_at
FROM psm_audit_entries;

COMMENT ON TABLE  psm_audit_entries  IS 'Enterprise Audit Trail — migration 021';
COMMENT ON COLUMN psm_audit_entries.changed_fields IS
    'آرایه JSON از [{field, oldValue, newValue}] — محاسبه‌شده توسط AuditBuilder.ComputeDiff';
