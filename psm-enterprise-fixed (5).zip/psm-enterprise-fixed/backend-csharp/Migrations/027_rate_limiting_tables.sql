-- ============================================================================
-- Migration: 027_rate_limiting_tables
-- Purpose: Add tables for rate limiting statistics and tracking
-- ============================================================================

-- ── Rate Limiting Statistics ────────────────────────────────────────────────
-- Tracks API request counts for analytics and enforcement
CREATE TABLE IF NOT EXISTS rate_limit_stats (
    id BIGSERIAL PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    ip_address VARCHAR(45) NOT NULL,
    endpoint_path VARCHAR(255) NOT NULL,
    method VARCHAR(10) NOT NULL,
    request_count INT NOT NULL DEFAULT 1,
    window_start TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    window_end TIMESTAMP NOT NULL,
    rejected BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ── Indexes for fast lookup ─────────────────────────────────────────────────
CREATE INDEX idx_rate_limit_stats_tenant_user 
    ON rate_limit_stats(tenant_id, user_id, window_start);

CREATE INDEX idx_rate_limit_stats_ip_window 
    ON rate_limit_stats(ip_address, window_start);

CREATE INDEX idx_rate_limit_stats_endpoint 
    ON rate_limit_stats(endpoint_path, method, window_start);

-- ── Rate Limit Violations (for audit trail) ─────────────────────────────────
CREATE TABLE IF NOT EXISTS rate_limit_violations (
    id BIGSERIAL PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    ip_address VARCHAR(45) NOT NULL,
    endpoint_path VARCHAR(255) NOT NULL,
    method VARCHAR(10) NOT NULL,
    violation_type VARCHAR(50) NOT NULL,
    limit_name VARCHAR(100) NOT NULL,
    limit_value INT NOT NULL,
    actual_count INT NOT NULL,
    user_agent TEXT,
    violation_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ── Indexes for violation tracking ──────────────────────────────────────────
CREATE INDEX idx_rate_limit_violations_tenant_user 
    ON rate_limit_violations(tenant_id, user_id, violation_timestamp);

CREATE INDEX idx_rate_limit_violations_ip 
    ON rate_limit_violations(ip_address, violation_timestamp);

CREATE INDEX idx_rate_limit_violations_type 
    ON rate_limit_violations(violation_type, violation_timestamp);

-- ── Rate Limit Configuration (per-endpoint rules) ───────────────────────────
CREATE TABLE IF NOT EXISTS rate_limit_config (
    id BIGSERIAL PRIMARY KEY,
    endpoint_pattern VARCHAR(255) NOT NULL,
    method VARCHAR(10) NOT NULL,
    policy_name VARCHAR(100) NOT NULL,
    limit_per_minute INT NOT NULL DEFAULT 100,
    enabled BOOLEAN DEFAULT TRUE,
    description VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(endpoint_pattern, method)
);

-- ── Pre-configured rate limit rules ─────────────────────────────────────────
INSERT INTO rate_limit_config (endpoint_pattern, method, policy_name, limit_per_minute, description) VALUES
    ('/api/auth/login', 'POST', 'login-strict', 5, 'شدید: حمایت در برابر تهاجم رمز عبور'),
    ('/api/auth/register', 'POST', 'login-strict', 5, 'شدید: حمایت در برابر ثبت نام توده‌ای'),
    ('/api/auth/refresh', 'POST', 'login-strict', 10, 'شدید: تجدید کننده توکن'),
    ('/api/*/ai/*', 'POST', 'heavy-operation', 10, 'سنگین: درخواست‌های هوش مصنوعی'),
    ('/api/documents/upload', 'POST', 'heavy-operation', 10, 'سنگین: بارگذاری سند'),
    ('/api/*/export', 'GET', 'heavy-operation', 10, 'سنگین: صادرات داده'),
    ('/api/*', 'GET', 'auth-user', 100, 'معمول: درخواست‌های GET'),
    ('/api/*', 'POST', 'auth-user', 100, 'معمول: درخواست‌های POST'),
    ('/api/*', 'PUT', 'auth-user', 100, 'معمول: درخواست‌های PUT'),
    ('/api/*', 'DELETE', 'auth-user', 50, 'معمول: درخواست‌های DELETE')
ON CONFLICT DO NOTHING;

COMMENT ON TABLE rate_limit_stats IS 'درخواست API درخواست‌های درخواست برای تجزیه و تحلیل و نفاذ';
COMMENT ON TABLE rate_limit_violations IS 'ردیابی نقض محدودیت‌های نرخ برای دلایل امنیتی و تدقیقی';
COMMENT ON TABLE rate_limit_config IS 'قوانین پیکربندی محدودیت نرخ قابل تنظیم برای هر نقطه‌پایانی';
