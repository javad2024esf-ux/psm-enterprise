-- ════════════════════════════════════════════════════════════════════════════
-- Migration 025 — Orphan Modules Schema
-- HIRA, RCA, Competency, Training, Contractors, PSI,
-- Mechanical Integrity, Emergency, Participation, Culture,
-- Stakeholders, Standards, Metrics, Management Review
-- ════════════════════════════════════════════════════════════════════════════

-- ─── HIRA ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS hira_assessments (
    id              TEXT PRIMARY KEY,
    title           TEXT NOT NULL,
    facility        TEXT,
    department      TEXT,
    assessor        TEXT,
    status          TEXT NOT NULL DEFAULT 'Draft',
    assessment_date TIMESTAMPTZ,
    created_by      TEXT,
    data            JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ,
    deleted_at      TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS hira_hazards (
    id                    TEXT PRIMARY KEY,
    hira_id               TEXT NOT NULL REFERENCES hira_assessments(id),
    hazard_description    TEXT,
    activity              TEXT,
    potential_consequence TEXT,
    existing_controls     TEXT,
    likelihood            INTEGER NOT NULL DEFAULT 1,
    severity              INTEGER NOT NULL DEFAULT 1,
    risk_level            TEXT,
    recommended_actions   TEXT,
    data                  JSONB NOT NULL DEFAULT '{}',
    created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at            TIMESTAMPTZ,
    deleted_at            TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_hira_hazards_hira_id ON hira_hazards(hira_id);

-- ─── RCA ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rca_records (
    id            TEXT PRIMARY KEY,
    title         TEXT NOT NULL,
    incident_date TEXT,
    location      TEXT,
    description   TEXT,
    investigator  TEXT,
    status        TEXT NOT NULL DEFAULT 'Open',
    methodology   TEXT,
    created_by    TEXT,
    data          JSONB NOT NULL DEFAULT '{}',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ,
    deleted_at    TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS rca_causes (
    id                 TEXT PRIMARY KEY,
    rca_id             TEXT NOT NULL REFERENCES rca_records(id),
    cause_type         TEXT,
    description        TEXT,
    contributing_factor TEXT,
    corrective_action  TEXT,
    data               JSONB NOT NULL DEFAULT '{}',
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_rca_causes_rca_id ON rca_causes(rca_id);

-- ─── Competency ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS competencies (
    id          TEXT PRIMARY KEY,
    title       TEXT NOT NULL,
    category    TEXT,
    description TEXT,
    level       TEXT,
    data        JSONB NOT NULL DEFAULT '{}',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ,
    deleted_at  TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS competency_assessments (
    id              TEXT PRIMARY KEY,
    competency_id   TEXT NOT NULL REFERENCES competencies(id),
    employee_id     TEXT,
    employee_name   TEXT,
    score           INTEGER NOT NULL DEFAULT 0,
    assessor        TEXT,
    assessment_date TIMESTAMPTZ,
    notes           TEXT,
    data            JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_competency_assessments_competency_id ON competency_assessments(competency_id);

-- ─── Training ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS training_sessions (
    id             TEXT PRIMARY KEY,
    title          TEXT NOT NULL,
    category       TEXT,
    trainer        TEXT,
    scheduled_date TIMESTAMPTZ,
    duration_hours INTEGER NOT NULL DEFAULT 0,
    location       TEXT,
    status         TEXT NOT NULL DEFAULT 'Scheduled',
    description    TEXT,
    created_by     TEXT,
    data           JSONB NOT NULL DEFAULT '{}',
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ,
    deleted_at     TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS training_participants (
    id            TEXT PRIMARY KEY,
    training_id   TEXT NOT NULL REFERENCES training_sessions(id),
    employee_id   TEXT,
    employee_name TEXT,
    status        TEXT,
    passed        BOOLEAN NOT NULL DEFAULT FALSE,
    notes         TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_training_participants_training_id ON training_participants(training_id);

-- ─── Contractors ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS contractors (
    id              TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    company         TEXT,
    contact_person  TEXT,
    contact_email   TEXT,
    contact_phone   TEXT,
    contract_number TEXT,
    contract_start  TIMESTAMPTZ,
    contract_end    TIMESTAMPTZ,
    status          TEXT NOT NULL DEFAULT 'Active',
    scope_of_work   TEXT,
    created_by      TEXT,
    data            JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ,
    deleted_at      TIMESTAMPTZ
);

-- ─── PSI ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS psi_documents (
    id                 TEXT PRIMARY KEY,
    title              TEXT NOT NULL,
    category           TEXT,
    document_number    TEXT,
    revision           TEXT,
    status             TEXT NOT NULL DEFAULT 'Active',
    description        TEXT,
    responsible_person TEXT,
    review_date        TIMESTAMPTZ,
    created_by         TEXT,
    data               JSONB NOT NULL DEFAULT '{}',
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ,
    deleted_at         TIMESTAMPTZ
);

-- ─── Mechanical Integrity ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS mi_equipment (
    id                    TEXT PRIMARY KEY,
    tag_number            TEXT NOT NULL,
    equipment_name        TEXT NOT NULL,
    equipment_type        TEXT,
    location              TEXT,
    status                TEXT NOT NULL DEFAULT 'Active',
    installation_date     TIMESTAMPTZ,
    next_inspection_date  TIMESTAMPTZ,
    responsible_person    TEXT,
    data                  JSONB NOT NULL DEFAULT '{}',
    created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at            TIMESTAMPTZ,
    deleted_at            TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS mi_inspections (
    id              TEXT PRIMARY KEY,
    equipment_id    TEXT NOT NULL REFERENCES mi_equipment(id),
    inspection_type TEXT,
    inspection_date TIMESTAMPTZ,
    inspector       TEXT,
    result          TEXT,
    findings        TEXT,
    recommendations TEXT,
    next_due_date   TIMESTAMPTZ,
    data            JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mi_inspections_equipment_id ON mi_inspections(equipment_id);

-- ─── Emergency ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS emergency_plans (
    id              TEXT PRIMARY KEY,
    title           TEXT NOT NULL,
    scenario_type   TEXT,
    location        TEXT,
    description     TEXT,
    response_team   TEXT,
    status          TEXT NOT NULL DEFAULT 'Draft',
    last_drill_date TIMESTAMPTZ,
    next_drill_date TIMESTAMPTZ,
    created_by      TEXT,
    data            JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ,
    deleted_at      TIMESTAMPTZ
);

-- ─── Participation ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS participation_activities (
    id            TEXT PRIMARY KEY,
    title         TEXT NOT NULL,
    activity_type TEXT,
    activity_date TIMESTAMPTZ,
    organizer     TEXT,
    department    TEXT,
    description   TEXT,
    status        TEXT NOT NULL DEFAULT 'Planned',
    created_by    TEXT,
    data          JSONB NOT NULL DEFAULT '{}',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ,
    deleted_at    TIMESTAMPTZ
);

-- ─── Culture ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS culture_assessments (
    id              TEXT PRIMARY KEY,
    title           TEXT NOT NULL,
    assessment_type TEXT,
    assessment_date TIMESTAMPTZ,
    assessor        TEXT,
    department      TEXT,
    status          TEXT NOT NULL DEFAULT 'Draft',
    created_by      TEXT,
    data            JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ,
    deleted_at      TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS culture_responses (
    id            TEXT PRIMARY KEY,
    assessment_id TEXT NOT NULL REFERENCES culture_assessments(id),
    question_id   TEXT,
    question_text TEXT,
    score         INTEGER NOT NULL DEFAULT 0,
    comments      TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_culture_responses_assessment_id ON culture_responses(assessment_id);

-- ─── Stakeholders ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS stakeholders (
    id                  TEXT PRIMARY KEY,
    name                TEXT NOT NULL,
    organization        TEXT,
    role                TEXT,
    email               TEXT,
    phone               TEXT,
    interest_level      TEXT,
    influence_level     TEXT,
    engagement_strategy TEXT,
    created_by          TEXT,
    data                JSONB NOT NULL DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ,
    deleted_at          TIMESTAMPTZ
);

-- ─── Standards ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS standards (
    id              TEXT PRIMARY KEY,
    title           TEXT NOT NULL,
    standard_number TEXT,
    issuing_body    TEXT,
    category        TEXT,
    revision        TEXT,
    issue_date      TIMESTAMPTZ,
    review_date     TIMESTAMPTZ,
    status          TEXT NOT NULL DEFAULT 'Active',
    description     TEXT,
    created_by      TEXT,
    data            JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ,
    deleted_at      TIMESTAMPTZ
);

-- ─── Metrics / KPIs ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS psm_metrics (
    id                 TEXT PRIMARY KEY,
    title              TEXT NOT NULL,
    category           TEXT,
    metric_type        TEXT,
    unit               TEXT,
    target_value       DOUBLE PRECISION,
    frequency          TEXT,
    responsible_person TEXT,
    description        TEXT,
    created_by         TEXT,
    data               JSONB NOT NULL DEFAULT '{}',
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ,
    deleted_at         TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS metric_entries (
    id           TEXT PRIMARY KEY,
    metric_id    TEXT NOT NULL REFERENCES psm_metrics(id),
    actual_value DOUBLE PRECISION NOT NULL,
    period_date  TIMESTAMPTZ,
    notes        TEXT,
    recorded_by  TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_metric_entries_metric_id ON metric_entries(metric_id);

-- ─── Management Review ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS management_reviews (
    id          TEXT PRIMARY KEY,
    title       TEXT NOT NULL,
    review_date TIMESTAMPTZ,
    chairperson TEXT,
    location    TEXT,
    status      TEXT NOT NULL DEFAULT 'Planned',
    agenda      TEXT,
    minutes     TEXT,
    created_by  TEXT,
    data        JSONB NOT NULL DEFAULT '{}',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ,
    deleted_at  TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS mr_action_items (
    id          TEXT PRIMARY KEY,
    review_id   TEXT NOT NULL REFERENCES management_reviews(id),
    description TEXT,
    assigned_to TEXT,
    due_date    TIMESTAMPTZ,
    priority    TEXT,
    status      TEXT NOT NULL DEFAULT 'Open',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_mr_action_items_review_id ON mr_action_items(review_id);

-- ─── Set permissions for orphan modules ──────────────────────────────────────
-- Admin: all permissions
INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES 
  ('role_admin', 'HIRA', true, true, true, true),
  ('role_admin', 'RCA', true, true, true, true),
  ('role_admin', 'Competency', true, true, true, true),
  ('role_admin', 'Training', true, true, true, true),
  ('role_admin', 'Contractor', true, true, true, true),
  ('role_admin', 'PSI', true, true, true, true),
  ('role_admin', 'MechanicalIntegrity', true, true, true, true),
  ('role_admin', 'Emergency', true, true, true, true),
  ('role_admin', 'Participation', true, true, true, true),
  ('role_admin', 'Culture', true, true, true, true),
  ('role_admin', 'Stakeholder', true, true, true, true),
  ('role_admin', 'Standard', true, true, true, true),
  ('role_admin', 'Metric', true, true, true, true),
  ('role_admin', 'ManagementReview', true, true, true, true)
ON CONFLICT (role_id, module) DO UPDATE
  SET can_read = true, can_write = true, can_approve = true, can_delete = true;

-- PSMManager and higher roles: read/write permissions
INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES 
  ('role_psmmanager', 'HIRA', true, true, false, false),
  ('role_psmmanager', 'RCA', true, true, false, false),
  ('role_psmmanager', 'Competency', true, true, false, false),
  ('role_psmmanager', 'Training', true, true, false, false),
  ('role_psmmanager', 'Contractor', true, true, false, false),
  ('role_psmmanager', 'PSI', true, true, false, false),
  ('role_psmmanager', 'MechanicalIntegrity', true, true, false, false),
  ('role_psmmanager', 'Emergency', true, true, false, false),
  ('role_psmmanager', 'Participation', true, true, false, false),
  ('role_psmmanager', 'Culture', true, true, false, false),
  ('role_psmmanager', 'Stakeholder', true, true, false, false),
  ('role_psmmanager', 'Standard', true, true, false, false),
  ('role_psmmanager', 'Metric', true, true, false, false),
  ('role_psmmanager', 'ManagementReview', true, true, false, false)
ON CONFLICT (role_id, module) DO UPDATE
  SET can_read = true, can_write = true;

-- Other roles: read-only permissions
INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES 
  ('role_processengineer', 'HIRA', true, false, false, false),
  ('role_processengineer', 'RCA', true, false, false, false),
  ('role_processengineer', 'Competency', true, false, false, false),
  ('role_processengineer', 'Training', true, false, false, false),
  ('role_processengineer', 'Contractor', true, false, false, false),
  ('role_processengineer', 'PSI', true, false, false, false),
  ('role_processengineer', 'MechanicalIntegrity', true, false, false, false),
  ('role_processengineer', 'Emergency', true, false, false, false),
  ('role_processengineer', 'Participation', true, false, false, false),
  ('role_processengineer', 'Culture', true, false, false, false),
  ('role_processengineer', 'Stakeholder', true, false, false, false),
  ('role_processengineer', 'Standard', true, false, false, false),
  ('role_processengineer', 'Metric', true, false, false, false),
  ('role_processengineer', 'ManagementReview', true, false, false, false)
ON CONFLICT (role_id, module) DO UPDATE
  SET can_read = true;
