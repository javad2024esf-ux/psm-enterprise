using Dapper;
using Npgsql;
using PSM.Api.Data;
using Serilog;
using ILogger = Serilog.ILogger;

namespace PSM.Api.Migrations.Runner;

/// <summary>
/// Reads all *.sql files from the Migrations directory (sorted alphabetically),
/// tracks applied versions in schema_migrations table, and runs pending ones.
/// </summary>
public class MigrationRunner
{
    private readonly IDbHelper _db;
    private readonly ILogger   _log;

    public MigrationRunner(IDbHelper db, ILogger log)
    {
        _db  = db;
        _log = log.ForContext<MigrationRunner>();
    }

    public async Task RunAsync()
    {
        _log.Information("[Migration] Starting migration runner…");

        await EnsureTrackingTableAsync();

        var applied = await GetAppliedVersionsAsync();

        // Look for SQL files in output dir (copied from project)
        var migrationsDir = Path.Combine(AppContext.BaseDirectory, "Migrations");
        if (!Directory.Exists(migrationsDir))
        {
            _log.Warning("[Migration] Migrations directory not found at {Dir}", migrationsDir);
            return;
        }

        var files = Directory.GetFiles(migrationsDir, "*.sql")
                             .OrderBy(f => Path.GetFileName(f))
                             .ToList();

        if (files.Count == 0)
        {
            _log.Information("[Migration] No SQL migration files found.");
            return;
        }

        int ran = 0;
        foreach (var file in files)
        {
            var version = Path.GetFileNameWithoutExtension(file);
            if (applied.Contains(version))
            {
                _log.Debug("[Migration] ✅ {Version} — already applied", version);
                continue;
            }

            _log.Information("[Migration] ⏳ Running {Version}…", version);

            var sql = await File.ReadAllTextAsync(file);
            var statements = SplitStatements(sql);

            try
            {
                await ApplyMigrationAsync(version, statements);
                ran++;
                _log.Information("[Migration] ✅ {Version} applied", version);
            }
            catch (Exception ex)
            {
                _log.Error(ex, "[Migration] ❌ Failed to apply {Version}", version);
                throw;
            }
        }

        _log.Information("[Migration] Done. {Ran} new migration(s) applied.", ran);
    }

    private async Task ApplyMigrationAsync(string version, IEnumerable<string> statements)
    {
        await _db.WithTransactionAsync(async (conn, tx) =>
        {
            foreach (var stmt in statements)
            {
                if (!HasSqlContent(stmt)) continue;
                await ((NpgsqlConnection)conn).ExecuteAsync(stmt, transaction: (NpgsqlTransaction)tx);
            }

            // Record as applied
            await ((NpgsqlConnection)conn).ExecuteAsync(
                "INSERT INTO schema_migrations (version) VALUES (@version) ON CONFLICT DO NOTHING",
                new { version },
                transaction: (NpgsqlTransaction)tx);
        });
    }

    private async Task EnsureTrackingTableAsync()
    {
        await _db.ExecuteAsync(@"
            CREATE TABLE IF NOT EXISTS schema_migrations (
                version    TEXT        PRIMARY KEY,
                applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        ");
    }

    private async Task<HashSet<string>> GetAppliedVersionsAsync()
    {
        var rows = await _db.QueryAsync<string>(
            "SELECT version FROM schema_migrations ORDER BY version");
        return rows.ToHashSet();
    }

    private static IEnumerable<string> SplitStatements(string sql)
    {
        // Properly split on semicolons while respecting:
        // 1. Dollar-quoted strings: $tag$...$tag$ (including $$ ... $$)
        // 2. Single-quoted strings: '...'
        // 3. Line comments: -- ...
        // 4. Block comments: /* ... */

        var statements = new List<string>();
        var current = new System.Text.StringBuilder();
        int i = 0;
        int len = sql.Length;

        while (i < len)
        {
            // Line comment
            if (i + 1 < len && sql[i] == '-' && sql[i + 1] == '-')
            {
                while (i < len && sql[i] != '\n') { current.Append(sql[i]); i++; }
                continue;
            }

            // Block comment
            if (i + 1 < len && sql[i] == '/' && sql[i + 1] == '*')
            {
                current.Append(sql[i]); current.Append(sql[i+1]); i += 2;
                while (i + 1 < len && !(sql[i] == '*' && sql[i+1] == '/'))
                { current.Append(sql[i]); i++; }
                if (i + 1 < len) { current.Append(sql[i]); current.Append(sql[i+1]); i += 2; }
                continue;
            }

            // Dollar-quoting: find the tag ($tag$ or $$)
            if (sql[i] == '$')
            {
                int tagEnd = sql.IndexOf('$', i + 1);
                if (tagEnd >= i + 1)
                {
                    string tag = sql.Substring(i, tagEnd - i + 1); // e.g. "$$" or "$body$"
                    current.Append(tag);
                    i = tagEnd + 1;
                    // Read until closing tag
                    int closeTag = sql.IndexOf(tag, i, StringComparison.Ordinal);
                    if (closeTag >= 0)
                    {
                        current.Append(sql.Substring(i, closeTag - i + tag.Length));
                        i = closeTag + tag.Length;
                    }
                    else
                    {
                        // No closing tag found — append rest
                        current.Append(sql.Substring(i));
                        i = len;
                    }
                    continue;
                }
            }

            // Single-quoted string
            if (sql[i] == '\'')
            {
                current.Append(sql[i]); i++;
                while (i < len)
                {
                    current.Append(sql[i]);
                    if (sql[i] == '\'' && (i + 1 >= len || sql[i + 1] != '\'')) { i++; break; }
                    if (sql[i] == '\'' && i + 1 < len && sql[i + 1] == '\'') { current.Append(sql[i+1]); i += 2; continue; }
                    i++;
                }
                continue;
            }

            // Statement terminator
            if (sql[i] == ';')
            {
                var stmt = current.ToString().Trim();
                if (stmt.Length > 0) statements.Add(stmt);
                current.Clear();
                i++;
                continue;
            }

            current.Append(sql[i]); i++;
        }

        // Remaining content after last semicolon
        var last = current.ToString().Trim();
        if (last.Length > 0) statements.Add(last);

        return statements;
    }

    private static bool HasSqlContent(string stmt)
    {
        // Skip empty or comment-only statements
        if (!stmt.Split('\n').Any(line => { var t = line.Trim(); return t.Length > 0 && !t.StartsWith("--"); }))
            return false;

        // Skip transaction control statements — the runner manages its own transaction
        var upper = stmt.Trim().ToUpperInvariant();
        if (upper == "BEGIN" || upper == "COMMIT" || upper == "ROLLBACK") return false;

        return true;
    }
}
