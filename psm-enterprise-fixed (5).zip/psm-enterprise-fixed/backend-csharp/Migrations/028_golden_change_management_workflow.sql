-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║  PSM Enterprise — Migration 028 : Golden Change Management Workflow    ║
-- ║  PSI Change -> MOC -> HAZOP -> LOPA -> Procedure -> Training -> PSSR -> Startup
-- ╚══════════════════════════════════════════════════════════════════════════╝

DO $migration$
BEGIN

  -- ═══════════════════════════════════════════════════════════════════════
  -- Table 1: Change Request Master
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS change_requests (
    id              TEXT        PRIMARY KEY,
    request_number  TEXT        NOT NULL UNIQUE,
    title           TEXT        NOT NULL,
    description     TEXT,
    psi_id          TEXT        REFERENCES records(id),
    change_type     TEXT        NOT NULL, -- 'Major' | 'Minor' | 'Emergency'
    priority        TEXT        NOT NULL DEFAULT 'Medium', -- 'Low' | 'Medium' | 'High' | 'Critical'
    impact_area     TEXT[],
    equipment_ids   TEXT[],
    requested_by    TEXT        NOT NULL REFERENCES users(id),
    requested_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    target_date     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE INDEX IF NOT EXISTS idx_change_req_num ON change_requests(request_number);
  CREATE INDEX IF NOT EXISTS idx_change_type ON change_requests(change_type);
  CREATE INDEX IF NOT EXISTS idx_change_priority ON change_requests(priority);
  CREATE INDEX IF NOT EXISTS idx_change_requested_by ON change_requests(requested_by);

  -- ═══════════════════════════════════════════════════════════════════════
  -- Table 2: Workflow Stage Progress Tracker
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS change_workflow_stages (
    id              TEXT        PRIMARY KEY,
    change_id       TEXT        NOT NULL REFERENCES change_requests(id) ON DELETE CASCADE,
    stage_name      TEXT        NOT NULL, -- 'PSI_Change' | 'MOC' | 'HAZOP_Review' | 'LOPA_Review' | 'Procedure_Update' | 'Training' | 'PSSR' | 'Startup_Approval'
    stage_status    TEXT        NOT NULL DEFAULT 'Pending', -- 'Pending' | 'In_Progress' | 'On_Hold' | 'Completed' | 'Failed'
    started_at      TIMESTAMPTZ,
    completed_at    TIMESTAMPTZ,
    assigned_to     TEXT        REFERENCES users(id),
    notes           TEXT,
    metadata        JSONB       NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(change_id, stage_name)
  );

  CREATE INDEX IF NOT EXISTS idx_change_stage_change_id ON change_workflow_stages(change_id);
  CREATE INDEX IF NOT EXISTS idx_change_stage_name ON change_workflow_stages(stage_name);
  CREATE INDEX IF NOT EXISTS idx_change_stage_status ON change_workflow_stages(stage_status);
  CREATE INDEX IF NOT EXISTS idx_change_stage_assigned ON change_workflow_stages(assigned_to);

  -- ═══════════════════════════════════════════════════════════════════════
  -- Table 3: Stage Actions & Checklist
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS change_stage_actions (
    id              TEXT        PRIMARY KEY,
    stage_id        TEXT        NOT NULL REFERENCES change_workflow_stages(id) ON DELETE CASCADE,
    action_item     TEXT        NOT NULL,
    action_type     TEXT        NOT NULL, -- 'Review' | 'Approval' | 'Test' | 'Documentation' | 'Training'
    is_open         BOOLEAN     NOT NULL DEFAULT TRUE,
    assigned_to     TEXT        REFERENCES users(id),
    due_date        TIMESTAMPTZ,
    completed_at    TIMESTAMPTZ,
    completed_by    TEXT        REFERENCES users(id),
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE INDEX IF NOT EXISTS idx_action_stage_id ON change_stage_actions(stage_id);
  CREATE INDEX IF NOT EXISTS idx_action_is_open ON change_stage_actions(is_open);
  CREATE INDEX IF NOT EXISTS idx_action_assigned_to ON change_stage_actions(assigned_to);

  -- ═══════════════════════════════════════════════════════════════════════
  -- Table 4: HAZOP to Change Linkage
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS change_hazop_mapping (
    id              TEXT        PRIMARY KEY,
    change_id       TEXT        NOT NULL REFERENCES change_requests(id) ON DELETE CASCADE,
    hazop_id        TEXT        NOT NULL REFERENCES records(id) ON DELETE CASCADE,
    mapped_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    mapped_by       TEXT        NOT NULL REFERENCES users(id),
    UNIQUE(change_id, hazop_id)
  );

  CREATE INDEX IF NOT EXISTS idx_change_hazop_change ON change_hazop_mapping(change_id);
  CREATE INDEX IF NOT EXISTS idx_change_hazop_hazop ON change_hazop_mapping(hazop_id);

  -- ═══════════════════════════════════════════════════════════════════════
  -- Table 5: LOPA to Change Linkage
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS change_lopa_mapping (
    id              TEXT        PRIMARY KEY,
    change_id       TEXT        NOT NULL REFERENCES change_requests(id) ON DELETE CASCADE,
    lopa_id         TEXT        NOT NULL REFERENCES records(id) ON DELETE CASCADE,
    sil_determined  BOOLEAN     NOT NULL DEFAULT FALSE,
    mapped_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    mapped_by       TEXT        NOT NULL REFERENCES users(id),
    UNIQUE(change_id, lopa_id)
  );

  CREATE INDEX IF NOT EXISTS idx_change_lopa_change ON change_lopa_mapping(change_id);
  CREATE INDEX IF NOT EXISTS idx_change_lopa_lopa ON change_lopa_mapping(lopa_id);

  -- ═══════════════════════════════════════════════════════════════════════
  -- Table 6: Training Records for Change
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS change_training_records (
    id              TEXT        PRIMARY KEY,
    change_id       TEXT        NOT NULL REFERENCES change_requests(id) ON DELETE CASCADE,
    user_id         TEXT        NOT NULL REFERENCES users(id),
    training_date   TIMESTAMPTZ NOT NULL,
    completed       BOOLEAN     NOT NULL DEFAULT FALSE,
    completion_date TIMESTAMPTZ,
    certificate_url TEXT,
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(change_id, user_id)
  );

  CREATE INDEX IF NOT EXISTS idx_training_change_id ON change_training_records(change_id);
  CREATE INDEX IF NOT EXISTS idx_training_user_id ON change_training_records(user_id);
  CREATE INDEX IF NOT EXISTS idx_training_completed ON change_training_records(completed);

  -- ═══════════════════════════════════════════════════════════════════════
  -- Table 7: PSSR Checklist for Change
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS change_pssr_checklist (
    id              TEXT        PRIMARY KEY,
    change_id       TEXT        NOT NULL REFERENCES change_requests(id) ON DELETE CASCADE,
    pssr_item       TEXT        NOT NULL,
    item_category   TEXT        NOT NULL, -- 'Equipment' | 'Documentation' | 'Procedure' | 'Safety'
    is_verified     BOOLEAN     NOT NULL DEFAULT FALSE,
    verified_by     TEXT        REFERENCES users(id),
    verified_at     TIMESTAMPTZ,
    verification_notes TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE INDEX IF NOT EXISTS idx_pssr_change_id ON change_pssr_checklist(change_id);
  CREATE INDEX IF NOT EXISTS idx_pssr_verified ON change_pssr_checklist(is_verified);

  -- ═══════════════════════════════════════════════════════════════════════
  -- Table 8: Startup Approval Gate
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS change_startup_gates (
    id              TEXT        PRIMARY KEY,
    change_id       TEXT        NOT NULL REFERENCES change_requests(id) ON DELETE CASCADE,
    training_complete BOOLEAN   NOT NULL DEFAULT FALSE,
    pssr_complete   BOOLEAN     NOT NULL DEFAULT FALSE,
    hazop_actions_closed BOOLEAN NOT NULL DEFAULT FALSE,
    lopa_actions_closed BOOLEAN NOT NULL DEFAULT FALSE,
    approval_status TEXT        NOT NULL DEFAULT 'Pending', -- 'Pending' | 'Approved' | 'Rejected'
    approved_by     TEXT        REFERENCES users(id),
    approved_at     TIMESTAMPTZ,
    rejection_reason TEXT,
    can_startup     BOOLEAN     GENERATED ALWAYS AS (
      training_complete AND pssr_complete AND hazop_actions_closed AND lopa_actions_closed
    ) STORED,
    checked_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(change_id)
  );

  CREATE INDEX IF NOT EXISTS idx_startup_change_id ON change_startup_gates(change_id);
  CREATE INDEX IF NOT EXISTS idx_startup_can_startup ON change_startup_gates(can_startup);
  CREATE INDEX IF NOT EXISTS idx_startup_approval_status ON change_startup_gates(approval_status);

  -- ═══════════════════════════════════════════════════════════════════════
  -- Table 9: Dashboard Indicators
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS change_dashboard_metrics (
    id              TEXT        PRIMARY KEY,
    metric_name     TEXT        NOT NULL UNIQUE,
    metric_value    INT         NOT NULL DEFAULT 0,
    metric_type     TEXT        NOT NULL, -- 'Total' | 'In_Progress' | 'Completed' | 'Blocked'
    change_type     TEXT,
    priority        TEXT,
    last_updated    TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE INDEX IF NOT EXISTS idx_metric_name ON change_dashboard_metrics(metric_name);
  CREATE INDEX IF NOT EXISTS idx_metric_type ON change_dashboard_metrics(metric_type);

  -- ═══════════════════════════════════════════════════════════════════════
  -- Seed: Golden Workflow Definition
  -- ═══════════════════════════════════════════════════════════════════════
  INSERT INTO workflow_definitions (id, name, module, version, config, is_active)
  VALUES ('wfd_golden_change', 'Golden Change Management', 'ChangeManagement', 1,
    '{"stages":["PSI_Change","MOC","HAZOP_Review","LOPA_Review","Procedure_Update","Training","PSSR","Startup_Approval"],"sla_hours":480}'::jsonb,
    true)
  ON CONFLICT (module, version) DO NOTHING;

  -- ═══════════════════════════════════════════════════════════════════════
  -- Seed: Workflow States
  -- ═══════════════════════════════════════════════════════════════════════
  INSERT INTO workflow_states (id, workflow_id, name, label, is_initial, is_final, sla_hours, color)
  VALUES
    ('wfs_psi_change',    'wfd_golden_change', 'PSI_Change',        'PSI Change Request',      true,  false, 48,  '#FFC107'),
    ('wfs_moc',           'wfd_golden_change', 'MOC',               'Management of Change',    false, false, 120, '#2196F3'),
    ('wfs_hazop',         'wfd_golden_change', 'HAZOP_Review',      'HAZOP Review',            false, false, 240, '#FF9800'),
    ('wfs_lopa',          'wfd_golden_change', 'LOPA_Review',       'LOPA Review',             false, false, 240, '#9C27B0'),
    ('wfs_procedure',     'wfd_golden_change', 'Procedure_Update',  'Procedure Update',        false, false, 72,  '#4CAF50'),
    ('wfs_training',      'wfd_golden_change', 'Training',          'Training Execution',      false, false, 96,  '#00BCD4'),
    ('wfs_pssr',          'wfd_golden_change', 'PSSR',              'Pre-Startup Safety Review',false, false, 48,  '#FF5722'),
    ('wfs_startup',       'wfd_golden_change', 'Startup_Approval',  'Startup Approval',        false, true,  24,  '#4CAF50')
  ON CONFLICT (workflow_id, name) DO NOTHING;

  -- ═══════════════════════════════════════════════════════════════════════
  -- Seed: Workflow Transitions
  -- ═══════════════════════════════════════════════════════════════════════
  INSERT INTO workflow_transitions (id, workflow_id, from_state, to_state, action, label)
  VALUES
    ('wft_psi_to_moc',      'wfd_golden_change', 'PSI_Change',        'MOC',               'submit_for_moc',      'Submit to MOC'),
    ('wft_moc_to_hazop',    'wfd_golden_change', 'MOC',               'HAZOP_Review',      'approve_moc',         'Approve MOC'),
    ('wft_hazop_to_lopa',   'wfd_golden_change', 'HAZOP_Review',      'LOPA_Review',       'complete_hazop',      'Complete HAZOP'),
    ('wft_lopa_to_proc',    'wfd_golden_change', 'LOPA_Review',       'Procedure_Update',  'complete_lopa',       'Complete LOPA'),
    ('wft_proc_to_train',   'wfd_golden_change', 'Procedure_Update',  'Training',          'finalize_procedures', 'Finalize Procedures'),
    ('wft_train_to_pssr',   'wfd_golden_change', 'Training',          'PSSR',              'complete_training',   'Training Complete'),
    ('wft_pssr_to_startup', 'wfd_golden_change', 'PSSR',              'Startup_Approval',  'complete_pssr',       'Complete PSSR'),
    ('wft_startup_approve', 'wfd_golden_change', 'Startup_Approval',  'Startup_Approval',  'approve_startup',     'Approve Startup'),
    ('wft_moc_reject',      'wfd_golden_change', 'MOC',               'PSI_Change',        'reject_moc',          'Return to PSI'),
    ('wft_hazop_reject',    'wfd_golden_change', 'HAZOP_Review',      'MOC',               'reject_hazop',        'Return to MOC'),
    ('wft_lopa_reject',     'wfd_golden_change', 'LOPA_Review',       'HAZOP_Review',      'reject_lopa',         'Return to HAZOP'),
    ('wft_pssr_reject',     'wfd_golden_change', 'PSSR',              'Training',          'reject_pssr',         'Return to Training')
  ON CONFLICT DO NOTHING;

  -- ═══════════════════════════════════════════════════════════════════════
  -- Seed: Dashboard Metrics Templates
  -- ═══════════════════════════════════════════════════════════════════════
  INSERT INTO change_dashboard_metrics (id, metric_name, metric_type, metric_value)
  VALUES
    ('cdm_total_changes',      'Total Changes',           'Total',        0),
    ('cdm_in_progress',        'In Progress',             'In_Progress',  0),
    ('cdm_completed',          'Completed',               'Completed',    0),
    ('cdm_blocked',            'Blocked',                 'Blocked',      0),
    ('cdm_major_in_progress',  'Major Changes In Progress', 'In_Progress', 0),
    ('cdm_overdue',            'Overdue',                 'Blocked',      0)
  ON CONFLICT (metric_name) DO NOTHING;

  INSERT INTO schema_migrations (version) VALUES ('028_golden_change_management_workflow')
    ON CONFLICT DO NOTHING;

END
$migration$;
