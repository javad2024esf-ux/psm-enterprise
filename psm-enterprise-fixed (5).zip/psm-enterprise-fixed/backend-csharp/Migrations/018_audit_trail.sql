-- ═══════════════════════════════════════════════════════════════════════════
-- Migration 018: RBAC Audit Trail
-- ═══════════════════════════════════════════════════════════════════════════
-- Backs backend/src/services/rbac-audit.service.cjs (RBACauditLogger).
--
-- This is a SEPARATE table from the pre-existing `audit_log` table
-- (migration 001_initial_schema.sql, written via server.cjs's
-- writeAuditLog() and read by modules/audit/index.cjs's GET /audit-log).
-- Both tables are written going forward:
--   - audit_log    -> generic app-wide activity log (unchanged, untouched)
--   - audit_trail  -> RBAC-specific events with structured before/after
--                     detail (role create/update/delete, permission grant/
--                     revoke, role assignment, permission denial)
-- This is additive only: no existing table, column, or row is altered,
-- dropped, or renamed. No breaking schema changes.
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS audit_trail (
  id            BIGSERIAL   PRIMARY KEY,
  action        TEXT        NOT NULL,   -- e.g. ROLE_CREATED, PERMISSION_CHANGED, PERMISSION_DENIED
  user_id       TEXT,                   -- actor; 'system' / 'unknown' allowed, no FK (mirrors audit_log)
  resource_type TEXT        NOT NULL,   -- e.g. ROLE, ROLE_PERMISSION, USER_ROLE, ACCESS_CHECK
  resource_id   TEXT,
  details       JSONB       NOT NULL DEFAULT '{}',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_trail_user          ON audit_trail (user_id);
CREATE INDEX IF NOT EXISTS idx_audit_trail_action         ON audit_trail (action);
CREATE INDEX IF NOT EXISTS idx_audit_trail_resource       ON audit_trail (resource_type, resource_id);
CREATE INDEX IF NOT EXISTS idx_audit_trail_created_at     ON audit_trail (created_at DESC);
