-- ════════════════════════════════════════════════════════════════════════════
-- 014_bowtie_subtables.sql
--
-- FIX: modules/bowtie/index.cjs queries bowtie_causes, bowtie_consequences,
-- bowtie_barriers and bowtie_controls, but migration 012_lopa_bowtie.sql
-- (and 013) only ever created bowtie_diagrams. Every read/write to those four
-- tables fails at runtime with:
--   error: relation "bowtie_causes" does not exist
-- This migration adds the four missing tables, matching the columns the
-- module's routes actually SELECT/INSERT/UPDATE.
-- ════════════════════════════════════════════════════════════════════════════

-- ─── Causes (علت‌ها — سمت چپ BowTie) ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bowtie_causes (
  id          TEXT        PRIMARY KEY,
  diagram_id  TEXT        NOT NULL REFERENCES bowtie_diagrams(id) ON DELETE CASCADE,
  description TEXT        NOT NULL,
  category    TEXT        NOT NULL DEFAULT 'Process',
  probability NUMERIC(12,6),
  sort_order  INTEGER     NOT NULL DEFAULT 0,
  data        JSONB       NOT NULL DEFAULT '{}',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted     BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_bowtie_causes_diagram ON bowtie_causes (diagram_id);

-- ─── Consequences (پیامدها — سمت راست BowTie) ────────────────────────────────
CREATE TABLE IF NOT EXISTS bowtie_consequences (
  id          TEXT        PRIMARY KEY,
  diagram_id  TEXT        NOT NULL REFERENCES bowtie_diagrams(id) ON DELETE CASCADE,
  description TEXT        NOT NULL,
  severity    SMALLINT    NOT NULL DEFAULT 3 CHECK (severity BETWEEN 1 AND 5),
  category    TEXT        NOT NULL DEFAULT 'Safety',
  sort_order  INTEGER     NOT NULL DEFAULT 0,
  data        JSONB       NOT NULL DEFAULT '{}',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted     BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_bowtie_consequences_diagram ON bowtie_consequences (diagram_id);

-- ─── Barriers (موانع — Prevention & Mitigation) ──────────────────────────────
CREATE TABLE IF NOT EXISTS bowtie_barriers (
  id              TEXT        PRIMARY KEY,
  diagram_id      TEXT        NOT NULL REFERENCES bowtie_diagrams(id) ON DELETE CASCADE,
  description     TEXT        NOT NULL,
  barrier_type    TEXT        NOT NULL DEFAULT 'Engineering',
  side            TEXT        NOT NULL CHECK (side IN ('prevention','mitigation')),
  effectiveness   NUMERIC(4,3) NOT NULL DEFAULT 0.9 CHECK (effectiveness BETWEEN 0 AND 1),
  cause_id        TEXT        REFERENCES bowtie_causes(id) ON DELETE SET NULL,
  consequence_id  TEXT        REFERENCES bowtie_consequences(id) ON DELETE SET NULL,
  is_degraded     BOOLEAN     NOT NULL DEFAULT FALSE,
  sort_order      INTEGER     NOT NULL DEFAULT 0,
  data            JSONB       NOT NULL DEFAULT '{}',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted         BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_bowtie_barriers_diagram ON bowtie_barriers (diagram_id);
CREATE INDEX IF NOT EXISTS idx_bowtie_barriers_cause    ON bowtie_barriers (cause_id);
CREATE INDEX IF NOT EXISTS idx_bowtie_barriers_conseq   ON bowtie_barriers (consequence_id);

-- ─── Controls (کنترل‌های موانع — degradation / escalation factors) ───────────
CREATE TABLE IF NOT EXISTS bowtie_controls (
  id           TEXT        PRIMARY KEY,
  diagram_id   TEXT        NOT NULL REFERENCES bowtie_diagrams(id) ON DELETE CASCADE,
  barrier_id   TEXT        NOT NULL REFERENCES bowtie_barriers(id) ON DELETE CASCADE,
  description  TEXT        NOT NULL,
  control_type TEXT        NOT NULL DEFAULT 'Administrative',
  sort_order   INTEGER     NOT NULL DEFAULT 0,
  data         JSONB       NOT NULL DEFAULT '{}',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted      BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_bowtie_controls_diagram ON bowtie_controls (diagram_id);
CREATE INDEX IF NOT EXISTS idx_bowtie_controls_barrier ON bowtie_controls (barrier_id);
