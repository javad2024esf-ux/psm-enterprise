-- ════════════════════════════════════════════════════════════════════════════
-- 019_lopa_sil_determination.sql
--
-- هدف ۱: تعیین سطح SIL واقعی (IEC 61511) برای هر سناریوی LOPA — بر اساس
--         RRF مورد نیاز برای لایه SIS (Safety Instrumented System) پس از در
--         نظر گرفتن سهم سایر IPL های غیر-SIS، و RRF کسب‌شده از SIS تعریف‌شده.
--
-- هدف ۲: ماژول HAZOP در عمل از طریق فروشگاه عمومی "records" (element=
--         'HAZOP-Studies' / 'HAZOP-Deviations' ...) کار می‌کند، نه از طریق
--         جداول رابطه‌ای hazop_studies/hazop_deviations. FK سخت روی
--         hazop_study_id / hazop_deviation_id در lopa_studies/lopa_scenarios/
--         bowtie_diagrams باعث می‌شد اتصال HAZOP→LOPA→SIL از داخل UI واقعی با
--         خطای foreign key violation شکست بخورد. این migration آن FK ها را
--         حذف می‌کند؛ شناسه‌های متنی همچنان به‌عنوان مرجع متقابل بین ماژول‌ها
--         نگهداری می‌شوند، فقط دیگر در سطح دیتابیس enforce نمی‌شوند.
-- ════════════════════════════════════════════════════════════════════════════

BEGIN;

DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN
    SELECT con.conname, cl.relname AS tbl
    FROM pg_constraint con
    JOIN pg_class cl ON cl.oid = con.conrelid
    JOIN pg_attribute att ON att.attrelid = con.conrelid AND att.attnum = con.conkey[1]
    WHERE con.contype = 'f'
      AND cl.relname IN ('lopa_studies','lopa_scenarios','bowtie_diagrams')
      AND att.attname IN ('hazop_study_id','hazop_deviation_id','lopa_study_id')
  LOOP
    EXECUTE format('ALTER TABLE %I DROP CONSTRAINT %I', r.tbl, r.conname);
  END LOOP;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'lopa_scenarios') THEN
    ALTER TABLE lopa_scenarios ADD COLUMN IF NOT EXISTS required_rrf_sis NUMERIC(16,3);
    ALTER TABLE lopa_scenarios ADD COLUMN IF NOT EXISTS sil_required      TEXT;
    ALTER TABLE lopa_scenarios ADD COLUMN IF NOT EXISTS achieved_rrf_sis  NUMERIC(16,3);
    ALTER TABLE lopa_scenarios ADD COLUMN IF NOT EXISTS sil_achieved      TEXT;
    ALTER TABLE lopa_scenarios ADD COLUMN IF NOT EXISTS sil_gap_met       BOOLEAN NOT NULL DEFAULT FALSE;
    ALTER TABLE lopa_scenarios ADD COLUMN IF NOT EXISTS pfd_non_sis       NUMERIC(16,9);
    ALTER TABLE lopa_scenarios ADD COLUMN IF NOT EXISTS pfd_sis           NUMERIC(16,9);
    ALTER TABLE lopa_scenarios ADD COLUMN IF NOT EXISTS sif_tag           TEXT;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_lopa_scenarios_sil_required ON lopa_scenarios (sil_required);
CREATE INDEX IF NOT EXISTS idx_lopa_scenarios_sil_gap_met  ON lopa_scenarios (sil_gap_met);

INSERT INTO schema_migrations (version) VALUES ('019_lopa_sil_determination')
ON CONFLICT DO NOTHING;

COMMIT;
