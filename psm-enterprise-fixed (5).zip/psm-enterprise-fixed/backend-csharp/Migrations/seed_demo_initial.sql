
-- =========================================================
-- PSM-ERP Demo Seed Data - Initial Safe Version
-- Compatible with confirmed tables from:
--   backend/migrations/001_initial_schema.sql
--   backend/migrations/003a_workflow_core_tables.sql - workflow_definitions
--
-- Tables used:
--   users, settings, records, workflow_definitions,
--   notifications, documents, audit_log
--
-- Purpose:
--   Populate dashboard/action/workflow/PSM demo screens with realistic Persian demo data.
-- =========================================================

BEGIN;

-- ---------------------------------------------------------
-- 1) Demo users
-- NOTE:
-- password_hash values are placeholders. Login may require existing project's hash format.
-- Use existing admin user for login unless you replace hashes with valid generated ones.
-- ---------------------------------------------------------
INSERT INTO users (
  id, username, password_hash, full_name, email, role, department, unit, status,
  failed_attempts, mfa_enabled, must_change_password, created_at, last_login
) VALUES
  ('usr-demo-admin', 'demo.admin', '$demo_hash_replace_with_project_hash', 'مدیر سیستم دمو', 'demo.admin@arak-psm.local', 'Admin', 'مدیریت HSE', 'ستاد', 'Active', 0, FALSE, FALSE, NOW() - INTERVAL '90 days', NOW() - INTERVAL '2 hours'),
  ('usr-hse-manager', 'hse.manager', '$demo_hash_replace_with_project_hash', 'مدیر HSE', 'hse.manager@arak-psm.local', 'Manager', 'HSE', 'واحد ایمنی', 'Active', 0, FALSE, FALSE, NOW() - INTERVAL '80 days', NOW() - INTERVAL '1 day'),
  ('usr-process-eng', 'process.eng', '$demo_hash_replace_with_project_hash', 'کارشناس فرایند', 'process.eng@arak-psm.local', 'Engineer', 'مهندسی فرایند', 'الفین', 'Active', 0, FALSE, FALSE, NOW() - INTERVAL '70 days', NOW() - INTERVAL '3 days'),
  ('usr-maint-lead', 'maint.lead', '$demo_hash_replace_with_project_hash', 'سرپرست تعمیرات', 'maint.lead@arak-psm.local', 'Supervisor', 'تعمیرات', 'یوتیلیتی', 'Active', 0, FALSE, FALSE, NOW() - INTERVAL '60 days', NOW() - INTERVAL '5 days'),
  ('usr-operator', 'shift.operator', '$demo_hash_replace_with_project_hash', 'اپراتور شیفت', 'operator@arak-psm.local', 'Viewer', 'بهره‌برداری', 'پلیمر', 'Active', 0, FALSE, TRUE, NOW() - INTERVAL '45 days', NULL)
ON CONFLICT (id) DO UPDATE SET
  username = EXCLUDED.username,
  full_name = EXCLUDED.full_name,
  email = EXCLUDED.email,
  role = EXCLUDED.role,
  department = EXCLUDED.department,
  unit = EXCLUDED.unit,
  status = EXCLUDED.status,
  last_login = EXCLUDED.last_login;

-- ---------------------------------------------------------
-- 2) Application/demo settings
-- ---------------------------------------------------------
INSERT INTO settings (key, value, updated_at) VALUES
  ('company.name', 'مجتمع پتروشیمی اراک', NOW()),
  ('company.demo_mode', 'true', NOW()),
  ('dashboard.scope.default', 'whole_company', NOW()),
  ('psm.demo.seed.version', '2026-06-18.initial', NOW()),
  ('ui.locale', 'fa-IR', NOW()),
  ('ui.direction', 'rtl', NOW())
ON CONFLICT (key) DO UPDATE SET
  value = EXCLUDED.value,
  updated_at = NOW();

-- ---------------------------------------------------------
-- 3) Workflow definitions
-- Confirmed table: workflow_definitions
-- ---------------------------------------------------------
INSERT INTO workflow_definitions (
  id, name, module, version, config, is_active, created_by, created_at, updated_at
) VALUES
  (
    'wf-def-moc-approval-v1',
    'گردش‌کار تصویب تغییرات MOC',
    'moc',
    1,
    '{
      "title": "MOC Approval Workflow",
      "slaHours": 72,
      "steps": [
        {"key": "draft", "title": "ثبت اولیه", "role": "Engineer"},
        {"key": "hse_review", "title": "بازبینی HSE", "role": "Manager", "slaHours": 24},
        {"key": "process_review", "title": "بازبینی فرایندی", "role": "Engineer", "slaHours": 24},
        {"key": "approval", "title": "تصویب نهایی", "role": "Admin", "slaHours": 24}
      ],
      "demoInstances": 3
    }'::jsonb,
    TRUE,
    'usr-demo-admin',
    NOW() - INTERVAL '40 days',
    NOW() - INTERVAL '2 days'
  ),
  (
    'wf-def-action-closure-v1',
    'گردش‌کار بستن اقدامات اصلاحی',
    'action_register',
    1,
    '{
      "title": "Corrective Action Closure Workflow",
      "slaHours": 168,
      "steps": [
        {"key": "assigned", "title": "ارجاع به مسئول اقدام"},
        {"key": "evidence", "title": "ثبت شواهد انجام"},
        {"key": "verification", "title": "راستی‌آزمایی HSE"},
        {"key": "closed", "title": "اختتام"}
      ]
    }'::jsonb,
    TRUE,
    'usr-hse-manager',
    NOW() - INTERVAL '35 days',
    NOW() - INTERVAL '1 day'
  ),
  (
    'wf-def-pssr-v1',
    'گردش‌کار PSSR پیش از راه‌اندازی',
    'pssr',
    1,
    '{
      "title": "Pre Startup Safety Review",
      "slaHours": 120,
      "requiredChecklists": ["mechanical", "instrument", "process", "emergency", "training"]
    }'::jsonb,
    TRUE,
    'usr-demo-admin',
    NOW() - INTERVAL '30 days',
    NOW() - INTERVAL '4 days'
  )
ON CONFLICT (module, version) DO UPDATE SET
  name = EXCLUDED.name,
  config = EXCLUDED.config,
  is_active = EXCLUDED.is_active,
  updated_at = NOW();

-- ---------------------------------------------------------
-- 4) Records: dashboard/action register/HSE modules
-- Confirmed flexible table: records(collection, unit, status, data jsonb)
-- ---------------------------------------------------------
INSERT INTO records (
  id, collection, unit, status, data, created_at, updated_at, created_by, deleted
) VALUES

-- -------------------------
-- Action Register records
-- -------------------------
('rec-act-001', 'actions', 'الفین', 'Open', '{
  "title": "تعویض گیج فشار معیوب روی خط خوراک C2",
  "code": "ACT-1403-001",
  "origin": "HAZOP",
  "priority": "Critical",
  "riskLevel": "High",
  "owner": "سرپرست تعمیرات",
  "ownerUserId": "usr-maint-lead",
  "dueDate": "2026-06-12",
  "progress": 35,
  "overdue": true,
  "module": "HAZOP/HIRA",
  "unit": "الفین",
  "description": "در بازبینی HAZOP، عدم اطمینان از صحت قرائت فشار به‌عنوان عامل تشدیدکننده شناسایی شد."
}'::jsonb, NOW() - INTERVAL '20 days', NOW() - INTERVAL '2 days', 'usr-process-eng', FALSE),

('rec-act-002', 'actions', 'یوتیلیتی', 'In Progress', '{
  "title": "بازنگری دستورالعمل ایزولاسیون انرژی LOTO",
  "code": "ACT-1403-002",
  "origin": "Audit",
  "priority": "High",
  "riskLevel": "Medium",
  "owner": "مدیر HSE",
  "ownerUserId": "usr-hse-manager",
  "dueDate": "2026-06-25",
  "progress": 60,
  "overdue": false,
  "module": "Operating Procedures",
  "unit": "یوتیلیتی"
}'::jsonb, NOW() - INTERVAL '18 days', NOW() - INTERVAL '1 day', 'usr-hse-manager', FALSE),

('rec-act-003', 'actions', 'پلیمر', 'Open', '{
  "title": "تکمیل آموزش واکنش در شرایط اضطراری برای شیفت B",
  "code": "ACT-1403-003",
  "origin": "Training",
  "priority": "Medium",
  "riskLevel": "Medium",
  "owner": "اپراتور شیفت",
  "ownerUserId": "usr-operator",
  "dueDate": "2026-07-05",
  "progress": 10,
  "overdue": false,
  "module": "Training",
  "unit": "پلیمر"
}'::jsonb, NOW() - INTERVAL '15 days', NOW() - INTERVAL '3 days', 'usr-hse-manager', FALSE),

('rec-act-004', 'actions', 'آروماتیک', 'Closed', '{
  "title": "نصب برچسب‌های هشدار مواد شیمیایی روی مخازن",
  "code": "ACT-1403-004",
  "origin": "Inspection",
  "priority": "Low",
  "riskLevel": "Low",
  "owner": "واحد بهره‌برداری",
  "dueDate": "2026-06-01",
  "progress": 100,
  "overdue": false,
  "closedAt": "2026-05-30",
  "module": "PSI",
  "unit": "آروماتیک"
}'::jsonb, NOW() - INTERVAL '28 days', NOW() - INTERVAL '15 days', 'usr-operator', FALSE),

('rec-act-005', 'actions', 'الفین', 'Open', '{
  "title": "کالیبراسیون سنسورهای گاز قابل اشتعال در ناحیه کمپرسورها",
  "code": "ACT-1403-005",
  "origin": "Incident Investigation",
  "priority": "Critical",
  "riskLevel": "High",
  "owner": "سرپرست تعمیرات",
  "ownerUserId": "usr-maint-lead",
  "dueDate": "2026-06-10",
  "progress": 20,
  "overdue": true,
  "module": "Incident",
  "unit": "الفین"
}'::jsonb, NOW() - INTERVAL '12 days', NOW() - INTERVAL '1 day', 'usr-hse-manager', FALSE),

-- -------------------------
-- HAZOP records
-- -------------------------
('rec-hazop-001', 'hazop', 'الفین', 'Open', '{
  "studyNo": "HZP-OL-1403-01",
  "title": "مطالعه HAZOP واحد الفین - بخش کمپرسور خوراک",
  "node": "Feed Compressor K-101",
  "deviation": "فشار بالا",
  "guideword": "More Pressure",
  "cause": "بسته شدن شیر خروجی یا خرابی کنترلر فشار",
  "consequence": "افزایش فشار، فعال شدن PSV، احتمال توقف اضطراری واحد",
  "safeguards": ["PSV نصب شده", "آلارم فشار بالا", "Interlock توقف کمپرسور"],
  "recommendations": ["تست عملکردی interlock", "بازنگری set point آلارم"],
  "riskBefore": "High",
  "riskAfter": "Medium",
  "status": "In Review",
  "leader": "کارشناس فرایند"
}'::jsonb, NOW() - INTERVAL '32 days', NOW() - INTERVAL '2 days', 'usr-process-eng', FALSE),

('rec-hazop-002', 'hazop', 'پلیمر', 'Approved', '{
  "studyNo": "HZP-PL-1403-02",
  "title": "مطالعه HAZOP راکتور پلیمریزاسیون",
  "node": "Polymer Reactor R-220",
  "deviation": "دمای بالا",
  "guideword": "More Temperature",
  "cause": "کاهش دبی آب خنک‌کننده یا واکنش runaway",
  "consequence": "افزایش فشار راکتور و افت کیفیت محصول",
  "safeguards": ["سیستم خنک‌کننده اضطراری", "Trip دمای بالا"],
  "recommendations": ["مانور عملیاتی کنترل runaway"],
  "riskBefore": "Critical",
  "riskAfter": "Medium",
  "status": "Approved",
  "leader": "مدیر HSE"
}'::jsonb, NOW() - INTERVAL '50 days', NOW() - INTERVAL '10 days', 'usr-hse-manager', FALSE),

-- -------------------------
-- HIRA records
-- -------------------------
('rec-hira-001', 'hira', 'یوتیلیتی', 'Open', '{
  "assessmentNo": "HIRA-UT-1403-01",
  "activity": "تعمیر پمپ آب آتش‌نشانی",
  "hazard": "راه‌اندازی ناخواسته تجهیز هنگام تعمیرات",
  "existingControls": ["مجوز کار", "LOTO", "ناظر ایمنی"],
  "likelihood": 3,
  "severity": 5,
  "riskScore": 15,
  "riskLevel": "High",
  "requiredAction": "بازآموزی LOTO برای تیم تعمیرات",
  "responsible": "سرپرست تعمیرات"
}'::jsonb, NOW() - INTERVAL '19 days', NOW() - INTERVAL '2 days', 'usr-maint-lead', FALSE),

('rec-hira-002', 'hira', 'آروماتیک', 'Approved', '{
  "assessmentNo": "HIRA-AR-1403-02",
  "activity": "نمونه‌برداری از مخزن حلال",
  "hazard": "تماس پوستی/تنفسی با بخارات آلی",
  "existingControls": ["ماسک مناسب", "دستکش ضدحلال", "دوش و چشم‌شوی اضطراری"],
  "likelihood": 2,
  "severity": 4,
  "riskScore": 8,
  "riskLevel": "Medium",
  "requiredAction": "کنترل دوره‌ای PPE",
  "responsible": "HSE"
}'::jsonb, NOW() - INTERVAL '25 days', NOW() - INTERVAL '8 days', 'usr-hse-manager', FALSE),

-- -------------------------
-- PSI records
-- -------------------------
('rec-psi-001', 'psi', 'الفین', 'Approved', '{
  "docNo": "PSI-PID-OL-001",
  "title": "P&ID به‌روز شده واحد الفین",
  "category": "P&ID",
  "revision": "Rev. 4",
  "ownerDepartment": "مهندسی فرایند",
  "lastReviewDate": "2026-05-20",
  "nextReviewDate": "2027-05-20",
  "completeness": 92,
  "status": "Approved"
}'::jsonb, NOW() - INTERVAL '60 days', NOW() - INTERVAL '12 days', 'usr-process-eng', FALSE),

('rec-psi-002', 'psi', 'پلیمر', 'In Review', '{
  "docNo": "PSI-SDS-PL-014",
  "title": "SDS مواد افزودنی پلیمری",
  "category": "SDS",
  "revision": "Rev. 2",
  "ownerDepartment": "HSE",
  "lastReviewDate": "2026-04-10",
  "nextReviewDate": "2026-10-10",
  "completeness": 78,
  "status": "In Review"
}'::jsonb, NOW() - INTERVAL '55 days', NOW() - INTERVAL '5 days', 'usr-hse-manager', FALSE),

-- -------------------------
-- PSSR records
-- -------------------------
('rec-pssr-001', 'pssr', 'یوتیلیتی', 'Approved', '{
  "pssrNo": "PSSR-UT-1403-01",
  "title": "راه‌اندازی پمپ جدید آب آتش‌نشانی",
  "system": "Fire Water Pump P-901B",
  "checklistCompletion": 100,
  "approvedBy": "مدیر HSE",
  "approvalDate": "2026-05-28",
  "openPunchItems": 0,
  "status": "Approved"
}'::jsonb, NOW() - INTERVAL '35 days', NOW() - INTERVAL '18 days', 'usr-hse-manager', FALSE),

('rec-pssr-002', 'pssr', 'الفین', 'Open', '{
  "pssrNo": "PSSR-OL-1403-02",
  "title": "راه‌اندازی مجدد کمپرسور K-101 پس از تعمیرات اساسی",
  "system": "Feed Compressor K-101",
  "checklistCompletion": 65,
  "openPunchItems": 4,
  "criticalPunchItems": 1,
  "status": "Open"
}'::jsonb, NOW() - INTERVAL '10 days', NOW() - INTERVAL '1 day', 'usr-maint-lead', FALSE),

-- -------------------------
-- Incidents
-- -------------------------
('rec-inc-001', 'incidents', 'الفین', 'Open', '{
  "incidentNo": "INC-1403-001",
  "title": "نشتی جزئی گاز در فلنج مسیر برگشت کمپرسور",
  "date": "2026-06-02",
  "severity": "Medium",
  "type": "Near Miss",
  "immediateCause": "شل بودن پیچ‌های فلنج پس از تعمیرات",
  "rootCause": "کنترل ناکافی torque پس از بستن فلنج",
  "status": "Investigation",
  "actionsCreated": 2,
  "daysWithoutIncidentImpact": false
}'::jsonb, NOW() - INTERVAL '16 days', NOW() - INTERVAL '3 days', 'usr-operator', FALSE),

('rec-inc-002', 'incidents', 'پلیمر', 'Closed', '{
  "incidentNo": "INC-1403-002",
  "title": "لغزش اپراتور در سکوی دسترسی",
  "date": "2026-05-12",
  "severity": "Low",
  "type": "First Aid",
  "immediateCause": "وجود روغن روی کف سکو",
  "rootCause": "ضعف housekeeping",
  "status": "Closed",
  "actionsCreated": 1
}'::jsonb, NOW() - INTERVAL '38 days', NOW() - INTERVAL '20 days', 'usr-hse-manager', FALSE),

-- -------------------------
-- Training / Competency
-- -------------------------
('rec-trn-001', 'training', 'الفین', 'Completed', '{
  "courseCode": "TRN-PSM-001",
  "title": "مبانی مدیریت ایمنی فرایند PSM",
  "targetGroup": "کارشناسان و سرپرستان",
  "participants": 28,
  "completed": 25,
  "completionRate": 89,
  "instructor": "مدیر HSE",
  "date": "2026-05-25",
  "status": "Completed"
}'::jsonb, NOW() - INTERVAL '45 days', NOW() - INTERVAL '24 days', 'usr-hse-manager', FALSE),

('rec-trn-002', 'training', 'یوتیلیتی', 'Open', '{
  "courseCode": "TRN-LOTO-002",
  "title": "ایزولاسیون انرژی و LOTO",
  "targetGroup": "تعمیرات و بهره‌برداری",
  "participants": 22,
  "completed": 14,
  "completionRate": 64,
  "plannedDate": "2026-06-30",
  "status": "Open"
}'::jsonb, NOW() - INTERVAL '14 days', NOW() - INTERVAL '2 days', 'usr-maint-lead', FALSE),

-- -------------------------
-- Permits / PTW
-- -------------------------
('rec-ptw-001', 'permits', 'الفین', 'Active', '{
  "permitNo": "PTW-1403-044",
  "type": "Hot Work",
  "title": "جوشکاری ساپورت خط بخار در ناحیه کمپرسور",
  "area": "K-101 Platform",
  "issuer": "اپراتور شیفت",
  "validFrom": "2026-06-18T08:00:00+03:30",
  "validTo": "2026-06-18T18:00:00+03:30",
  "gasTestRequired": true,
  "status": "Active"
}'::jsonb, NOW() - INTERVAL '6 hours', NOW() - INTERVAL '1 hour', 'usr-operator', FALSE),

('rec-ptw-002', 'permits', 'یوتیلیتی', 'Active', '{
  "permitNo": "PTW-1403-045",
  "type": "Confined Space",
  "title": "بازرسی داخلی مخزن ذخیره آب DM",
  "area": "DM Water Tank",
  "issuer": "مدیر HSE",
  "validFrom": "2026-06-18T07:00:00+03:30",
  "validTo": "2026-06-18T16:00:00+03:30",
  "gasTestRequired": true,
  "standbyRequired": true,
  "status": "Active"
}'::jsonb, NOW() - INTERVAL '7 hours', NOW() - INTERVAL '30 minutes', 'usr-hse-manager', FALSE),

-- -------------------------
-- Audits / Management review / RBPS gap
-- -------------------------
('rec-aud-001', 'audits', 'کل شرکت', 'Open', '{
  "auditNo": "AUD-RBPS-1403-01",
  "title": "ممیزی داخلی RBPS - فصل اول",
  "scope": "Whole Company",
  "nonConformities": 6,
  "majorNC": 1,
  "minorNC": 5,
  "completion": 72,
  "status": "Open"
}'::jsonb, NOW() - INTERVAL '22 days', NOW() - INTERVAL '2 days', 'usr-demo-admin', FALSE),

('rec-rbps-001', 'rbps_gap', 'کل شرکت', 'In Progress', '{
  "assessmentNo": "RBPS-GAP-1403-Q1",
  "title": "تحلیل شکاف عناصر RBPS",
  "overallCompliance": 68,
  "elements": {
    "processSafetyCulture": 74,
    "complianceWithStandards": 61,
    "processSafetyCompetency": 70,
    "workforceInvolvement": 66,
    "processKnowledgeManagement": 72,
    "hazardIdentification": 63,
    "operatingProcedures": 69,
    "safeWorkPractices": 75,
    "assetIntegrity": 58,
    "managementOfChange": 64,
    "incidentInvestigation": 71,
    "emergencyManagement": 67
  },
  "status": "In Progress"
}'::jsonb, NOW() - INTERVAL '30 days', NOW() - INTERVAL '1 day', 'usr-demo-admin', FALSE),

-- -------------------------
-- Workflow instance-like demo records in records table
-- Useful if UI derives workflow cards from records API
-- -------------------------
('rec-wfi-001', 'workflow_instances', 'الفین', 'Active', '{
  "workflowDefinitionId": "wf-def-moc-approval-v1",
  "instanceNo": "WF-MOC-1403-001",
  "title": "تغییر set point آلارم فشار کمپرسور K-101",
  "module": "moc",
  "currentStep": "hse_review",
  "currentStepTitle": "بازبینی HSE",
  "slaDueAt": "2026-06-20T12:00:00+03:30",
  "slaStatus": "On Track",
  "requestedBy": "کارشناس فرایند",
  "assignedTo": "مدیر HSE",
  "progress": 45,
  "status": "Active"
}'::jsonb, NOW() - INTERVAL '4 days', NOW() - INTERVAL '5 hours', 'usr-process-eng', FALSE),

('rec-wfi-002', 'workflow_instances', 'یوتیلیتی', 'Delayed', '{
  "workflowDefinitionId": "wf-def-action-closure-v1",
  "instanceNo": "WF-ACT-1403-002",
  "title": "اختتام اقدام بازنگری LOTO",
  "module": "action_register",
  "currentStep": "verification",
  "currentStepTitle": "راستی‌آزمایی HSE",
  "slaDueAt": "2026-06-15T16:00:00+03:30",
  "slaStatus": "Violated",
  "requestedBy": "سرپرست تعمیرات",
  "assignedTo": "مدیر HSE",
  "progress": 80,
  "status": "Delayed"
}'::jsonb, NOW() - INTERVAL '9 days', NOW() - INTERVAL '1 day', 'usr-maint-lead', FALSE),

('rec-wfi-003', 'workflow_instances', 'الفین', 'Awaiting Approval', '{
  "workflowDefinitionId": "wf-def-pssr-v1",
  "instanceNo": "WF-PSSR-1403-003",
  "title": "تأیید PSSR راه‌اندازی K-101",
  "module": "pssr",
  "currentStep": "approval",
  "currentStepTitle": "تصویب نهایی",
  "slaDueAt": "2026-06-21T10:00:00+03:30",
  "slaStatus": "On Track",
  "requestedBy": "سرپرست تعمیرات",
  "assignedTo": "مدیر سیستم دمو",
  "progress": 90,
  "status": "Awaiting Approval"
}'::jsonb, NOW() - INTERVAL '5 days', NOW() - INTERVAL '2 hours', 'usr-maint-lead', FALSE),

-- -------------------------
-- Assets / Mechanical integrity
-- -------------------------
('rec-asset-001', 'assets', 'الفین', 'Critical', '{
  "assetTag": "K-101",
  "title": "کمپرسور خوراک واحد الفین",
  "assetType": "Compressor",
  "criticality": "Critical",
  "inspectionDueDate": "2026-07-10",
  "lastInspectionDate": "2026-01-10",
  "integrityStatus": "Attention Required",
  "openFindings": 2
}'::jsonb, NOW() - INTERVAL '70 days', NOW() - INTERVAL '6 days', 'usr-maint-lead', FALSE),

('rec-asset-002', 'assets', 'یوتیلیتی', 'Normal', '{
  "assetTag": "P-901B",
  "title": "پمپ آب آتش‌نشانی رزرو",
  "assetType": "Fire Water Pump",
  "criticality": "High",
  "inspectionDueDate": "2026-08-01",
  "lastInspectionDate": "2026-05-01",
  "integrityStatus": "Healthy",
  "openFindings": 0
}'::jsonb, NOW() - INTERVAL '65 days', NOW() - INTERVAL '10 days', 'usr-maint-lead', FALSE)

ON CONFLICT (id) DO UPDATE SET
  collection = EXCLUDED.collection,
  unit = EXCLUDED.unit,
  status = EXCLUDED.status,
  data = EXCLUDED.data,
  updated_at = NOW(),
  created_by = EXCLUDED.created_by,
  deleted = FALSE;

-- ---------------------------------------------------------
-- 5) Documents
-- ---------------------------------------------------------
INSERT INTO documents (
  id, name, module, tags, file_path, file_size, mime_type, created_by, created_at
) VALUES
  ('doc-psi-pid-001', 'P&ID واحد الفین - Rev.4', 'PSI', ARRAY['PSI','P&ID','الفین'], '/demo/docs/psi_pid_olefin_rev4.pdf', 2457600, 'application/pdf', 'usr-process-eng', NOW() - INTERVAL '20 days'),
  ('doc-hazop-report-001', 'گزارش HAZOP کمپرسور K-101', 'HAZOP', ARRAY['HAZOP','K-101','Risk'], '/demo/docs/hazop_k101_report.pdf', 1843200, 'application/pdf', 'usr-hse-manager', NOW() - INTERVAL '12 days'),
  ('doc-loto-procedure-001', 'دستورالعمل LOTO - نسخه بازنگری شده', 'Operating Procedures', ARRAY['LOTO','Procedure','Maintenance'], '/demo/docs/loto_procedure_rev2.docx', 860000, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'usr-maint-lead', NOW() - INTERVAL '6 days'),
  ('doc-training-psm-001', 'اسلاید آموزشی مبانی PSM', 'Training', ARRAY['Training','PSM','Persian'], '/demo/docs/psm_training_intro.pdf', 3300000, 'application/pdf', 'usr-hse-manager', NOW() - INTERVAL '18 days')
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  module = EXCLUDED.module,
  tags = EXCLUDED.tags,
  file_path = EXCLUDED.file_path,
  file_size = EXCLUDED.file_size,
  mime_type = EXCLUDED.mime_type;

-- ---------------------------------------------------------
-- 6) Notifications
-- ---------------------------------------------------------
INSERT INTO notifications (
  id, user_id, type, title, message, module, record_id, is_read, created_at
) VALUES
  ('notif-001', 'usr-hse-manager', 'warning', 'اقدام بحرانی معوق شده است', 'اقدام ACT-1403-001 مربوط به گیج فشار K-101 از موعد مقرر عبور کرده است.', 'Action Register', 'rec-act-001', FALSE, NOW() - INTERVAL '2 hours'),
  ('notif-002', 'usr-maint-lead', 'info', 'گردش‌کار جدید به شما ارجاع شد', 'اختتام اقدام بازنگری LOTO برای راستی‌آزمایی ارسال شده است.', 'Workflow', 'rec-wfi-002', FALSE, NOW() - INTERVAL '5 hours'),
  ('notif-003', 'usr-demo-admin', 'approval', 'در انتظار تصویب PSSR', 'PSSR راه‌اندازی کمپرسور K-101 در مرحله تصویب نهایی قرار دارد.', 'PSSR', 'rec-wfi-003', FALSE, NOW() - INTERVAL '1 day'),
  ('notif-004', 'usr-process-eng', 'success', 'مطالعه HAZOP ثبت شد', 'مطالعه HAZOP واحد الفین با موفقیت در سیستم ثبت شد.', 'HAZOP', 'rec-hazop-001', TRUE, NOW() - INTERVAL '4 days'),
  ('notif-005', 'usr-operator', 'training', 'یادآوری دوره آموزشی', 'دوره LOTO برای شیفت شما تا پایان ماه برنامه‌ریزی شده است.', 'Training', 'rec-trn-002', FALSE, NOW() - INTERVAL '1 day')
ON CONFLICT (id) DO UPDATE SET
  user_id = EXCLUDED.user_id,
  type = EXCLUDED.type,
  title = EXCLUDED.title,
  message = EXCLUDED.message,
  module = EXCLUDED.module,
  record_id = EXCLUDED.record_id,
  is_read = EXCLUDED.is_read;

-- ---------------------------------------------------------
-- 7) Audit log
-- ---------------------------------------------------------
INSERT INTO audit_log (
  id, user_id, action, module, description, timestamp
) VALUES
  ('audit-001', 'usr-demo-admin', 'DEMO_SEED_APPLIED', 'System', 'دیتای دمو اولیه برای ارائه محصول بارگذاری شد.', NOW()),
  ('audit-002', 'usr-hse-manager', 'CREATE_RECORD', 'HAZOP', 'ثبت مطالعه HAZOP کمپرسور K-101', NOW() - INTERVAL '12 days'),
  ('audit-003', 'usr-maint-lead', 'UPDATE_ACTION', 'Action Register', 'به‌روزرسانی پیشرفت اقدام ACT-1403-002', NOW() - INTERVAL '1 day'),
  ('audit-004', 'usr-process-eng', 'CREATE_WORKFLOW', 'Workflow', 'ایجاد گردش‌کار تغییر set point آلارم فشار', NOW() - INTERVAL '4 days'),
  ('audit-005', 'usr-hse-manager', 'APPROVE_PSSR', 'PSSR', 'تصویب PSSR پمپ آب آتش‌نشانی P-901B', NOW() - INTERVAL '18 days')
ON CONFLICT (id) DO UPDATE SET
  user_id = EXCLUDED.user_id,
  action = EXCLUDED.action,
  module = EXCLUDED.module,
  description = EXCLUDED.description,
  timestamp = EXCLUDED.timestamp;

COMMIT;

-- =========================================================
-- Quick verification queries
-- =========================================================
-- SELECT collection, status, COUNT(*) FROM records WHERE deleted = FALSE GROUP BY collection, status ORDER BY collection, status;
-- SELECT COUNT(*) AS open_actions FROM records WHERE collection = 'actions' AND status IN ('Open','In Progress');
-- SELECT COUNT(*) AS active_workflows FROM records WHERE collection = 'workflow_instances' AND status IN ('Active','Awaiting Approval','Delayed');
-- SELECT COUNT(*) AS unread_notifications FROM notifications WHERE is_read = FALSE;
