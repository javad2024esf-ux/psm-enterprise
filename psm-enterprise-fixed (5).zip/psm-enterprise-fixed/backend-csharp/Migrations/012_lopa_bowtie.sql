-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║  PSM Enterprise — Migration 012 : LOPA & BowTie Tables (PostgreSQL)     ║
-- ╚══════════════════════════════════════════════════════════════════════════╝

-- ─── LOPA Studies ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS lopa_studies (
  id                    TEXT        PRIMARY KEY,
  title                 TEXT        NOT NULL,
  hazop_study_id        TEXT,
  facility              TEXT,
  unit                  TEXT,
  lead_engineer         TEXT,
  status                TEXT        NOT NULL DEFAULT 'Draft',
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by            TEXT,
  deleted               BOOLEAN     NOT NULL DEFAULT FALSE,
  data                  JSONB       NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_lopa_studies_hazop_id ON lopa_studies (hazop_study_id);
CREATE INDEX IF NOT EXISTS idx_lopa_studies_status   ON lopa_studies (status);

-- ─── LOPA Scenarios ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS lopa_scenarios (
  id                      TEXT        PRIMARY KEY,
  lopa_study_id           TEXT        NOT NULL REFERENCES lopa_studies(id) ON DELETE CASCADE,
  hazop_deviation_id      TEXT,
  scenario_number         TEXT        NOT NULL,
  initiating_event        TEXT        NOT NULL,
  initiating_frequency    NUMERIC(12,6) NOT NULL DEFAULT 1,
  consequence_description TEXT,
  consequence_severity    INTEGER     NOT NULL DEFAULT 3 CHECK (consequence_severity BETWEEN 1 AND 5),
  target_risk             NUMERIC(12,9) NOT NULL DEFAULT 0.0001,
  residual_risk           NUMERIC(12,9),
  risk_gap                NUMERIC(12,9),
  risk_gap_met            BOOLEAN     GENERATED ALWAYS AS (
    CASE WHEN residual_risk IS NOT NULL AND target_risk IS NOT NULL
         THEN residual_risk <= target_risk
         ELSE FALSE
    END
  ) STORED,
  notes                   TEXT,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted                 BOOLEAN     NOT NULL DEFAULT FALSE,
  data                    JSONB       NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_lopa_scenarios_study   ON lopa_scenarios (lopa_study_id);
CREATE INDEX IF NOT EXISTS idx_lopa_scenarios_hazop   ON lopa_scenarios (hazop_deviation_id);

-- ─── LOPA IPLs (Independent Protection Layers) ───────────────────────────────
CREATE TABLE IF NOT EXISTS lopa_ipls (
  id                    TEXT        PRIMARY KEY,
  scenario_id           TEXT        NOT NULL REFERENCES lopa_scenarios(id) ON DELETE CASCADE,
  ipl_name              TEXT        NOT NULL,
  ipl_type              TEXT        NOT NULL DEFAULT 'Engineering',
  description           TEXT,
  pfd                   NUMERIC(10,6) NOT NULL DEFAULT 0.1 CHECK (pfd > 0 AND pfd <= 1),
  risk_reduction_factor NUMERIC(12,3) GENERATED ALWAYS AS (1.0 / NULLIF(pfd, 0)) STORED,
  is_validated          BOOLEAN     NOT NULL DEFAULT FALSE,
  owner                 TEXT,
  audit_interval        TEXT,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted               BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_lopa_ipls_scenario ON lopa_ipls (scenario_id);

-- ─── BowTie Diagrams ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bowtie_diagrams (
  id                TEXT        PRIMARY KEY,
  title             TEXT        NOT NULL,
  top_event         TEXT        NOT NULL,
  top_event_node    TEXT,
  hazard            TEXT,
  hazop_study_id    TEXT,
  hazop_deviation_id TEXT,
  lopa_study_id     TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by        TEXT,
  deleted           BOOLEAN     NOT NULL DEFAULT FALSE,
  data              JSONB       NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_bowtie_hazop_study ON bowtie_diagrams (hazop_study_id);
CREATE INDEX IF NOT EXISTS idx_bowtie_hazop_dev   ON bowtie_diagrams (hazop_deviation_id);
CREATE INDEX IF NOT EXISTS idx_bowtie_lopa        ON bowtie_diagrams (lopa_study_id);
