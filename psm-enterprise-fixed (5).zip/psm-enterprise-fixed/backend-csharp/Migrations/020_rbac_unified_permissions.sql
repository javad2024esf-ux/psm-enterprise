-- Migration 020: یکپارچه‌سازی RBAC — افزودن permissionهای جدید
-- این migration permissionهای لازم برای سیاست‌های جدید را اضافه می‌کند

-- ── AI-Platform ───────────────────────────────────────────────────────────────
-- Admin: همه دسترسی‌ها
INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES ('role_admin', 'AI-Platform', true, true, true, true)
ON CONFLICT (role_id, module) DO UPDATE
  SET can_read = true, can_write = true, can_approve = true, can_delete = true;

-- PSMManager: استفاده از AI (بدون admin/diagnose)
INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES ('role_psmmanager', 'AI-Platform', true, true, false, false)
ON CONFLICT (role_id, module) DO UPDATE
  SET can_read = true, can_write = true;

-- HSEManager: فقط خواندن/استفاده
INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES ('role_hsemanager', 'AI-Platform', true, true, false, false)
ON CONFLICT (role_id, module) DO UPDATE
  SET can_read = true, can_write = true;

-- ProcessEngineer: فقط خواندن/استفاده
INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES ('role_processengineer', 'AI-Platform', true, true, false, false)
ON CONFLICT (role_id, module) DO UPDATE
  SET can_read = true, can_write = true;

-- ── Audit ─────────────────────────────────────────────────────────────────────
-- Admin: همه دسترسی‌ها (can_approve = دسترسی به critical/full)
INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES ('role_admin', 'Audit', true, true, true, true)
ON CONFLICT (role_id, module) DO UPDATE
  SET can_read = true, can_write = true, can_approve = true, can_delete = true;

-- PSMManager: خواندن کامل + critical
INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES ('role_psmmanager', 'Audit', true, false, true, false)
ON CONFLICT (role_id, module) DO UPDATE
  SET can_read = true, can_approve = true;

-- HSEManager: خواندن کامل + critical
INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES ('role_hsemanager', 'Audit', true, false, true, false)
ON CONFLICT (role_id, module) DO UPDATE
  SET can_read = true, can_approve = true;

-- ProcessEngineer: فقط خواندن record history
INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES ('role_processengineer', 'Audit', true, false, false, false)
ON CONFLICT (role_id, module) DO UPDATE
  SET can_read = true;

-- ── Users ─────────────────────────────────────────────────────────────────────
-- Admin: همه دسترسی‌ها
INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES ('role_admin', 'Users', true, true, true, true)
ON CONFLICT (role_id, module) DO UPDATE
  SET can_read = true, can_write = true, can_approve = true, can_delete = true;

-- PSMManager: مدیریت کاربران (بدون حذف)
INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES ('role_psmmanager', 'Users', true, true, false, false)
ON CONFLICT (role_id, module) DO UPDATE
  SET can_read = true, can_write = true;

-- ── WORK_PERMIT — حذف ────────────────────────────────────────────────────────
-- Admin: همه دسترسی‌ها شامل حذف
INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES ('role_admin', 'WORK_PERMIT', true, true, true, true)
ON CONFLICT (role_id, module) DO UPDATE
  SET can_read = true, can_write = true, can_approve = true, can_delete = true;

-- PSMManager: approve + delete (بدون can_approve قبلی)
UPDATE role_permissions
SET can_delete = true
WHERE role_id = 'role_psmmanager' AND module = 'WORK_PERMIT';
