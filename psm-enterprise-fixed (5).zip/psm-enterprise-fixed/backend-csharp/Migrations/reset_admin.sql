-- ریست قفل حساب admin و اطمینان از وجود کاربر
-- این اسکریپت را مستقیماً در PostgreSQL اجرا کنید

-- ۱. ریست قفل و failed_attempts برای admin
UPDATE users 
SET failed_attempts = 0,
    locked_until = NULL,
    status = 'Active'
WHERE username = 'admin';

-- ۲. بررسی وضعیت (برای تأیید)
SELECT id, username, role, status, failed_attempts, locked_until, must_change_password
FROM users
WHERE username = 'admin';
