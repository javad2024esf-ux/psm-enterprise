-- 📁 Migrations/002_RolePermissions_EnterpriseRefactor.sql
-- ============================================================================
-- MIGRATION: RoleRepository Refactoring for Enterprise Compliance
-- 
-- CHANGES:
-- 1. Add is_system_role flag to roles table (SuperAdmin pattern)
-- 2. Add is_active soft-delete for compliance auditing
-- 3. Create role_audit_log table for permission change tracking
-- 4. Populate SuperAdmin and update existing system roles
-- 5. Add constraints to prevent unauthorized bypass behavior
--
-- EXECUTION TIME: ~5 seconds (no data migration needed)
-- ROLLBACK: Handled by reverting views/constraints, keeping historical data
-- ============================================================================

BEGIN TRANSACTION;

-- ┌──────────────────────────────────────────────────────────────────────────┐
-- │ PART 1: Extend roles table with enterprise features                      │
-- └──────────────────────────────────────────────────────────────────────────┘

-- Check if columns already exist (idempotent)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'roles' AND column_name = 'is_system_role'
    ) THEN
        ALTER TABLE roles ADD COLUMN is_system_role BOOLEAN NOT NULL DEFAULT FALSE;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'roles' AND column_name = 'is_active'
    ) THEN
        ALTER TABLE roles ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT TRUE;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'roles' AND column_name = 'description'
    ) THEN
        ALTER TABLE roles ADD COLUMN description TEXT;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'roles' AND column_name = 'created_at'
    ) THEN
        ALTER TABLE roles ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT NOW();
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'roles' AND column_name = 'updated_at'
    ) THEN
        ALTER TABLE roles ADD COLUMN updated_at TIMESTAMP;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'roles' AND column_name = 'updated_by'
    ) THEN
        ALTER TABLE roles ADD COLUMN updated_by VARCHAR(255);
    END IF;
END $$;

-- Add unique constraint on active roles (allow multiple soft-deleted)
CREATE UNIQUE INDEX IF NOT EXISTS roles_name_active_unique
ON roles (name) WHERE is_active = TRUE;

-- ┌──────────────────────────────────────────────────────────────────────────┐
-- │ PART 2: Create audit log table (critical for compliance)                 │
-- └──────────────────────────────────────────────────────────────────────────┘

CREATE TABLE IF NOT EXISTS role_audit_log (
    id SERIAL PRIMARY KEY,
    action VARCHAR(50) NOT NULL CHECK (action IN (
        'CREATE', 'UPDATE', 'DELETE', 
        'PERMISSION_GRANT', 'PERMISSION_REVOKE',
        'SUPERADMIN_BYPASS'
    )),
    role_name VARCHAR(255),
    target_user VARCHAR(255),  -- User affected by permission change
    changed_by VARCHAR(255) NOT NULL,
    details TEXT,  -- JSON or key=value format
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_role_audit_role ON role_audit_log(role_name);
CREATE INDEX IF NOT EXISTS idx_role_audit_changed_by ON role_audit_log(changed_by);
CREATE INDEX IF NOT EXISTS idx_role_audit_created ON role_audit_log(created_at);

-- ┌──────────────────────────────────────────────────────────────────────────┐
-- │ PART 3: Populate/update system roles                                     │
-- └──────────────────────────────────────────────────────────────────────────┘

-- Create SuperAdmin if it doesn't exist
INSERT INTO roles (id, name, label, description, is_system_role, is_active, created_at)
VALUES (
    1,
    'SuperAdmin',
    'سوپر ادمین',
    'Enterprise-wide administrator. Implicit permission bypass (audited).',
    TRUE,
    TRUE,
    NOW()
)
ON CONFLICT (id) DO UPDATE SET
    is_system_role = TRUE,
    label = EXCLUDED.label,
    description = 'Enterprise-wide administrator. Implicit permission bypass (audited).'
WHERE roles.name = 'SuperAdmin';

-- Mark existing system roles as system roles
UPDATE roles SET is_system_role = TRUE WHERE name IN ('PSMManager', 'Admin');

-- Add description for PSMManager (existing)
UPDATE roles 
SET description = 'Default manager role with read/write permissions (no bypass).'
WHERE name = 'PSMManager' AND description IS NULL;

-- ┌──────────────────────────────────────────────────────────────────────────┐
-- │ PART 4: Ensure role_permissions has proper constraints                   │
-- └──────────────────────────────────────────────────────────────────────────┘

-- Add timestamp if missing
ALTER TABLE role_permissions
ADD COLUMN IF NOT EXISTS created_at TIMESTAMP NOT NULL DEFAULT NOW();

-- Add unique constraint to prevent duplicate entries
ALTER TABLE role_permissions
ADD CONSTRAINT role_permissions_unique UNIQUE (role_id, module);

-- ┌──────────────────────────────────────────────────────────────────────────┐
-- │ PART 5: Create a view for compliance reporting                           │
-- └──────────────────────────────────────────────────────────────────────────┘

-- View: All active role permissions (for dashboards)
DROP VIEW IF EXISTS v_role_permissions CASCADE;
CREATE VIEW v_role_permissions AS
SELECT 
    rp.id,
    rp.role_id,
    r.name as role_name,
    r.is_system_role,
    rp.module,
    rp.can_read,
    rp.can_write,
    rp.can_approve,
    rp.can_delete,
    rp.created_at,
    CASE 
        WHEN r.is_system_role AND r.name = 'SuperAdmin' THEN 'BYPASS (SuperAdmin)'
        WHEN rp.can_read THEN 'READ'
        WHEN rp.can_write THEN 'WRITE'
        WHEN rp.can_approve THEN 'APPROVE'
        WHEN rp.can_delete THEN 'DELETE'
        ELSE 'NONE'
    END as permission_level
FROM role_permissions rp
INNER JOIN roles r ON r.id = rp.role_id
WHERE r.is_active = TRUE;

-- View: Audit trail for last 30 days
DROP VIEW IF EXISTS v_role_audit_recent CASCADE;
CREATE VIEW v_role_audit_recent AS
SELECT 
    id,
    action,
    role_name,
    target_user,
    changed_by,
    details,
    created_at,
    TO_CHAR(created_at, 'YYYY-MM-DD HH24:MI:SS') as formatted_date
FROM role_audit_log
WHERE created_at >= NOW() - INTERVAL '30 days'
ORDER BY created_at DESC;

-- ┌──────────────────────────────────────────────────────────────────────────┐
-- │ PART 6: Log the migration itself                                         │
-- └──────────────────────────────────────────────────────────────────────────┘

INSERT INTO role_audit_log (action, changed_by, details, created_at)
VALUES (
    'CREATE',
    'MIGRATION',
    'RoleRepository Enterprise Refactor - added SuperAdmin pattern, audit log',
    NOW()
);

COMMIT;

-- ┌──────────────────────────────────────────────────────────────────────────┐
-- │ VERIFICATION QUERIES                                                     │
-- └──────────────────────────────────────────────────────────────────────────┘

-- Run these to verify the migration:
/*

-- 1. Check roles table structure
SELECT column_name, data_type, is_nullable 
FROM information_schema.columns 
WHERE table_name = 'roles' 
ORDER BY ordinal_position;

-- 2. Verify system roles
SELECT id, name, is_system_role, is_active, description 
FROM roles 
WHERE is_system_role = TRUE 
ORDER BY name;

-- 3. Check audit log exists and is populated
SELECT COUNT(*) as audit_entries, action, MAX(created_at) as latest 
FROM role_audit_log 
GROUP BY action;

-- 4. Check for permission conflicts (should be 0)
SELECT role_id, module, COUNT(*) as duplicate_count
FROM role_permissions
GROUP BY role_id, module
HAVING COUNT(*) > 1;

-- 5. View recent permission activity
SELECT * FROM v_role_audit_recent LIMIT 10;

-- 6. List all current permissions (compliance report)
SELECT * FROM v_role_permissions ORDER BY role_name, module;

*/

-- ┌──────────────────────────────────────────────────────────────────────────┐
-- │ ROLLBACK PROCEDURE (if needed)                                           │
-- └──────────────────────────────────────────────────────────────────────────┘

/*
-- To rollback this migration:

BEGIN TRANSACTION;

-- Remove new views
DROP VIEW IF EXISTS v_role_audit_recent;
DROP VIEW IF EXISTS v_role_permissions;

-- Remove constraints
ALTER TABLE role_permissions DROP CONSTRAINT IF EXISTS role_permissions_unique;
DROP INDEX IF EXISTS roles_name_active_unique;

-- Remove new columns (keep audit log for compliance)
ALTER TABLE role_permissions DROP COLUMN IF EXISTS created_at;
ALTER TABLE roles DROP COLUMN IF EXISTS is_system_role;
ALTER TABLE roles DROP COLUMN IF EXISTS is_active;
ALTER TABLE roles DROP COLUMN IF EXISTS description;
ALTER TABLE roles DROP COLUMN IF EXISTS created_at;
ALTER TABLE roles DROP COLUMN IF EXISTS updated_at;
ALTER TABLE roles DROP COLUMN IF EXISTS updated_by;

-- The role_audit_log table is intentionally NOT dropped (compliance requirement)

COMMIT;
*/
