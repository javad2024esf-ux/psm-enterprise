-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║  PSM Enterprise — Migration 003a : Workflow Core Tables                ║
-- ║  این فایل باید قبل از 003 اجرا شود (ترتیب الفبایی تضمین می‌کند).      ║
-- ║  کل migration در یک DO block است تا با pg در Node.js کار کند.          ║
-- ╚══════════════════════════════════════════════════════════════════════════╝

DO $migration$
BEGIN

  -- ═══════════════════════════════════════════════════════════════════════
  -- جدول 1: تعریف Workflow‌ها
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS workflow_definitions (
    id            TEXT        PRIMARY KEY,
    name          TEXT        NOT NULL,
    module        TEXT        NOT NULL,
    version       INT         NOT NULL DEFAULT 1,
    config        JSONB       NOT NULL DEFAULT '{}',
    is_active     BOOLEAN     NOT NULL DEFAULT TRUE,
    created_by    TEXT        REFERENCES users(id),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(module, version)
  );

  CREATE INDEX IF NOT EXISTS idx_wf_def_module ON workflow_definitions(module);
  CREATE INDEX IF NOT EXISTS idx_wf_def_active ON workflow_definitions(is_active);

  -- ═══════════════════════════════════════════════════════════════════════
  -- جدول 2: حالت‌های Workflow
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS workflow_states (
    id            TEXT        PRIMARY KEY,
    workflow_id   TEXT        NOT NULL REFERENCES workflow_definitions(id) ON DELETE CASCADE,
    name          TEXT        NOT NULL,
    label         TEXT        NOT NULL,
    is_initial    BOOLEAN     NOT NULL DEFAULT FALSE,
    is_final      BOOLEAN     NOT NULL DEFAULT FALSE,
    sla_hours     INT,
    required_role TEXT,
    color         TEXT,
    metadata      JSONB       NOT NULL DEFAULT '{}',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(workflow_id, name)
  );

  CREATE INDEX IF NOT EXISTS idx_wf_state_wf   ON workflow_states(workflow_id);
  CREATE INDEX IF NOT EXISTS idx_wf_state_name ON workflow_states(name);

  -- ═══════════════════════════════════════════════════════════════════════
  -- جدول 3: انتقال‌های Workflow
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS workflow_transitions (
    id            TEXT        PRIMARY KEY,
    workflow_id   TEXT        NOT NULL REFERENCES workflow_definitions(id) ON DELETE CASCADE,
    from_state    TEXT        NOT NULL,
    to_state      TEXT        NOT NULL,
    action        TEXT        NOT NULL,
    label         TEXT,
    required_role TEXT,
    conditions    JSONB       NOT NULL DEFAULT '{}',
    metadata      JSONB       NOT NULL DEFAULT '{}',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE INDEX IF NOT EXISTS idx_wf_trans_wf   ON workflow_transitions(workflow_id);
  CREATE INDEX IF NOT EXISTS idx_wf_trans_from ON workflow_transitions(workflow_id, from_state);
  CREATE INDEX IF NOT EXISTS idx_wf_trans_act  ON workflow_transitions(action);

  -- ═══════════════════════════════════════════════════════════════════════
  -- جدول 4: نمونه‌های فعال Workflow
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS workflow_instances (
    id                  TEXT        PRIMARY KEY,
    record_id           TEXT        NOT NULL REFERENCES records(id) ON DELETE CASCADE,
    workflow_id         TEXT        NOT NULL REFERENCES workflow_definitions(id),
    collection          TEXT        NOT NULL,
    current_state       TEXT        NOT NULL,
    due_at              TIMESTAMPTZ,
    completed_at        TIMESTAMPTZ,
    escalation_policy   TEXT        NOT NULL DEFAULT 'Standard',
    form_schema         JSONB       NOT NULL DEFAULT '{}',
    conditional_routes  JSONB       NOT NULL DEFAULT '{}',
    metadata            JSONB       NOT NULL DEFAULT '{}',
    created_by          TEXT        REFERENCES users(id),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(record_id)
  );

  CREATE INDEX IF NOT EXISTS idx_wf_inst_record     ON workflow_instances(record_id);
  CREATE INDEX IF NOT EXISTS idx_wf_inst_wf         ON workflow_instances(workflow_id);
  CREATE INDEX IF NOT EXISTS idx_wf_inst_state      ON workflow_instances(current_state);
  CREATE INDEX IF NOT EXISTS idx_wf_inst_collection ON workflow_instances(collection);

  -- ═══════════════════════════════════════════════════════════════════════
  -- جدول 5: تاریخچه Workflow
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS workflow_history (
    id            TEXT        PRIMARY KEY,
    instance_id   TEXT        NOT NULL REFERENCES workflow_instances(id) ON DELETE CASCADE,
    action        TEXT        NOT NULL,
    from_state    TEXT,
    to_state      TEXT,
    comment       TEXT        NOT NULL DEFAULT '',
    performed_by  TEXT        NOT NULL REFERENCES users(id),
    performed_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    metadata      JSONB       NOT NULL DEFAULT '{}'
  );

  CREATE INDEX IF NOT EXISTS idx_wf_hist_inst   ON workflow_history(instance_id);
  CREATE INDEX IF NOT EXISTS idx_wf_hist_time   ON workflow_history(performed_at);
  CREATE INDEX IF NOT EXISTS idx_wf_hist_action ON workflow_history(action);
  CREATE INDEX IF NOT EXISTS idx_wf_hist_user   ON workflow_history(performed_by);

  -- ═══════════════════════════════════════════════════════════════════════
  -- Seed: تعریف‌های پیش‌فرض workflow برای هر ماژول
  -- ═══════════════════════════════════════════════════════════════════════
  INSERT INTO workflow_definitions (id, name, module, version, config, is_active) VALUES
    ('wfd_moc',      'مدیریت تغییر (MOC)',                    'MOC',      1, '{"initial_state":"Draft","sla_hours":240}'::jsonb,    true),
    ('wfd_hazop',    'مطالعه HAZOP',                          'HAZOP',    1, '{"initial_state":"Initiated","sla_hours":480}'::jsonb, true),
    ('wfd_incident', 'گزارش حوادث',                           'Incident', 1, '{"initial_state":"Reported","sla_hours":120}'::jsonb,  true),
    ('wfd_audit',    'ممیزی ایمنی',                           'Audit',    1, '{"initial_state":"Planned","sla_hours":336}'::jsonb,   true),
    ('wfd_pssr',     'بررسی ایمنی قبل از راه‌اندازی (PSSR)', 'PSSR',     1, '{"initial_state":"Initiated","sla_hours":72}'::jsonb,  true),
    ('wfd_default',  'جریان پیش‌فرض',                        'Default',  1, '{"initial_state":"Draft","sla_hours":168}'::jsonb,    true)
  ON CONFLICT (module, version) DO NOTHING;

  INSERT INTO schema_migrations (version) VALUES ('003a_workflow_core_tables')
    ON CONFLICT DO NOTHING;

END
$migration$;
