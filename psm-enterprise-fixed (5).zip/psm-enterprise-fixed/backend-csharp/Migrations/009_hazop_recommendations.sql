BEGIN;

CREATE TABLE IF NOT EXISTS hazop_recommendations (
  id                  TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  study_id            TEXT,
  deviation_id        TEXT,
  node_id             TEXT,
  recommendation_text TEXT        NOT NULL,
  owner               VARCHAR(100),
  priority            VARCHAR(50) DEFAULT 'Medium' CHECK (priority IN ('Low','Medium','High','Critical')),
  due_date            DATE,
  status              VARCHAR(50) DEFAULT 'Open' CHECK (status IN ('Open','In Progress','Pending Approval','Closed','On Hold')),
  approval_status     VARCHAR(50) DEFAULT 'Not Submitted' CHECK (approval_status IN ('Not Submitted','Pending','Approved','Rejected')),
  approver            VARCHAR(100),
  closure_evidence    TEXT,
  closure_date        DATE,
  completion_date     DATE,
  remarks             TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by          TEXT,
  updated_at          TIMESTAMPTZ,
  updated_by          TEXT
);

CREATE TABLE IF NOT EXISTS hazop_recommendation_updates (
  id                TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  recommendation_id TEXT,
  update_text       TEXT        NOT NULL,
  status_change     VARCHAR(50),
  updated_by        VARCHAR(100),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  attachments       TEXT
);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE table_name = 'hazop_recommendation_updates' AND constraint_name = 'fk_rec_update'
  ) THEN
    ALTER TABLE hazop_recommendation_updates ADD CONSTRAINT fk_rec_update
      FOREIGN KEY (recommendation_id) REFERENCES hazop_recommendations(id) ON DELETE CASCADE;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_studies') THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.table_constraints
      WHERE table_name = 'hazop_recommendations' AND constraint_name = 'fk_rec_study'
    ) THEN
      ALTER TABLE hazop_recommendations ADD CONSTRAINT fk_rec_study
        FOREIGN KEY (study_id) REFERENCES hazop_studies(id) ON DELETE CASCADE;
    END IF;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_deviations') THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.table_constraints
      WHERE table_name = 'hazop_recommendations' AND constraint_name = 'fk_rec_deviation'
    ) THEN
      ALTER TABLE hazop_recommendations ADD CONSTRAINT fk_rec_deviation
        FOREIGN KEY (deviation_id) REFERENCES hazop_deviations(id) ON DELETE CASCADE;
    END IF;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_nodes') THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.table_constraints
      WHERE table_name = 'hazop_recommendations' AND constraint_name = 'fk_rec_node'
    ) THEN
      ALTER TABLE hazop_recommendations ADD CONSTRAINT fk_rec_node
        FOREIGN KEY (node_id) REFERENCES hazop_nodes(id) ON DELETE SET NULL;
    END IF;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_recommendations_study     ON hazop_recommendations(study_id);
CREATE INDEX IF NOT EXISTS idx_recommendations_deviation ON hazop_recommendations(deviation_id);
CREATE INDEX IF NOT EXISTS idx_recommendations_owner     ON hazop_recommendations(owner);
CREATE INDEX IF NOT EXISTS idx_recommendations_status    ON hazop_recommendations(status);
CREATE INDEX IF NOT EXISTS idx_recommendations_approval  ON hazop_recommendations(approval_status);
CREATE INDEX IF NOT EXISTS idx_recommendations_due_date  ON hazop_recommendations(due_date);
CREATE INDEX IF NOT EXISTS idx_recommendations_closure   ON hazop_recommendations(closure_date);
CREATE INDEX IF NOT EXISTS idx_rec_updates_rec_id        ON hazop_recommendation_updates(recommendation_id);

INSERT INTO schema_migrations (version, applied_at)
VALUES ('009_hazop_recommendations', NOW())
ON CONFLICT DO NOTHING;

COMMIT;
