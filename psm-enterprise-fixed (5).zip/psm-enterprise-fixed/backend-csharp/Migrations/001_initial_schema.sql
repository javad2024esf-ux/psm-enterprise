-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║  PSM Enterprise — Migration 001 : Initial Schema (PostgreSQL)           ║
-- ╚══════════════════════════════════════════════════════════════════════════╝

-- ─── Extensions ──────────────────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "pgcrypto";      -- برای gen_random_uuid
CREATE EXTENSION IF NOT EXISTS "pg_trgm";       -- برای ایندکس LIKE سریع روی text

-- ─── جدول کاربران ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id                   TEXT        PRIMARY KEY,
  username             TEXT        UNIQUE NOT NULL,
  password_hash        TEXT        NOT NULL,
  full_name            TEXT        NOT NULL,
  email                TEXT,
  role                 TEXT        NOT NULL DEFAULT 'Viewer',
  department           TEXT,
  unit                 TEXT,
  status               TEXT        NOT NULL DEFAULT 'Active',
  failed_attempts      INT         NOT NULL DEFAULT 0,
  locked_until         TIMESTAMPTZ,
  mfa_enabled          BOOLEAN     NOT NULL DEFAULT FALSE,
  must_change_password BOOLEAN     NOT NULL DEFAULT FALSE,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_login           TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_users_username ON users (username);
CREATE INDEX IF NOT EXISTS idx_users_role     ON users (role);
CREATE INDEX IF NOT EXISTS idx_users_status   ON users (status);

-- ─── جدول رکوردهای عمومی (قلب PSM) ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS records (
  id            TEXT        PRIMARY KEY,
  collection    TEXT        NOT NULL,
  unit          TEXT,
  status        TEXT,
  data          JSONB       NOT NULL DEFAULT '{}',
  -- ستون tsvector برای full-text search
  search_vector TSVECTOR    GENERATED ALWAYS AS (
    to_tsvector(
      'simple',
      COALESCE(data::text, '')
    )
  ) STORED,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by    TEXT,
  deleted       BOOLEAN     NOT NULL DEFAULT FALSE
);

-- ایندکس‌های رایج
CREATE INDEX IF NOT EXISTS idx_records_collection ON records (collection);
CREATE INDEX IF NOT EXISTS idx_records_unit       ON records (collection, unit);
CREATE INDEX IF NOT EXISTS idx_records_status     ON records (collection, status);
CREATE INDEX IF NOT EXISTS idx_records_deleted    ON records (collection, deleted);
CREATE INDEX IF NOT EXISTS idx_records_created    ON records (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_records_composite  ON records (collection, unit, deleted);

-- ایندکس GIN برای full-text search
CREATE INDEX IF NOT EXISTS idx_records_fts  ON records USING GIN (search_vector);

-- ایندکس GIN برای کوئری‌های JSONB (@> و jsonpath)
CREATE INDEX IF NOT EXISTS idx_records_data ON records USING GIN (data jsonb_path_ops);

-- ─── Sessions ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sessions (
  token      TEXT        PRIMARY KEY,
  user_id    TEXT        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sessions_user    ON sessions (user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions (expires_at);

-- ─── Settings ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Audit Log ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_log (
  id          TEXT        PRIMARY KEY,
  user_id     TEXT,
  action      TEXT        NOT NULL,
  module      TEXT,
  description TEXT,
  timestamp   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_user      ON audit_log (user_id);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_log (timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_module    ON audit_log (module);

-- ─── Documents (metadata) ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS documents (
  id          TEXT        PRIMARY KEY,
  name        TEXT        NOT NULL,
  module      TEXT,
  tags        TEXT[],
  file_path   TEXT,
  file_size   BIGINT,
  mime_type   TEXT,
  created_by  TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_documents_module ON documents (module);
CREATE INDEX IF NOT EXISTS idx_documents_tags   ON documents USING GIN (tags);

-- ─── Notifications ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  id         TEXT        PRIMARY KEY,
  user_id    TEXT,
  type       TEXT,
  title      TEXT,
  message    TEXT,
  module     TEXT,
  record_id  TEXT,
  is_read    BOOLEAN     NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications (user_id, is_read);

-- ─── Migration Tracking ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS schema_migrations (
  version    TEXT        PRIMARY KEY,
  applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO schema_migrations (version) VALUES ('001_initial_schema')
  ON CONFLICT DO NOTHING;
