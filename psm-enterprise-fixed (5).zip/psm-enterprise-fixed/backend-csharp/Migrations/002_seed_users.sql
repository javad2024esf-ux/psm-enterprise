-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║  PSM Enterprise — Migration 002 : Seed Default Users                    ║
-- ╚══════════════════════════════════════════════════════════════════════════╝
-- ⚠  رمزهای پیش‌فرض درون migration ذخیره نمی‌شوند.
--    کاربران پایه (admin و ...) توسط seedUsers() در backend/migrate.cjs ساخته می‌شوند —
--    همان فایلی که این migration را هم اجرا می‌کند — و فقط وقتی هیچ کاربری وجود ندارد اجرا می‌شود.
--    کاربران دمو/نمایشی (برای ارائه) جدا هستند: backend/seed-demo-users.cjs (به‌صورت اختیاری،
--    فقط در محیط Docker تست/دمو با SEED_DEMO_DATA=true).
--    در هر دو مسیر، هش رمز فقط با hashPassword() از database.cjs انجام می‌شود؛ هرگز SQL دستی.

-- فقط ردیابی migration را ثبت کن؛ درج واقعی توسط seedUsers() در migrate.cjs انجام می‌شود.
INSERT INTO schema_migrations (version) VALUES ('002_seed_users')
  ON CONFLICT DO NOTHING;
