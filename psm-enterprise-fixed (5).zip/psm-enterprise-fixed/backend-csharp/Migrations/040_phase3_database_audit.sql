-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║  PSM Enterprise — Migration: Phase 3 Database Audit & Optimization     ║
-- ║  Purpose: Fix relationships, indexes, constraints, concurrency control  ║
-- ╚══════════════════════════════════════════════════════════════════════════╝

-- ─────────────────────────────────────────────────────────────────────────────
-- ► Phase 1: Add Row Version (Optimistic Concurrency Control) to All Tables
-- ─────────────────────────────────────────────────────────────────────────────

-- Add row_version to asset tables
ALTER TABLE psm_assets
ADD COLUMN IF NOT EXISTS row_version bytea DEFAULT '\x00'::bytea;

ALTER TABLE psm_process_units
ADD COLUMN IF NOT EXISTS row_version bytea DEFAULT '\x00'::bytea;

ALTER TABLE psm_hazards
ADD COLUMN IF NOT EXISTS row_version bytea DEFAULT '\x00'::bytea;

ALTER TABLE psm_scenarios
ADD COLUMN IF NOT EXISTS row_version bytea DEFAULT '\x00'::bytea;

ALTER TABLE psm_barriers
ADD COLUMN IF NOT EXISTS row_version bytea DEFAULT '\x00'::bytea;

ALTER TABLE psm_action_items
ADD COLUMN IF NOT EXISTS row_version bytea DEFAULT '\x00'::bytea;

ALTER TABLE psm_change_requests
ADD COLUMN IF NOT EXISTS row_version bytea DEFAULT '\x00'::bytea;

ALTER TABLE psm_documents
ADD COLUMN IF NOT EXISTS row_version bytea DEFAULT '\x00'::bytea;

ALTER TABLE psm_incidents
ADD COLUMN IF NOT EXISTS row_version bytea DEFAULT '\x00'::bytea;

ALTER TABLE psm_relationships
ADD COLUMN IF NOT EXISTS row_version bytea DEFAULT '\x00'::bytea;

ALTER TABLE psm_relationship_lineage
ADD COLUMN IF NOT EXISTS row_version bytea DEFAULT '\x00'::bytea IF NOT EXISTS;

ALTER TABLE psm_entity_references
ADD COLUMN IF NOT EXISTS row_version bytea DEFAULT '\x00'::bytea IF NOT EXISTS;

ALTER TABLE users
ADD COLUMN IF NOT EXISTS row_version bytea DEFAULT '\x00'::bytea;

-- ─────────────────────────────────────────────────────────────────────────────
-- ► Phase 2: Add Missing Foreign Key Indexes (Critical for Performance)
-- ─────────────────────────────────────────────────────────────────────────────

-- Process Unit FK indexes
CREATE INDEX IF NOT EXISTS idx_psm_assets_process_unit_id 
    ON psm_assets(process_unit_id) WHERE deleted = false;

-- Hazard FK indexes  
CREATE INDEX IF NOT EXISTS idx_psm_scenarios_hazard_fk 
    ON psm_scenarios(hazard_id) WHERE deleted = false;

-- Barrier FK indexes
CREATE INDEX IF NOT EXISTS idx_psm_barriers_process_unit_fk 
    ON psm_barriers(process_unit_id) WHERE deleted = false;

-- Action Item FK indexes
CREATE INDEX IF NOT EXISTS idx_psm_action_items_source 
    ON psm_action_items(source_module, source_id) WHERE deleted = false;

-- Document FK indexes
CREATE INDEX IF NOT EXISTS idx_psm_documents_module_created
    ON psm_documents(module, created_at DESC) WHERE deleted = false;

-- Incident FK indexes
CREATE INDEX IF NOT EXISTS idx_psm_incidents_affected_unit_fk 
    ON psm_incidents(affected_process_unit) WHERE deleted = false;

-- ─────────────────────────────────────────────────────────────────────────────
-- ► Phase 3: Fix Relationship Cascade Rules
-- ─────────────────────────────────────────────────────────────────────────────

-- Drop and recreate FK from hazard to process_unit (Restrict, not Cascade)
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'fk_hazards_process_units'
        AND table_name = 'psm_hazards'
    ) THEN
        ALTER TABLE psm_hazards DROP CONSTRAINT fk_hazards_process_units;
    END IF;
END $$;

ALTER TABLE psm_hazards
ADD CONSTRAINT fk_hazards_process_units 
    FOREIGN KEY (process_unit_id) 
    REFERENCES psm_process_units(id) 
    ON DELETE RESTRICT 
    ON UPDATE CASCADE;

-- Drop and recreate FK from scenario to hazard (Cascade)
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'fk_scenarios_hazards'
        AND table_name = 'psm_scenarios'
    ) THEN
        ALTER TABLE psm_scenarios DROP CONSTRAINT fk_scenarios_hazards;
    END IF;
END $$;

ALTER TABLE psm_scenarios
ADD CONSTRAINT fk_scenarios_hazards 
    FOREIGN KEY (hazard_id) 
    REFERENCES psm_hazards(id) 
    ON DELETE CASCADE 
    ON UPDATE CASCADE;

-- Drop and recreate FK from scenario to process_unit (Restrict)
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'fk_scenarios_process_units'
        AND table_name = 'psm_scenarios'
    ) THEN
        ALTER TABLE psm_scenarios DROP CONSTRAINT fk_scenarios_process_units;
    END IF;
END $$;

ALTER TABLE psm_scenarios
ADD CONSTRAINT fk_scenarios_process_units 
    FOREIGN KEY (process_unit_id) 
    REFERENCES psm_process_units(id) 
    ON DELETE RESTRICT 
    ON UPDATE CASCADE;

-- Ensure FK from relationship_changes to relationships
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'fk_rel_changes_relationships'
        AND table_name = 'psm_relationship_changes'
    ) THEN
        ALTER TABLE psm_relationship_changes
        ADD CONSTRAINT fk_rel_changes_relationships 
            FOREIGN KEY (relationship_id) 
            REFERENCES psm_relationships(id) 
            ON DELETE CASCADE 
            ON UPDATE CASCADE;
    END IF;
END $$;

-- ─────────────────────────────────────────────────────────────────────────────
-- ► Phase 4: Add Composite Indexes for Complex Queries (N+1 Prevention)
-- ─────────────────────────────────────────────────────────────────────────────

-- Asset queries with status and unit filtering
CREATE INDEX IF NOT EXISTS idx_psm_assets_unit_status_deleted
    ON psm_assets(unit, status, deleted) 
    WHERE deleted = false;

-- Hazard queries with unit and risk filtering
CREATE INDEX IF NOT EXISTS idx_psm_hazards_unit_risk_status
    ON psm_hazards(process_unit_id, risk_level, status)
    WHERE deleted = false;

-- Scenario queries by unit and risk
CREATE INDEX IF NOT EXISTS idx_psm_scenarios_unit_risk_status
    ON psm_scenarios(process_unit_id, risk_level, status)
    WHERE deleted = false;

-- Action item queries by owner and status
CREATE INDEX IF NOT EXISTS idx_psm_action_items_owner_status_due
    ON psm_action_items(owner, status, due_date)
    WHERE deleted = false;

-- Change request approval workflow
CREATE INDEX IF NOT EXISTS idx_psm_change_requests_approver_status
    ON psm_change_requests(approved_by, status, severity)
    WHERE deleted = false;

-- Document queries by module and archive status
CREATE INDEX IF NOT EXISTS idx_psm_documents_module_archive_type
    ON psm_documents(module, is_archived, document_type)
    WHERE deleted = false;

-- Incident investigation tracking
CREATE INDEX IF NOT EXISTS idx_psm_incidents_unit_status_date
    ON psm_incidents(affected_process_unit, status, incident_date DESC)
    WHERE deleted = false;

-- Relationship queries for graph traversal
CREATE INDEX IF NOT EXISTS idx_psm_relationships_bidirectional
    ON psm_relationships(source_entity_id, target_entity_id, status)
    WHERE deleted = false;

-- ─────────────────────────────────────────────────────────────────────────────
-- ► Phase 5: Add Partial Indexes for Soft Deletes (Query Optimization)
-- ─────────────────────────────────────────────────────────────────────────────

-- All entities - active records only indexes
CREATE INDEX IF NOT EXISTS idx_psm_assets_active
    ON psm_assets(id) 
    WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_psm_process_units_active
    ON psm_process_units(id) 
    WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_psm_hazards_active
    ON psm_hazards(id) 
    WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_psm_scenarios_active
    ON psm_scenarios(id) 
    WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_psm_barriers_active
    ON psm_barriers(id) 
    WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_psm_action_items_active
    ON psm_action_items(id) 
    WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_psm_change_requests_active
    ON psm_change_requests(id) 
    WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_psm_documents_active
    ON psm_documents(id) 
    WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_psm_incidents_active
    ON psm_incidents(id) 
    WHERE deleted = false;

CREATE INDEX IF NOT EXISTS idx_psm_relationships_active
    ON psm_relationships(id) 
    WHERE deleted = false;

-- ─────────────────────────────────────────────────────────────────────────────
-- ► Phase 6: Add Check Constraints for Data Integrity
-- ─────────────────────────────────────────────────────────────────────────────

-- Asset status constraint
ALTER TABLE psm_assets
ADD CONSTRAINT ck_psm_assets_status 
    CHECK (status IN ('Active', 'Inactive', 'In-Maintenance', 'Decommissioned'));

-- Process unit status constraint
ALTER TABLE psm_process_units
ADD CONSTRAINT ck_psm_process_units_status 
    CHECK (status IN ('Operating', 'Idle', 'Under-Maintenance', 'Decommissioned'));

-- Hazard severity constraint
ALTER TABLE psm_hazards
ADD CONSTRAINT ck_psm_hazards_severity 
    CHECK (severity IN ('Catastrophic', 'Critical', 'Major', 'Minor', NULL));

-- Scenario severity constraint
ALTER TABLE psm_scenarios
ADD CONSTRAINT ck_psm_scenarios_severity 
    CHECK (severity IN ('Minor', 'Moderate', 'Severe', 'Catastrophic', NULL));

-- Barrier type constraint
ALTER TABLE psm_barriers
ADD CONSTRAINT ck_psm_barriers_type 
    CHECK (barrier_type IN ('Prevention', 'Mitigation', 'Detection'));

-- Action item status constraint
ALTER TABLE psm_action_items
ADD CONSTRAINT ck_psm_action_items_status 
    CHECK (status IN ('Open', 'In-Progress', 'Completed', 'Closed'));

-- Action item priority constraint
ALTER TABLE psm_action_items
ADD CONSTRAINT ck_psm_action_items_priority 
    CHECK (priority IN ('High', 'Medium', 'Low'));

-- Change request status constraint
ALTER TABLE psm_change_requests
ADD CONSTRAINT ck_psm_change_requests_status 
    CHECK (status IN ('Proposed', 'Reviewed', 'Approved', 'Implemented', 'Closed'));

-- Change request severity constraint
ALTER TABLE psm_change_requests
ADD CONSTRAINT ck_psm_change_requests_severity 
    CHECK (severity IN ('Critical', 'Major', 'Minor'));

-- Document archive constraint
ALTER TABLE psm_documents
ADD CONSTRAINT ck_psm_documents_archive 
    CHECK (is_archived IN (true, false));

-- Incident type constraint
ALTER TABLE psm_incidents
ADD CONSTRAINT ck_psm_incidents_type 
    CHECK (incident_type IN ('Near-Miss', 'Lost-Time', 'Environmental', 'Property-Damage', 'Fatality'));

-- Incident severity constraint
ALTER TABLE psm_incidents
ADD CONSTRAINT ck_psm_incidents_severity 
    CHECK (severity IN ('Minor', 'Serious', 'Major', 'Catastrophic'));

-- Relationship direction constraint
ALTER TABLE psm_relationships
ADD CONSTRAINT ck_psm_relationships_direction 
    CHECK (direction IN ('OneWay', 'TwoWay'));

-- Relationship status constraint
ALTER TABLE psm_relationships
ADD CONSTRAINT ck_psm_relationships_status 
    CHECK (status IN ('Active', 'Dormant', 'Archived', 'Superseded'));

-- ─────────────────────────────────────────────────────────────────────────────
-- ► Phase 7: Update Migration Tracking
-- ─────────────────────────────────────────────────────────────────────────────

INSERT INTO schema_migrations (version) VALUES ('040_phase3_database_audit')
  ON CONFLICT (version) DO NOTHING;
