-- ════════════════════════════════════════════════════════════════════════════
-- 035_lopa_bowtie_integration.sql
--
-- Implements the LOPA → BowTie leg of the HAZOP → LOPA → BowTie chain.
--
-- Changes:
--   1. bowtie_causes        — add lopa_scenario_id (FK) so each threat node
--                             can trace back to the LOPA Scenario that spawned it.
--   2. bowtie_consequences  — add lopa_scenario_id (FK) + mitigated_frequency,
--                             target_risk, sil_required columns so risk values
--                             from LOPA flow directly into the BowTie consequence.
--   3. lopa_scenarios       — bowtie_diagram_id column was added in
--                             030_integrated_risk_model.sql; index guard only.
--
-- All ALTER TABLE statements are guarded with IF NOT EXISTS / ADD COLUMN IF NOT
-- EXISTS so this migration is safe to re-run.
-- ════════════════════════════════════════════════════════════════════════════

BEGIN;

-- ─── 1. bowtie_causes: trace the initiating-event threat to LOPA ─────────
ALTER TABLE bowtie_causes
  ADD COLUMN IF NOT EXISTS lopa_scenario_id TEXT
    REFERENCES lopa_scenarios(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_bowtie_causes_lopa_scenario
  ON bowtie_causes (lopa_scenario_id);

-- ─── 2. bowtie_consequences: carry LOPA risk values forward ──────────────
ALTER TABLE bowtie_consequences
  ADD COLUMN IF NOT EXISTS lopa_scenario_id   TEXT
    REFERENCES lopa_scenarios(id) ON DELETE SET NULL;

ALTER TABLE bowtie_consequences
  ADD COLUMN IF NOT EXISTS mitigated_frequency NUMERIC(18, 12);

ALTER TABLE bowtie_consequences
  ADD COLUMN IF NOT EXISTS target_risk         NUMERIC(18, 12);

ALTER TABLE bowtie_consequences
  ADD COLUMN IF NOT EXISTS sil_required        TEXT;

CREATE INDEX IF NOT EXISTS idx_bowtie_consequences_lopa_scenario
  ON bowtie_consequences (lopa_scenario_id);

-- ─── 3. Guard index on lopa_scenarios.bowtie_diagram_id (idempotent) ─────
CREATE INDEX IF NOT EXISTS idx_lopa_scenarios_bowtie
  ON lopa_scenarios (bowtie_diagram_id);

INSERT INTO schema_migrations (version) VALUES ('035_lopa_bowtie_integration')
  ON CONFLICT DO NOTHING;

COMMIT;
