-- مهاجرت برای اصلاح مشکل رمز عبور admin
-- این مهاجرت حساب admin را آنلاک کرده و تلاش های ناموفق را صفر می کند
-- توجه: رمز عبور جدید "Admin@PSM#2026" است

-- ریست قفل حساب و تلاش های ناموفق
UPDATE users 
SET failed_attempts = 0,
    locked_until = NULL,
    status = 'Active',
    must_change_password = true
WHERE username = 'admin';

-- بررسی وضعیت
SELECT id, username, role, status, failed_attempts, locked_until
FROM users
WHERE username = 'admin';
