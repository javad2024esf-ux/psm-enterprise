-- FIXED during refactor: idx_audit_action / idx_notifications_recipient collided with
-- pre-existing indexes of the same name from 003b_workflow_engine.sql
-- (workflow_audit_trail). Renamed to idx_wp_audit_action / idx_wp_notifications_recipient.

-- ═══════════════════════════════════════════════════════════════════════════
-- Migration: Work Permit Workflow Tables
-- نسخه: 015
-- توضیح: جداول کامل برای workflow مجوزهای کاری
-- ═══════════════════════════════════════════════════════════════════════════

-- جدول اصلی مجوزهای کاری
CREATE TABLE IF NOT EXISTS work_permits (
  id VARCHAR(64) PRIMARY KEY,
  tenant_id VARCHAR(64) NOT NULL,
  
  -- معلومات مجوز
  permit_type VARCHAR(50) NOT NULL, -- Hot Work, Confined Space, Excavation, etc.
  job_title VARCHAR(255) NOT NULL,
  description TEXT,
  location VARCHAR(255) NOT NULL,
  
  -- زمان بندی
  job_date DATE NOT NULL,
  estimated_duration NUMERIC(10, 2), -- hours
  actual_start_time TIMESTAMP,
  actual_end_time TIMESTAMP,
  
  -- اطلاعات پیمانکار
  contractor_name VARCHAR(255) NOT NULL,
  contractor_license VARCHAR(100),
  supervisor VARCHAR(255) NOT NULL,
  
  -- وضعیت و ریسک
  state VARCHAR(50) DEFAULT 'Draft', -- Draft, Supervisor_Review, HSE_Review, Area_Manager_Approval, Active, Completion, Closed
  state_changed_at TIMESTAMP DEFAULT NOW(),
  risk_level VARCHAR(20), -- Low, Medium, High, Very High
  
  -- تأیید‌ها
  supervisor_approval BOOLEAN DEFAULT FALSE,
  hse_approval BOOLEAN DEFAULT FALSE,
  area_manager_approval BOOLEAN DEFAULT FALSE,
  escalation_level VARCHAR(50),
  
  -- داده‌های فرم برای هر مرحله
  form_data JSONB DEFAULT '{}',
  
  -- اقدامات ایمنی
  required_ppe TEXT[], -- array of PPE items
  required_equipment TEXT[], -- array of equipment
  additional_measures TEXT,
  
  -- نتایج و نظارت
  actual_duration NUMERIC(10, 2),
  safety_incidents TEXT,
  issues_encountered TEXT,
  completion_notes TEXT,
  
  -- دیجیتال سیگنیچر و تأیید
  watch_person VARCHAR(255),
  safety_briefing_conducted BOOLEAN DEFAULT FALSE,
  equipment_status_check BOOLEAN DEFAULT FALSE,
  site_restoration BOOLEAN DEFAULT FALSE,
  tools_returned BOOLEAN DEFAULT FALSE,
  
  -- مسئولان
  created_by VARCHAR(64),
  created_at TIMESTAMP DEFAULT NOW(),
  last_modified_by VARCHAR(64),
  updated_at TIMESTAMP DEFAULT NOW(),
  
  -- متادیتا
  tags TEXT[],
  custom_fields JSONB DEFAULT '{}',
  
  CONSTRAINT fk_work_permits_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

-- ایندکس‌های عملکردی
CREATE INDEX idx_work_permits_tenant ON work_permits(tenant_id);
CREATE INDEX idx_work_permits_state ON work_permits(state);
CREATE INDEX idx_work_permits_permit_type ON work_permits(permit_type);
CREATE INDEX idx_work_permits_risk_level ON work_permits(risk_level);
CREATE INDEX idx_work_permits_job_date ON work_permits(job_date);
CREATE INDEX idx_work_permits_created_at ON work_permits(created_at DESC);

-- جدول ردیابی SLA
CREATE TABLE IF NOT EXISTS work_permit_sla_tracking (
  id SERIAL PRIMARY KEY,
  permit_id VARCHAR(64) NOT NULL,
  state VARCHAR(50) NOT NULL,
  target_hours NUMERIC(10, 2) NOT NULL,
  entered_at TIMESTAMP DEFAULT NOW(),
  exited_at TIMESTAMP,
  exceeded BOOLEAN DEFAULT FALSE,
  
  CONSTRAINT fk_sla_tracking_permit FOREIGN KEY (permit_id) REFERENCES work_permits(id) ON DELETE CASCADE
);

CREATE INDEX idx_sla_tracking_permit ON work_permit_sla_tracking(permit_id);
CREATE INDEX idx_sla_tracking_exceeded ON work_permit_sla_tracking(exceeded);

-- جدول تاریخچة تصعید
CREATE TABLE IF NOT EXISTS work_permit_escalations (
  id SERIAL PRIMARY KEY,
  permit_id VARCHAR(64) NOT NULL,
  escalation_reason VARCHAR(255),
  escalated_to TEXT[], -- array of user IDs
  escalated_at TIMESTAMP DEFAULT NOW(),
  resolved_at TIMESTAMP,
  resolved_by VARCHAR(64),
  resolution_notes TEXT,
  
  CONSTRAINT fk_escalations_permit FOREIGN KEY (permit_id) REFERENCES work_permits(id) ON DELETE CASCADE
);

CREATE INDEX idx_escalations_permit ON work_permit_escalations(permit_id);
CREATE INDEX idx_escalations_resolved ON work_permit_escalations(resolved_at);

-- جدول اعلان‌های مجوز
CREATE TABLE IF NOT EXISTS work_permit_notifications (
  id SERIAL PRIMARY KEY,
  permit_id VARCHAR(64) NOT NULL,
  recipient_id VARCHAR(64),
  notification_type VARCHAR(50), -- APPROVAL_PENDING, ESCALATION, REMINDER, etc.
  subject VARCHAR(255),
  message TEXT,
  sent_at TIMESTAMP DEFAULT NOW(),
  read_at TIMESTAMP,
  action_url VARCHAR(500),
  
  CONSTRAINT fk_notifications_permit FOREIGN KEY (permit_id) REFERENCES work_permits(id) ON DELETE CASCADE
);

CREATE INDEX idx_notifications_permit ON work_permit_notifications(permit_id);
CREATE INDEX idx_wp_notifications_recipient ON work_permit_notifications(recipient_id);
CREATE INDEX idx_notifications_unread ON work_permit_notifications(read_at) WHERE read_at IS NULL;

-- جدول تاریخچة بازبینی
CREATE TABLE IF NOT EXISTS work_permit_audit_trail (
  id SERIAL PRIMARY KEY,
  permit_id VARCHAR(64) NOT NULL,
  action VARCHAR(50), -- CREATE, UPDATE, TRANSITION, APPROVE, REJECT
  user_id VARCHAR(64),
  user_name VARCHAR(255),
  changes JSONB,
  timestamp TIMESTAMP DEFAULT NOW(),
  ip_address VARCHAR(45),
  details TEXT,
  
  CONSTRAINT fk_audit_permit FOREIGN KEY (permit_id) REFERENCES work_permits(id) ON DELETE CASCADE
);

CREATE INDEX idx_audit_permit ON work_permit_audit_trail(permit_id);
CREATE INDEX idx_wp_audit_action ON work_permit_audit_trail(action);
CREATE INDEX idx_wp_audit_user ON work_permit_audit_trail(user_id);
CREATE INDEX idx_wp_audit_timestamp ON work_permit_audit_trail(timestamp DESC);

-- جدول اعضای گروه کار
CREATE TABLE IF NOT EXISTS work_permit_crew (
  id SERIAL PRIMARY KEY,
  permit_id VARCHAR(64) NOT NULL,
  crew_member_name VARCHAR(255) NOT NULL,
  crew_member_id VARCHAR(64),
  role VARCHAR(100), -- Worker, Supervisor, Watch Person, etc.
  qualifications TEXT[], -- array of qualifications
  trained_for_task BOOLEAN DEFAULT FALSE,
  added_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT fk_crew_permit FOREIGN KEY (permit_id) REFERENCES work_permits(id) ON DELETE CASCADE
);

CREATE INDEX idx_crew_permit ON work_permit_crew(permit_id);
CREATE INDEX idx_crew_role ON work_permit_crew(role);

-- جدول سوابق ایمنی
CREATE TABLE IF NOT EXISTS work_permit_safety_records (
  id SERIAL PRIMARY KEY,
  permit_id VARCHAR(64) NOT NULL,
  safety_check_type VARCHAR(100), -- Equipment Check, PPE Inspection, etc.
  checked_at TIMESTAMP DEFAULT NOW(),
  checked_by VARCHAR(64),
  status VARCHAR(50), -- PASS, FAIL, NEEDS_REPAIR
  findings TEXT,
  corrective_actions TEXT,
  follow_up_date DATE,
  
  CONSTRAINT fk_safety_permit FOREIGN KEY (permit_id) REFERENCES work_permits(id) ON DELETE CASCADE
);

CREATE INDEX idx_safety_permit ON work_permit_safety_records(permit_id);
CREATE INDEX idx_safety_status ON work_permit_safety_records(status);

-- جدول درس‌های آموخته شده
CREATE TABLE IF NOT EXISTS work_permit_lessons_learned (
  id SERIAL PRIMARY KEY,
  permit_id VARCHAR(64) NOT NULL,
  lesson_title VARCHAR(255),
  description TEXT,
  lesson_category VARCHAR(100), -- Safety, Process, Equipment, etc.
  shared_organization_wide BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW(),
  created_by VARCHAR(64),
  
  CONSTRAINT fk_lessons_permit FOREIGN KEY (permit_id) REFERENCES work_permits(id) ON DELETE CASCADE
);

CREATE INDEX idx_lessons_permit ON work_permit_lessons_learned(permit_id);
CREATE INDEX idx_lessons_shared ON work_permit_lessons_learned(shared_organization_wide);

-- جدول گزارش‌های SLA و عملکرد
CREATE TABLE IF NOT EXISTS work_permit_performance_metrics (
  id SERIAL PRIMARY KEY,
  tenant_id VARCHAR(64) NOT NULL,
  permit_type VARCHAR(50),
  risk_level VARCHAR(20),
  avg_approval_time_hours NUMERIC(10, 2),
  sla_compliance_percentage NUMERIC(5, 2),
  total_permits BIGINT,
  permits_exceeded_sla BIGINT,
  month_year DATE,
  
  CONSTRAINT fk_metrics_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

CREATE INDEX idx_metrics_tenant ON work_permit_performance_metrics(tenant_id);
CREATE INDEX idx_metrics_period ON work_permit_performance_metrics(month_year);

-- TRIGGER: بروزرسانی updated_at
CREATE OR REPLACE FUNCTION update_work_permits_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tr_work_permits_updated_at ON work_permits;
CREATE TRIGGER tr_work_permits_updated_at
BEFORE UPDATE ON work_permits
FOR EACH ROW
EXECUTE FUNCTION update_work_permits_updated_at();

-- TRIGGER: ثبت تاریخچة تغییرات
CREATE OR REPLACE FUNCTION log_work_permit_changes()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'UPDATE' THEN
    INSERT INTO work_permit_audit_trail (permit_id, action, user_id, changes)
    VALUES (NEW.id, 'UPDATE', COALESCE(NEW.last_modified_by, 'system'), jsonb_build_object(
      'changed_fields', jsonb_each(jsonb_build_object(
        'state', CASE WHEN NEW.state != OLD.state THEN jsonb_build_object('old', OLD.state, 'new', NEW.state) ELSE NULL END,
        'risk_level', CASE WHEN NEW.risk_level != OLD.risk_level THEN jsonb_build_object('old', OLD.risk_level, 'new', NEW.risk_level) ELSE NULL END,
        'supervisor_approval', CASE WHEN NEW.supervisor_approval != OLD.supervisor_approval THEN jsonb_build_object('old', OLD.supervisor_approval, 'new', NEW.supervisor_approval) ELSE NULL END,
        'hse_approval', CASE WHEN NEW.hse_approval != OLD.hse_approval THEN jsonb_build_object('old', OLD.hse_approval, 'new', NEW.hse_approval) ELSE NULL END,
        'area_manager_approval', CASE WHEN NEW.area_manager_approval != OLD.area_manager_approval THEN jsonb_build_object('old', OLD.area_manager_approval, 'new', NEW.area_manager_approval) ELSE NULL END
      ))
    ));
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tr_log_work_permit_changes ON work_permits;
CREATE TRIGGER tr_log_work_permit_changes
AFTER UPDATE ON work_permits
FOR EACH ROW
EXECUTE FUNCTION log_work_permit_changes();

-- نمایش تجمیع‌ی برای گزارش‌ها
CREATE OR REPLACE VIEW work_permit_summary AS
SELECT
  p.tenant_id,
  p.permit_type,
  p.state,
  p.risk_level,
  COUNT(*) as total_permits,
  COUNT(CASE WHEN p.state = 'Closed' THEN 1 END) as completed_permits,
  AVG(EXTRACT(HOUR FROM (COALESCE(p.actual_end_time, NOW()) - p.created_at))) as avg_duration_hours,
  MAX(p.created_at) as last_permit_date
FROM work_permits p
WHERE p.created_at >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY p.tenant_id, p.permit_type, p.state, p.risk_level;

-- Seed: نمونه داده
INSERT INTO work_permits (
  id, tenant_id, permit_type, job_title, description, location,
  job_date, estimated_duration, contractor_name, supervisor,
  state, risk_level, created_by
) VALUES (
  'wp_sample_001', 'tenant_1', 'Hot Work', 'جوشکاری لوله فشار', 
  'جوشکاری لوله های فشار در بخش تقطیر',
  'Distillation Unit - Column A',
  CURRENT_DATE + INTERVAL '7 days', 8,
  'شرکت صنعتی پار', 'علی محمدی',
  'Draft', 'High', 'admin'
) ON CONFLICT DO NOTHING;
