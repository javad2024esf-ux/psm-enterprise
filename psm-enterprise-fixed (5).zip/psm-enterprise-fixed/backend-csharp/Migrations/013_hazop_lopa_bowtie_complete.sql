
BEGIN;
CREATE TABLE IF NOT EXISTS hazop_studies (
  id            TEXT        PRIMARY KEY,
  title         TEXT        NOT NULL,
  facility      TEXT,
  unit          TEXT,
  lead_engineer TEXT,
  scope         TEXT,
  methodology   TEXT        NOT NULL DEFAULT 'HAZOP (IEC 61882)',
  status        TEXT        NOT NULL DEFAULT 'Draft'
                            CHECK (status IN ('Draft','Active','Completed','Archived')),
  start_date    DATE,
  end_date      DATE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by    TEXT,
  deleted       BOOLEAN     NOT NULL DEFAULT FALSE,
  data          JSONB       NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS hazop_nodes (
  id            TEXT        PRIMARY KEY,
  study_id      TEXT        NOT NULL REFERENCES hazop_studies(id) ON DELETE CASCADE,
  node_number   TEXT        NOT NULL,
  description   TEXT        NOT NULL,
  process_line  TEXT,
  design_intent TEXT,
  p_and_id      TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted       BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS hazop_deviations (
  id                   TEXT        PRIMARY KEY,
  study_id             TEXT        NOT NULL REFERENCES hazop_studies(id) ON DELETE CASCADE,
  node_id              TEXT        REFERENCES hazop_nodes(id) ON DELETE CASCADE,
  guide_word           TEXT        NOT NULL,
  parameter            TEXT        NOT NULL,
  deviation            TEXT        NOT NULL,
  causes               TEXT,
  consequences         TEXT,
  existing_safeguards  TEXT,
  recommendations      TEXT,
  severity             INTEGER     NOT NULL DEFAULT 3 CHECK (severity BETWEEN 1 AND 5),
  likelihood           INTEGER     NOT NULL DEFAULT 3 CHECK (likelihood BETWEEN 1 AND 5),
  risk_level           TEXT        GENERATED ALWAYS AS (
    CASE (severity * likelihood)
      WHEN 1  THEN 'Negligible'
      WHEN 2  THEN 'Low'
      WHEN 3  THEN 'Low'
      WHEN 4  THEN 'Medium'
      WHEN 5  THEN 'Medium'
      WHEN 6  THEN 'Medium'
      WHEN 8  THEN 'High'
      WHEN 9  THEN 'High'
      WHEN 10 THEN 'High'
      WHEN 12 THEN 'Critical'
      WHEN 15 THEN 'Critical'
      WHEN 16 THEN 'Critical'
      WHEN 20 THEN 'Critical'
      WHEN 25 THEN 'Critical'
      ELSE
        CASE
          WHEN (severity * likelihood) >= 15 THEN 'Critical'
          WHEN (severity * likelihood) >= 10 THEN 'High'
          WHEN (severity * likelihood) >= 5  THEN 'Medium'
          WHEN (severity * likelihood) >= 3  THEN 'Low'
          ELSE 'Negligible'
        END
    END
  ) STORED,
  status               TEXT        NOT NULL DEFAULT 'Open'
                                   CHECK (status IN ('Open','Action Required','Closed')),
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted              BOOLEAN     NOT NULL DEFAULT FALSE,
  data                 JSONB       NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_hazop_studies_status  ON hazop_studies (status);
CREATE INDEX IF NOT EXISTS idx_hazop_nodes_study     ON hazop_nodes (study_id);
CREATE INDEX IF NOT EXISTS idx_hazop_dev_study       ON hazop_deviations (study_id);
CREATE INDEX IF NOT EXISTS idx_hazop_dev_node        ON hazop_deviations (node_id);
CREATE INDEX IF NOT EXISTS idx_hazop_dev_risk        ON hazop_deviations (risk_level);

CREATE TABLE IF NOT EXISTS lopa_studies (
  id             TEXT        PRIMARY KEY,
  title          TEXT        NOT NULL,
  hazop_study_id TEXT        REFERENCES hazop_studies(id) ON DELETE SET NULL,
  facility       TEXT,
  unit           TEXT,
  lead_engineer  TEXT,
  status         TEXT        NOT NULL DEFAULT 'Draft',
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by     TEXT,
  deleted        BOOLEAN     NOT NULL DEFAULT FALSE,
  data           JSONB       NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS lopa_scenarios (
  id                     TEXT         PRIMARY KEY,
  lopa_study_id          TEXT         NOT NULL REFERENCES lopa_studies(id) ON DELETE CASCADE,
  hazop_deviation_id     TEXT         REFERENCES hazop_deviations(id) ON DELETE SET NULL,
  scenario_number        TEXT         NOT NULL,
  initiating_event       TEXT         NOT NULL,
  initiating_frequency   NUMERIC(12,6) NOT NULL DEFAULT 1,
  consequence_description TEXT,
  consequence_severity   INTEGER      NOT NULL DEFAULT 3 CHECK (consequence_severity BETWEEN 1 AND 5),
  target_risk            NUMERIC(12,9) NOT NULL DEFAULT 0.0001,
  residual_risk          NUMERIC(12,9),
  risk_gap               NUMERIC(12,9),
  risk_gap_met           BOOLEAN      GENERATED ALWAYS AS (
    CASE WHEN residual_risk IS NOT NULL AND target_risk IS NOT NULL
         THEN residual_risk <= target_risk ELSE FALSE END
  ) STORED,
  notes                  TEXT,
  created_at             TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at             TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  deleted                BOOLEAN      NOT NULL DEFAULT FALSE,
  data                   JSONB        NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS lopa_ipls (
  id                    TEXT        PRIMARY KEY,
  scenario_id           TEXT        NOT NULL REFERENCES lopa_scenarios(id) ON DELETE CASCADE,
  ipl_name              TEXT        NOT NULL,
  ipl_type              TEXT        NOT NULL DEFAULT 'Engineering',
  description           TEXT,
  pfd                   NUMERIC(10,6) NOT NULL DEFAULT 0.1 CHECK (pfd > 0 AND pfd <= 1),
  risk_reduction_factor NUMERIC(12,3) GENERATED ALWAYS AS (1.0 / NULLIF(pfd, 0)) STORED,
  is_validated          BOOLEAN     NOT NULL DEFAULT FALSE,
  owner                 TEXT,
  audit_interval        TEXT,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted               BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS bowtie_diagrams (
  id                 TEXT        PRIMARY KEY,
  title              TEXT        NOT NULL,
  top_event          TEXT        NOT NULL,
  top_event_node     TEXT,
  hazard             TEXT,
  hazop_study_id     TEXT        REFERENCES hazop_studies(id) ON DELETE SET NULL,
  hazop_deviation_id TEXT        REFERENCES hazop_deviations(id) ON DELETE SET NULL,
  lopa_study_id      TEXT        REFERENCES lopa_studies(id) ON DELETE SET NULL,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by         TEXT,
  deleted            BOOLEAN     NOT NULL DEFAULT FALSE,
  data               JSONB       NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_lopa_studies_hazop    ON lopa_studies (hazop_study_id);
CREATE INDEX IF NOT EXISTS idx_lopa_scenarios_study  ON lopa_scenarios (lopa_study_id);
CREATE INDEX IF NOT EXISTS idx_lopa_scenarios_hazop  ON lopa_scenarios (hazop_deviation_id);
CREATE INDEX IF NOT EXISTS idx_lopa_ipls_scenario    ON lopa_ipls (scenario_id);
CREATE INDEX IF NOT EXISTS idx_bowtie_hazop_study    ON bowtie_diagrams (hazop_study_id);
CREATE INDEX IF NOT EXISTS idx_bowtie_hazop_dev      ON bowtie_diagrams (hazop_deviation_id);
CREATE INDEX IF NOT EXISTS idx_bowtie_lopa           ON bowtie_diagrams (lopa_study_id);

INSERT INTO schema_migrations (version) VALUES ('013_hazop_lopa_bowtie_complete')
ON CONFLICT DO NOTHING;

COMMIT;
