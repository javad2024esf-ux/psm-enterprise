-- ═══════════════════════════════════════════════════════════════════════════
-- Migration 004: Dynamic Role & Permission System
-- ═══════════════════════════════════════════════════════════════════════════

-- ─── جدول نقش‌های پویا ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS roles (
  id          TEXT        PRIMARY KEY,
  name        TEXT        NOT NULL UNIQUE,        -- کلید سیستمی (e.g. "SafetyLead")
  label       TEXT        NOT NULL,               -- نمایشی فارسی (e.g. "مسئول ایمنی")
  description TEXT,
  color       TEXT        NOT NULL DEFAULT '#6366f1',
  is_system   BOOLEAN     NOT NULL DEFAULT FALSE, -- نقش‌های پیش‌فرض قابل حذف نیستند
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── جدول مجوزهای هر نقش به تفکیک ماژول ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS role_permissions (
  id          SERIAL      PRIMARY KEY,
  role_id     TEXT        NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  module      TEXT        NOT NULL,               -- e.g. 'HAZOP', 'MOC', 'INCIDENT'
  can_read    BOOLEAN     NOT NULL DEFAULT FALSE,
  can_write   BOOLEAN     NOT NULL DEFAULT FALSE,
  can_approve BOOLEAN     NOT NULL DEFAULT FALSE,
  can_delete  BOOLEAN     NOT NULL DEFAULT FALSE,
  UNIQUE(role_id, module)
);

CREATE INDEX IF NOT EXISTS idx_role_permissions_role ON role_permissions(role_id);

-- ─── درج نقش‌های پیش‌فرض سیستم ────────────────────────────────────────────────
INSERT INTO roles (id, name, label, description, color, is_system) VALUES
  ('role_admin',        'Admin',          'مدیر سیستم',       'دسترسی کامل به همه بخش‌ها',             '#7c3aed', TRUE),
  ('role_psmmanager',   'PSMManager',     'مدیر PSM',         'مدیریت کامل فرآیندهای PSM',             '#0284c7', TRUE),
  ('role_hsemanager',   'HSEManager',     'مدیر HSE',         'مدیریت ایمنی، بهداشت و محیط زیست',      '#059669', TRUE),
  ('role_unithead',     'UnitHead',       'سرپرست واحد',      'مدیریت عملیات واحد مشخص',               '#2563eb', TRUE),
  ('role_processengineer','ProcessEngineer','مهندس فرآیند',   'بررسی و تحلیل فرآیندهای صنعتی',         '#4f46e5', TRUE),
  ('role_supervisor',   'Supervisor',     'سرپرست شیفت',      'نظارت بر عملیات شیفت',                  '#d97706', TRUE),
  ('role_operator',     'Operator',       'اپراتور',          'اجرای دستورالعمل‌های عملیاتی',           '#ea580c', TRUE),
  ('role_inspector',    'Inspector',      'بازرس',            'بازرسی تجهیزات و فرآیندها',              '#0d9488', TRUE),
  ('role_contractormgr','ContractorMgr',  'مسئول پیمانکاران', 'مدیریت قراردادها و پیمانکاران',          '#e11d48', TRUE),
  ('role_viewer',       'Viewer',         'ناظر / مهمان',     'فقط مشاهده گزارشات',                    '#64748b', TRUE)
ON CONFLICT (name) DO NOTHING;

-- ─── ماژول‌های PSM Enterprise ──────────────────────────────────────────────────
-- مجوزهای پیش‌فرض Admin (همه چیز)
DO $$
DECLARE
  modules TEXT[] := ARRAY[
    'HAZOP','HIRA','MOC','INCIDENT','AUDIT','ACTION_REGISTER',
    'ASSET_INTEGRITY','COMPETENCY','CONDUCT_OPS','CONTRACTOR',
    'CULTURE','EMERGENCY','KNOWLEDGE','MANAGEMENT_REVIEW',
    'METRICS','PROCEDURES','READINESS','SAFE_WORK','STAKEHOLDER',
    'STANDARDS','TRAINING','WORKFORCE','DOCUMENTS','USERS','SETTINGS',
    'LOPA','BOWTIE','WORKFLOW','GAP_ANALYSIS','MANAGEMENT_REPORT'
  ];
  m TEXT;
BEGIN
  FOREACH m IN ARRAY modules LOOP
    INSERT INTO role_permissions(role_id, module, can_read, can_write, can_approve, can_delete)
    VALUES
      ('role_admin',          m, TRUE,  TRUE,  TRUE,  TRUE),
      ('role_psmmanager',     m, TRUE,  TRUE,  TRUE,  FALSE),
      ('role_hsemanager',     m, TRUE,  TRUE,  FALSE, FALSE),
      ('role_unithead',       m, TRUE,  TRUE,  FALSE, FALSE),
      ('role_processengineer',m, TRUE,  TRUE,  FALSE, FALSE),
      ('role_supervisor',     m, TRUE,  FALSE, FALSE, FALSE),
      ('role_operator',       m, TRUE,  FALSE, FALSE, FALSE),
      ('role_inspector',      m, TRUE,  FALSE, FALSE, FALSE),
      ('role_contractormgr',  m, FALSE, FALSE, FALSE, FALSE),
      ('role_viewer',         m, TRUE,  FALSE, FALSE, FALSE)
    ON CONFLICT (role_id, module) DO NOTHING;
  END LOOP;
END $$;

-- ContractorMgr فقط به ماژول‌های مربوطه دسترسی دارد
UPDATE role_permissions SET can_read=TRUE, can_write=TRUE
WHERE role_id='role_contractormgr' AND module IN ('CONTRACTOR','DOCUMENTS','AUDIT');

-- ═══════════════════════════════════════════════════════════════════════════
-- اصلاح مجوزهای Viewer: فقط ماژول‌های عمومی قابل مشاهده
-- ═══════════════════════════════════════════════════════════════════════════
-- ابتدا همه can_read را برای viewer برمی‌داریم
UPDATE role_permissions SET can_read=FALSE WHERE role_id='role_viewer';

-- فقط ماژول‌های مجاز برای مشاهده
UPDATE role_permissions SET can_read=TRUE
WHERE role_id='role_viewer' AND module IN (
  'INCIDENT',           -- گزارش حوادث
  'METRICS',            -- شاخص‌های عملکرد
  'AUDIT',              -- ممیزی
  'MANAGEMENT_REVIEW',  -- بازنگری مدیریت
  'TRAINING',           -- آموزش
  'EMERGENCY'           -- آمادگی اضطراری
);
-- مدیر می‌تواند از طریق پنل مدیریت نقش‌ها این مجوزها را تغییر دهد
