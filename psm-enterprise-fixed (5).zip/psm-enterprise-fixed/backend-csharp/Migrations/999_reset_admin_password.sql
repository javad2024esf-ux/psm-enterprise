-- ریست رمز عبور admin به Admin@PSM#2026
-- این اسکریپت را مستقیماً در PostgreSQL اجرا کنید

UPDATE users 
SET password_hash       = '$2b$12$aD0.axBkCrQVsdgDvTSqWuoP1FNrcYXe51YIeka6f8D0gpqq.5swm',
    failed_attempts     = 0,
    locked_until        = NULL,
    status              = 'Active',
    must_change_password = false
WHERE username = 'admin';

-- تأیید
SELECT id, username, role, status, failed_attempts, locked_until, must_change_password
FROM users
WHERE username = 'admin';
