-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║  PSM Enterprise — Migration 005 : Integration Engine                    ║
-- ║  معماری یکپارچه‌سازی بین ماژول‌های PSM                                ║
-- ╚══════════════════════════════════════════════════════════════════════════╝

-- ─── ۱. جدول تعریف قوانین Integration ────────────────────────────────────────
-- هر رکورد یک «قانون اتصال» بین دو ماژول تعریف می‌کند
-- مثال: وقتی MOC به مرحله Implementation رسید → PSSR بساز
CREATE TABLE IF NOT EXISTS integration_rules (
  id            TEXT        PRIMARY KEY,
  name          TEXT        NOT NULL,
  description   TEXT,

  -- منبع رویداد
  source_module TEXT        NOT NULL,   -- 'MOC-Registry' | 'Incident-Core' | ...
  trigger_event TEXT        NOT NULL,   -- 'STATUS_CHANGE' | 'RECORD_CREATED' | 'FIELD_CHANGE' | 'MANUAL'
  trigger_condition JSONB   NOT NULL DEFAULT '{}',
  -- مثال: { "status": "Implementation" }
  -- مثال: { "field": "severity", "operator": "eq", "value": "Critical" }

  -- هدف عملیات
  target_module TEXT        NOT NULL,   -- 'Action-Register' | 'PSSR-Registry' | 'Notifications'
  action_type   TEXT        NOT NULL,   -- 'CREATE_RECORD' | 'UPDATE_RECORD' | 'SEND_NOTIFICATION' | 'START_WORKFLOW'
  action_template JSONB     NOT NULL DEFAULT '{}',
  -- mapping فیلدها از source به target

  -- کنترل
  is_active     BOOLEAN     NOT NULL DEFAULT TRUE,
  priority      INT         NOT NULL DEFAULT 10,   -- عدد کمتر = اجرای زودتر
  created_by    TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_int_rules_source   ON integration_rules (source_module, trigger_event, is_active);
CREATE INDEX IF NOT EXISTS idx_int_rules_active   ON integration_rules (is_active, priority);

-- ─── ۲. جدول رویدادهای Integration (Event Log / Inbox) ───────────────────────
-- هر بار که یک رویداد در PSM رخ می‌دهد اینجا ثبت می‌شود
-- این جدول event bus داخلی سیستم است
CREATE TABLE IF NOT EXISTS integration_events (
  id            TEXT        PRIMARY KEY,
  event_type    TEXT        NOT NULL,   -- 'STATUS_CHANGE' | 'RECORD_CREATED' | ...
  source_module TEXT        NOT NULL,
  source_id     TEXT        NOT NULL,   -- شناسه رکورد منبع
  payload       JSONB       NOT NULL DEFAULT '{}',  -- داده کامل رویداد
  triggered_by  TEXT,                   -- user_id یا 'system'
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  -- وضعیت پردازش
  status        TEXT        NOT NULL DEFAULT 'pending',  -- 'pending' | 'processing' | 'done' | 'failed'
  processed_at  TIMESTAMPTZ,
  error_message TEXT,
  retry_count   INT         NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_int_events_status    ON integration_events (status, created_at);
CREATE INDEX IF NOT EXISTS idx_int_events_source    ON integration_events (source_module, source_id);
CREATE INDEX IF NOT EXISTS idx_int_events_type      ON integration_events (event_type, status);

-- ─── ۳. جدول نتایج اجرای قوانین Integration ─────────────────────────────────
-- هر بار که یک قانون روی رویداد اجرا می‌شود اینجا ثبت می‌شود
CREATE TABLE IF NOT EXISTS integration_executions (
  id            TEXT        PRIMARY KEY,
  event_id      TEXT        NOT NULL REFERENCES integration_events(id) ON DELETE CASCADE,
  rule_id       TEXT        NOT NULL REFERENCES integration_rules(id)  ON DELETE CASCADE,

  -- نتیجه
  status        TEXT        NOT NULL DEFAULT 'pending',  -- 'success' | 'failed' | 'skipped'
  result        JSONB,       -- شناسه رکورد ایجادشده یا داده‌های مفید
  error_message TEXT,
  duration_ms   INT,
  executed_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_int_exec_event  ON integration_executions (event_id);
CREATE INDEX IF NOT EXISTS idx_int_exec_rule   ON integration_executions (rule_id);
CREATE INDEX IF NOT EXISTS idx_int_exec_status ON integration_executions (status, executed_at DESC);

-- ─── ۴. جدول Action Register مرکزی (ارتقاء) ─────────────────────────────────
-- این جدول یک view مرکزی از تمام اقدامات در سیستم است
-- تمام اقدامات از MOC، Incident، HAZOP، Audit، Management Review اینجا جمع می‌شوند
CREATE TABLE IF NOT EXISTS action_register (
  id              TEXT        PRIMARY KEY,
  title           TEXT        NOT NULL,
  description     TEXT,

  -- منبع (کدام ماژول این اقدام را ایجاد کرده)
  source_module   TEXT        NOT NULL,  -- 'MOC' | 'Incident' | 'HAZOP' | 'Audit' | ...
  source_id       TEXT        NOT NULL,  -- شناسه رکورد منبع
  source_ref      TEXT,                  -- شماره مرجع قابل نمایش (مثل MOC-2024-001)

  -- اقدام
  responsible     TEXT,                  -- user_id یا نام
  due_date        DATE,
  unit            TEXT,
  priority        TEXT        NOT NULL DEFAULT 'Medium',  -- 'Critical' | 'High' | 'Medium' | 'Low'
  status          TEXT        NOT NULL DEFAULT 'Open',    -- 'Open' | 'In Progress' | 'Overdue' | 'Done' | 'Verified' | 'Closed'
  tags            TEXT[]      NOT NULL DEFAULT '{}',

  -- integration metadata
  created_by_rule TEXT        REFERENCES integration_rules(id),
  event_id        TEXT        REFERENCES integration_events(id),

  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  closed_at       TIMESTAMPTZ,
  deleted         BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_ar_source    ON action_register (source_module, source_id);
CREATE INDEX IF NOT EXISTS idx_ar_status    ON action_register (status, due_date);
CREATE INDEX IF NOT EXISTS idx_ar_unit      ON action_register (unit, status);
CREATE INDEX IF NOT EXISTS idx_ar_priority  ON action_register (priority, status);
CREATE INDEX IF NOT EXISTS idx_ar_deleted   ON action_register (deleted);

-- ─── ۵. قوانین پیش‌فرض PSM ────────────────────────────────────────────────────
INSERT INTO integration_rules (id, name, description, source_module, trigger_event, trigger_condition, target_module, action_type, action_template, priority)
VALUES

-- قانون ۱: Incident CAPA → Action Register
('rule_inc_action',
 'Incident CAPA به Action Register',
 'وقتی حادثه به مرحله Action_Plan رسید، اقدامات CAPA به Action Register منتقل شوند',
 'Incident-Core', 'STATUS_CHANGE',
 '{"toStatus": "Action_Plan"}',
 'Action-Register', 'CREATE_RECORD',
 '{"titlePrefix": "[حادثه]", "priority": "High", "tags": ["CAPA", "Incident"]}',
 10),

-- قانون ۲: MOC Approval → PSSR Auto-Create
('rule_moc_pssr',
 'MOC تأیید شده → PSSR خودکار',
 'وقتی MOC به مرحله Implementation رفت، یک PSSR به صورت خودکار ایجاد شود',
 'MOC-Registry', 'STATUS_CHANGE',
 '{"toStatus": "Implementation"}',
 'PSSR-Registry', 'CREATE_RECORD',
 '{"titlePrefix": "PSSR برای MOC:", "daysOffset": 14, "status": "InProgress"}',
 10),

-- قانون ۳: Audit Finding → Action Register
('rule_audit_action',
 'یافته ممیزی → Action Register',
 'هر یافته جدید ممیزی به صورت خودکار به Action Register اضافه شود',
 'Audit-Findings', 'RECORD_CREATED',
 '{}',
 'Action-Register', 'CREATE_RECORD',
 '{"titlePrefix": "[ممیزی]", "priorityField": "severity", "tags": ["Audit"]}',
 10),

-- قانون ۴: HAZOP Recommendation → Action Register
('rule_hazop_action',
 'توصیه HAZOP → Action Register',
 'توصیه‌های مطالعه HAZOP به Action Register منتقل شوند',
 'HAZOP-Deviations', 'RECORD_CREATED',
 '{"hasRecommendation": true}',
 'Action-Register', 'CREATE_RECORD',
 '{"titlePrefix": "[HAZOP]", "priority": "High", "tags": ["HAZOP", "Safety"]}',
 10),

-- قانون ۵: Management Review Action → Action Register
('rule_mgmt_action',
 'تصمیم بازنگری مدیریت → Action Register',
 'تصمیمات و اقدامات جلسه بازنگری مدیریت به Action Register اضافه شوند',
 'Management-Actions', 'RECORD_CREATED',
 '{}',
 'Action-Register', 'CREATE_RECORD',
 '{"titlePrefix": "[بازنگری مدیریت]", "priority": "High", "tags": ["Management Review"]}',
 10),

-- قانون ۶: Critical Incident → Notification فوری
('rule_critical_notif',
 'حادثه بحرانی → اعلان فوری',
 'حوادث با شدت Critical فوراً به PSMManager و HSEManager اطلاع داده شوند',
 'Incident-Core', 'RECORD_CREATED',
 '{"field": "severity", "operator": "eq", "value": "Critical"}',
 'Notifications', 'SEND_NOTIFICATION',
 '{"roles": ["PSMManager", "HSEManager", "Admin"], "priority": "urgent", "titlePrefix": "🚨 حادثه بحرانی:"}',
 1),

-- قانون ۷: Overdue Action → Notification
('rule_overdue_notif',
 'اقدام سررسیدگذشته → اعلان',
 'اقدامات سررسیدگذشته را به مسئول اطلاع بده',
 'Action-Register', 'FIELD_CHANGE',
 '{"field": "status", "operator": "eq", "value": "Overdue"}',
 'Notifications', 'SEND_NOTIFICATION',
 '{"roles": ["responsible"], "titlePrefix": "⏰ اقدام سررسیدگذشته:"}',
 5),

-- قانون ۸: PTW Expired → Stop Work Notification
('rule_ptw_expired',
 'مجوز کار منقضی → اعلان توقف',
 'وقتی مجوز کار ایمن منقضی شد، به Supervisor اطلاع داده شود',
 'PTW-Core', 'STATUS_CHANGE',
 '{"toStatus": "Expired"}',
 'Notifications', 'SEND_NOTIFICATION',
 '{"roles": ["Supervisor", "UnitHead"], "titlePrefix": "⚠️ مجوز کار منقضی:"}',
 1),

-- قانون ۹: Asset Deficiency Critical → Action Register
('rule_asset_deficiency',
 'نقص بحرانی دارایی → Action Register',
 'نقص‌های بحرانی در بازرسی دارایی‌ها به Action Register منتقل شوند',
 'Assets-Deficiencies', 'RECORD_CREATED',
 '{"field": "severity", "operator": "in", "value": ["Critical", "Major"]}',
 'Action-Register', 'CREATE_RECORD',
 '{"titlePrefix": "[یکپارچگی دارایی]", "priority": "Critical", "tags": ["MI", "Asset"]}',
 5)

ON CONFLICT (id) DO NOTHING;

-- ─── Tracking ────────────────────────────────────────────────────────────────
INSERT INTO schema_migrations (version) VALUES ('005_integration_engine')
  ON CONFLICT DO NOTHING;
