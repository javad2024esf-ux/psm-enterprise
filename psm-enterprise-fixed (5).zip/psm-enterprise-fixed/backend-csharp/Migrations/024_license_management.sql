-- Migration: 024_license_management
-- License management tables for PSM Enterprise

-- ═══════════════════════════════════════════════════════════════════════════
-- License Activation Table
-- ═══════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS license_activations (
    id SERIAL PRIMARY KEY,
    license_key VARCHAR(256) NOT NULL UNIQUE,
    organization VARCHAR(256) NOT NULL,
    contact_email VARCHAR(256),
    machine_id VARCHAR(64),
    
    -- Status: active, inactive, expired, revoked
    status VARCHAR(32) NOT NULL DEFAULT 'inactive',
    
    -- Timestamps
    issued_at TIMESTAMP WITH TIME ZONE,
    activated_at TIMESTAMP WITH TIME ZONE,
    deactivated_at TIMESTAMP WITH TIME ZONE,
    expires_at TIMESTAMP WITH TIME ZONE,
    
    -- License details
    license_type VARCHAR(32) DEFAULT 'enterprise',
    max_users INTEGER DEFAULT 100,
    current_users INTEGER DEFAULT 0,
    max_projects INTEGER DEFAULT 1000,
    current_projects INTEGER DEFAULT 0,
    
    -- Metadata (JSON)
    metadata JSONB,
    
    -- Audit timestamps
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (NOW() AT TIME ZONE 'UTC'),
    updated_at TIMESTAMP WITH TIME ZONE
    
    -- Note: Unique constraint for active licenses created via partial index below
);

CREATE INDEX idx_license_activations_status ON license_activations(status);
CREATE INDEX idx_license_activations_organization ON license_activations(organization);
CREATE INDEX idx_license_activations_activated_at ON license_activations(activated_at DESC);
CREATE INDEX idx_license_activations_expires_at ON license_activations(expires_at);
CREATE UNIQUE INDEX idx_license_activations_active_org ON license_activations(organization) WHERE status = 'active';

-- ═══════════════════════════════════════════════════════════════════════════
-- License Audit Events Table
-- ═══════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS license_audit_events (
    id SERIAL PRIMARY KEY,
    
    -- Event details
    event_type VARCHAR(64) NOT NULL, -- ACTIVATE, DEACTIVATE, VALIDATE_FAILED, etc.
    license_key VARCHAR(256),
    organization VARCHAR(256),
    status VARCHAR(32),
    
    -- Request context
    ip_address INET,
    user_agent VARCHAR(512),
    
    -- Event data
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (NOW() AT TIME ZONE 'UTC'),
    details JSONB,
    
    -- Indexes
    CONSTRAINT fk_license_key FOREIGN KEY (license_key) 
        REFERENCES license_activations(license_key) ON DELETE CASCADE
);

CREATE INDEX idx_license_audit_events_event_type ON license_audit_events(event_type);
CREATE INDEX idx_license_audit_events_organization ON license_audit_events(organization);
CREATE INDEX idx_license_audit_events_timestamp ON license_audit_events(timestamp DESC);
CREATE INDEX idx_license_audit_events_license_key ON license_audit_events(license_key);

-- ═══════════════════════════════════════════════════════════════════════════
-- License Configuration Table
-- ═══════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS license_config (
    id SERIAL PRIMARY KEY,
    config_key VARCHAR(128) NOT NULL UNIQUE,
    config_value TEXT,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (NOW() AT TIME ZONE 'UTC'),
    updated_at TIMESTAMP WITH TIME ZONE
);

-- Insert default config
INSERT INTO license_config (config_key, config_value, description)
VALUES 
    ('license_secret_key', 'license_secret_2024_psm_enterprise_v9', 'HMAC secret for license validation'),
    ('trial_mode_enabled', 'true', 'Allow trial mode if no license'),
    ('trial_days_limit', '30', 'Days allowed in trial mode'),
    ('enable_offline_mode', 'false', 'Allow offline usage after activation')
ON CONFLICT (config_key) DO NOTHING;

-- ═══════════════════════════════════════════════════════════════════════════
-- Data Integrity Comments
-- ═══════════════════════════════════════════════════════════════════════════
COMMENT ON TABLE license_activations IS 
    'Enterprise license activation records with HMAC-SHA256 key validation';

COMMENT ON TABLE license_audit_events IS 
    'Audit trail for all license operations (activation, validation, deactivation)';

COMMENT ON COLUMN license_activations.license_key IS 
    'HMAC-signed license key (data + signature)';

COMMENT ON COLUMN license_activations.status IS 
    'License status: active, inactive, expired, revoked';

COMMENT ON COLUMN license_activations.machine_id IS 
    'System machine identifier for license binding (optional)';

COMMENT ON COLUMN license_activations.metadata IS 
    'Additional metadata: activation_ip, activated_by, etc.';
