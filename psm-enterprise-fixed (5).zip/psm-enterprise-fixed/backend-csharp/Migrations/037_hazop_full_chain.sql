-- ============================================================
-- Migration 037: HAZOP Full Chain
-- Study → Node → Deviation → Cause → Consequence → Safeguard
--             → Recommendation → Action Register
--             → Workflow → Notification → Audit
-- ============================================================
BEGIN;

-- ─── 1. hazop_causes ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS hazop_causes (
  id              TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  deviation_id    TEXT        NOT NULL,
  study_id        TEXT,
  description     TEXT        NOT NULL,
  cause_type      VARCHAR(50) DEFAULT 'Process'
                  CHECK (cause_type IN ('Process','Human','Equipment','External','Management')),
  likelihood      INT         DEFAULT 3 CHECK (likelihood BETWEEN 1 AND 5),
  initiating_event TEXT,
  frequency_basis TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by      TEXT,
  updated_at      TIMESTAMPTZ,
  deleted         BOOLEAN     NOT NULL DEFAULT false
);

-- ─── 2. hazop_consequences ──────────────────────────────────
CREATE TABLE IF NOT EXISTS hazop_consequences (
  id              TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  deviation_id    TEXT        NOT NULL,
  study_id        TEXT,
  description     TEXT        NOT NULL,
  consequence_category VARCHAR(50) DEFAULT 'Safety'
                  CHECK (consequence_category IN ('Safety','Environmental','Financial','Operational','Reputational')),
  severity        INT         DEFAULT 3 CHECK (severity BETWEEN 1 AND 5),
  affected_population TEXT,
  credible        BOOLEAN     NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by      TEXT,
  updated_at      TIMESTAMPTZ,
  deleted         BOOLEAN     NOT NULL DEFAULT false
);

-- ─── 3. hazop_safeguards ────────────────────────────────────
CREATE TABLE IF NOT EXISTS hazop_safeguards (
  id              TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  deviation_id    TEXT        NOT NULL,
  study_id        TEXT,
  description     TEXT        NOT NULL,
  safeguard_type  VARCHAR(50) DEFAULT 'Prevention'
                  CHECK (safeguard_type IN ('Prevention','Detection','Mitigation','Emergency')),
  ipl_credited    BOOLEAN     NOT NULL DEFAULT false,
  pfd             NUMERIC(10,6),
  tag_number      TEXT,
  status          VARCHAR(50) DEFAULT 'Active'
                  CHECK (status IN ('Active','Inactive','Under Review','Bypassed')),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by      TEXT,
  updated_at      TIMESTAMPTZ,
  deleted         BOOLEAN     NOT NULL DEFAULT false
);

-- ─── 4. hazop_workflow_instances ────────────────────────────
-- (مکمل جدول workflow_instances عمومی — ولی اختصاصی HAZOP)
CREATE TABLE IF NOT EXISTS hazop_workflow_instances (
  id              TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  entity_type     VARCHAR(50) NOT NULL,  -- 'study' | 'deviation' | 'recommendation'
  entity_id       TEXT        NOT NULL,
  study_id        TEXT,
  current_state   VARCHAR(100) NOT NULL DEFAULT 'Draft',
  previous_state  VARCHAR(100),
  assigned_to     TEXT,
  assigned_role   VARCHAR(100),
  due_date        TIMESTAMPTZ,
  priority        VARCHAR(50)  DEFAULT 'Normal'
                  CHECK (priority IN ('Low','Normal','High','Critical')),
  comments        TEXT,
  started_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at    TIMESTAMPTZ,
  created_by      TEXT,
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted         BOOLEAN     NOT NULL DEFAULT false,
  UNIQUE (entity_type, entity_id)
);

CREATE TABLE IF NOT EXISTS hazop_workflow_history (
  id              TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  instance_id     TEXT        NOT NULL,
  entity_type     VARCHAR(50) NOT NULL,
  entity_id       TEXT        NOT NULL,
  study_id        TEXT,
  from_state      VARCHAR(100),
  to_state        VARCHAR(100) NOT NULL,
  action          VARCHAR(100) NOT NULL,
  actor_id        TEXT,
  actor_name      TEXT,
  comment         TEXT,
  transitioned_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── 5. hazop_notifications ─────────────────────────────────
CREATE TABLE IF NOT EXISTS hazop_notifications (
  id              TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  study_id        TEXT,
  entity_type     VARCHAR(50),   -- 'deviation' | 'recommendation' | 'action' | 'workflow'
  entity_id       TEXT,
  recipient_id    TEXT        NOT NULL,
  notification_type VARCHAR(100) NOT NULL,
  title           TEXT        NOT NULL,
  body            TEXT,
  priority        VARCHAR(50)  DEFAULT 'Normal',
  is_read         BOOLEAN     NOT NULL DEFAULT false,
  read_at         TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── 6. hazop_audit_trail ────────────────────────────────────
CREATE TABLE IF NOT EXISTS hazop_audit_trail (
  id              TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  study_id        TEXT,
  entity_type     VARCHAR(50)  NOT NULL,  -- 'study'|'node'|'deviation'|'cause'|'consequence'|'safeguard'|'recommendation'|'action'|'workflow'
  entity_id       TEXT         NOT NULL,
  action          VARCHAR(100) NOT NULL,  -- 'CREATE'|'UPDATE'|'DELETE'|'STATUS_CHANGE'|'WORKFLOW_TRANSITION'|'NOTIFY'
  actor_id        TEXT,
  actor_name      TEXT,
  old_values      JSONB,
  new_values      JSONB,
  ip_address      TEXT,
  user_agent      TEXT,
  occurred_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Foreign Keys (idempotent) ────────────────────────────────

DO $$
BEGIN
  -- causes → deviations
  IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_name='fk_cause_deviation') THEN
    ALTER TABLE hazop_causes ADD CONSTRAINT fk_cause_deviation FOREIGN KEY (deviation_id) REFERENCES hazop_deviations(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_name='fk_cause_study') THEN
    ALTER TABLE hazop_causes ADD CONSTRAINT fk_cause_study FOREIGN KEY (study_id) REFERENCES hazop_studies(id) ON DELETE CASCADE;
  END IF;

  -- consequences → deviations
  IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_name='fk_consequence_deviation') THEN
    ALTER TABLE hazop_consequences ADD CONSTRAINT fk_consequence_deviation FOREIGN KEY (deviation_id) REFERENCES hazop_deviations(id) ON DELETE CASCADE;
  END IF;

  -- safeguards → deviations
  IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_name='fk_safeguard_deviation') THEN
    ALTER TABLE hazop_safeguards ADD CONSTRAINT fk_safeguard_deviation FOREIGN KEY (deviation_id) REFERENCES hazop_deviations(id) ON DELETE CASCADE;
  END IF;

  -- workflow history → instances
  IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_name='fk_wf_history_instance') THEN
    ALTER TABLE hazop_workflow_history ADD CONSTRAINT fk_wf_history_instance FOREIGN KEY (instance_id) REFERENCES hazop_workflow_instances(id) ON DELETE CASCADE;
  END IF;
END $$;

-- ─── Indexes ─────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_causes_deviation      ON hazop_causes(deviation_id);
CREATE INDEX IF NOT EXISTS idx_causes_study          ON hazop_causes(study_id);
CREATE INDEX IF NOT EXISTS idx_consequences_deviation ON hazop_consequences(deviation_id);
CREATE INDEX IF NOT EXISTS idx_safeguards_deviation  ON hazop_safeguards(deviation_id);
CREATE INDEX IF NOT EXISTS idx_hazop_wf_entity       ON hazop_workflow_instances(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_hazop_wf_study        ON hazop_workflow_instances(study_id);
CREATE INDEX IF NOT EXISTS idx_hazop_wf_hist_inst    ON hazop_workflow_history(instance_id);
CREATE INDEX IF NOT EXISTS idx_hazop_notif_recipient ON hazop_notifications(recipient_id);
CREATE INDEX IF NOT EXISTS idx_hazop_notif_study     ON hazop_notifications(study_id);
CREATE INDEX IF NOT EXISTS idx_hazop_audit_entity    ON hazop_audit_trail(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_hazop_audit_study     ON hazop_audit_trail(study_id);
CREATE INDEX IF NOT EXISTS idx_hazop_audit_actor     ON hazop_audit_trail(actor_id);

-- ─── seed workflow states for HAZOP ──────────────────────────
-- این insert فقط اگر جدول workflow_definitions وجود داشته باشد
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name='workflow_definitions') THEN
    INSERT INTO workflow_definitions (id, module, name, version, config, is_active, created_at)
    VALUES (
      gen_random_uuid()::text,
      'HAZOP',
      'HAZOP Full Chain Workflow',
      1,
      jsonb_build_object(
        'states', '["Draft","Under Review","Approved","Action Required","Closed","Archived"]'::jsonb,
        'transitions', '[
          {"from":"Draft","to":"Under Review","action":"submit","roles":["Engineer","Admin"]},
          {"from":"Under Review","to":"Approved","action":"approve","roles":["Manager","Admin"]},
          {"from":"Under Review","to":"Draft","action":"reject","roles":["Manager","Admin"]},
          {"from":"Approved","to":"Action Required","action":"raise_action","roles":["Engineer","Manager","Admin"]},
          {"from":"Action Required","to":"Closed","action":"close","roles":["Manager","Admin"]},
          {"from":"Approved","to":"Closed","action":"close","roles":["Manager","Admin"]},
          {"from":"Closed","to":"Archived","action":"archive","roles":["Admin"]}
        ]'::jsonb
      ),
      true,
      NOW()
    )
    ON CONFLICT DO NOTHING;
  END IF;
END $$;

INSERT INTO schema_migrations (version, applied_at)
VALUES ('037_hazop_full_chain', NOW())
ON CONFLICT DO NOTHING;

COMMIT;
