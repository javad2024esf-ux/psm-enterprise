BEGIN;

CREATE TABLE IF NOT EXISTS hazop_team_members (
  id            TEXT         PRIMARY KEY DEFAULT gen_random_uuid()::text,
  study_id      TEXT,
  user_id       TEXT,
  user_name     VARCHAR(100) NOT NULL,
  email         VARCHAR(100),
  role          VARCHAR(100) NOT NULL CHECK (role IN (
    'Leader','Scribe','Process Engineer','Operations',
    'Maintenance','Instrumentation','HSE','External'
  )),
  department    VARCHAR(100),
  join_date     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  is_active     BOOLEAN      NOT NULL DEFAULT TRUE,
  attendance    VARCHAR(20)  DEFAULT 'Present' CHECK (attendance IN ('Present','Absent','Late','Excused')),
  meeting_date  DATE,
  sign_off      BOOLEAN      DEFAULT FALSE,
  sign_off_date DATE,
  comments      TEXT
);

CREATE TABLE IF NOT EXISTS hazop_team_meetings (
  id                 TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  study_id           TEXT,
  meeting_date       TIMESTAMPTZ,
  facilitator        VARCHAR(100),
  attendees          TEXT,
  agenda             TEXT,
  minutes            TEXT,
  decisions_recorded TEXT,
  next_meeting_date  TIMESTAMPTZ,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_studies') THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.table_constraints
      WHERE table_name = 'hazop_team_members' AND constraint_name = 'fk_team_members_study'
    ) THEN
      ALTER TABLE hazop_team_members ADD CONSTRAINT fk_team_members_study
        FOREIGN KEY (study_id) REFERENCES hazop_studies(id) ON DELETE CASCADE;
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM information_schema.table_constraints
      WHERE table_name = 'hazop_team_meetings' AND constraint_name = 'fk_team_meetings_study'
    ) THEN
      ALTER TABLE hazop_team_meetings ADD CONSTRAINT fk_team_meetings_study
        FOREIGN KEY (study_id) REFERENCES hazop_studies(id) ON DELETE CASCADE;
    END IF;

    ALTER TABLE hazop_studies ADD COLUMN IF NOT EXISTS study_leader    VARCHAR(100);
    ALTER TABLE hazop_studies ADD COLUMN IF NOT EXISTS team_size       INTEGER DEFAULT 0;
    ALTER TABLE hazop_studies ADD COLUMN IF NOT EXISTS last_meeting_at TIMESTAMPTZ;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_team_members_study      ON hazop_team_members(study_id);
CREATE INDEX IF NOT EXISTS idx_team_members_role       ON hazop_team_members(role);
CREATE INDEX IF NOT EXISTS idx_team_members_active     ON hazop_team_members(is_active);
CREATE INDEX IF NOT EXISTS idx_team_members_attendance ON hazop_team_members(attendance);
CREATE INDEX IF NOT EXISTS idx_team_members_signoff    ON hazop_team_members(sign_off);
CREATE INDEX IF NOT EXISTS idx_team_meetings_study     ON hazop_team_meetings(study_id);
CREATE INDEX IF NOT EXISTS idx_team_meetings_date      ON hazop_team_meetings(meeting_date);

INSERT INTO schema_migrations (version, applied_at)
VALUES ('010_hazop_team', NOW())
ON CONFLICT DO NOTHING;

COMMIT;
