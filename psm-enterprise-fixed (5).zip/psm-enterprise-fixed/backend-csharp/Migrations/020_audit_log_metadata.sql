-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║  Migration 020 : audit_log.metadata column                               ║
-- ╚══════════════════════════════════════════════════════════════════════════╝
-- src/services/audit.service.cjs's writeAuditLog() always inserts a
-- `metadata` value, but the audit_log table (001_initial_schema.sql) never
-- had that column. Every single audit write (fired on every record
-- create/update/delete, including all HAZOP actions) was therefore failing
-- with "column \"metadata\" of relation \"audit_log\" does not exist" and
-- spamming the server logs — masking real errors during debugging.

ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS metadata JSONB;
