-- ═══════════════════════════════════════════════════════════════════════════
-- Migration 017: Refresh-token rotation
-- Real JWT access tokens are short-lived (15m). Refresh tokens are opaque,
-- stored hashed (sha256), rotated on every use, and chained via `family_id`
-- so that reuse of a stale token revokes the whole family (theft detection).
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS refresh_tokens (
  id           TEXT        PRIMARY KEY,
  user_id      TEXT        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token        TEXT        NOT NULL UNIQUE,
  revoked      BOOLEAN     NOT NULL DEFAULT FALSE,
  expires_at   TIMESTAMPTZ NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user  ON refresh_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_token ON refresh_tokens(token);
