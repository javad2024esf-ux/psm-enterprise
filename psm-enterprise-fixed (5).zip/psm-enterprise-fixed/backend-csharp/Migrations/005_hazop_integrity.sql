
BEGIN;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_nodes') THEN
    ALTER TABLE hazop_nodes DROP CONSTRAINT IF EXISTS fk_hazop_nodes_study CASCADE;
    ALTER TABLE hazop_nodes
      ADD CONSTRAINT fk_hazop_nodes_study
      FOREIGN KEY (study_id) REFERENCES hazop_studies(id) ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_deviations') THEN
    ALTER TABLE hazop_deviations DROP CONSTRAINT IF EXISTS fk_hazop_deviations_study CASCADE;
    ALTER TABLE hazop_deviations DROP CONSTRAINT IF EXISTS fk_hazop_deviations_node  CASCADE;

    ALTER TABLE hazop_deviations
      ADD CONSTRAINT fk_hazop_deviations_study
      FOREIGN KEY (study_id) REFERENCES hazop_studies(id) ON DELETE CASCADE ON UPDATE CASCADE;

    ALTER TABLE hazop_deviations
      ADD CONSTRAINT fk_hazop_deviations_node
      FOREIGN KEY (node_id) REFERENCES hazop_nodes(id) ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
END $$;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_studies') THEN
    CREATE INDEX IF NOT EXISTS idx_hazop_studies_unit_status  ON hazop_studies(unit, status);
    CREATE INDEX IF NOT EXISTS idx_hazop_studies_facility     ON hazop_studies(facility);
    CREATE INDEX IF NOT EXISTS idx_hazop_studies_created      ON hazop_studies(created_at DESC);
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_nodes') THEN
    CREATE INDEX IF NOT EXISTS idx_hazop_nodes_study          ON hazop_nodes(study_id);
    CREATE INDEX IF NOT EXISTS idx_hazop_nodes_study_number   ON hazop_nodes(study_id, node_number);
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_deviations') THEN
    CREATE INDEX IF NOT EXISTS idx_hazop_deviations_study        ON hazop_deviations(study_id);
    CREATE INDEX IF NOT EXISTS idx_hazop_deviations_node         ON hazop_deviations(node_id);
    CREATE INDEX IF NOT EXISTS idx_hazop_deviations_study_status ON hazop_deviations(study_id, status);
    CREATE INDEX IF NOT EXISTS idx_hazop_deviations_risk_level   ON hazop_deviations(risk_level);
    CREATE INDEX IF NOT EXISTS idx_hazop_deviations_created      ON hazop_deviations(created_at DESC);
  END IF;
END $$;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_studies') THEN
    ALTER TABLE hazop_studies
      ADD COLUMN IF NOT EXISTS progress  INTEGER DEFAULT 0,
      ADD COLUMN IF NOT EXISTS objective TEXT,
      ADD COLUMN IF NOT EXISTS tags      TEXT;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_nodes') THEN
    ALTER TABLE hazop_nodes
      ADD COLUMN IF NOT EXISTS color                VARCHAR(7),
      ADD COLUMN IF NOT EXISTS operating_conditions TEXT;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_deviations') THEN
    ALTER TABLE hazop_deviations
      ADD COLUMN IF NOT EXISTS starred             BOOLEAN DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS bowtie_causes       TEXT,
      ADD COLUMN IF NOT EXISTS bowtie_consequences TEXT,
      ADD COLUMN IF NOT EXISTS bowtie_barriers     TEXT;
  END IF;
END $$;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_studies') THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.table_constraints
      WHERE table_name = 'hazop_studies' AND constraint_name = 'chk_hazop_study_status'
    ) THEN
      ALTER TABLE hazop_studies
        ADD CONSTRAINT chk_hazop_study_status
        CHECK (status IN ('Draft','Active','Planning','In Progress','Completed','Approved','Archived'));
    END IF;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_deviations') THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.table_constraints
      WHERE table_name = 'hazop_deviations' AND constraint_name = 'chk_hazop_deviation_status'
    ) THEN
      ALTER TABLE hazop_deviations
        ADD CONSTRAINT chk_hazop_deviation_status
        CHECK (status IN ('Open','Under Review','Closed','Action Required'));
    END IF;
  END IF;
END $$;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_studies')    THEN ANALYZE hazop_studies;    END IF;
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_nodes')      THEN ANALYZE hazop_nodes;      END IF;
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_deviations') THEN ANALYZE hazop_deviations; END IF;
END $$;
CREATE OR REPLACE FUNCTION hazop_audit_trigger()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO audit_log (action, entity_type, entity_id, new_data, created_by)
    VALUES ('INSERT', TG_TABLE_NAME, NEW.id, row_to_json(NEW)::jsonb, CURRENT_USER);
  ELSIF TG_OP = 'UPDATE' THEN
    INSERT INTO audit_log (action, entity_type, entity_id, old_data, new_data, created_by)
    VALUES ('UPDATE', TG_TABLE_NAME, NEW.id, row_to_json(OLD)::jsonb, row_to_json(NEW)::jsonb, CURRENT_USER);
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO audit_log (action, entity_type, entity_id, old_data, created_by)
    VALUES ('DELETE', TG_TABLE_NAME, OLD.id, row_to_json(OLD)::jsonb, CURRENT_USER);
  END IF;
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_studies') THEN
    DROP TRIGGER IF EXISTS hazop_studies_audit ON hazop_studies;
    CREATE TRIGGER hazop_studies_audit
      AFTER INSERT OR UPDATE OR DELETE ON hazop_studies
      FOR EACH ROW EXECUTE FUNCTION hazop_audit_trigger();
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_nodes') THEN
    DROP TRIGGER IF EXISTS hazop_nodes_audit ON hazop_nodes;
    CREATE TRIGGER hazop_nodes_audit
      AFTER INSERT OR UPDATE OR DELETE ON hazop_nodes
      FOR EACH ROW EXECUTE FUNCTION hazop_audit_trigger();
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_deviations') THEN
    DROP TRIGGER IF EXISTS hazop_deviations_audit ON hazop_deviations;
    CREATE TRIGGER hazop_deviations_audit
      AFTER INSERT OR UPDATE OR DELETE ON hazop_deviations
      FOR EACH ROW EXECUTE FUNCTION hazop_audit_trigger();
  END IF;
END $$;
INSERT INTO schema_migrations (version, applied_at)
VALUES ('005_hazop_integrity', NOW())
ON CONFLICT DO NOTHING;

COMMIT;

