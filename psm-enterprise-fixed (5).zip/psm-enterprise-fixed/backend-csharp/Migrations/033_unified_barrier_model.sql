-- ════════════════════════════════════════════════════════════════════════════════════
-- Migration 033: Unified Barrier Model
-- Integrates LOPA, BowTie and Barrier Management into one unified risk model.
--
-- Changes:
--   1. Fix status CHECK on barriers to include 'OutOfService' (was 'Inactive')
--   2. Add side column to bowtie_barriers to distinguish Preventive vs Recovery
--   3. Add lopa_ipl_id back-link on bowtie_barriers for direct IPL→BowTie traceability
--   4. Add bowtie_barrier_id forward-link on lopa_ipls for symmetry
--   5. Create pg function auto_create_barrier_for_ipl() + trigger
--   6. Create pg function sync_barrier_status_to_links() + trigger
--   7. Add barrier_audit_log for full audit trail beyond barrier_status_history
--   8. Add incident_barrier_context view for Req-6 (display related studies when 
--      incident references a barrier)
-- ════════════════════════════════════════════════════════════════════════════════════

BEGIN;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 1. Fix barriers.status CHECK — add 'OutOfService', keep backward compat
-- ─────────────────────────────────────────────────────────────────────────────────────

ALTER TABLE barriers
    DROP CONSTRAINT IF EXISTS barriers_status_check;

ALTER TABLE barriers
    ADD CONSTRAINT barriers_status_check
    CHECK (status IN ('Active','Degraded','Failed','OutOfService'));

-- Migrate legacy 'Inactive' rows if any
UPDATE barriers SET status = 'OutOfService' WHERE status = 'Inactive';

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 2. bowtie_barriers: add side column (Preventive vs Recovery) and IPL back-link
-- ─────────────────────────────────────────────────────────────────────────────────────

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'bowtie_barriers') THEN
    -- side column distinguishes Preventive (left of top event) vs Recovery (right)
    ALTER TABLE bowtie_barriers
      ADD COLUMN IF NOT EXISTS bowtie_side TEXT DEFAULT 'Preventive'
        CHECK (bowtie_side IN ('Preventive','Recovery'));

    -- back-link to the LOPA IPL that originated this BowTie barrier
    ALTER TABLE bowtie_barriers
      ADD COLUMN IF NOT EXISTS lopa_ipl_id TEXT
        REFERENCES lopa_ipls(id) ON DELETE SET NULL;

    -- Fix status CHECK to include OutOfService
    ALTER TABLE bowtie_barriers
      DROP CONSTRAINT IF EXISTS bowtie_barriers_barrier_status_check;

    ALTER TABLE bowtie_barriers
      ADD CONSTRAINT bowtie_barriers_barrier_status_check
      CHECK (barrier_status IN ('Active','Degraded','Failed','OutOfService','Under Test'));

    CREATE INDEX IF NOT EXISTS idx_bowtie_barriers_lopa_ipl ON bowtie_barriers(lopa_ipl_id);
    CREATE INDEX IF NOT EXISTS idx_bowtie_barriers_bowtie_side ON bowtie_barriers(bowtie_side);
  END IF;
END $$;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 3. lopa_ipls: add forward link to bowtie_barrier + unified_barrier
-- ─────────────────────────────────────────────────────────────────────────────────────

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'lopa_ipls') THEN
    ALTER TABLE lopa_ipls
      ADD COLUMN IF NOT EXISTS bowtie_barrier_id TEXT
        REFERENCES bowtie_barriers(id) ON DELETE SET NULL;

    CREATE INDEX IF NOT EXISTS idx_lopa_ipls_bowtie_barrier ON lopa_ipls(bowtie_barrier_id);
  END IF;
END $$;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 4. barrier_audit_log — richer than barrier_status_history; captures any field change
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS barrier_audit_log (
  id                  TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  barrier_id          TEXT        NOT NULL REFERENCES barriers(id) ON DELETE CASCADE,
  action              TEXT        NOT NULL, -- 'STATUS_CHANGE','FIELD_UPDATE','CREATED','DELETED','SYNC_LOPA','SYNC_BOWTIE'
  field_name          TEXT,
  old_value           TEXT,
  new_value           TEXT,
  reason              TEXT,
  triggered_by        TEXT,  -- 'user','system','cascade','trigger'
  triggered_by_entity TEXT,  -- entity type: 'incident', 'bowtie', 'lopa', etc.
  triggered_by_id     TEXT,  -- entity id
  changed_by          TEXT,
  changed_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  data                JSONB       NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_barrier_audit_log_barrier   ON barrier_audit_log(barrier_id);
CREATE INDEX IF NOT EXISTS idx_barrier_audit_log_action    ON barrier_audit_log(action);
CREATE INDEX IF NOT EXISTS idx_barrier_audit_log_date      ON barrier_audit_log(changed_at);
CREATE INDEX IF NOT EXISTS idx_barrier_audit_log_triggered ON barrier_audit_log(triggered_by_entity, triggered_by_id);

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 5. TRIGGER FUNCTION: Auto-create a Barrier record whenever a LOPA IPL is inserted
--    (Requirement 1: Every LOPA IPL shall automatically create a Barrier)
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION auto_create_barrier_for_ipl()
RETURNS TRIGGER AS $$
DECLARE
  v_barrier_id TEXT;
  v_barrier_type TEXT;
  v_effectiveness NUMERIC(4,3);
BEGIN
  -- Skip if a barrier already exists for this IPL
  IF EXISTS (SELECT 1 FROM barriers WHERE lopa_ipl_id = NEW.id AND deleted = FALSE) THEN
    RETURN NEW;
  END IF;

  -- Map IPL type to barrier type
  v_barrier_type := CASE UPPER(TRIM(COALESCE(NEW.ipl_type,'')))
    WHEN 'ENGINEERING'          THEN 'Engineering'
    WHEN 'ADMINISTRATIVE'       THEN 'Administrative'
    WHEN 'PROCEDURAL'           THEN 'Procedural'
    WHEN 'PROCEDURE'            THEN 'Procedural'
    WHEN 'SIS'                  THEN 'SIS'
    WHEN 'SIF'                  THEN 'SIS'
    WHEN 'DETECTION'            THEN 'Detection'
    WHEN 'ALARM'                THEN 'Detection'
    WHEN 'BPCS'                 THEN 'Detection'
    ELSE 'Engineering'
  END;

  -- Derive effectiveness from PFD: effectiveness = 1 - PFD  (clamped 0.01–0.999)
  v_effectiveness := GREATEST(0.001, LEAST(0.999,
    CASE WHEN NEW.pfd > 0 AND NEW.pfd < 1 THEN (1.0 - NEW.pfd)::NUMERIC(4,3)
         ELSE 0.9
    END));

  v_barrier_id := gen_random_uuid()::text;

  INSERT INTO barriers (
    id, lopa_ipl_id, barrier_name, barrier_type, description,
    owner_discipline, owner_contact, audit_interval,
    effectiveness_rating, status, critical_flag,
    created_at, updated_at, data
  ) VALUES (
    v_barrier_id,
    NEW.id,
    COALESCE(NEW.ipl_name, 'IPL Barrier'),
    v_barrier_type,
    NEW.description,
    NEW.owner,
    NULL,
    NEW.audit_interval,
    v_effectiveness,
    'Active',
    (UPPER(TRIM(COALESCE(NEW.ipl_type,''))) IN ('SIS','SIF')),
    NOW(),
    NOW(),
    '{}'::jsonb
  );

  -- Back-link the IPL to the barrier
  UPDATE lopa_ipls SET risk_barrier_id = v_barrier_id, last_status_sync = NOW()
  WHERE id = NEW.id;

  -- Audit
  INSERT INTO barrier_audit_log (barrier_id, action, new_value, triggered_by, triggered_by_entity, triggered_by_id, changed_by)
  VALUES (v_barrier_id, 'CREATED', 'Active', 'trigger', 'lopa_ipl', NEW.id, 'system');

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_auto_create_barrier_for_ipl ON lopa_ipls;
CREATE TRIGGER trg_auto_create_barrier_for_ipl
  AFTER INSERT ON lopa_ipls
  FOR EACH ROW
  EXECUTE FUNCTION auto_create_barrier_for_ipl();

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 6. FUNCTION: Full cascade when barrier status changes
--    - Updates linked LOPA IPL status
--    - Updates linked BowTie barrier status
--    - Records audit history in BOTH barrier_status_history AND barrier_audit_log
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION update_barrier_status_cascade(
  p_barrier_id TEXT,
  p_new_status TEXT,
  p_reason     TEXT    DEFAULT NULL,
  p_incident_id TEXT   DEFAULT NULL,
  p_changed_by  TEXT   DEFAULT NULL
) RETURNS TABLE(
  success       BOOLEAN,
  message       TEXT,
  affected_rows INTEGER
) AS $$
DECLARE
  v_affected        INTEGER := 0;
  v_old_status      TEXT;
  v_lopa_ipl_id     TEXT;
  v_bowtie_barr_id  TEXT;
  v_lopa_new_status TEXT;
  v_bt_new_status   TEXT;
BEGIN
  -- Validate status value
  IF p_new_status NOT IN ('Active','Degraded','Failed','OutOfService') THEN
    RETURN QUERY SELECT FALSE, 'Invalid status. Must be Active, Degraded, Failed or OutOfService', 0;
    RETURN;
  END IF;

  -- Fetch current barrier
  SELECT status, lopa_ipl_id, bowtie_barrier_id
    INTO v_old_status, v_lopa_ipl_id, v_bowtie_barr_id
    FROM barriers
   WHERE id = p_barrier_id AND deleted = FALSE;

  IF v_old_status IS NULL THEN
    RETURN QUERY SELECT FALSE, 'Barrier not found', 0;
    RETURN;
  END IF;

  -- No-op guard
  IF v_old_status = p_new_status THEN
    RETURN QUERY SELECT TRUE, 'Status unchanged', 0;
    RETURN;
  END IF;

  -- 1) Update barrier
  UPDATE barriers
     SET status     = p_new_status,
         updated_at = NOW(),
         updated_by = p_changed_by
   WHERE id = p_barrier_id;
  v_affected := v_affected + 1;

  -- 2) Record barrier_status_history (existing table — backward compat)
  INSERT INTO barrier_status_history (
    id, barrier_id, previous_status, new_status,
    reason, triggered_by_incident, changed_by, changed_at
  ) VALUES (
    gen_random_uuid()::text,
    p_barrier_id,
    v_old_status,
    p_new_status,
    p_reason,
    p_incident_id,
    p_changed_by,
    NOW()
  );

  -- 3) Record barrier_audit_log
  INSERT INTO barrier_audit_log (
    barrier_id, action, field_name, old_value, new_value,
    reason, triggered_by, triggered_by_entity, triggered_by_id, changed_by
  ) VALUES (
    p_barrier_id, 'STATUS_CHANGE', 'status', v_old_status, p_new_status,
    p_reason,
    CASE WHEN p_incident_id IS NOT NULL THEN 'cascade' ELSE 'user' END,
    CASE WHEN p_incident_id IS NOT NULL THEN 'incident' ELSE NULL END,
    p_incident_id,
    p_changed_by
  );

  -- 4) Map barrier status → LOPA IPL status
  v_lopa_new_status := CASE p_new_status
    WHEN 'Failed'       THEN 'Failed'
    WHEN 'Degraded'     THEN 'Degraded'
    WHEN 'OutOfService' THEN 'Decommissioned'
    ELSE 'Active'
  END;

  -- 5) Update linked LOPA IPL
  IF v_lopa_ipl_id IS NOT NULL THEN
    UPDATE lopa_ipls
       SET status          = v_lopa_new_status,
           failure_count   = CASE WHEN p_new_status = 'Failed' THEN failure_count + 1 ELSE failure_count END,
           last_status_sync = NOW()
     WHERE id = v_lopa_ipl_id;
    v_affected := v_affected + 1;

    INSERT INTO barrier_audit_log (
      barrier_id, action, field_name, old_value, new_value,
      reason, triggered_by, triggered_by_entity, triggered_by_id, changed_by
    ) VALUES (
      p_barrier_id, 'SYNC_LOPA', 'lopa_ipl.status', NULL, v_lopa_new_status,
      'Cascade from barrier status change', 'cascade', 'lopa_ipl', v_lopa_ipl_id, 'system'
    );
  END IF;

  -- 6) Map barrier status → BowTie barrier status
  v_bt_new_status := CASE p_new_status
    WHEN 'Failed'       THEN 'Failed'
    WHEN 'Degraded'     THEN 'Degraded'
    WHEN 'OutOfService' THEN 'Failed'
    ELSE 'Active'
  END;

  -- 7) Update linked BowTie barrier
  IF v_bowtie_barr_id IS NOT NULL THEN
    UPDATE bowtie_barriers
       SET barrier_status = v_bt_new_status,
           is_degraded    = (p_new_status IN ('Degraded','Failed','OutOfService')),
           last_tested    = CASE WHEN p_new_status = 'Active' THEN NOW() ELSE last_tested END,
           updated_at     = NOW()
     WHERE id = v_bowtie_barr_id;
    v_affected := v_affected + 1;

    INSERT INTO barrier_audit_log (
      barrier_id, action, field_name, old_value, new_value,
      reason, triggered_by, triggered_by_entity, triggered_by_id, changed_by
    ) VALUES (
      p_barrier_id, 'SYNC_BOWTIE', 'bowtie_barrier.barrier_status', NULL, v_bt_new_status,
      'Cascade from barrier status change', 'cascade', 'bowtie_barrier', v_bowtie_barr_id, 'system'
    );
  END IF;

  RETURN QUERY SELECT TRUE, 'Barrier status updated and cascaded', v_affected;
END;
$$ LANGUAGE plpgsql;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 7. VIEW: incident_barrier_context
--    Satisfies Requirement 6 — when an Incident references a Barrier, display
--    Related HAZOP Studies, Deviations, LOPA Studies, Scenarios, BowTie Diagrams
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE OR REPLACE VIEW incident_barrier_context AS
SELECT
  inc.id                        AS incident_id,
  inc.incident_number,
  inc.title                     AS incident_title,
  inc.severity_actual           AS incident_severity,
  inc.status                    AS incident_status,
  inc.date_occurred,

  -- Barrier info
  b.id                          AS barrier_id,
  b.barrier_name,
  b.barrier_type,
  b.status                      AS barrier_status,
  b.critical_flag,
  ib.barrier_failure_type,
  ib.contribution_to_incident,

  -- LOPA IPL → LOPA Scenario → LOPA Study
  li.id                         AS lopa_ipl_id,
  li.ipl_name,
  li.ipl_type,
  ls.id                         AS lopa_scenario_id,
  ls.scenario_number,
  ls.initiating_event,
  ls.consequence_severity,
  ls.residual_risk,
  ls.risk_gap_met,
  lst.id                        AS lopa_study_id,
  lst.title                     AS lopa_study_title,

  -- BowTie
  bb.id                         AS bowtie_barrier_id,
  bb.description                AS bowtie_barrier_description,
  bb.bowtie_side,
  bd.id                         AS bowtie_diagram_id,
  bd.title                      AS bowtie_diagram_title,
  bd.top_event,

  -- HAZOP (via LOPA scenario's hazop_deviation_id)
  hd.id                         AS hazop_deviation_id,
  hd.deviation                  AS hazop_deviation,
  hd.guide_word,
  hd.parameter,
  hd.risk_level                 AS hazop_risk_level,
  hs.id                         AS hazop_study_id,
  hs.title                      AS hazop_study_title,

  -- HAZOP also via direct incident_hazop_mappings
  ihm.hazop_deviation_id        AS direct_hazop_deviation_id,
  ihm.hazop_study_id            AS direct_hazop_study_id

FROM incidents inc
INNER JOIN incident_barriers ib  ON inc.id = ib.incident_id
INNER JOIN barriers b            ON ib.barrier_id = b.id AND b.deleted = FALSE

-- LOPA IPL path
LEFT JOIN lopa_ipls li           ON b.lopa_ipl_id = li.id AND li.deleted = FALSE
LEFT JOIN lopa_scenarios ls      ON li.scenario_id = ls.id AND ls.deleted = FALSE
LEFT JOIN lopa_studies lst       ON ls.lopa_study_id = lst.id AND lst.deleted = FALSE

-- BowTie path
LEFT JOIN bowtie_barriers bb     ON b.bowtie_barrier_id = bb.id AND bb.deleted = FALSE
LEFT JOIN bowtie_diagrams bd     ON bb.diagram_id = bd.id AND bd.deleted = FALSE

-- HAZOP via LOPA scenario
LEFT JOIN hazop_deviations hd    ON ls.hazop_deviation_id = hd.id AND hd.deleted = FALSE
LEFT JOIN hazop_studies hs       ON hd.study_id = hs.id AND hs.deleted = FALSE

-- Direct HAZOP mappings on the incident
LEFT JOIN incident_hazop_mappings ihm ON inc.id = ihm.incident_id

WHERE inc.deleted = FALSE;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 8. FUNCTION: Get full impact analysis for a barrier
--    Used by GET /api/barriers/{id}/impact
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION get_barrier_full_impact(p_barrier_id TEXT)
RETURNS JSONB AS $$
DECLARE
  v_result JSONB;
BEGIN
  SELECT jsonb_build_object(
    'barrier_id',          b.id,
    'barrier_name',        b.barrier_name,
    'status',              b.status,
    'effectiveness_rating',b.effectiveness_rating,
    'critical_flag',       b.critical_flag,
    'lopa_ipl', jsonb_build_object(
      'id',        li.id,
      'ipl_name',  li.ipl_name,
      'ipl_type',  li.ipl_type,
      'pfd',       li.pfd,
      'status',    li.status
    ),
    'lopa_scenario', jsonb_build_object(
      'id',              ls.id,
      'scenario_number', ls.scenario_number,
      'initiating_event',ls.initiating_event,
      'residual_risk',   ls.residual_risk,
      'risk_gap_met',    ls.risk_gap_met
    ),
    'lopa_study', jsonb_build_object(
      'id',     lst.id,
      'title',  lst.title,
      'status', lst.status
    ),
    'bowtie_barrier', jsonb_build_object(
      'id',          bb.id,
      'description', bb.description,
      'bowtie_side', bb.bowtie_side,
      'status',      bb.barrier_status
    ),
    'bowtie_diagram', jsonb_build_object(
      'id',       bd.id,
      'title',    bd.title,
      'top_event',bd.top_event
    ),
    'hazop_deviation', jsonb_build_object(
      'id',        hd.id,
      'deviation', hd.deviation,
      'risk_level',hd.risk_level
    ),
    'hazop_study', jsonb_build_object(
      'id',    hs.id,
      'title', hs.title
    ),
    'linked_incidents', (
      SELECT COUNT(*) FROM incident_barriers ib2 WHERE ib2.barrier_id = p_barrier_id
    ),
    'status_history', (
      SELECT jsonb_agg(jsonb_build_object(
        'id',              bsh.id,
        'previous_status', bsh.previous_status,
        'new_status',      bsh.new_status,
        'reason',          bsh.reason,
        'changed_by',      bsh.changed_by,
        'changed_at',      bsh.changed_at
      ) ORDER BY bsh.changed_at DESC)
      FROM barrier_status_history bsh
      WHERE bsh.barrier_id = p_barrier_id
      LIMIT 20
    )
  )
  INTO v_result
  FROM barriers b
  LEFT JOIN lopa_ipls li      ON b.lopa_ipl_id = li.id
  LEFT JOIN lopa_scenarios ls ON li.scenario_id = ls.id
  LEFT JOIN lopa_studies lst  ON ls.lopa_study_id = lst.id
  LEFT JOIN bowtie_barriers bb ON b.bowtie_barrier_id = bb.id
  LEFT JOIN bowtie_diagrams bd ON bb.diagram_id = bd.id
  LEFT JOIN hazop_deviations hd ON ls.hazop_deviation_id = hd.id
  LEFT JOIN hazop_studies hs   ON hd.study_id = hs.id
  WHERE b.id = p_barrier_id AND b.deleted = FALSE;

  RETURN COALESCE(v_result, '{}'::jsonb);
END;
$$ LANGUAGE plpgsql STABLE;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 9. FUNCTION: Get full impact analysis for an incident
--    Used by GET /api/incidents/{id}/impact
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION get_incident_full_impact(p_incident_id TEXT)
RETURNS JSONB AS $$
DECLARE
  v_result JSONB;
BEGIN
  WITH
  inc AS (
    SELECT * FROM incidents WHERE id = p_incident_id AND deleted = FALSE
  ),
  barriers_agg AS (
    SELECT jsonb_agg(jsonb_build_object(
      'barrier_id',           b.id,
      'barrier_name',         b.barrier_name,
      'barrier_type',         b.barrier_type,
      'barrier_status',       b.status,
      'critical_flag',        b.critical_flag,
      'barrier_failure_type', ib.barrier_failure_type,
      'failure_evidence',     ib.failure_evidence,
      'contribution',         ib.contribution_to_incident
    )) AS val
    FROM incident_barriers ib
    JOIN barriers b ON ib.barrier_id = b.id AND b.deleted = FALSE
    WHERE ib.incident_id = p_incident_id
  ),
  hazop_studies_agg AS (
    SELECT jsonb_agg(DISTINCT jsonb_build_object(
      'id',    hs.id,
      'title', hs.title,
      'facility', hs.facility,
      'status', hs.status
    )) AS val
    FROM (
      -- Via direct incident_hazop_mappings
      SELECT DISTINCT ihm.hazop_study_id AS sid
      FROM incident_hazop_mappings ihm WHERE ihm.incident_id = p_incident_id
      UNION
      -- Via barrier → lopa_ipl → lopa_scenario → hazop_deviation → hazop_study
      SELECT DISTINCT hd.study_id AS sid
      FROM incident_barriers ib
      JOIN barriers b ON ib.barrier_id = b.id AND b.deleted = FALSE
      JOIN lopa_ipls li ON b.lopa_ipl_id = li.id AND li.deleted = FALSE
      JOIN lopa_scenarios ls ON li.scenario_id = ls.id AND ls.deleted = FALSE
      JOIN hazop_deviations hd ON ls.hazop_deviation_id = hd.id AND hd.deleted = FALSE
      WHERE ib.incident_id = p_incident_id
    ) src
    JOIN hazop_studies hs ON hs.id = src.sid AND hs.deleted = FALSE
  ),
  hazop_deviations_agg AS (
    SELECT jsonb_agg(DISTINCT jsonb_build_object(
      'id',         hd.id,
      'study_id',   hd.study_id,
      'deviation',  hd.deviation,
      'guide_word', hd.guide_word,
      'parameter',  hd.parameter,
      'risk_level', hd.risk_level
    )) AS val
    FROM (
      SELECT DISTINCT ihm.hazop_deviation_id AS did
      FROM incident_hazop_mappings ihm WHERE ihm.incident_id = p_incident_id
      UNION
      SELECT DISTINCT hd2.id AS did
      FROM incident_barriers ib
      JOIN barriers b ON ib.barrier_id = b.id AND b.deleted = FALSE
      JOIN lopa_ipls li ON b.lopa_ipl_id = li.id AND li.deleted = FALSE
      JOIN lopa_scenarios ls ON li.scenario_id = ls.id AND ls.deleted = FALSE
      JOIN hazop_deviations hd2 ON ls.hazop_deviation_id = hd2.id AND hd2.deleted = FALSE
      WHERE ib.incident_id = p_incident_id
    ) src
    JOIN hazop_deviations hd ON hd.id = src.did AND hd.deleted = FALSE
  ),
  lopa_studies_agg AS (
    SELECT jsonb_agg(DISTINCT jsonb_build_object(
      'id',     lst.id,
      'title',  lst.title,
      'status', lst.status
    )) AS val
    FROM (
      SELECT DISTINCT ilm.lopa_study_id AS sid
      FROM incident_lopa_mappings ilm WHERE ilm.incident_id = p_incident_id
      UNION
      SELECT DISTINCT lst2.id AS sid
      FROM incident_barriers ib
      JOIN barriers b ON ib.barrier_id = b.id AND b.deleted = FALSE
      JOIN lopa_ipls li ON b.lopa_ipl_id = li.id AND li.deleted = FALSE
      JOIN lopa_scenarios ls ON li.scenario_id = ls.id AND ls.deleted = FALSE
      JOIN lopa_studies lst2 ON ls.lopa_study_id = lst2.id AND lst2.deleted = FALSE
      WHERE ib.incident_id = p_incident_id
    ) src
    JOIN lopa_studies lst ON lst.id = src.sid AND lst.deleted = FALSE
  ),
  lopa_scenarios_agg AS (
    SELECT jsonb_agg(DISTINCT jsonb_build_object(
      'id',              ls.id,
      'lopa_study_id',   ls.lopa_study_id,
      'scenario_number', ls.scenario_number,
      'initiating_event',ls.initiating_event,
      'residual_risk',   ls.residual_risk,
      'risk_gap_met',    ls.risk_gap_met
    )) AS val
    FROM (
      SELECT DISTINCT ilm.lopa_scenario_id AS sid
      FROM incident_lopa_mappings ilm WHERE ilm.incident_id = p_incident_id
      UNION
      SELECT DISTINCT ls2.id AS sid
      FROM incident_barriers ib
      JOIN barriers b ON ib.barrier_id = b.id AND b.deleted = FALSE
      JOIN lopa_ipls li ON b.lopa_ipl_id = li.id AND li.deleted = FALSE
      JOIN lopa_scenarios ls2 ON li.scenario_id = ls2.id AND ls2.deleted = FALSE
      WHERE ib.incident_id = p_incident_id
    ) src
    JOIN lopa_scenarios ls ON ls.id = src.sid AND ls.deleted = FALSE
  ),
  bowtie_agg AS (
    SELECT jsonb_agg(DISTINCT jsonb_build_object(
      'id',       bd.id,
      'title',    bd.title,
      'top_event',bd.top_event,
      'hazard',   bd.hazard
    )) AS val
    FROM (
      SELECT DISTINCT ibm.bowtie_diagram_id AS did
      FROM incident_bowtie_mappings ibm WHERE ibm.incident_id = p_incident_id
      UNION
      SELECT DISTINCT bd2.id AS did
      FROM incident_barriers ib
      JOIN barriers b ON ib.barrier_id = b.id AND b.deleted = FALSE
      JOIN bowtie_barriers bb ON b.bowtie_barrier_id = bb.id AND bb.deleted = FALSE
      JOIN bowtie_diagrams bd2 ON bb.diagram_id = bd2.id AND bd2.deleted = FALSE
      WHERE ib.incident_id = p_incident_id
    ) src
    JOIN bowtie_diagrams bd ON bd.id = src.did AND bd.deleted = FALSE
  )
  SELECT jsonb_build_object(
    'incident_id',              p_incident_id,
    'incident_number',          inc.incident_number,
    'title',                    inc.title,
    'severity_actual',          inc.severity_actual,
    'date_occurred',            inc.date_occurred,
    'status',                   inc.status,
    'barriers',                 COALESCE(barriers_agg.val, '[]'::jsonb),
    'related_hazop_studies',    COALESCE(hazop_studies_agg.val, '[]'::jsonb),
    'related_hazop_deviations', COALESCE(hazop_deviations_agg.val, '[]'::jsonb),
    'related_lopa_studies',     COALESCE(lopa_studies_agg.val, '[]'::jsonb),
    'related_lopa_scenarios',   COALESCE(lopa_scenarios_agg.val, '[]'::jsonb),
    'related_bowtie_diagrams',  COALESCE(bowtie_agg.val, '[]'::jsonb),
    'summary', jsonb_build_object(
      'barriers_involved',       (SELECT COUNT(*) FROM incident_barriers WHERE incident_id = p_incident_id),
      'critical_barriers',       (
        SELECT COUNT(*) FROM incident_barriers ib2
        JOIN barriers b2 ON ib2.barrier_id = b2.id
        WHERE ib2.incident_id = p_incident_id AND b2.critical_flag = TRUE
      ),
      'hazop_studies_affected',  (SELECT COUNT(DISTINCT sid) FROM (
        SELECT ihm2.hazop_study_id AS sid FROM incident_hazop_mappings ihm2 WHERE ihm2.incident_id = p_incident_id
      ) x),
      'lopa_studies_affected',   (SELECT COUNT(DISTINCT sid) FROM (
        SELECT ilm2.lopa_study_id AS sid FROM incident_lopa_mappings ilm2 WHERE ilm2.incident_id = p_incident_id
      ) x),
      'bowtie_diagrams_affected',(SELECT COUNT(DISTINCT did) FROM (
        SELECT ibm2.bowtie_diagram_id AS did FROM incident_bowtie_mappings ibm2 WHERE ibm2.incident_id = p_incident_id
      ) x)
    )
  )
  INTO v_result
  FROM inc, barriers_agg, hazop_studies_agg, hazop_deviations_agg,
       lopa_studies_agg, lopa_scenarios_agg, bowtie_agg;

  RETURN COALESCE(v_result, '{}'::jsonb);
END;
$$ LANGUAGE plpgsql STABLE;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 10. RBAC: Register IUnifiedBarrier service + UnifiedBarrierRepository
-- ─────────────────────────────────────────────────────────────────────────────────────

INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES
  ('role_admin',           'UNIFIED_BARRIERS', TRUE,  TRUE,  TRUE,  TRUE),
  ('role_psmmanager',      'UNIFIED_BARRIERS', TRUE,  TRUE,  TRUE,  FALSE),
  ('role_hsemanager',      'UNIFIED_BARRIERS', TRUE,  TRUE,  TRUE,  FALSE),
  ('role_processengineer', 'UNIFIED_BARRIERS', TRUE,  TRUE,  FALSE, FALSE),
  ('role_inspector',       'UNIFIED_BARRIERS', TRUE,  TRUE,  FALSE, FALSE),
  ('role_viewer',          'UNIFIED_BARRIERS', TRUE,  FALSE, FALSE, FALSE)
ON CONFLICT (role_id, module) DO NOTHING;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 11. Migration tracking
-- ─────────────────────────────────────────────────────────────────────────────────────

INSERT INTO schema_migrations (version, applied_at)
VALUES ('033_unified_barrier_model', NOW())
ON CONFLICT DO NOTHING;

COMMIT;
