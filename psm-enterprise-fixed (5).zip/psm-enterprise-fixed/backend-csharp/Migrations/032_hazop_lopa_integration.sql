BEGIN;

-- Add missing foreign key references to lopa_scenarios for complete traceability
ALTER TABLE lopa_scenarios 
  ADD COLUMN IF NOT EXISTS hazop_study_id TEXT REFERENCES hazop_studies(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS hazop_node_id TEXT REFERENCES hazop_nodes(id) ON DELETE SET NULL;

-- Populate hazop_study_id in lopa_scenarios from hazop_deviations
UPDATE lopa_scenarios ls
SET hazop_study_id = hd.study_id
FROM hazop_deviations hd
WHERE ls.hazop_deviation_id = hd.id 
  AND ls.hazop_study_id IS NULL;

-- Populate hazop_node_id in lopa_scenarios from hazop_deviations
UPDATE lopa_scenarios ls
SET hazop_node_id = hd.node_id
FROM hazop_deviations hd
WHERE ls.hazop_deviation_id = hd.id 
  AND ls.hazop_node_id IS NULL;

-- Create indexes for performance on the new columns
CREATE INDEX IF NOT EXISTS idx_lopa_scenarios_hazop_study 
  ON lopa_scenarios (hazop_study_id);

CREATE INDEX IF NOT EXISTS idx_lopa_scenarios_hazop_node 
  ON lopa_scenarios (hazop_node_id);

-- Add audit tracking for HAZOP-LOPA relationships
CREATE TABLE IF NOT EXISTS hazop_lopa_audit_trail (
  id            BIGSERIAL PRIMARY KEY,
  action        TEXT NOT NULL,
  hazop_study_id TEXT REFERENCES hazop_studies(id) ON DELETE CASCADE,
  hazop_node_id TEXT REFERENCES hazop_nodes(id) ON DELETE SET NULL,
  hazop_deviation_id TEXT REFERENCES hazop_deviations(id) ON DELETE CASCADE,
  lopa_study_id TEXT REFERENCES lopa_studies(id) ON DELETE CASCADE,
  lopa_scenario_id TEXT REFERENCES lopa_scenarios(id) ON DELETE CASCADE,
  performed_by  TEXT,
  performed_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  details       JSONB NOT NULL DEFAULT '{}',
  ip_address    TEXT,
  user_agent    TEXT
);

CREATE INDEX IF NOT EXISTS idx_hazop_lopa_audit_hazop_study 
  ON hazop_lopa_audit_trail (hazop_study_id);

CREATE INDEX IF NOT EXISTS idx_hazop_lopa_audit_lopa_study 
  ON hazop_lopa_audit_trail (lopa_study_id);

CREATE INDEX IF NOT EXISTS idx_hazop_lopa_audit_timestamp 
  ON hazop_lopa_audit_trail (performed_at DESC);

-- Add status tracking for LOPA creation from HAZOP
ALTER TABLE lopa_studies 
  ADD COLUMN IF NOT EXISTS created_from_hazop_study_id TEXT REFERENCES hazop_studies(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS creation_method TEXT DEFAULT 'Manual';

-- Add traceability columns to lopa_scenarios
ALTER TABLE lopa_scenarios
  ADD COLUMN IF NOT EXISTS related_recommendation_ids TEXT[] DEFAULT ARRAY[]::TEXT[];

-- Update schema version
INSERT INTO schema_migrations (version) VALUES ('032_hazop_lopa_integration')
ON CONFLICT DO NOTHING;

COMMIT;
