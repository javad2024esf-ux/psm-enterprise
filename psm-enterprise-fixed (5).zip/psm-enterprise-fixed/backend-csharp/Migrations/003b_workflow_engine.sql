-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║  PSM Enterprise — Migration 006 : Enhanced Workflow Engine v2.0        ║
-- ║  جداول جدید برای مدیریت سند، SLA، و تصعید                             ║
-- ╚══════════════════════════════════════════════════════════════════════════╝

-- ═══════════════════════════════════════════════════════════════════════════
-- جدول 1: نسخه‌های سند Workflow
-- ═══════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS workflow_document_versions (
  id              TEXT        PRIMARY KEY,
  record_id       TEXT        NOT NULL REFERENCES records(id) ON DELETE CASCADE,
  version         INT         NOT NULL,
  content         JSONB       NOT NULL DEFAULT '{}',
  status          TEXT        NOT NULL DEFAULT 'draft',  -- draft | under_review | approved | archived
  created_by      TEXT        NOT NULL REFERENCES users(id),
  change_log      TEXT,
  locked          BOOLEAN     NOT NULL DEFAULT FALSE,
  locked_by       TEXT        REFERENCES users(id),
  locked_at       TIMESTAMPTZ,
  approved_by     TEXT        REFERENCES users(id),
  approved_at     TIMESTAMPTZ,
  archived_at     TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  
  UNIQUE(record_id, version)
);

CREATE INDEX IF NOT EXISTS idx_doc_ver_record    ON workflow_document_versions(record_id);
CREATE INDEX IF NOT EXISTS idx_doc_ver_status    ON workflow_document_versions(status);
CREATE INDEX IF NOT EXISTS idx_doc_ver_locked    ON workflow_document_versions(locked);
CREATE INDEX IF NOT EXISTS idx_doc_ver_approved  ON workflow_document_versions(approved_at);

-- ═══════════════════════════════════════════════════════════════════════════
-- جدول 2: تأیید‌های درانتظار در زنجیره تأیید
-- ═══════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS workflow_pending_approvals (
  id              TEXT        PRIMARY KEY,
  instance_id     TEXT        NOT NULL REFERENCES workflow_instances(id) ON DELETE CASCADE,
  role            TEXT        NOT NULL,              -- نقشی که باید تأیید کند
  assigned_to     TEXT        REFERENCES users(id),  -- فرد خاصی (اختیاری)
  status          TEXT        NOT NULL DEFAULT 'pending',  -- pending | approved | rejected
  assigned_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  due_at          TIMESTAMPTZ,
  priority        INT         NOT NULL DEFAULT 0,    -- برای ترتیب‌بندی
  
  -- داده‌های بازخورد
  responded_at    TIMESTAMPTZ,
  response        TEXT,
  response_comment TEXT,
  
  -- escalation tracking
  escalated       BOOLEAN     NOT NULL DEFAULT FALSE,
  escalated_at    TIMESTAMPTZ,
  escalated_to    TEXT,
  
  metadata        JSONB       NOT NULL DEFAULT '{}',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pending_inst      ON workflow_pending_approvals(instance_id);
CREATE INDEX IF NOT EXISTS idx_pending_status    ON workflow_pending_approvals(status);
CREATE INDEX IF NOT EXISTS idx_pending_role      ON workflow_pending_approvals(role);
CREATE INDEX IF NOT EXISTS idx_pending_assigned  ON workflow_pending_approvals(assigned_to);
CREATE INDEX IF NOT EXISTS idx_pending_due       ON workflow_pending_approvals(due_at);

-- ═══════════════════════════════════════════════════════════════════════════
-- جدول 3: تصعید و فشار‌دهندگی (Escalations)
-- ═══════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS workflow_escalations (
  id              TEXT        PRIMARY KEY,
  instance_id     TEXT        NOT NULL REFERENCES workflow_instances(id) ON DELETE CASCADE,
  escalate_to     TEXT        NOT NULL,              -- نقش یا شناسه کاربر
  notify_roles    TEXT[]      NOT NULL DEFAULT '{}',
  escalation_level INT        NOT NULL DEFAULT 1,    -- 1, 2, 3, ...
  reason          TEXT,
  notification_sent BOOLEAN   NOT NULL DEFAULT FALSE,
  sent_at         TIMESTAMPTZ,
  acknowledged    BOOLEAN     NOT NULL DEFAULT FALSE,
  acknowledged_at TIMESTAMPTZ,
  acknowledged_by TEXT,
  escalated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_escalation_inst   ON workflow_escalations(instance_id);
CREATE INDEX IF NOT EXISTS idx_escalation_sent   ON workflow_escalations(notification_sent, sent_at);
CREATE INDEX IF NOT EXISTS idx_escalation_ack    ON workflow_escalations(acknowledged);

-- ═══════════════════════════════════════════════════════════════════════════
-- جدول 4: سیاست‌های تصعید (Escalation Policies)
-- ═══════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS workflow_escalation_policies (
  id              TEXT        PRIMARY KEY,
  name            TEXT        NOT NULL UNIQUE,      -- 'Standard' | 'Critical' | 'MOC'
  description     TEXT,
  module          TEXT,                             -- اگر null باشد برای همه
  rules           JSONB       NOT NULL DEFAULT '[]', -- [{after_hours, escalate_to, notify_roles}]
  is_active       BOOLEAN     NOT NULL DEFAULT TRUE,
  created_by      TEXT        REFERENCES users(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_esc_policy_active ON workflow_escalation_policies(is_active);
CREATE INDEX IF NOT EXISTS idx_esc_policy_module ON workflow_escalation_policies(module);

-- ═══════════════════════════════════════════════════════════════════════════
-- جدول 5: طرح‌های فرم (Form Schemas)
-- ═══════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS workflow_form_schemas (
  id              TEXT        PRIMARY KEY,
  workflow_id     TEXT        NOT NULL REFERENCES workflow_definitions(id) ON DELETE CASCADE,
  state_name      TEXT        NOT NULL,
  fields          JSONB       NOT NULL DEFAULT '[]', -- [{name, label, type, required, options}]
  condition_rules JSONB       NOT NULL DEFAULT '{}', -- شرایط برای نمایش فیلدها
  is_active       BOOLEAN     NOT NULL DEFAULT TRUE,
  version         INT         NOT NULL DEFAULT 1,
  created_by      TEXT        REFERENCES users(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  
  UNIQUE(workflow_id, state_name, version)
);

CREATE INDEX IF NOT EXISTS idx_form_schema_wf    ON workflow_form_schemas(workflow_id);
CREATE INDEX IF NOT EXISTS idx_form_schema_state ON workflow_form_schemas(state_name);

-- ═══════════════════════════════════════════════════════════════════════════
-- جدول 6: قوانین مسیریابی شرطی (Conditional Routes)
-- ═══════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS workflow_conditional_routes (
  id              TEXT        PRIMARY KEY,
  workflow_id     TEXT        NOT NULL REFERENCES workflow_definitions(id) ON DELETE CASCADE,
  from_state      TEXT        NOT NULL,
  conditions      JSONB       NOT NULL DEFAULT '{}', -- [{field, operator, value}]
  target_state    TEXT        NOT NULL,
  priority        INT         NOT NULL DEFAULT 0,    -- اولویت ارزیابی
  is_active       BOOLEAN     NOT NULL DEFAULT TRUE,
  created_by      TEXT        REFERENCES users(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_cond_route_wf     ON workflow_conditional_routes(workflow_id);
CREATE INDEX IF NOT EXISTS idx_cond_route_from   ON workflow_conditional_routes(from_state);
CREATE INDEX IF NOT EXISTS idx_cond_route_active ON workflow_conditional_routes(is_active);

-- ═══════════════════════════════════════════════════════════════════════════
-- جدول 7: نقض SLA (SLA Breaches)
-- ═══════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS workflow_sla_breaches (
  id              TEXT        PRIMARY KEY,
  instance_id     TEXT        NOT NULL REFERENCES workflow_instances(id) ON DELETE CASCADE,
  state_name      TEXT        NOT NULL,
  sla_hours       INT,
  breach_time     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  breach_duration_hours NUMERIC(10,2),
  severity        TEXT        NOT NULL DEFAULT 'warning', -- warning | critical
  notified        BOOLEAN     NOT NULL DEFAULT FALSE,
  resolved        BOOLEAN     NOT NULL DEFAULT FALSE,
  resolved_at     TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sla_breach_inst   ON workflow_sla_breaches(instance_id);
CREATE INDEX IF NOT EXISTS idx_sla_breach_time   ON workflow_sla_breaches(breach_time);
CREATE INDEX IF NOT EXISTS idx_sla_breach_notif  ON workflow_sla_breaches(notified);

-- ═══════════════════════════════════════════════════════════════════════════
-- جدول 8: تاریخچه تغییرات (Audit Trail)
-- ═══════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS workflow_audit_trail (
  id              TEXT        PRIMARY KEY,
  instance_id     TEXT        NOT NULL REFERENCES workflow_instances(id) ON DELETE CASCADE,
  action          TEXT        NOT NULL,
  change_before   JSONB,
  change_after    JSONB,
  changed_by      TEXT        NOT NULL REFERENCES users(id),
  changed_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ip_address      INET,
  user_agent      TEXT,
  reason          TEXT,
  metadata        JSONB       NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_audit_inst       ON workflow_audit_trail(instance_id);
CREATE INDEX IF NOT EXISTS idx_audit_time       ON workflow_audit_trail(changed_at);
CREATE INDEX IF NOT EXISTS idx_audit_action     ON workflow_audit_trail(action);
CREATE INDEX IF NOT EXISTS idx_audit_user       ON workflow_audit_trail(changed_by);

-- ═══════════════════════════════════════════════════════════════════════════
-- جدول 9: الگوهای اعلان (Notification Templates)
-- ═══════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS workflow_notification_templates (
  id              TEXT        PRIMARY KEY,
  workflow_id     TEXT        NOT NULL REFERENCES workflow_definitions(id) ON DELETE CASCADE,
  event_type      TEXT        NOT NULL,  -- state_entered | approval_requested | sla_breach | escalation
  channel         TEXT        NOT NULL,  -- email | sms | in_app | all
  subject_template TEXT,                 -- برای email
  body_template   TEXT        NOT NULL,  -- Template با {{placeholders}}
  roles_to_notify TEXT[]      NOT NULL DEFAULT '{}',
  is_active       BOOLEAN     NOT NULL DEFAULT TRUE,
  created_by      TEXT        REFERENCES users(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notif_templ_wf   ON workflow_notification_templates(workflow_id);
CREATE INDEX IF NOT EXISTS idx_notif_templ_evt  ON workflow_notification_templates(event_type);

-- ═══════════════════════════════════════════════════════════════════════════
-- جدول 10: متریک‌های کارکردی (Performance Metrics)
-- ═══════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS workflow_performance_metrics (
  id              TEXT        PRIMARY KEY,
  instance_id     TEXT        NOT NULL REFERENCES workflow_instances(id) ON DELETE CASCADE,
  total_duration_hours NUMERIC(10,2),
  sla_compliance  BOOLEAN,
  average_transition_time_hours NUMERIC(10,2),
  bottleneck_state TEXT,
  bottleneck_duration_hours NUMERIC(10,2),
  approval_count  INT,
  escalation_count INT,
  revision_count  INT,
  user_satisfaction_score INT,  -- 1-5
  notes           TEXT,
  calculated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_perf_metrics_inst ON workflow_performance_metrics(instance_id);
CREATE INDEX IF NOT EXISTS idx_perf_metrics_sla ON workflow_performance_metrics(sla_compliance);

-- ═══════════════════════════════════════════════════════════════════════════
-- View: سایدار بار کاری (Workload Distribution)
-- ═══════════════════════════════════════════════════════════════════════════
CREATE OR REPLACE VIEW workflow_workload_distribution AS
SELECT 
  u.id,
  u.full_name,
  u.role,
  COUNT(DISTINCT wpa.instance_id) AS pending_approvals,
  COUNT(DISTINCT we.id) FILTER (WHERE we.acknowledged = false) AS unacknowledged_escalations,
  COUNT(DISTINCT wsb.id) FILTER (WHERE wsb.resolved = false) AS active_sla_breaches,
  MAX(wpa.due_at) AS next_deadline
FROM users u
LEFT JOIN workflow_pending_approvals wpa ON wpa.assigned_to = u.id AND wpa.status = 'pending'
LEFT JOIN workflow_escalations we ON we.escalate_to = u.role AND we.acknowledged = false
LEFT JOIN workflow_sla_breaches wsb ON wsb.severity = 'critical' AND wsb.resolved = false
GROUP BY u.id, u.full_name, u.role;

-- ═══════════════════════════════════════════════════════════════════════════
-- View: خلاصه وضعیت کلی (Dashboard Summary)
-- ═══════════════════════════════════════════════════════════════════════════
CREATE OR REPLACE VIEW workflow_dashboard_summary AS
SELECT 
  (SELECT COUNT(*) FROM workflow_instances WHERE completed_at IS NULL) AS active_workflows,
  (SELECT COUNT(*) FROM workflow_instances WHERE due_at < NOW() AND completed_at IS NULL) AS overdue_workflows,
  (SELECT COUNT(*) FROM workflow_sla_breaches WHERE resolved = false) AS active_sla_breaches,
  (SELECT COUNT(*) FROM workflow_pending_approvals WHERE status = 'pending') AS pending_approvals,
  (SELECT COUNT(*) FROM workflow_escalations WHERE acknowledged = false) AS unacknowledged_escalations,
  (SELECT ROUND(AVG(EXTRACT(EPOCH FROM (completed_at - created_at))/3600), 2)
   FROM workflow_instances WHERE completed_at IS NOT NULL) AS avg_completion_hours,
  (SELECT ROUND(
     100.0 * COUNT(*) FILTER (WHERE completed_at <= due_at OR due_at IS NULL) / 
     NULLIF(COUNT(*), 0), 2)
   FROM workflow_instances WHERE completed_at IS NOT NULL) AS sla_compliance_percentage;

-- ═══════════════════════════════════════════════════════════════════════════
-- Trigger: خودکار تشخیص نقض SLA
-- ═══════════════════════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION check_sla_breach()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.due_at IS NOT NULL AND NEW.completed_at IS NULL AND NOW() > NEW.due_at THEN
    INSERT INTO workflow_sla_breaches (
      id, instance_id, state_name, sla_hours, severity
    ) VALUES (
      'slab_' || NEW.id || '_' || NOW()::text,
      NEW.id,
      NEW.current_state,
      (SELECT sla_hours FROM workflow_states WHERE name = NEW.current_state),
      CASE 
        WHEN EXTRACT(EPOCH FROM (NOW() - NEW.due_at))/3600 > 24 THEN 'critical'
        ELSE 'warning'
      END
    )
    ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sla_breach ON workflow_instances;
CREATE TRIGGER trg_sla_breach
AFTER UPDATE ON workflow_instances
FOR EACH ROW
EXECUTE FUNCTION check_sla_breach();

-- ═══════════════════════════════════════════════════════════════════════════
-- Trigger: ثبت تغییرات در Audit Trail
-- ═══════════════════════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION log_workflow_changes()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'UPDATE' THEN
    INSERT INTO workflow_audit_trail (
      id, instance_id, action, change_before, change_after, changed_by
    ) VALUES (
      'wfat_' || NEW.id || '_' || NOW()::text,
      NEW.id,
      'STATE_CHANGE',
      jsonb_build_object('state', OLD.current_state),
      jsonb_build_object('state', NEW.current_state),
      COALESCE((SELECT id FROM users LIMIT 1), 'system')
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_audit_workflow ON workflow_instances;
CREATE TRIGGER trg_audit_workflow
AFTER UPDATE ON workflow_instances
FOR EACH ROW
WHEN (OLD.current_state IS DISTINCT FROM NEW.current_state)
EXECUTE FUNCTION log_workflow_changes();

-- ═══════════════════════════════════════════════════════════════════════════
-- Insert پیش‌فرض: سیاست‌های تصعید
-- ═══════════════════════════════════════════════════════════════════════════
INSERT INTO workflow_escalation_policies (id, name, description, rules, is_active) VALUES
  ('esc_pol_standard', 'Standard', 'سیاست استاندارد برای اکثر workflow‌ها',
   '[
      {"after_hours": 24, "escalate_to": "PSMManager", "notify_roles": ["HSEManager"]},
      {"after_hours": 48, "escalate_to": "HSEManager", "notify_roles": ["Admin"]},
      {"after_hours": 72, "escalate_to": "Admin", "notify_roles": []}
    ]'::jsonb, true),
  
  ('esc_pol_critical', 'Critical', 'سیاست تصعید سریع برای موارد بحرانی',
   '[
      {"after_hours": 4, "escalate_to": "HSEManager", "notify_roles": []},
      {"after_hours": 8, "escalate_to": "Admin", "notify_roles": ["PSMManager"]},
      {"after_hours": 12, "escalate_to": "Admin", "notify_roles": [], "send_email": true}
    ]'::jsonb, true),
  
  ('esc_pol_moc', 'MOC', 'سیاست تصعید MOC',
   '[
      {"after_hours": 48, "escalate_to": "PSMManager", "notify_roles": ["ProcessEngineer"]},
      {"after_hours": 96, "escalate_to": "Admin", "notify_roles": ["PSMManager"]}
    ]'::jsonb, true)
ON CONFLICT DO NOTHING;

-- ═══════════════════════════════════════════════════════════════════════════
-- بروزرسانی جدول workflow_instances
-- ═══════════════════════════════════════════════════════════════════════════
ALTER TABLE workflow_instances ADD COLUMN IF NOT EXISTS escalation_policy TEXT DEFAULT 'Standard';
ALTER TABLE workflow_instances ADD COLUMN IF NOT EXISTS form_schema JSONB DEFAULT '{}';
ALTER TABLE workflow_instances ADD COLUMN IF NOT EXISTS conditional_routes JSONB DEFAULT '{}';

-- ثبت migration
INSERT INTO schema_migrations (version) VALUES ('006_enhanced_workflow_v2')
  ON CONFLICT (version) DO NOTHING;
