-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║  PSM Enterprise — Migration 022 : Action Register Dedicated Table       ║
-- ║  Migrates Action Register from generic records → dedicated table        ║
-- ╚══════════════════════════════════════════════════════════════════════════╝

-- ─── Create action_register table ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS action_register (
  id                TEXT        PRIMARY KEY,
  title             TEXT        NOT NULL,
  description       TEXT,
  source            TEXT        NOT NULL DEFAULT 'Other',
  source_id         TEXT,
  source_ref        TEXT,
  unit              TEXT,
  responsible       TEXT,
  due_date          DATE,
  status            TEXT        NOT NULL DEFAULT 'Open',
  priority          TEXT        NOT NULL DEFAULT 'Medium',
  completion_date   DATE,
  verified_by       TEXT,
  verification_note TEXT,
  tags              TEXT[],
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by        TEXT,
  deleted           BOOLEAN     NOT NULL DEFAULT FALSE
);

-- ─── Add missing columns if table already existed without them ────────────
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='action_register' AND column_name='source') THEN
    ALTER TABLE action_register ADD COLUMN source TEXT NOT NULL DEFAULT 'Other';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='action_register' AND column_name='source_id') THEN
    ALTER TABLE action_register ADD COLUMN source_id TEXT;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='action_register' AND column_name='source_ref') THEN
    ALTER TABLE action_register ADD COLUMN source_ref TEXT;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='action_register' AND column_name='unit') THEN
    ALTER TABLE action_register ADD COLUMN unit TEXT;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='action_register' AND column_name='responsible') THEN
    ALTER TABLE action_register ADD COLUMN responsible TEXT;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='action_register' AND column_name='due_date') THEN
    ALTER TABLE action_register ADD COLUMN due_date DATE;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='action_register' AND column_name='priority') THEN
    ALTER TABLE action_register ADD COLUMN priority TEXT NOT NULL DEFAULT 'Medium';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='action_register' AND column_name='completion_date') THEN
    ALTER TABLE action_register ADD COLUMN completion_date DATE;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='action_register' AND column_name='verified_by') THEN
    ALTER TABLE action_register ADD COLUMN verified_by TEXT;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='action_register' AND column_name='verification_note') THEN
    ALTER TABLE action_register ADD COLUMN verification_note TEXT;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='action_register' AND column_name='tags') THEN
    ALTER TABLE action_register ADD COLUMN tags TEXT[];
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='action_register' AND column_name='deleted') THEN
    ALTER TABLE action_register ADD COLUMN deleted BOOLEAN NOT NULL DEFAULT FALSE;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_name='action_register' AND column_name='created_by') THEN
    ALTER TABLE action_register ADD COLUMN created_by TEXT;
  END IF;
END $$;

-- ─── Indexes for performance ──────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_action_register_status
  ON action_register (status);

CREATE INDEX IF NOT EXISTS idx_action_register_source
  ON action_register (source);

CREATE INDEX IF NOT EXISTS idx_action_register_unit
  ON action_register (unit);

CREATE INDEX IF NOT EXISTS idx_action_register_responsible
  ON action_register (responsible);

CREATE INDEX IF NOT EXISTS idx_action_register_due_date
  ON action_register (due_date);

CREATE INDEX IF NOT EXISTS idx_action_register_priority
  ON action_register (priority);

CREATE INDEX IF NOT EXISTS idx_action_register_created_at
  ON action_register (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_action_register_deleted
  ON action_register (deleted);

CREATE INDEX IF NOT EXISTS idx_action_register_composite
  ON action_register (status, unit, deleted);

CREATE INDEX IF NOT EXISTS idx_action_register_tags
  ON action_register USING GIN (tags);

-- ─── Migrate data from records table (if it exists) ──────────────────────
DO $$
BEGIN
  IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'records') THEN
    INSERT INTO action_register (
      id, title, description, source, source_id, source_ref,
      unit, responsible, due_date, status, priority,
      completion_date, verified_by, verification_note, tags,
      created_at, updated_at, created_by, deleted
    )
    SELECT
      r.id,
      COALESCE(r.data->>'title', ''),
      r.data->>'description',
      COALESCE(r.data->>'source', 'Other'),
      r.data->>'sourceId',
      r.data->>'sourceRef',
      r.unit,
      r.data->>'responsible',
      TO_DATE(NULLIF(r.data->>'dueDate',''), 'YYYY-MM-DD'),
      COALESCE(r.status, r.data->>'status', 'Open'),
      COALESCE(r.data->>'priority', 'Medium'),
      TO_DATE(NULLIF(r.data->>'completionDate',''), 'YYYY-MM-DD'),
      r.data->>'verifiedBy',
      r.data->>'verificationNote',
      CASE
        WHEN r.data->>'tags' IS NOT NULL THEN string_to_array(r.data->>'tags', ',')
        ELSE NULL
      END,
      r.created_at,
      r.updated_at,
      r.created_by,
      r.deleted
    FROM records r
    WHERE r.collection = 'action_register'
      AND NOT EXISTS (
        SELECT 1 FROM action_register ar WHERE ar.id = r.id
      );
  END IF;
END $$;

-- ─── Mark migrated records as soft-deleted in records table ──────────────
DO $$
BEGIN
  IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'records') THEN
    UPDATE records
    SET deleted = true
    WHERE collection = 'action_register' AND deleted = false;
  END IF;
END $$;

-- ─── Log migration completion ─────────────────────────────────────────────
INSERT INTO settings (key, value, updated_at)
VALUES ('action_register_migration_completed', '2026-06-25', NOW())
ON CONFLICT (key) DO UPDATE
SET value = '2026-06-25', updated_at = NOW();
