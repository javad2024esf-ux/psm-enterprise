-- ═══════════════════════════════════════════════════════════════════════════
-- Migration 014b: tenants bootstrap
--
-- PRE-EXISTING BUG FOUND DURING THIS REFACTOR: migrations 015 and 016
-- (work_permits, pssr_records, work_permit_performance_metrics) declare a
-- foreign key `REFERENCES tenants(id)`, but no migration anywhere in this
-- repository ever created a `tenants` table. Running `node migrate.cjs`
-- top-to-bottom on a fresh database has therefore always failed at 015 with
-- `relation "tenants" does not exist` — meaning the workflow/PSSR migrations
-- could never have been applied successfully before. This migration adds
-- the missing table with a single default tenant so the chain completes,
-- without changing the (single-tenant) behavior of the app today.
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS tenants (
  id          TEXT        PRIMARY KEY,
  name        TEXT        NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO tenants (id, name)
VALUES ('tenant_1', 'Default Tenant')
ON CONFLICT (id) DO NOTHING;
