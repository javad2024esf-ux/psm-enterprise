-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║  PSM Enterprise — Migration 029 : Change Audit & Notifications Tables  ║
-- ╚══════════════════════════════════════════════════════════════════════════╝

DO $migration$
BEGIN

  -- ═══════════════════════════════════════════════════════════════════════
  -- Table 1: Change Audit Logs
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS change_audit_logs (
    id              TEXT        PRIMARY KEY,
    change_id       TEXT        NOT NULL REFERENCES change_requests(id) ON DELETE CASCADE,
    action          TEXT        NOT NULL, -- 'create_change' | 'advance_stage' | 'return_stage' | 'approve_startup' | etc.
    from_stage      TEXT,
    to_stage        TEXT,
    performed_by    TEXT        NOT NULL REFERENCES users(id),
    comment         TEXT,
    metadata        JSONB       NOT NULL DEFAULT '{}',
    performed_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE INDEX IF NOT EXISTS idx_audit_change_id ON change_audit_logs(change_id);
  CREATE INDEX IF NOT EXISTS idx_audit_action ON change_audit_logs(action);
  CREATE INDEX IF NOT EXISTS idx_audit_performed_by ON change_audit_logs(performed_by);
  CREATE INDEX IF NOT EXISTS idx_audit_performed_at ON change_audit_logs(performed_at);

  -- ═══════════════════════════════════════════════════════════════════════
  -- Table 2: Change Notifications
  -- ═══════════════════════════════════════════════════════════════════════
  CREATE TABLE IF NOT EXISTS change_notifications (
    id              TEXT        PRIMARY KEY,
    change_id       TEXT        NOT NULL REFERENCES change_requests(id) ON DELETE CASCADE,
    notification_type TEXT      NOT NULL, -- 'ChangeCreated' | 'StageAdvanced' | 'TrainingAssigned' | 'StartupApproved'
    title           TEXT        NOT NULL,
    message         TEXT        NOT NULL,
    recipient       TEXT        NOT NULL, -- USER ID or ROLE
    is_read         BOOLEAN     NOT NULL DEFAULT FALSE,
    read_at         TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );

  CREATE INDEX IF NOT EXISTS idx_notif_change_id ON change_notifications(change_id);
  CREATE INDEX IF NOT EXISTS idx_notif_recipient ON change_notifications(recipient);
  CREATE INDEX IF NOT EXISTS idx_notif_is_read ON change_notifications(is_read);
  CREATE INDEX IF NOT EXISTS idx_notif_type ON change_notifications(notification_type);
  CREATE INDEX IF NOT EXISTS idx_notif_created_at ON change_notifications(created_at);

  INSERT INTO schema_migrations (version) VALUES ('029_change_audit_notifications')
    ON CONFLICT DO NOTHING;

END
$migration$;
