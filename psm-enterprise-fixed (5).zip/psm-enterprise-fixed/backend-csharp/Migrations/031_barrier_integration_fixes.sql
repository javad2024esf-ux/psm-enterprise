-- ════════════════════════════════════════════════════════════════════════════════════
-- Migration 031: Integrated Risk Model — follow-up fixes
-- 1) lopa_ipls back-link columns to the unified `barriers` table (LopaRepository already
--    had code referencing these columns, but no prior migration created them).
-- 2) RBAC: register the new "BARRIERS" permission module for all system roles, mirroring
--    the defaults migration 004 set up for HAZOP/LOPA/BOWTIE/INCIDENT.
-- ════════════════════════════════════════════════════════════════════════════════════

BEGIN;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 1. lopa_ipls: back-link to barriers + last sync timestamp
-- ─────────────────────────────────────────────────────────────────────────────────────

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'lopa_ipls') THEN
    ALTER TABLE lopa_ipls ADD COLUMN IF NOT EXISTS risk_barrier_id TEXT
      REFERENCES barriers(id) ON DELETE SET NULL;
    ALTER TABLE lopa_ipls ADD COLUMN IF NOT EXISTS last_status_sync TIMESTAMPTZ;
    CREATE INDEX IF NOT EXISTS idx_lopa_ipls_risk_barrier ON lopa_ipls(risk_barrier_id);
  END IF;
END $$;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 2. RBAC: seed default permissions for the BARRIERS module across all system roles.
--    Pattern mirrors Migration 004 (dynamic role/permission system).
--    Barrier status changes cascade safety-critical updates to LOPA/BowTie, so write
--    access is restricted to engineering/safety roles; status escalation (Approve) is
--    reserved for managers; delete is Admin-only.
-- ─────────────────────────────────────────────────────────────────────────────────────

INSERT INTO role_permissions (role_id, module, can_read, can_write, can_approve, can_delete)
VALUES
  ('role_admin',           'BARRIERS', TRUE,  TRUE,  TRUE,  TRUE),
  ('role_psmmanager',      'BARRIERS', TRUE,  TRUE,  TRUE,  FALSE),
  ('role_hsemanager',      'BARRIERS', TRUE,  TRUE,  TRUE,  FALSE),
  ('role_unithead',        'BARRIERS', TRUE,  TRUE,  FALSE, FALSE),
  ('role_processengineer', 'BARRIERS', TRUE,  TRUE,  FALSE, FALSE),
  ('role_supervisor',      'BARRIERS', TRUE,  FALSE, FALSE, FALSE),
  ('role_operator',        'BARRIERS', TRUE,  FALSE, FALSE, FALSE),
  ('role_inspector',       'BARRIERS', TRUE,  TRUE,  FALSE, FALSE),
  ('role_contractormgr',   'BARRIERS', FALSE, FALSE, FALSE, FALSE),
  ('role_viewer',          'BARRIERS', TRUE,  FALSE, FALSE, FALSE)
ON CONFLICT (role_id, module) DO NOTHING;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 3. Migration tracking
-- ─────────────────────────────────────────────────────────────────────────────────────

INSERT INTO schema_migrations (version, applied_at)
VALUES ('031_barrier_integration_fixes', NOW())
ON CONFLICT DO NOTHING;

COMMIT;
