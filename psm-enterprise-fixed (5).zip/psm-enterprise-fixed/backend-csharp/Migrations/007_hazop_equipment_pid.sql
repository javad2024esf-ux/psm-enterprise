
BEGIN;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_nodes') THEN
    ALTER TABLE hazop_nodes ADD COLUMN IF NOT EXISTS equipment_tag  VARCHAR(100);
    ALTER TABLE hazop_nodes ADD COLUMN IF NOT EXISTS line_number    VARCHAR(100);
    ALTER TABLE hazop_nodes ADD COLUMN IF NOT EXISTS pid_reference  VARCHAR(255);
    ALTER TABLE hazop_nodes ADD COLUMN IF NOT EXISTS process_unit   VARCHAR(100);
    ALTER TABLE hazop_nodes ADD COLUMN IF NOT EXISTS area           VARCHAR(100);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS hazop_pid_documents (
  id            TEXT         PRIMARY KEY DEFAULT gen_random_uuid()::text,
  study_id      TEXT,
  document_name VARCHAR(255) NOT NULL,
  document_path TEXT,
  uploaded_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  uploaded_by   TEXT
);

CREATE TABLE IF NOT EXISTS hazop_equipment_registry (
  id                    TEXT         PRIMARY KEY DEFAULT gen_random_uuid()::text,
  study_id              TEXT,
  equipment_tag         VARCHAR(100) NOT NULL,
  equipment_name        VARCHAR(255) NOT NULL,
  equipment_type        VARCHAR(100),
  process_unit          VARCHAR(100),
  area                  VARCHAR(100),
  description           TEXT,
  purchase_date         DATE,
  last_maintenance_date DATE,
  UNIQUE(study_id, equipment_tag)
);

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_studies') THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.table_constraints
      WHERE table_name = 'hazop_pid_documents' AND constraint_name = 'fk_pid_docs_study'
    ) THEN
      ALTER TABLE hazop_pid_documents
        ADD CONSTRAINT fk_pid_docs_study
        FOREIGN KEY (study_id) REFERENCES hazop_studies(id) ON DELETE CASCADE;
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM information_schema.table_constraints
      WHERE table_name = 'hazop_equipment_registry' AND constraint_name = 'fk_equip_study'
    ) THEN
      ALTER TABLE hazop_equipment_registry
        ADD CONSTRAINT fk_equip_study
        FOREIGN KEY (study_id) REFERENCES hazop_studies(id) ON DELETE CASCADE;
    END IF;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_pid_documents_study      ON hazop_pid_documents(study_id);
CREATE INDEX IF NOT EXISTS idx_equipment_registry_study ON hazop_equipment_registry(study_id);
CREATE INDEX IF NOT EXISTS idx_equipment_registry_tag   ON hazop_equipment_registry(equipment_tag);

INSERT INTO schema_migrations (version, applied_at)
VALUES ('007_hazop_equipment_pid', NOW())
ON CONFLICT DO NOTHING;

COMMIT;
