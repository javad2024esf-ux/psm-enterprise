-- ════════════════════════════════════════════════════════════════════════════════════
-- Migration 030: Integrated Risk Model - Barriers, Incidents, Cross-References
-- PSM Enterprise: HAZOP + LOPA + BowTie + Incident Management Integration
-- ════════════════════════════════════════════════════════════════════════════════════

BEGIN;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 1. BARRIERS TABLE — Links LOPA IPLs to physical/administrative barriers
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS barriers (
  id                      TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  lopa_ipl_id             TEXT        NOT NULL UNIQUE REFERENCES lopa_ipls(id) ON DELETE CASCADE,
  bowtie_barrier_id       TEXT        REFERENCES bowtie_barriers(id) ON DELETE SET NULL,
  barrier_name            TEXT        NOT NULL,
  barrier_type            TEXT        NOT NULL CHECK (barrier_type IN ('Engineering','Administrative','Procedural','SIS','Detection')),
  description             TEXT,
  owner_discipline        TEXT,
  owner_contact           TEXT,
  maintenance_frequency   TEXT,
  last_tested             TIMESTAMPTZ,
  next_test_due           TIMESTAMPTZ,
  effectiveness_rating    NUMERIC(4,3) NOT NULL DEFAULT 0.9 CHECK (effectiveness_rating BETWEEN 0 AND 1),
  status                  TEXT        NOT NULL DEFAULT 'Active' CHECK (status IN ('Active','Degraded','Failed','Inactive')),
  failure_mode            TEXT,
  failure_reason          TEXT,
  failure_date            TIMESTAMPTZ,
  remediation_plan        TEXT,
  remediation_due_date    TIMESTAMPTZ,
  pfd_actual              NUMERIC(10,6),
  sil_level               INTEGER     CHECK (sil_level BETWEEN 0 AND 4),
  documentation_ref       TEXT,
  critical_flag           BOOLEAN     NOT NULL DEFAULT FALSE,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by              TEXT,
  deleted                 BOOLEAN     NOT NULL DEFAULT FALSE,
  data                    JSONB       NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_barriers_lopa_ipl        ON barriers(lopa_ipl_id);
CREATE INDEX IF NOT EXISTS idx_barriers_bowtie          ON barriers(bowtie_barrier_id);
CREATE INDEX IF NOT EXISTS idx_barriers_status          ON barriers(status);
CREATE INDEX IF NOT EXISTS idx_barriers_owner           ON barriers(owner_discipline);
CREATE INDEX IF NOT EXISTS idx_barriers_sil             ON barriers(sil_level);

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 2. INCIDENTS TABLE — Operational incidents linked to barriers and analysis
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS incidents (
  id                      TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  incident_number         TEXT        NOT NULL UNIQUE,
  title                   TEXT        NOT NULL,
  description             TEXT,
  facility                TEXT,
  unit                    TEXT,
  date_occurred           TIMESTAMPTZ NOT NULL,
  date_reported           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reporter_name           TEXT,
  reporter_contact        TEXT,
  incident_type           TEXT        NOT NULL CHECK (incident_type IN ('Near Miss','Injury','Environmental','Equipment Damage','Process Upset','Other')),
  severity_actual         INTEGER     NOT NULL CHECK (severity_actual BETWEEN 1 AND 5),
  root_cause              TEXT,
  immediate_actions       TEXT,
  corrective_actions      TEXT,
  preventive_actions      TEXT,
  status                  TEXT        NOT NULL DEFAULT 'Reported' 
                          CHECK (status IN ('Reported','Under Investigation','Analysis Complete','Closed','Archived')),
  investigation_lead      TEXT,
  date_closed             TIMESTAMPTZ,
  lessons_learned         TEXT,
  shared_with_industry    BOOLEAN     NOT NULL DEFAULT FALSE,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted                 BOOLEAN     NOT NULL DEFAULT FALSE,
  data                    JSONB       NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_incidents_number         ON incidents(incident_number);
CREATE INDEX IF NOT EXISTS idx_incidents_facility       ON incidents(facility);
CREATE INDEX IF NOT EXISTS idx_incidents_date           ON incidents(date_occurred);
CREATE INDEX IF NOT EXISTS idx_incidents_status         ON incidents(status);
CREATE INDEX IF NOT EXISTS idx_incidents_severity       ON incidents(severity_actual);

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 3. INCIDENT-BARRIER RELATIONSHIPS
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS incident_barriers (
  id                      TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  incident_id             TEXT        NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  barrier_id              TEXT        NOT NULL REFERENCES barriers(id) ON DELETE CASCADE,
  barrier_failure_type    TEXT        CHECK (barrier_failure_type IN ('Not Available','Failed to Function','Inadequate Effectiveness')),
  failure_evidence        TEXT,
  contribution_to_incident NUMERIC(4,3) DEFAULT 0.5,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(incident_id, barrier_id)
);

CREATE INDEX IF NOT EXISTS idx_incident_barriers_incident ON incident_barriers(incident_id);
CREATE INDEX IF NOT EXISTS idx_incident_barriers_barrier  ON incident_barriers(barrier_id);

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 4. CROSS-REFERENCE MAPPING: Incidents → HAZOP Scenarios
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS incident_hazop_mappings (
  id                      TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  incident_id             TEXT        NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  hazop_deviation_id      TEXT        NOT NULL REFERENCES hazop_deviations(id) ON DELETE CASCADE,
  hazop_study_id          TEXT        NOT NULL REFERENCES hazop_studies(id) ON DELETE CASCADE,
  relevance_score         NUMERIC(4,3) DEFAULT 0.8,
  notes                   TEXT,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(incident_id, hazop_deviation_id)
);

CREATE INDEX IF NOT EXISTS idx_incident_hazop_incident   ON incident_hazop_mappings(incident_id);
CREATE INDEX IF NOT EXISTS idx_incident_hazop_deviation  ON incident_hazop_mappings(hazop_deviation_id);
CREATE INDEX IF NOT EXISTS idx_incident_hazop_study      ON incident_hazop_mappings(hazop_study_id);

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 5. CROSS-REFERENCE MAPPING: Incidents → LOPA Studies
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS incident_lopa_mappings (
  id                      TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  incident_id             TEXT        NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  lopa_scenario_id        TEXT        NOT NULL REFERENCES lopa_scenarios(id) ON DELETE CASCADE,
  lopa_study_id           TEXT        NOT NULL REFERENCES lopa_studies(id) ON DELETE CASCADE,
  relevance_score         NUMERIC(4,3) DEFAULT 0.8,
  ipl_failure_count       INTEGER     DEFAULT 0,
  notes                   TEXT,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(incident_id, lopa_scenario_id)
);

CREATE INDEX IF NOT EXISTS idx_incident_lopa_incident    ON incident_lopa_mappings(incident_id);
CREATE INDEX IF NOT EXISTS idx_incident_lopa_scenario    ON incident_lopa_mappings(lopa_scenario_id);
CREATE INDEX IF NOT EXISTS idx_incident_lopa_study       ON incident_lopa_mappings(lopa_study_id);

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 6. CROSS-REFERENCE MAPPING: Incidents → BowTie Diagrams
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS incident_bowtie_mappings (
  id                      TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  incident_id             TEXT        NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  bowtie_diagram_id       TEXT        NOT NULL REFERENCES bowtie_diagrams(id) ON DELETE CASCADE,
  top_event_occurred      BOOLEAN     NOT NULL DEFAULT TRUE,
  barriers_failed         INTEGER     DEFAULT 0,
  relevance_score         NUMERIC(4,3) DEFAULT 0.8,
  notes                   TEXT,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(incident_id, bowtie_diagram_id)
);

CREATE INDEX IF NOT EXISTS idx_incident_bowtie_incident  ON incident_bowtie_mappings(incident_id);
CREATE INDEX IF NOT EXISTS idx_incident_bowtie_diagram   ON incident_bowtie_mappings(bowtie_diagram_id);

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 7. BARRIER AUDIT TRAIL — Track barrier status changes
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS barrier_status_history (
  id                      TEXT        PRIMARY KEY DEFAULT gen_random_uuid()::text,
  barrier_id              TEXT        NOT NULL REFERENCES barriers(id) ON DELETE CASCADE,
  previous_status         TEXT,
  new_status              TEXT        NOT NULL,
  reason                  TEXT,
  triggered_by_incident   TEXT        REFERENCES incidents(id) ON DELETE SET NULL,
  changed_by              TEXT,
  changed_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_barrier_history_barrier   ON barrier_status_history(barrier_id);
CREATE INDEX IF NOT EXISTS idx_barrier_history_incident  ON barrier_status_history(triggered_by_incident);
CREATE INDEX IF NOT EXISTS idx_barrier_history_date      ON barrier_status_history(changed_at);

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 8. ENHANCEMENT: Add cross-reference columns to existing HAZOP-LOPA-BowTie tables
-- ─────────────────────────────────────────────────────────────────────────────────────

DO $$
BEGIN
  -- Add LOPA-BowTie linkage (may already exist)
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'lopa_scenarios') THEN
    ALTER TABLE lopa_scenarios ADD COLUMN IF NOT EXISTS bowtie_diagram_id TEXT REFERENCES bowtie_diagrams(id) ON DELETE SET NULL;
    ALTER TABLE lopa_scenarios ADD COLUMN IF NOT EXISTS top_event_reference TEXT;
    CREATE INDEX IF NOT EXISTS idx_lopa_scenarios_bowtie ON lopa_scenarios(bowtie_diagram_id);
  END IF;

  -- Add status tracking to BowTie barriers
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'bowtie_barriers') THEN
    ALTER TABLE bowtie_barriers ADD COLUMN IF NOT EXISTS barrier_status TEXT DEFAULT 'Active' 
      CHECK (barrier_status IN ('Active','Degraded','Failed','Under Test'));
    ALTER TABLE bowtie_barriers ADD COLUMN IF NOT EXISTS last_tested TIMESTAMPTZ;
    ALTER TABLE bowtie_barriers ADD COLUMN IF NOT EXISTS linked_barrier_id TEXT REFERENCES barriers(id) ON DELETE SET NULL;
    CREATE INDEX IF NOT EXISTS idx_bowtie_barriers_status ON bowtie_barriers(barrier_status);
    CREATE INDEX IF NOT EXISTS idx_bowtie_barriers_linked ON bowtie_barriers(linked_barrier_id);
  END IF;

  -- Add incident reference to LOPA IPLs
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'lopa_ipls') THEN
    ALTER TABLE lopa_ipls ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'Active' 
      CHECK (status IN ('Active','Degraded','Failed','Decommissioned'));
    ALTER TABLE lopa_ipls ADD COLUMN IF NOT EXISTS last_tested TIMESTAMPTZ;
    ALTER TABLE lopa_ipls ADD COLUMN IF NOT EXISTS failure_count INTEGER DEFAULT 0;
    CREATE INDEX IF NOT EXISTS idx_lopa_ipls_status ON lopa_ipls(status);
  END IF;

  -- Add incident reference to HAZOP deviations
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'hazop_deviations') THEN
    ALTER TABLE hazop_deviations ADD COLUMN IF NOT EXISTS incident_reference TEXT;
    ALTER TABLE hazop_deviations ADD COLUMN IF NOT EXISTS linked_incidents INTEGER DEFAULT 0;
    CREATE INDEX IF NOT EXISTS idx_hazop_deviations_incidents ON hazop_deviations(linked_incidents);
  END IF;
END $$;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 9. TRANSACTION FUNCTION: Update Barrier Status (cascades to BowTie & LOPA)
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION update_barrier_status_cascade(
  p_barrier_id TEXT,
  p_new_status TEXT,
  p_reason TEXT DEFAULT NULL,
  p_incident_id TEXT DEFAULT NULL,
  p_changed_by TEXT DEFAULT NULL
) RETURNS TABLE(
  success BOOLEAN,
  message TEXT,
  affected_rows INTEGER
) AS $$
DECLARE
  v_affected INTEGER := 0;
  v_old_status TEXT;
  v_lopa_ipl_id TEXT;
  v_bowtie_barrier_id TEXT;
BEGIN
  -- Get current barrier details
  SELECT status, lopa_ipl_id, bowtie_barrier_id 
  INTO v_old_status, v_lopa_ipl_id, v_bowtie_barrier_id
  FROM barriers WHERE id = p_barrier_id AND deleted = FALSE;
  
  IF v_old_status IS NULL THEN
    RETURN QUERY SELECT FALSE, 'Barrier not found', 0;
    RETURN;
  END IF;

  -- Update Barrier status
  UPDATE barriers 
  SET status = p_new_status, updated_at = NOW(), updated_by = p_changed_by
  WHERE id = p_barrier_id;
  v_affected := v_affected + 1;

  -- Record history
  INSERT INTO barrier_status_history (barrier_id, previous_status, new_status, reason, triggered_by_incident, changed_by)
  VALUES (p_barrier_id, v_old_status, p_new_status, p_reason, p_incident_id, p_changed_by);

  -- Update linked LOPA IPL status
  IF v_lopa_ipl_id IS NOT NULL THEN
    UPDATE lopa_ipls
    SET status = CASE 
      WHEN p_new_status = 'Failed' THEN 'Failed'
      WHEN p_new_status = 'Degraded' THEN 'Degraded'
      ELSE status
    END,
    failure_count = CASE WHEN p_new_status = 'Failed' THEN failure_count + 1 ELSE failure_count END
    WHERE id = v_lopa_ipl_id;
    v_affected := v_affected + 1;
  END IF;

  -- Update linked BowTie barrier status
  IF v_bowtie_barrier_id IS NOT NULL THEN
    UPDATE bowtie_barriers
    SET barrier_status = CASE
      WHEN p_new_status = 'Failed' THEN 'Failed'
      WHEN p_new_status = 'Degraded' THEN 'Degraded'
      WHEN p_new_status = 'Active' THEN 'Active'
      ELSE barrier_status
    END,
    is_degraded = (p_new_status IN ('Degraded', 'Failed')),
    last_tested = NOW()
    WHERE id = v_bowtie_barrier_id;
    v_affected := v_affected + 1;
  END IF;

  RETURN QUERY SELECT TRUE, 'Barrier status updated successfully', v_affected;
END;
$$ LANGUAGE plpgsql;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 10. QUERY FUNCTION: Get all affected analyses when barrier fails
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION get_barrier_impact_analysis(p_barrier_id TEXT) 
RETURNS TABLE(
  analysis_type TEXT,
  analysis_id TEXT,
  analysis_title TEXT,
  severity TEXT,
  related_count INTEGER,
  last_updated TIMESTAMPTZ
) AS $$
BEGIN
  -- HAZOP deviations linked via incidents
  RETURN QUERY
  SELECT 
    'HAZOP'::TEXT,
    hd.id,
    hd.deviation,
    hd.risk_level,
    COUNT(*)::INTEGER,
    hd.updated_at
  FROM barriers b
  INNER JOIN incident_barriers ib ON b.id = ib.barrier_id
  INNER JOIN incidents inc ON ib.incident_id = inc.id
  INNER JOIN incident_hazop_mappings ihm ON inc.id = ihm.incident_id
  INNER JOIN hazop_deviations hd ON ihm.hazop_deviation_id = hd.id
  WHERE b.id = p_barrier_id AND b.deleted = FALSE
  GROUP BY hd.id, hd.deviation, hd.risk_level, hd.updated_at;

  -- LOPA scenarios linked via incidents
  RETURN QUERY
  SELECT 
    'LOPA'::TEXT,
    ls.id,
    ls.scenario_number,
    CASE 
      WHEN ls.risk_gap_met = FALSE THEN 'Non-Compliant'
      WHEN ls.risk_gap_met = TRUE THEN 'Compliant'
      ELSE 'Unknown'
    END,
    COUNT(*)::INTEGER,
    ls.updated_at
  FROM barriers b
  INNER JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
  INNER JOIN lopa_scenarios ls ON li.scenario_id = ls.id
  WHERE b.id = p_barrier_id AND b.deleted = FALSE AND li.deleted = FALSE
  GROUP BY ls.id, ls.scenario_number, ls.risk_gap_met, ls.updated_at;

  -- BowTie diagrams directly linked
  RETURN QUERY
  SELECT 
    'BowTie'::TEXT,
    bd.id,
    bd.title,
    'DIAGRAM'::TEXT,
    1::INTEGER,
    bd.updated_at
  FROM barriers b
  INNER JOIN bowtie_barriers bb ON b.bowtie_barrier_id = bb.id
  INNER JOIN bowtie_diagrams bd ON bb.diagram_id = bd.id
  WHERE b.id = p_barrier_id AND b.deleted = FALSE;
END;
$$ LANGUAGE plpgsql;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 11. QUERY FUNCTION: Get incident impact on multiple analysis types
-- ─────────────────────────────────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION get_incident_impact_summary(p_incident_id TEXT)
RETURNS TABLE(
  hazop_scenarios_affected INTEGER,
  lopa_studies_affected INTEGER,
  bowtie_diagrams_affected INTEGER,
  barriers_failed INTEGER,
  max_severity_hazop TEXT,
  max_severity_lopa NUMERIC
) AS $$
DECLARE
  v_hazop_count INTEGER := 0;
  v_lopa_count INTEGER := 0;
  v_bowtie_count INTEGER := 0;
  v_barrier_count INTEGER := 0;
  v_max_sev_hazop TEXT := 'Low';
  v_max_sev_lopa NUMERIC := 0;
BEGIN
  -- Count HAZOP scenarios
  SELECT COALESCE(COUNT(DISTINCT hazop_deviation_id), 0)::INTEGER
  INTO v_hazop_count
  FROM incident_hazop_mappings
  WHERE incident_id = p_incident_id;

  -- Count LOPA studies
  SELECT COALESCE(COUNT(DISTINCT lopa_study_id), 0)::INTEGER
  INTO v_lopa_count
  FROM incident_lopa_mappings
  WHERE incident_id = p_incident_id;

  -- Count BowTie diagrams
  SELECT COALESCE(COUNT(DISTINCT bowtie_diagram_id), 0)::INTEGER
  INTO v_bowtie_count
  FROM incident_bowtie_mappings
  WHERE incident_id = p_incident_id;

  -- Count failed barriers
  SELECT COALESCE(COUNT(DISTINCT barrier_id), 0)::INTEGER
  INTO v_barrier_count
  FROM incident_barriers
  WHERE incident_id = p_incident_id;

  -- Get max HAZOP severity
  SELECT COALESCE(MAX(hd.risk_level), 'Low')::TEXT
  INTO v_max_sev_hazop
  FROM incident_hazop_mappings ihm
  INNER JOIN hazop_deviations hd ON ihm.hazop_deviation_id = hd.id
  WHERE ihm.incident_id = p_incident_id;

  -- Get max LOPA residual risk
  SELECT COALESCE(MAX(ls.residual_risk), 0)::NUMERIC
  INTO v_max_sev_lopa
  FROM incident_lopa_mappings ilm
  INNER JOIN lopa_scenarios ls ON ilm.lopa_scenario_id = ls.id
  WHERE ilm.incident_id = p_incident_id;

  RETURN QUERY 
  SELECT v_hazop_count, v_lopa_count, v_bowtie_count, v_barrier_count, v_max_sev_hazop, v_max_sev_lopa;
END;
$$ LANGUAGE plpgsql;

-- ─────────────────────────────────────────────────────────────────────────────────────
-- 12. Migration tracking
-- ─────────────────────────────────────────────────────────────────────────────────────

INSERT INTO schema_migrations (version, applied_at)
VALUES ('030_integrated_risk_model', NOW())
ON CONFLICT DO NOTHING;

COMMIT;
