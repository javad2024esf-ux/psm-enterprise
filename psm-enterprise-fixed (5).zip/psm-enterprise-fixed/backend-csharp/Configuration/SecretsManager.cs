using System;
using System.Collections.Generic;

namespace PSM.Api.Configuration;

/// <summary>
/// Secure secrets management utility.
/// Handles sensitive configuration data with proper masking and validation.
/// Never logs or exposes secrets in error messages.
/// </summary>
public class SecretsManager
{
    private readonly Dictionary<string, string> _secrets = new();
    private const string MASKED_SECRET = "***REDACTED***";

    public void RegisterSecret(string key, string value)
    {
        if (string.IsNullOrWhiteSpace(key) || string.IsNullOrWhiteSpace(value))
            throw new ArgumentException("Secret key and value cannot be empty");

        _secrets[key] = value;
    }

    public string GetSecret(string key)
    {
        if (!_secrets.TryGetValue(key, out var value))
            throw new KeyNotFoundException($"Secret '{key}' not found");

        return value;
    }

    public bool TryGetSecret(string key, out string value)
    {
        return _secrets.TryGetValue(key, out value!);
    }

    public bool HasSecret(string key) => _secrets.ContainsKey(key);

    /// <summary>
    /// Returns masked version for logging/display purposes.
    /// Never use this for actual operations - always use GetSecret().
    /// </summary>
    public string GetMaskedSecret(string key)
    {
        return HasSecret(key) ? MASKED_SECRET : "NOT_SET";
    }

    /// <summary>
    /// Validates secret complexity and requirements.
    /// </summary>
    public static bool ValidateSecret(string secret, int minLength = 32)
    {
        if (string.IsNullOrWhiteSpace(secret))
            return false;

        // Secrets must be sufficiently long
        if (secret.Length < minLength)
            return false;

        // Should contain reasonable entropy (mix of character types)
        bool hasUpper = false, hasLower = false, hasDigit = false, hasSpecial = false;

        foreach (char c in secret)
        {
            if (char.IsUpper(c)) hasUpper = true;
            else if (char.IsLower(c)) hasLower = true;
            else if (char.IsDigit(c)) hasDigit = true;
            else hasSpecial = true;
        }

        // At least 3 of 4 character types
        int typesFound = (hasUpper ? 1 : 0) + (hasLower ? 1 : 0) + (hasDigit ? 1 : 0) + (hasSpecial ? 1 : 0);
        return typesFound >= 3;
    }
}
