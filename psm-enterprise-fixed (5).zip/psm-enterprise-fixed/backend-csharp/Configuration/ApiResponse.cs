namespace PSM.Api.Configuration;

/// <summary>
/// Standard API Response wrapper for all endpoints
/// </summary>
public class ApiResponse<T>
{
    public bool Success { get; set; }
    public T? Data { get; set; }
    public string? Message { get; set; }

    public ApiResponse() { }

    public ApiResponse(bool success, T? data = default, string? message = null)
    {
        Success = success;
        Data = data;
        Message = message;
    }

    /// <summary>Convenience constructor: infers success=true when data provided, false when null.</summary>
    public ApiResponse(T? data, string? message = null)
    {
        Data = data;
        Message = message;
        Success = data != null;
    }

    public static ApiResponse<T> SuccessResponse(T? data, string? message = null) =>
        new(true, data, message);

    public static ApiResponse<T> ErrorResponse(string message, T? data = default) =>
        new(false, data, message);
}

public class ApiResponse
{
    public bool Success { get; set; }
    public object? Data { get; set; }
    public string? Message { get; set; }

    public ApiResponse() { }

    public ApiResponse(bool success, object? data = null, string? message = null)
    {
        Success = success;
        Data = data;
        Message = message;
    }
}
