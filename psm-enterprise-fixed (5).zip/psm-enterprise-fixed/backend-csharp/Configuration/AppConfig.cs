namespace PSM.Api.Configuration;

/// <summary>
/// Application configuration settings loaded from environment variables.
/// </summary>
public class AppConfig
{
    /// <summary>JWT secret key for token signing (minimum 32 characters).</summary>
    public string JwtSecret { get; set; } = string.Empty;

    /// <summary>JWT token expiration time (e.g., "24h", "7d").</summary>
    public string JwtExpiresIn { get; set; } = "24h";

    /// <summary>Data directory for file storage.</summary>
    public string DataDir { get; set; } = string.Empty;

    /// <summary>Enable or disable AI features.</summary>
    public bool AiEnabled { get; set; }

    /// <summary>Anthropic API key for Claude API.</summary>
    public string AnthropicApiKey { get; set; } = string.Empty;

    /// <summary>AI model identifier (e.g., "claude-sonnet-4-6").</summary>
    public string AiModel { get; set; } = "claude-sonnet-4-6";

    /// <summary>License secret for validation.</summary>
    public string LicenseSecret { get; set; } = string.Empty;

    /// <summary>Database connection string.</summary>
    public string DbConnection { get; set; } = string.Empty;

    /// <summary>Redis connection string (optional).</summary>
    public string? RedisConnection { get; set; }

    /// <summary>SMTP server for email notifications.</summary>
    public string? SmtpServer { get; set; }

    /// <summary>SMTP port for email notifications.</summary>
    public int SmtpPort { get; set; } = 587;
}
