using PSM.Api.Repositories;
using PSM.Api.Services;

namespace PSM.Api.Configuration;

/// <summary>
/// Extension methods for configuring integrated risk management services
/// </summary>
public static class IntegratedRiskServiceCollectionExtensions
{
    /// <summary>
    /// Add all integrated risk management services to DI container
    /// Usage: services.AddIntegratedRiskServices();
    /// </summary>
    public static IServiceCollection AddIntegratedRiskServices(this IServiceCollection services)
    {
        // Repositories
        services.AddScoped<IBarrierRepository, BarrierRepository>();
        services.AddScoped<IIncidentRepository, IncidentRepository>();
        services.AddScoped<IIncidentBarrierRepository, IncidentBarrierRepository>();
        services.AddScoped<IIncidentHazopRepository, IncidentHazopRepository>();
        services.AddScoped<IIncidentLopaRepository, IncidentLopaRepository>();
        services.AddScoped<IIncidentBowTieRepository, IncidentBowTieRepository>();
        services.AddScoped<ICrossAnalysisRepository, CrossAnalysisRepository>();

        // Services
        services.AddScoped<IBarrierService, BarrierService>();
        services.AddScoped<IIncidentService, IncidentService>();
        services.AddScoped<IIntegratedRiskService, IntegratedRiskService>();

        return services;
    }
}

/// <summary>
/// INTEGRATED RISK MODEL — ARCHITECTURE & USAGE GUIDE
/// 
/// This implementation combines HAZOP (Hazard & Operability), LOPA (Layer of Protection Analysis),
/// and BowTie analysis into a unified risk management system with incident tracking.
/// </summary>
public class IntegratedRiskArchitecture
{
    /*
     * ════════════════════════════════════════════════════════════════════════════════════
     * 1. CORE CONCEPTS
     * ════════════════════════════════════════════════════════════════════════════════════
     * 
     * BARRIERS: Physical or administrative controls that protect against hazards
     *   - Created automatically when LOPA IPLs are created
     *   - Linked to both LOPA IPLs and BowTie barriers
     *   - Status tracked: Active, Degraded, Failed, Inactive
     *   - Failure cascades to update LOPA IPL and BowTie barrier status
     * 
     * INCIDENTS: Operational events (near-miss, injury, environmental release, etc.)
     *   - Linked to one or more failed barriers
     *   - Can be mapped to HAZOP scenarios, LOPA scenarios, BowTie diagrams
     *   - Shows comprehensive impact across all analysis types
     * 
     * HAZOP: Hazard & Operability study
     *   - Can create LOPA and BowTie directly from HAZOP deviations
     *   - When incident occurs, can link to relevant HAZOP scenarios
     * 
     * LOPA: Layer of Protection Analysis
     *   - IPLs (Independent Protection Layers) automatically create Barrier records
     *   - IPL status updated when linked barrier fails
     *   - Tracks risk reduction factors and SIL levels
     * 
     * BowTie: Barrier failure analysis
     *   - Linked to HAZOP via top event
     *   - Barriers linked to physical barrier records
     *   - Status of barriers reflected in BowTie diagram
     */

    /*
     * ════════════════════════════════════════════════════════════════════════════════════
     * 2. WORKFLOW: CREATING & LINKING ANALYSES
     * ════════════════════════════════════════════════════════════════════════════════════
     * 
     * SCENARIO 1: Create HAZOP, then LOPA & BowTie
     * ──────────────────────────────────────────────
     * 1. Create HAZOP study
     * 2. Identify hazards and deviations
     * 3. From HAZOP deviation, create LOPA study
     *    POST /api/risk-analysis/create-lopa-from-hazop
     * 4. Define LOPA scenarios and IPLs
     * 5. For each IPL, barrier record is created automatically
     * 6. From HAZOP deviation, create BowTie diagram
     *    POST /api/risk-analysis/create-bowtie-from-hazop
     * 7. Link BowTie barriers to barrier records
     * 
     * SCENARIO 2: Incident Occurs
     * ─────────────────────────────
     * 1. Create incident report
     *    POST /api/incidents
     * 2. Identify which barriers failed
     *    POST /api/incidents/{id}/barriers
     * 3. Link to affected HAZOP scenarios
     *    POST /api/incidents/{id}/hazop-mappings
     * 4. Link to affected LOPA scenarios
     *    POST /api/incidents/{id}/lopa-mappings
     * 5. Link to affected BowTie diagrams
     *    POST /api/incidents/{id}/bowtie-mappings
     * 6. Get comprehensive impact analysis
     *    GET /api/incidents/{id}/impact-analysis
     * 7. Update barrier status to "Failed" (cascades to LOPA & BowTie)
     *    PUT /api/barriers/{id}/status
     * 
     * SCENARIO 3: Barrier Failure
     * ────────────────────────────
     * 1. Barrier status is changed to "Failed"
     * 2. This automatically updates:
     *    - Linked LOPA IPL status to "Failed"
     *    - Linked BowTie barrier status to "Failed"
     *    - Status history records the change
     * 3. All affected analyses are queryable:
     *    GET /api/risk-analysis/barrier-impact/{barrierId}
     */

    /*
     * ════════════════════════════════════════════════════════════════════════════════════
     * 3. API ENDPOINTS SUMMARY
     * ════════════════════════════════════════════════════════════════════════════════════
     * 
     * BARRIERS
     * ────────
     * GET    /api/barriers                          List all barriers
     * GET    /api/barriers/with-analysis            List barriers with linked analysis counts
     * GET    /api/barriers/{id}                     Get specific barrier
     * GET    /api/barriers/by-lopa-ipl/{lopaIplId}  Get barrier by LOPA IPL ID
     * POST   /api/barriers                          Create barrier (typically from LOPA)
     * PUT    /api/barriers/{id}                     Update barrier details
     * PUT    /api/barriers/{id}/status              Update barrier status (cascades)
     * GET    /api/barriers/{id}/status-history      Get status change history
     * GET    /api/barriers/analytics/status-distribution
     * GET    /api/barriers/analytics/critical-count
     * 
     * INCIDENTS
     * ─────────
     * GET    /api/incidents                         List incidents
     * GET    /api/incidents/{id}                    Get specific incident
     * POST   /api/incidents                         Create incident
     * PUT    /api/incidents/{id}                    Update incident
     * PUT    /api/incidents/{id}/close              Close incident
     * POST   /api/incidents/{id}/barriers           Link barrier to incident
     * GET    /api/incidents/{id}/barriers           Get linked barriers
     * GET    /api/incidents/{id}/impact-analysis    Get comprehensive impact
     * POST   /api/incidents/{id}/barriers/batch     Batch link barriers
     * 
     * INTEGRATED RISK ANALYSIS
     * ────────────────────────
     * GET    /api/risk-analysis/barrier-impact/{barrierId}
     *        → Shows HAZOP, LOPA, BowTie affected by barrier failure
     * 
     * GET    /api/risk-analysis/incident-impact/{incidentId}
     *        → Shows all barriers, analyses affected by incident
     * 
     * POST   /api/risk-analysis/barrier-failure/{barrierId}
     *        → Handle barrier failure with cascade updates
     * 
     * GET    /api/risk-analysis/find-related-incidents
     *        → Find all incidents related to HAZOP/LOPA/BowTie
     * 
     * POST   /api/risk-analysis/batch-update-barriers
     *        → Update multiple barrier statuses at once
     * 
     * POST   /api/risk-analysis/create-lopa-from-hazop
     *        → Create LOPA study directly from HAZOP deviation
     * 
     * POST   /api/risk-analysis/create-bowtie-from-hazop
     *        → Create BowTie diagram directly from HAZOP deviation
     */

    /*
     * ════════════════════════════════════════════════════════════════════════════════════
     * 4. DATABASE SCHEMA RELATIONSHIPS
     * ════════════════════════════════════════════════════════════════════════════════════
     * 
     * barriers
     *   ├─ lopa_ipl_id (FK to lopa_ipls)
     *   ├─ bowtie_barrier_id (FK to bowtie_barriers)
     *   └─ status (Active, Degraded, Failed, Inactive)
     *       └─ Updates trigger cascade to lopa_ipls and bowtie_barriers
     * 
     * incident_barriers
     *   ├─ incident_id (FK to incidents)
     *   └─ barrier_id (FK to barriers)
     * 
     * incident_hazop_mappings
     *   ├─ incident_id (FK to incidents)
     *   ├─ hazop_deviation_id (FK to hazop_deviations)
     *   └─ hazop_study_id (FK to hazop_studies)
     * 
     * incident_lopa_mappings
     *   ├─ incident_id (FK to incidents)
     *   ├─ lopa_scenario_id (FK to lopa_scenarios)
     *   └─ lopa_study_id (FK to lopa_studies)
     * 
     * incident_bowtie_mappings
     *   ├─ incident_id (FK to incidents)
     *   └─ bowtie_diagram_id (FK to bowtie_diagrams)
     * 
     * barrier_status_history
     *   ├─ barrier_id (FK to barriers)
     *   ├─ triggered_by_incident (FK to incidents)
     *   └─ Audit trail of all barrier status changes
     */

    /*
     * ════════════════════════════════════════════════════════════════════════════════════
     * 5. CODE EXAMPLES
     * ════════════════════════════════════════════════════════════════════════════════════
     * 
     * Example 1: Create an Incident and Link Failed Barriers
     * ────────────────────────────────────────────────────────
     * 
     * // Create incident
     * var incidentReq = new CreateIncidentRequest
     * {
     *     incident_number = "INC-2024-001",
     *     title = "Pressure Relief Valve Failure",
     *     facility = "Plant A",
     *     severity_actual = 4,
     *     incident_type = "Equipment Damage",
     *     date_occurred = DateTime.UtcNow
     * };
     * var incident = await _incidentService.CreateIncidentAsync(incidentReq);
     * 
     * // Link barrier that failed
     * var barrierLinkReq = new CreateIncidentBarrierRequest
     * {
     *     incident_id = incident.Id,
     *     barrier_id = "barrier-123",
     *     barrier_failure_type = "Failed to Function",
     *     failure_evidence = "Valve did not open at setpoint"
     * };
     * await _incidentService.LinkBarrierAsync(barrierLinkReq);
     * 
     * // Update barrier status (cascades to LOPA & BowTie)
     * var updateReq = new UpdateBarrierStatusRequest
     * {
     *     new_status = "Failed",
     *     reason = "Incident INC-2024-001: Setpoint drift"
     * };
     * await _barrierService.UpdateBarrierStatusAsync("barrier-123", updateReq, userId);
     * 
     * // Get comprehensive impact
     * var impact = await _integratedRiskService.GetIncidentImpactAnalysisAsync(incident.Id);
     * // Shows:
     * // - All failed barriers
     * // - Affected HAZOP scenarios
     * // - Affected LOPA scenarios (IPL failures)
     * // - Affected BowTie diagrams
     * // - Impact summary
     * 
     * 
     * Example 2: Batch Update Multiple Barriers
     * ──────────────────────────────────────────
     * 
     * var batchReq = new BatchUpdateBarrierStatusRequest
     * {
     *     barrier_ids = new List<string> { "barrier-1", "barrier-2", "barrier-3" },
     *     new_status = "Degraded",
     *     reason = "Scheduled maintenance - expected duration 2 days"
     * };
     * var result = await _integratedRiskService.BatchUpdateBarrierStatusAsync(batchReq, userId);
     * 
     * // Result contains:
     * // - TotalProcessed: 3
     * // - SuccessfulCount: 3
     * // - FailedCount: 0
     * 
     * 
     * Example 3: Find Incidents Related to HAZOP Deviation
     * ────────────────────────────────────────────────────
     * 
     * var relatedIncidents = await _integratedRiskService.FindRelatedIncidentsAsync(
     *     hazopId: "dev-456"
     * );
     * // Returns all incidents linked to HAZOP deviation dev-456
     * 
     * 
     * Example 4: Create LOPA from HAZOP
     * ──────────────────────────────────
     * 
     * var lopaReq = new CreateLopaFromHazopRequest
     * {
     *     hazop_study_id = "study-123",
     *     hazop_deviation_id = "dev-456",
     *     title = "LOPA for High Pressure Event",
     *     facility = "Plant A"
     * };
     * var lopa = await _integratedRiskService.CreateLopaFromHazopAsync(lopaReq);
     * 
     * // Now define LOPA scenarios and IPLs
     * // When IPL is created, barrier record is created automatically
     */

    /*
     * ════════════════════════════════════════════════════════════════════════════════════
     * 6. DATABASE MIGRATION
     * ════════════════════════════════════════════════════════════════════════════════════
     * 
     * Run migration: 030_integrated_risk_model.sql
     * This creates:
     * - barriers table
     * - incidents table
     * - incident_barriers, incident_hazop_mappings, incident_lopa_mappings, incident_bowtie_mappings
     * - barrier_status_history table
     * - Functions: update_barrier_status_cascade, get_barrier_impact_analysis, get_incident_impact_summary
     */

    /*
     * ════════════════════════════════════════════════════════════════════════════════════
     * 7. KEY FEATURES
     * ════════════════════════════════════════════════════════════════════════════════════
     * 
     * ✓ Automatic Barrier Creation: When LOPA IPL is created, barrier is auto-created
     * ✓ Cascade Updates: Barrier status changes cascade to LOPA IPLs and BowTie barriers
     * ✓ Incident Tracking: Link incidents to barriers and all analyses
     * ✓ Cross-Analysis Queries: See which HAZOP, LOPA, BowTie affected by barrier failure
     * ✓ Impact Analysis: Comprehensive view of incident impact across all risk models
     * ✓ Audit Trail: Complete history of barrier status changes
     * ✓ Batch Operations: Update multiple barriers or link multiple barriers to incident
     * ✓ Analytics: Status distribution, failure patterns, incident trends
     * ✓ SIL Tracking: Monitor SIL levels for safety-critical barriers
     * ✓ Critical Flag: Mark barriers as critical for priority management
     */
}
