using Dapper;
using PSM.Api.Data;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

// ════════════════════════════════════════════════════════════════════════════
// Interface: IActionRegisterRepository
// ════════════════════════════════════════════════════════════════════════════

/// <summary>
/// Repository for action_register table.
/// Handles all data access operations for action register records.
/// Uses Dapper for high-performance data access.
/// </summary>
public interface IActionRegisterRepository
{
    /// <summary>
    /// Lists action registers with pagination and optional filtering.
    /// </summary>
    Task<(IEnumerable<ActionRegisterDto> Rows, long Total)> ListAsync(
        string? source, string? unit, string? status, string? priority,
        int limit, int offset);

    /// <summary>
    /// Gets a single action register by ID.
    /// </summary>
    Task<ActionRegisterDto?> GetByIdAsync(string id);

    /// <summary>
    /// Creates a new action register record.
    /// Returns the generated ID.
    /// </summary>
    Task<string> CreateAsync(
        string id, string title, string? description, string source,
        string? sourceId, string? sourceRef, string? unit, string? responsible,
        DateTime? dueDate, string status, string priority, string[]? tags,
        string? createdBy);

    /// <summary>
    /// Updates an existing action register record.
    /// Only non-null fields are updated.
    /// </summary>
    Task<bool> UpdateAsync(string id, UpdateActionRegisterRequest req, string updatedBy);

    /// <summary>
    /// Soft-deletes an action register record.
    /// </summary>
    Task<bool> DeleteAsync(string id);

    /// <summary>
    /// Gets aggregated statistics for the dashboard.
    /// </summary>
    Task<ActionRegisterStats> GetStatsAsync();

    /// <summary>
    /// Gets all overdue actions (past due date, not completed).
    /// </summary>
    Task<IEnumerable<ActionRegisterDto>> GetOverdueAsync();

    /// <summary>
    /// Searches actions by full-text match on title/description.
    /// </summary>
    Task<IEnumerable<ActionRegisterDto>> SearchAsync(string query, int limit);

    /// <summary>
    /// Gets actions by source ID (for cross-module references).
    /// </summary>
    Task<IEnumerable<ActionRegisterDto>> GetBySourceIdAsync(string sourceId);

    /// <summary>
    /// Gets actions assigned to a specific person.
    /// </summary>
    Task<IEnumerable<ActionRegisterDto>> GetByResponsibleAsync(string responsible);
}

// ════════════════════════════════════════════════════════════════════════════
// Implementation: ActionRegisterRepository
// ════════════════════════════════════════════════════════════════════════════

public class ActionRegisterRepository : IActionRegisterRepository
{
    private readonly IDbHelper _db;
    private readonly ILogger<ActionRegisterRepository> _logger;

    // SQL Column Selection — reuse across queries for consistency
    private const string COLUMNS = @"
        ar.id,
        ar.title,
        ar.description,
        ar.source,
        ar.source_id,
        ar.source_ref,
        ar.unit,
        ar.responsible,
        ar.due_date,
        ar.status,
        ar.priority,
        ar.completion_date,
        ar.verified_by,
        ar.verification_note,
        ar.tags,
        ar.created_at,
        ar.updated_at,
        ar.created_by";

    public ActionRegisterRepository(
        IDbHelper db,
        ILogger<ActionRegisterRepository> logger)
    {
        _db = db ?? throw new ArgumentNullException(nameof(db));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // LIST with Pagination & Filtering
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<(IEnumerable<ActionRegisterDto> Rows, long Total)> ListAsync(
        string? source, string? unit, string? status, string? priority,
        int limit, int offset)
    {
        try
        {
            limit = Math.Clamp(limit, 1, 500);
            offset = Math.Max(offset, 0);

            // Build WHERE clause dynamically
            var whereClauses = new List<string> { "ar.deleted = false" };
            var parameters = new DynamicParameters();

            parameters.Add("limit", limit);
            parameters.Add("offset", offset);

            if (!string.IsNullOrEmpty(source))
            {
                whereClauses.Add("ar.source = @source");
                parameters.Add("source", source);
            }

            if (!string.IsNullOrEmpty(unit))
            {
                whereClauses.Add("ar.unit = @unit");
                parameters.Add("unit", unit);
            }

            if (!string.IsNullOrEmpty(status))
            {
                whereClauses.Add("ar.status = @status");
                parameters.Add("status", status);
            }

            if (!string.IsNullOrEmpty(priority))
            {
                whereClauses.Add("ar.priority = @priority");
                parameters.Add("priority", priority);
            }

            var whereClause = string.Join(" AND ", whereClauses);

            // Main query with window function for total count
            var sql = $@"
                SELECT
                    {COLUMNS},
                    COUNT(*) OVER() AS total_count
                FROM action_register ar
                WHERE {whereClause}
                ORDER BY
                    ar.due_date ASC NULLS LAST,
                    ar.priority DESC NULLS LAST,
                    ar.created_at DESC
                LIMIT @limit OFFSET @offset";

            var rows = (await _db.QueryAsync<dynamic>(sql, parameters)).ToList();
            long total = rows.Count > 0 ? (long)(rows[0].total_count ?? 0L) : 0L;

            var dtos = rows.Select(MapRow).ToList();

            _logger.LogDebug("Listed {RowCount} action registers, total: {Total}",
                dtos.Count, total);

            return (dtos, total);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error listing action registers");
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // GET BY ID
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<ActionRegisterDto?> GetByIdAsync(string id)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(id))
                return null;

            var sql = $@"
                SELECT {COLUMNS}
                FROM action_register ar
                WHERE ar.id = @id AND ar.deleted = false";

            return await _db.QueryFirstOrDefaultAsync<ActionRegisterDto>(
                sql,
                new { id });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting action register {Id}", id);
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // CREATE
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<string> CreateAsync(
        string id, string title, string? description, string source,
        string? sourceId, string? sourceRef, string? unit, string? responsible,
        DateTime? dueDate, string status, string priority, string[]? tags,
        string? createdBy)
    {
        try
        {
            var sql = @"
                INSERT INTO action_register (
                    id, title, description, source, source_id, source_ref,
                    unit, responsible, due_date, status, priority, tags,
                    created_at, updated_at, created_by, deleted
                )
                VALUES (
                    @id, @title, @description, @source, @sourceId, @sourceRef,
                    @unit, @responsible, @dueDate, @status, @priority, @tags,
                    NOW(), NOW(), @createdBy, false
                )";

            await _db.ExecuteAsync(sql, new
            {
                id,
                title,
                description,
                source,
                sourceId,
                sourceRef,
                unit,
                responsible,
                dueDate,
                status,
                priority,
                tags,
                createdBy
            });

            _logger.LogDebug("Created action register {Id}", id);
            return id;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating action register");
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // UPDATE
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<bool> UpdateAsync(string id, UpdateActionRegisterRequest req, string updatedBy)
    {
        try
        {
            var existing = await GetByIdAsync(id);
            if (existing is null)
                return false;

            // Build dynamic UPDATE statement - only include fields that are not null
            var setClauses = new List<string>();
            var parameters = new DynamicParameters();
            parameters.Add("id", id);

            // Add each field to update if it's not null
            if (req.Title != null)
            {
                setClauses.Add("title = @title");
                parameters.Add("title", req.Title);
            }

            if (req.Description != null)
            {
                setClauses.Add("description = @description");
                parameters.Add("description", req.Description);
            }

            if (req.Source != null)
            {
                setClauses.Add("source = @source");
                parameters.Add("source", req.Source);
            }

            if (req.SourceId != null)
            {
                setClauses.Add("source_id = @sourceId");
                parameters.Add("sourceId", req.SourceId);
            }

            if (req.SourceRef != null)
            {
                setClauses.Add("source_ref = @sourceRef");
                parameters.Add("sourceRef", req.SourceRef);
            }

            if (req.Unit != null)
            {
                setClauses.Add("unit = @unit");
                parameters.Add("unit", req.Unit);
            }

            if (req.Responsible != null)
            {
                setClauses.Add("responsible = @responsible");
                parameters.Add("responsible", req.Responsible);
            }

            if (req.DueDate.HasValue)
            {
                setClauses.Add("due_date = @dueDate");
                parameters.Add("dueDate", req.DueDate.Value);
            }

            if (req.Status != null)
            {
                setClauses.Add("status = @status");
                parameters.Add("status", req.Status);
            }

            if (req.Priority != null)
            {
                setClauses.Add("priority = @priority");
                parameters.Add("priority", req.Priority);
            }

            if (req.CompletionDate.HasValue)
            {
                setClauses.Add("completion_date = @completionDate");
                parameters.Add("completionDate", req.CompletionDate.Value);
            }

            if (req.VerifiedBy != null)
            {
                setClauses.Add("verified_by = @verifiedBy");
                parameters.Add("verifiedBy", req.VerifiedBy);
            }

            if (req.VerificationNote != null)
            {
                setClauses.Add("verification_note = @verificationNote");
                parameters.Add("verificationNote", req.VerificationNote);
            }

            if (req.Tags != null)
            {
                setClauses.Add("tags = @tags");
                parameters.Add("tags", req.Tags);
            }

            // Always update timestamp
            setClauses.Add("updated_at = NOW()");

            if (setClauses.Count == 1) // Only updated_at, no actual changes
                return true;

            var sql = $@"
                UPDATE action_register
                SET {string.Join(", ", setClauses)}
                WHERE id = @id AND deleted = false";

            int affected = await _db.ExecuteAsync(sql, parameters);
            _logger.LogDebug("Updated action register {Id}, {AffectedRows} row(s)", id, affected);

            return affected > 0;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating action register {Id}", id);
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // DELETE (Soft)
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<bool> DeleteAsync(string id)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(id)) return false;

            var affected = await _db.ExecuteAsync(
                "UPDATE action_register SET deleted = true, updated_at = NOW() WHERE id = @id AND deleted = false",
                new { id });

            _logger.LogDebug("Soft-deleted action register {Id}, affected: {Rows}", id, affected);
            return affected > 0;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting action register {Id}", id);
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // STATISTICS
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<ActionRegisterStats> GetStatsAsync()
    {
        try
        {
            // Status counts
            var statusSql = @"
                SELECT
                    SUM(CASE WHEN status = 'Open' THEN 1 ELSE 0 END) as open_count,
                    SUM(CASE WHEN status = 'In Progress' THEN 1 ELSE 0 END) as in_progress_count,
                    SUM(CASE WHEN status = 'Overdue' THEN 1 ELSE 0 END) as overdue_count,
                    SUM(CASE WHEN status = 'Done' THEN 1 ELSE 0 END) as done_count,
                    SUM(CASE WHEN status = 'Verified' THEN 1 ELSE 0 END) as verified_count,
                    SUM(CASE WHEN status = 'Closed' THEN 1 ELSE 0 END) as closed_count,
                    COUNT(*) as total_count
                FROM action_register
                WHERE deleted = false";

            var statusRow = await _db.QueryFirstOrDefaultAsync<dynamic>(statusSql);

            var stats = new ActionRegisterStats
            {
                Open = statusRow?.open_count ?? 0,
                InProgress = statusRow?.in_progress_count ?? 0,
                Overdue = statusRow?.overdue_count ?? 0,
                Done = statusRow?.done_count ?? 0,
                Verified = statusRow?.verified_count ?? 0,
                Closed = statusRow?.closed_count ?? 0,
                Total = statusRow?.total_count ?? 0,
            };

            // By Priority
            var byPrioritySql = @"
                SELECT priority, COUNT(*) as cnt
                FROM action_register
                WHERE deleted = false
                GROUP BY priority
                ORDER BY cnt DESC";

            var byPriority = await _db.QueryAsync<dynamic>(byPrioritySql);
            foreach (var p in byPriority)
                stats.ByPriority[(string)p.priority] = (int)p.cnt;

            // By Source
            var bySourceSql = @"
                SELECT source, COUNT(*) as cnt
                FROM action_register
                WHERE deleted = false
                GROUP BY source
                ORDER BY cnt DESC";

            var bySource = await _db.QueryAsync<dynamic>(bySourceSql);
            foreach (var s in bySource)
                stats.BySource[(string)s.source] = (int)s.cnt;

            _logger.LogDebug("Statistics retrieved: {Total} total actions", stats.Total);
            return stats;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting action register statistics");
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // OVERDUE
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<IEnumerable<ActionRegisterDto>> GetOverdueAsync()
    {
        try
        {
            var sql = $@"
                SELECT {COLUMNS}
                FROM action_register ar
                WHERE ar.deleted = false
                  AND ar.due_date < CURRENT_DATE
                  AND ar.status NOT IN ('Done', 'Verified', 'Closed')
                ORDER BY ar.due_date ASC";

            return await _db.QueryAsync<ActionRegisterDto>(sql);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting overdue actions");
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SEARCH
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<IEnumerable<ActionRegisterDto>> SearchAsync(string query, int limit)
    {
        try
        {
            limit = Math.Clamp(limit, 1, 200);

            var sql = $@"
                SELECT {COLUMNS}
                FROM action_register ar
                WHERE ar.deleted = false
                  AND (
                    ar.title ILIKE @q
                    OR ar.description ILIKE @q
                    OR ar.source_ref ILIKE @q
                  )
                ORDER BY
                    CASE
                        WHEN ar.title ILIKE @q THEN 0
                        WHEN ar.source_ref ILIKE @q THEN 1
                        ELSE 2
                    END,
                    ar.created_at DESC
                LIMIT @limit";

            var searchPattern = $"%{query}%";
            return await _db.QueryAsync<ActionRegisterDto>(sql, new { q = searchPattern, limit });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error searching action register with query: {Query}", query);
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // GET BY SOURCE ID (for cross-module references)
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<IEnumerable<ActionRegisterDto>> GetBySourceIdAsync(string sourceId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(sourceId))
                return Enumerable.Empty<ActionRegisterDto>();

            var sql = $@"
                SELECT {COLUMNS}
                FROM action_register ar
                WHERE ar.source_id = @sourceId AND ar.deleted = false
                ORDER BY ar.created_at DESC";

            return await _db.QueryAsync<ActionRegisterDto>(sql, new { sourceId });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting actions by source ID: {SourceId}", sourceId);
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // GET BY RESPONSIBLE (for person assignments)
    // ─────────────────────────────────────────────────────────────────────────────

    public async Task<IEnumerable<ActionRegisterDto>> GetByResponsibleAsync(string responsible)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(responsible))
                return Enumerable.Empty<ActionRegisterDto>();

            var sql = $@"
                SELECT {COLUMNS}
                FROM action_register ar
                WHERE ar.responsible = @responsible AND ar.deleted = false
                ORDER BY
                    ar.due_date ASC NULLS LAST,
                    ar.priority DESC NULLS LAST,
                    ar.created_at DESC";

            return await _db.QueryAsync<ActionRegisterDto>(sql, new { responsible });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting actions by responsible: {Responsible}", responsible);
            throw;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // Helper: Map dynamic row to DTO
    // ─────────────────────────────────────────────────────────────────────────────

    private static ActionRegisterDto MapRow(dynamic r) => new()
    {
        Id = (string)r.id,
        Title = (string)r.title,
        Description = (string?)r.description,
        Source = (string)r.source,
        SourceId = (string?)r.source_id,
        SourceRef = (string?)r.source_ref,
        Unit = (string?)r.unit,
        Responsible = (string?)r.responsible,
        DueDate = r.due_date is null ? null : (DateTime?)r.due_date,
        Status = (string)r.status,
        Priority = (string)r.priority,
        CompletionDate = r.completion_date is null ? null : (DateTime?)r.completion_date,
        VerifiedBy = (string?)r.verified_by,
        VerificationNote = (string?)r.verification_note,
        Tags = r.tags as string[],
        CreatedAt = (DateTime)r.created_at,
        UpdatedAt = r.updated_at is null ? null : (DateTime?)r.updated_at,
        CreatedBy = (string?)r.created_by,
    };
}
