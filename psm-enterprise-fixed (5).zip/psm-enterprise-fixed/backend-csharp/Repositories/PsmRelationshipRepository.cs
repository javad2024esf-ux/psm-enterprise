using Dapper;
using PSM.Api.Data;
using PSM.Api.DTOs;
using PSM.Api.Models;

namespace PSM.Api.Repositories;

/// <summary>
/// Repository for managing PSM relationships between entities.
/// Provides operations for creating, querying, and analyzing relationships.
/// </summary>
public interface IPsmRelationshipRepository
{
    // Relationship Management
    Task<string> CreateRelationshipAsync(CreateRelationshipDto dto, string createdBy);
    Task UpdateRelationshipAsync(string id, UpdateRelationshipDto dto, string updatedBy);
    Task DeleteRelationshipAsync(string id, string deletedBy);
    Task<PsmRelationshipDto?> GetRelationshipAsync(string id);
    
    // Querying
    Task<IEnumerable<PsmRelationshipDto>> GetOutboundRelationshipsAsync(string entityId, string entityType);
    Task<IEnumerable<PsmRelationshipDto>> GetInboundRelationshipsAsync(string entityId, string entityType);
    Task<IEnumerable<PsmRelationshipDto>> GetRelationshipsByTypeAsync(string relationshipType);
    Task<RelationshipQueryDto> GetRelationshipGraphAsync(string entityId, string entityType, int maxDepth = 3);
    
    // Bulk Operations
    Task<BulkCreateRelationshipsResultDto> BulkCreateRelationshipsAsync(
        List<CreateRelationshipDto> dtos, string createdBy, string? batchDescription = null);
    
    // Analytics
    Task<RelationshipStatisticsDto> GetRelationshipStatisticsAsync();
    Task<CrossModuleFlowDto> GetCrossModuleFlowAsync(string sourceModule, string targetModule);
    Task<List<IntegrationHealthDto>> GetIntegrationHealthAsync();
    
    // Impact Analysis
    Task<ImpactAnalysisResultDto> AnalyzeImpactAsync(string entityId, string entityType);
    Task<EntityComplianceCheckDto> CheckEntityComplianceAsync(string entityId, string entityType);
}

public class PsmRelationshipRepository : IPsmRelationshipRepository
{
    private readonly IDbHelper _db;

    public PsmRelationshipRepository(IDbHelper db) => _db = db;

    public async Task<string> CreateRelationshipAsync(CreateRelationshipDto dto, string createdBy)
    {
        var id = Guid.NewGuid().ToString();
        var establishedDate = DateTime.UtcNow;

        await _db.ExecuteAsync(@"
            INSERT INTO psm_relationships (
                id, relationship_type, source_entity_type, source_entity_id,
                target_entity_type, target_entity_id, direction, weight, status,
                context, notes, established_date, created_by, deleted
            ) VALUES (
                @id, @relationshipType, @sourceEntityType, @sourceEntityId,
                @targetEntityType, @targetEntityId, @direction, @weight, 'Active',
                @context, @notes, @establishedDate, @createdBy, false
            )",
            new
            {
                id,
                dto.RelationshipType,
                dto.SourceEntityType,
                dto.SourceEntityId,
                dto.TargetEntityType,
                dto.TargetEntityId,
                direction = dto.Direction ?? "OneWay",
                dto.Weight,
                dto.Context,
                dto.Notes,
                establishedDate,
                createdBy
            });

        // Record relationship change
        await RecordRelationshipChangeAsync(id, "Created", null, null, null, "Initial creation", createdBy);

        // Invalidate cache for both entities
        await InvalidateCacheAsync(dto.SourceEntityId, dto.SourceEntityType);
        await InvalidateCacheAsync(dto.TargetEntityId, dto.TargetEntityType);

        return id;
    }

    public async Task UpdateRelationshipAsync(string id, UpdateRelationshipDto dto, string updatedBy)
    {
        // Get existing relationship for audit
        var existing = await GetRelationshipAsync(id);
        if (existing == null) throw new InvalidOperationException($"Relationship {id} not found");

        var sql = "UPDATE psm_relationships SET updated_by = @updatedBy, updated_at = NOW()";
        var parameters = new Dictionary<string, object?> { { "id", id }, { "updatedBy", updatedBy } };

        if (dto.Status != null)
        {
            sql += ", status = @status";
            parameters["status"] = dto.Status;
            await RecordRelationshipChangeAsync(id, "StatusChanged", "status", existing.Status, dto.Status, null, updatedBy);
        }

        if (dto.Weight.HasValue)
        {
            sql += ", weight = @weight";
            parameters["weight"] = dto.Weight;
            await RecordRelationshipChangeAsync(id, "Updated", "weight", existing.Weight?.ToString(), dto.Weight.ToString(), null, updatedBy);
        }

        if (dto.Context != null && dto.Context != existing.Context)
        {
            sql += ", context = @context";
            parameters["context"] = dto.Context;
            await RecordRelationshipChangeAsync(id, "Updated", "context", existing.Context, dto.Context, null, updatedBy);
        }

        sql += " WHERE id = @id";
        await _db.ExecuteAsync(sql, parameters);

        // Invalidate cache
        await InvalidateCacheAsync(existing.SourceEntityId, existing.SourceEntityType);
        await InvalidateCacheAsync(existing.TargetEntityId, existing.TargetEntityType);
    }

    public async Task DeleteRelationshipAsync(string id, string deletedBy)
    {
        var existing = await GetRelationshipAsync(id);
        if (existing == null) throw new InvalidOperationException($"Relationship {id} not found");

        await _db.ExecuteAsync(
            "UPDATE psm_relationships SET deleted = true, updated_by = @deletedBy, updated_at = NOW() WHERE id = @id",
            new { id, deletedBy });

        await RecordRelationshipChangeAsync(id, "Deleted", null, null, null, "Soft delete", deletedBy);

        // Invalidate cache
        await InvalidateCacheAsync(existing.SourceEntityId, existing.SourceEntityType);
        await InvalidateCacheAsync(existing.TargetEntityId, existing.TargetEntityType);
    }

    public Task<PsmRelationshipDto?> GetRelationshipAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<PsmRelationshipDto>(
            @"SELECT id, relationship_type as RelationshipType, source_entity_type as SourceEntityType,
                     source_entity_id as SourceEntityId, target_entity_type as TargetEntityType,
                     target_entity_id as TargetEntityId, direction, weight, status, context,
                     established_date as EstablishedDate, created_at as CreatedAt
              FROM psm_relationships
              WHERE id = @id AND deleted = false",
            new { id });

    public Task<IEnumerable<PsmRelationshipDto>> GetOutboundRelationshipsAsync(string entityId, string entityType) =>
        _db.QueryAsync<PsmRelationshipDto>(
            @"SELECT id, relationship_type as RelationshipType, source_entity_type as SourceEntityType,
                     source_entity_id as SourceEntityId, target_entity_type as TargetEntityType,
                     target_entity_id as TargetEntityId, direction, weight, status, context,
                     established_date as EstablishedDate, created_at as CreatedAt
              FROM psm_relationships
              WHERE source_entity_id = @entityId AND source_entity_type = @entityType
                AND status = 'Active' AND deleted = false
              ORDER BY established_date DESC",
            new { entityId, entityType });

    public Task<IEnumerable<PsmRelationshipDto>> GetInboundRelationshipsAsync(string entityId, string entityType) =>
        _db.QueryAsync<PsmRelationshipDto>(
            @"SELECT id, relationship_type as RelationshipType, source_entity_type as SourceEntityType,
                     source_entity_id as SourceEntityId, target_entity_type as TargetEntityType,
                     target_entity_id as TargetEntityId, direction, weight, status, context,
                     established_date as EstablishedDate, created_at as CreatedAt
              FROM psm_relationships
              WHERE target_entity_id = @entityId AND target_entity_type = @entityType
                AND status = 'Active' AND deleted = false
              ORDER BY established_date DESC",
            new { entityId, entityType });

    public Task<IEnumerable<PsmRelationshipDto>> GetRelationshipsByTypeAsync(string relationshipType) =>
        _db.QueryAsync<PsmRelationshipDto>(
            @"SELECT id, relationship_type as RelationshipType, source_entity_type as SourceEntityType,
                     source_entity_id as SourceEntityId, target_entity_type as TargetEntityType,
                     target_entity_id as TargetEntityId, direction, weight, status, context,
                     established_date as EstablishedDate, created_at as CreatedAt
              FROM psm_relationships
              WHERE relationship_type = @relationshipType AND status = 'Active' AND deleted = false
              ORDER BY established_date DESC",
            new { relationshipType });

    public async Task<RelationshipQueryDto> GetRelationshipGraphAsync(string entityId, string entityType, int maxDepth = 3)
    {
        var outbound = (await GetOutboundRelationshipsAsync(entityId, entityType)).ToList();
        var inbound = (await GetInboundRelationshipsAsync(entityId, entityType)).ToList();

        var outboundNodes = outbound.Select(r => new RelationshipGraphNodeDto(
            r.TargetEntityId,
            r.TargetEntityType,
            r.RelationshipType,
            1,
            null,
            null
        )).ToList();

        var inboundNodes = inbound.Select(r => new RelationshipGraphNodeDto(
            r.SourceEntityId,
            r.SourceEntityType,
            r.RelationshipType,
            1,
            null,
            null
        )).ToList();

        var relSummary = new Dictionary<string, int>();
        foreach (var rel in outbound.Concat(inbound))
        {
            var key = rel.RelationshipType;
            relSummary[key] = relSummary.ContainsKey(key) ? relSummary[key] + 1 : 1;
        }

        return new RelationshipQueryDto(entityId, entityType, inboundNodes, outboundNodes, relSummary);
    }

    public async Task<BulkCreateRelationshipsResultDto> BulkCreateRelationshipsAsync(
        List<CreateRelationshipDto> dtos, string createdBy, string? batchDescription = null)
    {
        var successCount = 0;
        var failureCount = 0;
        var createdIds = new List<string>();
        var failures = new List<string>();

        foreach (var dto in dtos)
        {
            try
            {
                var id = await CreateRelationshipAsync(dto, createdBy);
                createdIds.Add(id);
                successCount++;
            }
            catch (Exception ex)
            {
                failureCount++;
                failures.Add($"{dto.SourceEntityId}->{dto.TargetEntityId}: {ex.Message}");
            }
        }

        return new BulkCreateRelationshipsResultDto(successCount, failureCount, createdIds, failures);
    }

    public async Task<RelationshipStatisticsDto> GetRelationshipStatisticsAsync()
    {
        var total = await _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM psm_relationships WHERE deleted = false");

        var byType = (await _db.QueryAsync<(string RelationshipType, int Count)>(
            @"SELECT relationship_type, COUNT(1) as Count
              FROM psm_relationships
              WHERE deleted = false AND status = 'Active'
              GROUP BY relationship_type
              ORDER BY Count DESC")).ToDictionary(x => x.RelationshipType, x => x.Count);

        var byEntityType = (await _db.QueryAsync<(string EntityType, int Count)>(
            @"SELECT source_entity_type, COUNT(1) as Count
              FROM psm_relationships
              WHERE deleted = false AND status = 'Active'
              GROUP BY source_entity_type
              ORDER BY Count DESC")).ToDictionary(x => x.EntityType, x => x.Count);

        var active = await _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM psm_relationships WHERE status = 'Active' AND deleted = false");

        var archived = await _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM psm_relationships WHERE status = 'Archived' AND deleted = false");

        var topRels = (await _db.QueryAsync<(string RelationshipType, int Count)>(
            @"SELECT relationship_type, COUNT(1) as Count
              FROM psm_relationships
              WHERE status = 'Active' AND deleted = false
              GROUP BY relationship_type
              ORDER BY Count DESC LIMIT 10"))
            .Select(x => new TopRelationshipDto(x.RelationshipType, x.Count, (double)x.Count / total * 100))
            .ToList();

        return new RelationshipStatisticsDto(
            total,
            byType,
            byEntityType,
            active,
            archived,
            topRels,
            DateTime.UtcNow);
    }

    public async Task<CrossModuleFlowDto> GetCrossModuleFlowAsync(string sourceModule, string targetModule)
    {
        // This would need to be implemented based on your module linking logic
        var relationships = new List<PsmRelationshipDto>();
        var sourceIds = new List<string>();
        var targetIds = new List<string>();

        await Task.CompletedTask;
        return new CrossModuleFlowDto(sourceModule, targetModule, relationships, 0, sourceIds, targetIds);
    }

    public async Task<List<IntegrationHealthDto>> GetIntegrationHealthAsync()
    {
        var modules = new[] { "PSI", "HAZOP", "LOPA", "MOC", "PSSR", "RCA", "BowTie", "ActionRegister" };
        var health = new List<IntegrationHealthDto>();

        for (int i = 0; i < modules.Length; i++)
        {
            for (int j = i + 1; j < modules.Length; j++)
            {
                var flow = await GetCrossModuleFlowAsync(modules[i], modules[j]);
                var missingIntegrations = new List<string>();
                var healthStatus = flow.RelationshipCount > 0 ? "Good" : "Warning";

                health.Add(new IntegrationHealthDto(
                    modules[i],
                    modules[j],
                    flow.RelationshipCount,
                    missingIntegrations,
                    healthStatus,
                    null));
            }
        }

        return health;
    }

    public async Task<ImpactAnalysisResultDto> AnalyzeImpactAsync(string entityId, string entityType)
    {
        var directly = (await GetOutboundRelationshipsAsync(entityId, entityType)).ToList();
        var directlyImpacted = directly.Select(r => new ImpactedItemDto(
            r.TargetEntityId,
            r.TargetEntityType,
            r.RelationshipType,
            1,
            null,
            null,
            null
        )).ToList();

        var indirectlyImpacted = new List<ImpactedItemDto>();

        return new ImpactAnalysisResultDto(
            entityId,
            entityType,
            directlyImpacted,
            indirectlyImpacted,
            directlyImpacted.Count,
            "Low",
            null,
            DateTime.UtcNow);
    }

    public async Task<EntityComplianceCheckDto> CheckEntityComplianceAsync(string entityId, string entityType)
    {
        var outbound = (await GetOutboundRelationshipsAsync(entityId, entityType)).ToList();
        var inbound = (await GetInboundRelationshipsAsync(entityId, entityType)).ToList();

        var missing = new List<string>();
        var excess = new List<string>();
        var issues = new List<string>();

        if (outbound.Count == 0 && inbound.Count == 0)
        {
            issues.Add($"{entityType} {entityId} has no relationships defined");
        }

        return new EntityComplianceCheckDto(
            entityId,
            entityType,
            issues.Count == 0,
            missing,
            excess,
            issues,
            null);
    }

    private async Task RecordRelationshipChangeAsync(
        string relationshipId, string changeType, string? fieldChanged,
        string? oldValue, string? newValue, string? reason, string? changedBy)
    {
        var id = Guid.NewGuid().ToString();
        await _db.ExecuteAsync(@"
            INSERT INTO psm_relationship_changes (
                id, relationship_id, change_type, field_changed, old_value, new_value,
                reason, changed_by, change_timestamp, created_at, deleted
            ) VALUES (
                @id, @relationshipId, @changeType, @fieldChanged, @oldValue, @newValue,
                @reason, @changedBy, @changeTimestamp, NOW(), false
            )",
            new
            {
                id,
                relationshipId,
                changeType,
                fieldChanged,
                oldValue,
                newValue,
                reason,
                changedBy,
                changeTimestamp = DateTime.UtcNow
            });
    }

    private async Task InvalidateCacheAsync(string entityId, string entityType)
    {
        // This would invalidate any cached relationship counts/graphs for the entity
        await _db.ExecuteAsync(
            @"DELETE FROM psm_relationship_cache
              WHERE entity_id = @entityId AND entity_type = @entityType",
            new { entityId, entityType });
    }
}

/// <summary>
/// Repository for domain entities (Asset, ProcessUnit, Hazard, etc.)
/// </summary>
public interface IPsmDomainEntityRepository
{
    // Asset operations
    Task<string> CreateAssetAsync(CreateAssetDto dto, string createdBy);
    Task<AssetDto?> GetAssetAsync(string id);
    Task<IEnumerable<AssetDto>> ListAssetsAsync(string? unit = null);

    // ProcessUnit operations
    Task<string> CreateProcessUnitAsync(ProcessUnitDto dto, string createdBy);
    Task<ProcessUnitDto?> GetProcessUnitAsync(string id);
    Task<IEnumerable<ProcessUnitDto>> ListProcessUnitsAsync();

    // Hazard operations
    Task<string> CreateHazardAsync(HazardDto dto, string createdBy);
    Task<HazardDto?> GetHazardAsync(string id);
    Task<IEnumerable<HazardDto>> ListHazardsAsync(string? processUnitId = null);

    // ActionItem operations
    Task<string> CreateActionItemAsync(ActionItemDto dto, string createdBy);
    Task<ActionItemDto?> GetActionItemAsync(string id);
    Task<IEnumerable<ActionItemDto>> ListActionItemsAsync(string? sourceModule = null, string? status = null);
    Task<bool> UpdateActionItemAsync(string id, ActionItemDto dto);

    // Similar operations for other domain entities...
}

public class PsmDomainEntityRepository : IPsmDomainEntityRepository
{
    private readonly IDbHelper _db;

    public PsmDomainEntityRepository(IDbHelper db) => _db = db;

    public async Task<string> CreateAssetAsync(CreateAssetDto dto, string createdBy)
    {
        var id = Guid.NewGuid().ToString();
        await _db.ExecuteAsync(@"
            INSERT INTO psm_assets (
                id, name, description, category, manufacturer, model_number,
                serial_number, unit, status, design_code, criticality, drawing_reference,
                created_by, deleted
            ) VALUES (
                @id, @name, @description, @category, @manufacturer, @modelNumber,
                @serialNumber, @unit, @status, @designCode, @criticality, @drawingReference,
                @createdBy, false
            )",
            new
            {
                id,
                Name = dto.Name,
                Description = dto.Description,
                Category = dto.Category,
                Manufacturer = dto.Manufacturer,
                ModelNumber = dto.ModelNumber,
                SerialNumber = dto.SerialNumber,
                Unit = dto.Unit,
                Status = dto.Status ?? "Active",
                DesignCode = dto.DesignCode,
                Criticality = dto.Criticality,
                DrawingReference = dto.DrawingReference,
                CreatedBy = createdBy
            });
        return id;
    }

    public Task<AssetDto?> GetAssetAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<AssetDto>(
            @"SELECT id, name, description, category, manufacturer, model_number,
                     serial_number, unit, installation_date, last_maintenance, status,
                     design_code, criticality, drawing_reference, created_at, updated_at, created_by
              FROM psm_assets WHERE id = @id AND deleted = false",
            new { id });

    public Task<IEnumerable<AssetDto>> ListAssetsAsync(string? unit = null)
    {
        var sql = @"SELECT id, name, description, category, manufacturer, model_number,
                          serial_number, unit, installation_date, last_maintenance, status,
                          design_code, criticality, drawing_reference, created_at, updated_at, created_by
                   FROM psm_assets WHERE deleted = false";
        if (!string.IsNullOrEmpty(unit))
            sql += " AND unit = @unit";
        sql += " ORDER BY name";
        return _db.QueryAsync<AssetDto>(sql, new { unit });
    }

    public async Task<string> CreateProcessUnitAsync(ProcessUnitDto dto, string createdBy)
    {
        var id = Guid.NewGuid().ToString();
        await _db.ExecuteAsync(@"
            INSERT INTO psm_process_units (
                id, name, description, unit_type, location, operating_mode,
                design_temperature, design_pressure, pressure_unit, status,
                responsible_person, created_by, deleted
            ) VALUES (
                @id, @name, @description, @unitType, @location, @operatingMode,
                @designTemperature, @designPressure, @pressureUnit, @status,
                @responsiblePerson, @createdBy, false
            )",
            new
            {
                id,
                Name = dto.Name,
                Description = dto.Description,
                UnitType = dto.UnitType,
                Location = dto.Location,
                OperatingMode = dto.OperatingMode,
                DesignTemperature = dto.DesignTemperature,
                DesignPressure = dto.DesignPressure,
                PressureUnit = dto.PressureUnit,
                Status = dto.Status ?? "Operating",
                ResponsiblePerson = dto.ResponsiblePerson,
                CreatedBy = createdBy
            });
        return id;
    }

    public Task<ProcessUnitDto?> GetProcessUnitAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<ProcessUnitDto>(
            @"SELECT id, name, description, unit_type, location, operating_mode,
                     design_temperature, design_pressure, status, responsible_person,
                     created_at, updated_at
              FROM psm_process_units WHERE id = @id AND deleted = false",
            new { id });

    public Task<IEnumerable<ProcessUnitDto>> ListProcessUnitsAsync() =>
        _db.QueryAsync<ProcessUnitDto>(
            @"SELECT id, name, description, unit_type, location, operating_mode,
                     design_temperature, design_pressure, status, responsible_person,
                     created_at, updated_at
              FROM psm_process_units WHERE deleted = false ORDER BY name");

    public async Task<string> CreateHazardAsync(HazardDto dto, string createdBy)
    {
        var id = Guid.NewGuid().ToString();
        await _db.ExecuteAsync(@"
            INSERT INTO psm_hazards (
                id, name, description, hazard_category, hazard_source, severity,
                probability, risk_level, status, process_unit_id, identified_date,
                identified_by, created_by, deleted
            ) VALUES (
                @id, @name, @description, @hazardCategory, @hazardSource, @severity,
                @probability, @riskLevel, @status, @processUnitId, @identifiedDate,
                @identifiedBy, @createdBy, false
            )",
            new
            {
                id,
                Name = dto.Name,
                Description = dto.Description,
                HazardCategory = dto.HazardCategory,
                HazardSource = dto.HazardSource,
                Severity = dto.Severity,
                Probability = dto.Probability,
                RiskLevel = dto.RiskLevel,
                Status = dto.Status ?? "Identified",
                ProcessUnitId = dto.ProcessUnitId,
                IdentifiedDate = dto.IdentifiedDate,
                IdentifiedBy = dto.IdentifiedBy,
                CreatedBy = createdBy
            });
        return id;
    }

    public Task<HazardDto?> GetHazardAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<HazardDto>(
            @"SELECT id, name, description, hazard_category, hazard_source, severity,
                     probability, risk_level, status, process_unit_id, identified_date, created_at
              FROM psm_hazards WHERE id = @id AND deleted = false",
            new { id });

    public Task<IEnumerable<HazardDto>> ListHazardsAsync(string? processUnitId = null)
    {
        var sql = @"SELECT id, name, description, hazard_category, hazard_source, severity,
                          probability, risk_level, status, process_unit_id, identified_date, created_at
                   FROM psm_hazards WHERE deleted = false";
        if (!string.IsNullOrEmpty(processUnitId))
            sql += " AND process_unit_id = @processUnitId";
        sql += " ORDER BY created_at DESC";
        return _db.QueryAsync<HazardDto>(sql, new { processUnitId });
    }

    public async Task<string> CreateActionItemAsync(ActionItemDto dto, string createdBy)
    {
        var id = Guid.NewGuid().ToString();
        await _db.ExecuteAsync(@"
            INSERT INTO psm_action_items (
                id, title, description, action_type, priority, status, owner,
                due_date, source_module, source_id, created_by, deleted
            ) VALUES (
                @id, @title, @description, @actionType, @priority, @status, @owner,
                @dueDate, @sourceModule, @sourceId, @createdBy, false
            )",
            new
            {
                id,
                dto.Title,
                dto.Description,
                dto.ActionType,
                dto.Priority,
                dto.Status,
                dto.Owner,
                dto.DueDate,
                dto.SourceModule,
                dto.SourceId,
                createdBy
            });
        return id;
    }

    public Task<ActionItemDto?> GetActionItemAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<ActionItemDto>(
            @"SELECT id, title, description, action_type, priority, status, owner,
                     due_date, completion_date, source_module, source_id, verified_by,
                     verification_date, created_at
              FROM psm_action_items WHERE id = @id AND deleted = false",
            new { id });

    public Task<IEnumerable<ActionItemDto>> ListActionItemsAsync(string? sourceModule = null, string? status = null)
    {
        var sql = @"SELECT id, title, description, action_type, priority, status, owner,
                          due_date, completion_date, source_module, source_id, verified_by,
                          verification_date, created_at
                   FROM psm_action_items WHERE deleted = false";
        if (!string.IsNullOrEmpty(sourceModule))
            sql += " AND source_module = @sourceModule";
        if (!string.IsNullOrEmpty(status))
            sql += " AND status = @status";
        sql += " ORDER BY due_date ASC";
        return _db.QueryAsync<ActionItemDto>(sql, new { sourceModule, status });
    }

    public async Task<bool> UpdateActionItemAsync(string id, ActionItemDto dto)
    {
        var rows = await _db.ExecuteAsync(@"
            UPDATE psm_action_items SET
                title = @title,
                description = @description,
                action_type = @actionType,
                priority = @priority,
                status = @status,
                owner = @owner,
                due_date = @dueDate,
                completion_date = @completionDate,
                verified_by = @verifiedBy,
                verification_date = @verificationDate
            WHERE id = @id AND deleted = false",
            new
            {
                id,
                dto.Title,
                dto.Description,
                dto.ActionType,
                dto.Priority,
                dto.Status,
                dto.Owner,
                dto.DueDate,
                dto.CompletionDate,
                dto.VerifiedBy,
                dto.VerificationDate
            });
        return rows > 0;
    }
}
