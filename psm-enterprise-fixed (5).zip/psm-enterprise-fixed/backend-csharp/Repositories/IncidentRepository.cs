using Npgsql;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT REPOSITORY IMPLEMENTATION
// ════════════════════════════════════════════════════════════════════════════════════

public class IncidentRepository : IIncidentRepository
{
    private readonly string _connectionString;

    public IncidentRepository(IConfiguration config)
    {
        _connectionString = config.GetConnectionString("DefaultConnection")!;
    }

    public async Task<IncidentDto> CreateIncidentAsync(
        string id, string incidentNumber, string title, string? description,
        string? facility, string? unit, DateTime dateOccurred,
        string? reporterName, string? reporterContact, string incidentType,
        int severityActual, string? rootCause, string? immediateActions,
        string? correctiveActions, string? preventiveActions, string status,
        string? investigationLead, string? lessonsLearned, bool sharedWithIndustry,
        string? data)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO incidents (
                id, incident_number, title, description, facility, unit,
                date_occurred, reporter_name, reporter_contact, incident_type,
                severity_actual, root_cause, immediate_actions, corrective_actions,
                preventive_actions, status, investigation_lead, lessons_learned,
                shared_with_industry, data
            ) VALUES (
                @id, @incidentNumber, @title, @description, @facility, @unit,
                @dateOccurred, @reporterName, @reporterContact, @incidentType,
                @severityActual, @rootCause, @immediateActions, @correctiveActions,
                @preventiveActions, @status, @investigationLead, @lessonsLearned,
                @sharedWithIndustry, @data::jsonb
            ) RETURNING *;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@incidentNumber", incidentNumber);
        cmd.Parameters.AddWithValue("@title", title);
        cmd.Parameters.AddWithValue("@description", description ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@facility", facility ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@unit", unit ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@dateOccurred", dateOccurred);
        cmd.Parameters.AddWithValue("@reporterName", reporterName ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@reporterContact", reporterContact ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@incidentType", incidentType);
        cmd.Parameters.AddWithValue("@severityActual", severityActual);
        cmd.Parameters.AddWithValue("@rootCause", rootCause ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@immediateActions", immediateActions ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@correctiveActions", correctiveActions ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@preventiveActions", preventiveActions ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@status", status);
        cmd.Parameters.AddWithValue("@investigationLead", investigationLead ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@lessonsLearned", lessonsLearned ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@sharedWithIndustry", sharedWithIndustry);
        cmd.Parameters.AddWithValue("@data", data ?? "{}");

        await using var reader = await cmd.ExecuteReaderAsync();
        reader.Read();
        return MapIncidentDto(reader);
    }

    public async Task<IncidentDto?> GetIncidentAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM incidents
            WHERE id = @id AND deleted = FALSE;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        await using var reader = await cmd.ExecuteReaderAsync();
        return reader.Read() ? MapIncidentDto(reader) : null;
    }

    public async Task<IncidentDto?> GetIncidentByNumberAsync(string incidentNumber)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM incidents
            WHERE incident_number = @number AND deleted = FALSE;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@number", incidentNumber);

        await using var reader = await cmd.ExecuteReaderAsync();
        return reader.Read() ? MapIncidentDto(reader) : null;
    }

    public async Task<IEnumerable<IncidentDto>> ListIncidentsAsync(
        string? statusFilter = null, string? facilityFilter = null,
        int? severityMinimum = null, DateTime? dateFrom = null,
        DateTime? dateTo = null, int pageNumber = 1, int pageSize = 50)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        var sql = @"
            SELECT * FROM incidents
            WHERE deleted = FALSE";

        if (!string.IsNullOrEmpty(statusFilter))
            sql += " AND status = @status";
        if (!string.IsNullOrEmpty(facilityFilter))
            sql += " AND facility = @facility";
        if (severityMinimum.HasValue)
            sql += " AND severity_actual >= @severityMinimum";
        if (dateFrom.HasValue)
            sql += " AND date_occurred >= @dateFrom";
        if (dateTo.HasValue)
            sql += " AND date_occurred <= @dateTo";

        sql += @" ORDER BY date_occurred DESC
                LIMIT @limit OFFSET @offset;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        if (!string.IsNullOrEmpty(statusFilter))
            cmd.Parameters.AddWithValue("@status", statusFilter);
        if (!string.IsNullOrEmpty(facilityFilter))
            cmd.Parameters.AddWithValue("@facility", facilityFilter);
        if (severityMinimum.HasValue)
            cmd.Parameters.AddWithValue("@severityMinimum", severityMinimum);
        if (dateFrom.HasValue)
            cmd.Parameters.AddWithValue("@dateFrom", dateFrom);
        if (dateTo.HasValue)
            cmd.Parameters.AddWithValue("@dateTo", dateTo);

        cmd.Parameters.AddWithValue("@limit", pageSize);
        cmd.Parameters.AddWithValue("@offset", (pageNumber - 1) * pageSize);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<IncidentDto>();
        while (reader.Read())
            result.Add(MapIncidentDto(reader));
        return result;
    }

    public async Task<IEnumerable<IncidentDto>> SearchIncidentsAsync(string searchTerm)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM incidents
            WHERE deleted = FALSE AND (
                title ILIKE @searchTerm OR
                description ILIKE @searchTerm OR
                root_cause ILIKE @searchTerm OR
                incident_number ILIKE @searchTerm
            ) ORDER BY date_occurred DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@searchTerm", $"%{searchTerm}%");

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<IncidentDto>();
        while (reader.Read())
            result.Add(MapIncidentDto(reader));
        return result;
    }

    public async Task UpdateIncidentAsync(
        string id, string? title, string? description, string? facility,
        string? unit, string? rootCause, string? immediateActions,
        string? correctiveActions, string? preventiveActions, string? status,
        string? investigationLead, string? lessonsLearned, bool? sharedWithIndustry,
        string? data)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            UPDATE incidents SET
                title = COALESCE(@title, title),
                description = COALESCE(@description, description),
                facility = COALESCE(@facility, facility),
                unit = COALESCE(@unit, unit),
                root_cause = COALESCE(@rootCause, root_cause),
                immediate_actions = COALESCE(@immediateActions, immediate_actions),
                corrective_actions = COALESCE(@correctiveActions, corrective_actions),
                preventive_actions = COALESCE(@preventiveActions, preventive_actions),
                status = COALESCE(@status, status),
                investigation_lead = COALESCE(@investigationLead, investigation_lead),
                lessons_learned = COALESCE(@lessonsLearned, lessons_learned),
                shared_with_industry = COALESCE(@sharedWithIndustry, shared_with_industry),
                data = COALESCE(@data::jsonb, data),
                updated_at = NOW()
            WHERE id = @id AND deleted = FALSE;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@title", title ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@description", description ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@facility", facility ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@unit", unit ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@rootCause", rootCause ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@immediateActions", immediateActions ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@correctiveActions", correctiveActions ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@preventiveActions", preventiveActions ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@status", status ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@investigationLead", investigationLead ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@lessonsLearned", lessonsLearned ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@sharedWithIndustry", sharedWithIndustry ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@data", data ?? (object)DBNull.Value);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<bool> CloseIncidentAsync(string id, string? lessonsLearned)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            UPDATE incidents SET
                status = 'Closed',
                lessons_learned = COALESCE(@lessonsLearned, lessons_learned),
                date_closed = NOW(),
                updated_at = NOW()
            WHERE id = @id AND deleted = FALSE;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@lessonsLearned", lessonsLearned ?? (object)DBNull.Value);

        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<bool> DeleteIncidentAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = "DELETE FROM incidents WHERE id = @id;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<bool> SoftDeleteIncidentAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            UPDATE incidents
            SET deleted = TRUE, updated_at = NOW()
            WHERE id = @id;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<bool> IncidentExistsAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = "SELECT 1 FROM incidents WHERE id = @id AND deleted = FALSE;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        return await cmd.ExecuteScalarAsync() != null;
    }

    public async Task<int> GetTotalIncidentsAsync()
    {
        return (int?)await GetIncidentCountByCondition("deleted = FALSE") ?? 0;
    }

    public async Task<int> GetOpenIncidentsAsync()
    {
        return (int?)await GetIncidentCountByCondition("status != 'Closed' AND deleted = FALSE") ?? 0;
    }

    public async Task<int> GetIncidentsInPeriodAsync(DateTime from, DateTime to)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT COUNT(*) FROM incidents
            WHERE deleted = FALSE AND date_occurred BETWEEN @from AND @to;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@from", from);
        cmd.Parameters.AddWithValue("@to", to);

        return (int?)await cmd.ExecuteScalarAsync() ?? 0;
    }

    public async Task<Dictionary<string, int>> GetIncidentTypeDistributionAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT incident_type, COUNT(*) as count
            FROM incidents
            WHERE deleted = FALSE
            GROUP BY incident_type
            ORDER BY count DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        await using var reader = await cmd.ExecuteReaderAsync();

        var result = new Dictionary<string, int>();
        while (reader.Read())
            result[(string)reader["incident_type"]] = (int)reader["count"];
        return result;
    }

    public async Task<Dictionary<int, int>> GetIncidentsBySeverityAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT severity_actual, COUNT(*) as count
            FROM incidents
            WHERE deleted = FALSE
            GROUP BY severity_actual
            ORDER BY severity_actual ASC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        await using var reader = await cmd.ExecuteReaderAsync();

        var result = new Dictionary<int, int>();
        while (reader.Read())
            result[(int)reader["severity_actual"]] = (int)reader["count"];
        return result;
    }

    // Private helpers
    private async Task<object?> GetIncidentCountByCondition(string condition)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        var sql = $"SELECT COUNT(*) FROM incidents WHERE {condition};";
        await using var cmd = new NpgsqlCommand(sql, conn);
        return await cmd.ExecuteScalarAsync();
    }

    private IncidentDto MapIncidentDto(NpgsqlDataReader reader)
    {
        return new IncidentDto
        {
            Id = reader.IsDBNull(0) ? null : reader.GetString(0),
            IncidentNumber = reader.IsDBNull(1) ? null : reader.GetString(1),
            Title = reader.IsDBNull(2) ? null : reader.GetString(2),
            Description = reader.IsDBNull(3) ? null : reader.GetString(3),
            Facility = reader.IsDBNull(4) ? null : reader.GetString(4),
            Unit = reader.IsDBNull(5) ? null : reader.GetString(5),
            DateOccurred = reader.IsDBNull(6) ? null : reader.GetDateTime(6),
            DateReported = reader.IsDBNull(7) ? null : reader.GetDateTime(7),
            ReporterName = reader.IsDBNull(8) ? null : reader.GetString(8),
            ReporterContact = reader.IsDBNull(9) ? null : reader.GetString(9),
            IncidentType = reader.IsDBNull(10) ? null : reader.GetString(10),
            SeverityActual = reader.GetInt32(11),
            RootCause = reader.IsDBNull(12) ? null : reader.GetString(12),
            ImmediateActions = reader.IsDBNull(13) ? null : reader.GetString(13),
            CorrectiveActions = reader.IsDBNull(14) ? null : reader.GetString(14),
            PreventiveActions = reader.IsDBNull(15) ? null : reader.GetString(15),
            Status = reader.IsDBNull(16) ? null : reader.GetString(16),
            InvestigationLead = reader.IsDBNull(17) ? null : reader.GetString(17),
            DateClosed = reader.IsDBNull(18) ? null : reader.GetDateTime(18),
            LessonsLearned = reader.IsDBNull(19) ? null : reader.GetString(19),
            SharedWithIndustry = reader.GetBoolean(20),
            CreatedAt = reader.IsDBNull(21) ? null : reader.GetDateTime(21),
            UpdatedAt = reader.IsDBNull(22) ? null : reader.GetDateTime(22),
            Data = reader.IsDBNull(24) ? null : reader.GetString(24)
        };
    }

    // ── IntegratedRiskModelService additions ────────────────────────────────────

    public async Task<IEnumerable<IncidentBarrierDto>> GetIncidentBarriersAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT ib.id, ib.incident_id, ib.barrier_id,
                   ib.barrier_failure_type, ib.failure_evidence,
                   ib.contribution_to_incident, ib.created_at
            FROM incident_barriers ib
            WHERE ib.incident_id = @incidentId
            ORDER BY ib.created_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        var result = new List<IncidentBarrierDto>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new IncidentBarrierDto
            {
                Id = reader.IsDBNull(0) ? null : reader.GetString(0),
                IncidentId = reader.IsDBNull(1) ? null : reader.GetString(1),
                BarrierId = reader.IsDBNull(2) ? null : reader.GetString(2),
                BarrierFailureType = reader.IsDBNull(3) ? null : reader.GetString(3),
                FailureEvidence = reader.IsDBNull(4) ? null : reader.GetString(4),
                ContributionToIncident = reader.IsDBNull(5) ? null : reader.GetDecimal(5),
                CreatedAt = reader.IsDBNull(6) ? null : reader.GetDateTime(6)
            });
        }
        return result;
    }

    public async Task<IncidentBarrierDto> LinkBarrierAsync(string id, string incidentId,
        string barrierId, string? barrierFailureType, string? failureEvidence, decimal contribution)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO incident_barriers
                (id, incident_id, barrier_id, barrier_failure_type, failure_evidence,
                 contribution_to_incident, created_at)
            VALUES
                (@id, @incidentId, @barrierId, @barrierFailureType, @failureEvidence,
                 @contribution, NOW())
            ON CONFLICT (incident_id, barrier_id) DO UPDATE
                SET barrier_failure_type = EXCLUDED.barrier_failure_type,
                    failure_evidence = EXCLUDED.failure_evidence,
                    contribution_to_incident = EXCLUDED.contribution_to_incident
            RETURNING id, incident_id, barrier_id, barrier_failure_type,
                      failure_evidence, contribution_to_incident, created_at;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);
        cmd.Parameters.AddWithValue("@barrierId", barrierId);
        cmd.Parameters.AddWithValue("@barrierFailureType", barrierFailureType ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@failureEvidence", failureEvidence ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@contribution", contribution);

        await using var reader = await cmd.ExecuteReaderAsync();
        await reader.ReadAsync();
        return new IncidentBarrierDto
        {
            Id = reader.IsDBNull(0) ? null : reader.GetString(0),
            IncidentId = reader.IsDBNull(1) ? null : reader.GetString(1),
            BarrierId = reader.IsDBNull(2) ? null : reader.GetString(2),
            BarrierFailureType = reader.IsDBNull(3) ? null : reader.GetString(3),
            FailureEvidence = reader.IsDBNull(4) ? null : reader.GetString(4),
            ContributionToIncident = reader.IsDBNull(5) ? null : reader.GetDecimal(5),
            CreatedAt = reader.IsDBNull(6) ? null : reader.GetDateTime(6)
        };
    }

    public async Task<int> GetIncidentCountAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();
        const string sql = "SELECT COUNT(*)::int FROM incidents WHERE deleted = FALSE;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        return (int)(await cmd.ExecuteScalarAsync())!;
    }

    public async Task<int> GetOpenIncidentsCountAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();
        const string sql = @"
            SELECT COUNT(*)::int FROM incidents
            WHERE deleted = FALSE AND status NOT IN ('Closed','Resolved');";
        await using var cmd = new NpgsqlCommand(sql, conn);
        return (int)(await cmd.ExecuteScalarAsync())!;
    }

    public async Task<int> GetHighSeverityIncidentsCountAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();
        const string sql = @"
            SELECT COUNT(*)::int FROM incidents
            WHERE deleted = FALSE AND severity_actual >= 4;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        return (int)(await cmd.ExecuteScalarAsync())!;
    }

    public async Task<int> GetIncidentsWithBarrierFailuresCountAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();
        const string sql = @"
            SELECT COUNT(DISTINCT i.id)::int
            FROM incidents i
            JOIN incident_barriers ib ON ib.incident_id = i.id
            WHERE i.deleted = FALSE;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        return (int)(await cmd.ExecuteScalarAsync())!;
    }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT-BARRIER REPOSITORY IMPLEMENTATION
// ════════════════════════════════════════════════════════════════════════════════════

public class IncidentBarrierRepository : IIncidentBarrierRepository
{
    private readonly string _connectionString;

    public IncidentBarrierRepository(IConfiguration config)
    {
        _connectionString = config.GetConnectionString("DefaultConnection")!;
    }

    public async Task<IncidentBarrierDto> CreateIncidentBarrierAsync(
        string id, string incidentId, string barrierId, string? barrierFailureType,
        string? failureEvidence, decimal? contributionToIncident)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO incident_barriers (
                id, incident_id, barrier_id, barrier_failure_type,
                failure_evidence, contribution_to_incident
            ) VALUES (
                @id, @incidentId, @barrierId, @barrierFailureType,
                @failureEvidence, @contributionToIncident
            ) RETURNING *;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);
        cmd.Parameters.AddWithValue("@barrierId", barrierId);
        cmd.Parameters.AddWithValue("@barrierFailureType", barrierFailureType ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@failureEvidence", failureEvidence ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@contributionToIncident", contributionToIncident ?? (object)DBNull.Value);

        await using var reader = await cmd.ExecuteReaderAsync();
        reader.Read();
        return MapIncidentBarrierDto(reader);
    }

    public async Task<IncidentBarrierDto?> GetIncidentBarrierAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = "SELECT * FROM incident_barriers WHERE id = @id;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        await using var reader = await cmd.ExecuteReaderAsync();
        return reader.Read() ? MapIncidentBarrierDto(reader) : null;
    }

    public async Task<IEnumerable<IncidentBarrierDto>> GetIncidentBarriersAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM incident_barriers
            WHERE incident_id = @incidentId
            ORDER BY created_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<IncidentBarrierDto>();
        while (reader.Read())
            result.Add(MapIncidentBarrierDto(reader));
        return result;
    }

    public async Task<IEnumerable<IncidentBarrierDto>> GetBarrierIncidentsAsync(string barrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM incident_barriers
            WHERE barrier_id = @barrierId
            ORDER BY created_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@barrierId", barrierId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<IncidentBarrierDto>();
        while (reader.Read())
            result.Add(MapIncidentBarrierDto(reader));
        return result;
    }

    public async Task UpdateIncidentBarrierAsync(
        string id, string? barrierFailureType, string? failureEvidence,
        decimal? contributionToIncident)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            UPDATE incident_barriers SET
                barrier_failure_type = COALESCE(@barrierFailureType, barrier_failure_type),
                failure_evidence = COALESCE(@failureEvidence, failure_evidence),
                contribution_to_incident = COALESCE(@contributionToIncident, contribution_to_incident)
            WHERE id = @id;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@barrierFailureType", barrierFailureType ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@failureEvidence", failureEvidence ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@contributionToIncident", contributionToIncident ?? (object)DBNull.Value);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<bool> DeleteIncidentBarrierAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = "DELETE FROM incident_barriers WHERE id = @id;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<int> GetFailedBarrierCountForIncidentAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT COUNT(DISTINCT barrier_id) FROM incident_barriers
            WHERE incident_id = @incidentId;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        return (int?)await cmd.ExecuteScalarAsync() ?? 0;
    }

    private IncidentBarrierDto MapIncidentBarrierDto(NpgsqlDataReader reader)
    {
        return new IncidentBarrierDto
        {
            Id = reader.IsDBNull(0) ? null : reader.GetString(0),
            IncidentId = reader.IsDBNull(1) ? null : reader.GetString(1),
            BarrierId = reader.IsDBNull(2) ? null : reader.GetString(2),
            BarrierFailureType = reader.IsDBNull(3) ? null : reader.GetString(3),
            FailureEvidence = reader.IsDBNull(4) ? null : reader.GetString(4),
            ContributionToIncident = reader.IsDBNull(5) ? null : reader.GetDecimal(5),
            CreatedAt = reader.IsDBNull(6) ? null : reader.GetDateTime(6)
        };
    }
}
