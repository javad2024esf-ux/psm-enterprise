namespace PSM.Api.Repositories;

using Npgsql;
using PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT-HAZOP MAPPING REPOSITORY IMPLEMENTATION
// ════════════════════════════════════════════════════════════════════════════════════

public class IncidentHazopRepository : IIncidentHazopRepository
{
    private readonly string _connectionString;

    public IncidentHazopRepository(IConfiguration config)
    {
        _connectionString = config.GetConnectionString("DefaultConnection")!;
    }

    public async Task<IncidentHazopMappingDto> CreateMappingAsync(
        string id, string incidentId, string hazopDeviationId, string hazopStudyId,
        decimal? relevanceScore, string? notes)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO incident_hazop_mappings (
                id, incident_id, hazop_deviation_id, hazop_study_id,
                relevance_score, notes
            ) VALUES (
                @id, @incidentId, @hazopDeviationId, @hazopStudyId,
                @relevanceScore, @notes
            ) RETURNING *;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);
        cmd.Parameters.AddWithValue("@hazopDeviationId", hazopDeviationId);
        cmd.Parameters.AddWithValue("@hazopStudyId", hazopStudyId);
        cmd.Parameters.AddWithValue("@relevanceScore", relevanceScore ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@notes", notes ?? (object)DBNull.Value);

        await using var reader = await cmd.ExecuteReaderAsync();
        reader.Read();
        return MapMappingDto(reader);
    }

    public async Task<IncidentHazopMappingDto?> GetMappingAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = "SELECT * FROM incident_hazop_mappings WHERE id = @id;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        await using var reader = await cmd.ExecuteReaderAsync();
        return reader.Read() ? MapMappingDto(reader) : null;
    }

    public async Task<IEnumerable<IncidentHazopMappingDto>> GetIncidentHazopMappingsAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM incident_hazop_mappings
            WHERE incident_id = @incidentId
            ORDER BY created_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<IncidentHazopMappingDto>();
        while (reader.Read())
            result.Add(MapMappingDto(reader));
        return result;
    }

    public async Task<IEnumerable<IncidentHazopMappingDto>> GetHazopIncidentMappingsAsync(string deviationId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM incident_hazop_mappings
            WHERE hazop_deviation_id = @deviationId
            ORDER BY created_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@deviationId", deviationId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<IncidentHazopMappingDto>();
        while (reader.Read())
            result.Add(MapMappingDto(reader));
        return result;
    }

    public async Task UpdateMappingAsync(string id, decimal? relevanceScore, string? notes)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            UPDATE incident_hazop_mappings SET
                relevance_score = COALESCE(@relevanceScore, relevance_score),
                notes = COALESCE(@notes, notes)
            WHERE id = @id;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@relevanceScore", relevanceScore ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@notes", notes ?? (object)DBNull.Value);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<bool> DeleteMappingAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = "DELETE FROM incident_hazop_mappings WHERE id = @id;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<int> GetMappedHazopScenariosCountAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT COUNT(DISTINCT hazop_deviation_id) FROM incident_hazop_mappings
            WHERE incident_id = @incidentId;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        return (int?)await cmd.ExecuteScalarAsync() ?? 0;
    }

    private IncidentHazopMappingDto MapMappingDto(NpgsqlDataReader reader)
    {
        return new IncidentHazopMappingDto
        {
            Id = reader.IsDBNull(0) ? null : reader.GetString(0),
            IncidentId = reader.IsDBNull(1) ? null : reader.GetString(1),
            HazopDeviationId = reader.IsDBNull(2) ? null : reader.GetString(2),
            HazopStudyId = reader.IsDBNull(3) ? null : reader.GetString(3),
            RelevanceScore = reader.IsDBNull(4) ? null : reader.GetDecimal(4),
            Notes = reader.IsDBNull(5) ? null : reader.GetString(5),
            CreatedAt = reader.IsDBNull(6) ? null : reader.GetDateTime(6)
        };
    }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT-LOPA MAPPING REPOSITORY IMPLEMENTATION
// ════════════════════════════════════════════════════════════════════════════════════

public class IncidentLopaRepository : IIncidentLopaRepository
{
    private readonly string _connectionString;

    public IncidentLopaRepository(IConfiguration config)
    {
        _connectionString = config.GetConnectionString("DefaultConnection")!;
    }

    public async Task<IncidentLopaMappingDto> CreateMappingAsync(
        string id, string incidentId, string lopaScenarioId, string lopaStudyId,
        decimal? relevanceScore, int? iplFailureCount, string? notes)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO incident_lopa_mappings (
                id, incident_id, lopa_scenario_id, lopa_study_id,
                relevance_score, ipl_failure_count, notes
            ) VALUES (
                @id, @incidentId, @lopaScenarioId, @lopaStudyId,
                @relevanceScore, @iplFailureCount, @notes
            ) RETURNING *;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);
        cmd.Parameters.AddWithValue("@lopaScenarioId", lopaScenarioId);
        cmd.Parameters.AddWithValue("@lopaStudyId", lopaStudyId);
        cmd.Parameters.AddWithValue("@relevanceScore", relevanceScore ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@iplFailureCount", iplFailureCount ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@notes", notes ?? (object)DBNull.Value);

        await using var reader = await cmd.ExecuteReaderAsync();
        reader.Read();
        return MapMappingDto(reader);
    }

    public async Task<IncidentLopaMappingDto?> GetMappingAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = "SELECT * FROM incident_lopa_mappings WHERE id = @id;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        await using var reader = await cmd.ExecuteReaderAsync();
        return reader.Read() ? MapMappingDto(reader) : null;
    }

    public async Task<IEnumerable<IncidentLopaMappingDto>> GetIncidentLopaMappingsAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM incident_lopa_mappings
            WHERE incident_id = @incidentId
            ORDER BY created_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<IncidentLopaMappingDto>();
        while (reader.Read())
            result.Add(MapMappingDto(reader));
        return result;
    }

    public async Task<IEnumerable<IncidentLopaMappingDto>> GetLopaIncidentMappingsAsync(string lopaScenarioId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM incident_lopa_mappings
            WHERE lopa_scenario_id = @lopaScenarioId
            ORDER BY created_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@lopaScenarioId", lopaScenarioId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<IncidentLopaMappingDto>();
        while (reader.Read())
            result.Add(MapMappingDto(reader));
        return result;
    }

    public async Task UpdateMappingAsync(
        string id, decimal? relevanceScore, int? iplFailureCount, string? notes)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            UPDATE incident_lopa_mappings SET
                relevance_score = COALESCE(@relevanceScore, relevance_score),
                ipl_failure_count = COALESCE(@iplFailureCount, ipl_failure_count),
                notes = COALESCE(@notes, notes)
            WHERE id = @id;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@relevanceScore", relevanceScore ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@iplFailureCount", iplFailureCount ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@notes", notes ?? (object)DBNull.Value);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<bool> DeleteMappingAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = "DELETE FROM incident_lopa_mappings WHERE id = @id;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<int> GetMappedLopaStudiesCountAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT COUNT(DISTINCT lopa_study_id) FROM incident_lopa_mappings
            WHERE incident_id = @incidentId;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        return (int?)await cmd.ExecuteScalarAsync() ?? 0;
    }

    private IncidentLopaMappingDto MapMappingDto(NpgsqlDataReader reader)
    {
        return new IncidentLopaMappingDto
        {
            Id = reader.IsDBNull(0) ? null : reader.GetString(0),
            IncidentId = reader.IsDBNull(1) ? null : reader.GetString(1),
            LopaScenarioId = reader.IsDBNull(2) ? null : reader.GetString(2),
            LopaStudyId = reader.IsDBNull(3) ? null : reader.GetString(3),
            RelevanceScore = reader.IsDBNull(4) ? null : reader.GetDecimal(4),
            IplFailureCount = reader.IsDBNull(5) ? 0 : reader.GetInt32(5),
            Notes = reader.IsDBNull(6) ? null : reader.GetString(6),
            CreatedAt = reader.IsDBNull(7) ? null : reader.GetDateTime(7)
        };
    }
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT-BOWTIE MAPPING REPOSITORY IMPLEMENTATION
// ════════════════════════════════════════════════════════════════════════════════════

public class IncidentBowTieRepository : IIncidentBowTieRepository
{
    private readonly string _connectionString;

    public IncidentBowTieRepository(IConfiguration config)
    {
        _connectionString = config.GetConnectionString("DefaultConnection")!;
    }

    public async Task<IncidentBowTieMappingDto> CreateMappingAsync(
        string id, string incidentId, string bowTieDiagramId, bool topEventOccurred,
        int? barriersFailed, decimal? relevanceScore, string? notes)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO incident_bowtie_mappings (
                id, incident_id, bowtie_diagram_id, top_event_occurred,
                barriers_failed, relevance_score, notes
            ) VALUES (
                @id, @incidentId, @bowTieDiagramId, @topEventOccurred,
                @barriersFailed, @relevanceScore, @notes
            ) RETURNING *;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);
        cmd.Parameters.AddWithValue("@bowTieDiagramId", bowTieDiagramId);
        cmd.Parameters.AddWithValue("@topEventOccurred", topEventOccurred);
        cmd.Parameters.AddWithValue("@barriersFailed", barriersFailed ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@relevanceScore", relevanceScore ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@notes", notes ?? (object)DBNull.Value);

        await using var reader = await cmd.ExecuteReaderAsync();
        reader.Read();
        return MapMappingDto(reader);
    }

    public async Task<IncidentBowTieMappingDto?> GetMappingAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = "SELECT * FROM incident_bowtie_mappings WHERE id = @id;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        await using var reader = await cmd.ExecuteReaderAsync();
        return reader.Read() ? MapMappingDto(reader) : null;
    }

    public async Task<IEnumerable<IncidentBowTieMappingDto>> GetIncidentBowTieMappingsAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM incident_bowtie_mappings
            WHERE incident_id = @incidentId
            ORDER BY created_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<IncidentBowTieMappingDto>();
        while (reader.Read())
            result.Add(MapMappingDto(reader));
        return result;
    }

    public async Task<IEnumerable<IncidentBowTieMappingDto>> GetBowTieIncidentMappingsAsync(string diagramId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM incident_bowtie_mappings
            WHERE bowtie_diagram_id = @diagramId
            ORDER BY created_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@diagramId", diagramId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<IncidentBowTieMappingDto>();
        while (reader.Read())
            result.Add(MapMappingDto(reader));
        return result;
    }

    public async Task UpdateMappingAsync(
        string id, bool? topEventOccurred, int? barriersFailed,
        decimal? relevanceScore, string? notes)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            UPDATE incident_bowtie_mappings SET
                top_event_occurred = COALESCE(@topEventOccurred, top_event_occurred),
                barriers_failed = COALESCE(@barriersFailed, barriers_failed),
                relevance_score = COALESCE(@relevanceScore, relevance_score),
                notes = COALESCE(@notes, notes)
            WHERE id = @id;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@topEventOccurred", topEventOccurred ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@barriersFailed", barriersFailed ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@relevanceScore", relevanceScore ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@notes", notes ?? (object)DBNull.Value);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<bool> DeleteMappingAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = "DELETE FROM incident_bowtie_mappings WHERE id = @id;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<int> GetMappedBowTieDiagramsCountAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT COUNT(DISTINCT bowtie_diagram_id) FROM incident_bowtie_mappings
            WHERE incident_id = @incidentId;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        return (int?)await cmd.ExecuteScalarAsync() ?? 0;
    }

    private IncidentBowTieMappingDto MapMappingDto(NpgsqlDataReader reader)
    {
        return new IncidentBowTieMappingDto
        {
            Id = reader.IsDBNull(0) ? null : reader.GetString(0),
            IncidentId = reader.IsDBNull(1) ? null : reader.GetString(1),
            BowTieDiagramId = reader.IsDBNull(2) ? null : reader.GetString(2),
            TopEventOccurred = reader.GetBoolean(3),
            BarriersFailed = reader.IsDBNull(4) ? 0 : reader.GetInt32(4),
            RelevanceScore = reader.IsDBNull(5) ? null : reader.GetDecimal(5),
            Notes = reader.IsDBNull(6) ? null : reader.GetString(6),
            CreatedAt = reader.IsDBNull(7) ? null : reader.GetDateTime(7)
        };
    }
}

// ════════════════════════════════════════════════════════════════════════════════════
// COMPREHENSIVE CROSS-ANALYSIS REPOSITORY IMPLEMENTATION
// ════════════════════════════════════════════════════════════════════════════════════

public class CrossAnalysisRepository : ICrossAnalysisRepository
{
    private readonly string _connectionString;

    public CrossAnalysisRepository(IConfiguration config)
    {
        _connectionString = config.GetConnectionString("DefaultConnection")!;
    }

    public async Task<IncidentDetailedAnalysisDto> GetIncidentDetailedAnalysisAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        // Get incident
        const string incidentSql = "SELECT * FROM incidents WHERE id = @incidentId;";
        await using var incidentCmd = new NpgsqlCommand(incidentSql, conn);
        incidentCmd.Parameters.AddWithValue("@incidentId", incidentId);

        await using var incidentReader = await incidentCmd.ExecuteReaderAsync();
        var incident = incidentReader.Read() ? MapIncidentDto(incidentReader) : null;

        // Get failed barriers (junction rows carrying failure metadata for this incident)
        const string barriersSql = @"
            SELECT * FROM incident_barriers
            WHERE incident_id = @incidentId
            ORDER BY created_at DESC;";

        var barriers = new List<IncidentBarrierDto>();
        await using var barriersCmd = new NpgsqlCommand(barriersSql, conn);
        barriersCmd.Parameters.AddWithValue("@incidentId", incidentId);
        await using var barriersReader = await barriersCmd.ExecuteReaderAsync();
        while (barriersReader.Read())
            barriers.Add(MapIncidentBarrierDto(barriersReader));

        // Get affected HAZOP scenarios
        const string hazopSql = @"
            SELECT * FROM incident_hazop_mappings
            WHERE incident_id = @incidentId;";

        var hazopMappings = new List<IncidentHazopMappingDto>();
        await using var hazopCmd = new NpgsqlCommand(hazopSql, conn);
        hazopCmd.Parameters.AddWithValue("@incidentId", incidentId);
        await using var hazopReader = await hazopCmd.ExecuteReaderAsync();
        while (hazopReader.Read())
            hazopMappings.Add(MapHazopMappingDto(hazopReader));

        // Get affected LOPA scenarios
        const string lopaSql = @"
            SELECT * FROM incident_lopa_mappings
            WHERE incident_id = @incidentId;";

        var lopaMappings = new List<IncidentLopaMappingDto>();
        await using var lopaCmd = new NpgsqlCommand(lopaSql, conn);
        lopaCmd.Parameters.AddWithValue("@incidentId", incidentId);
        await using var lopaReader = await lopaCmd.ExecuteReaderAsync();
        while (lopaReader.Read())
            lopaMappings.Add(MapLopaMappingDto(lopaReader));

        // Get affected BowTie diagrams
        const string bowtieSql = @"
            SELECT * FROM incident_bowtie_mappings
            WHERE incident_id = @incidentId;";

        var bowtieMapping = new List<IncidentBowTieMappingDto>();
        await using var bowtieCmd = new NpgsqlCommand(bowtieSql, conn);
        bowtieCmd.Parameters.AddWithValue("@incidentId", incidentId);
        await using var bowtieReader = await bowtieCmd.ExecuteReaderAsync();
        while (bowtieReader.Read())
            bowtieMapping.Add(MapBowTieMappingDto(bowtieReader));

        // Get impact summary
        const string impactSql = @"
            SELECT * FROM get_incident_impact_summary(@incidentId);";

        var impactSummary = new IncidentImpactDto { IncidentId = incidentId };
        await using var impactCmd = new NpgsqlCommand(impactSql, conn);
        impactCmd.Parameters.AddWithValue("@incidentId", incidentId);
        await using var impactReader = await impactCmd.ExecuteReaderAsync();
        if (impactReader.Read())
        {
            impactSummary.HazopScenariosAffected = impactReader.IsDBNull(0) ? 0 : impactReader.GetInt32(0);
            impactSummary.LopaStudiesAffected = impactReader.IsDBNull(1) ? 0 : impactReader.GetInt32(1);
            impactSummary.BowTieDiagramsAffected = impactReader.IsDBNull(2) ? 0 : impactReader.GetInt32(2);
            impactSummary.BarriersFailed = impactReader.IsDBNull(3) ? 0 : impactReader.GetInt32(3);
            impactSummary.MaxSeverityHazop = impactReader.IsDBNull(4) ? null : impactReader.GetString(4);
            impactSummary.MaxSeverityLopa = impactReader.IsDBNull(5) ? null : impactReader.GetDecimal(5);
        }

        return new IncidentDetailedAnalysisDto
        {
            Incident = incident,
            FailedBarriers = barriers.Select(b => new BarrierDto { Id = b.BarrierId, BarrierName = b.BarrierName }).ToList(),
            AffectedHazopMappings = hazopMappings,
            AffectedLopaMappings = lopaMappings,
            AffectedBowTieMappings = bowtieMapping,
            ImpactSummary = impactSummary
        };
    }

    public async Task<BarrierFailureImpactDto> GetBarrierImpactAnalysisAsync(string barrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        // Get barrier
        const string barrierSql = "SELECT * FROM barriers WHERE id = @barrierId;";
        await using var barrierCmd = new NpgsqlCommand(barrierSql, conn);
        barrierCmd.Parameters.AddWithValue("@barrierId", barrierId);

        await using var barrierReader = await barrierCmd.ExecuteReaderAsync();
        if (!barrierReader.Read())
        {
            return new BarrierFailureImpactDto
            {
                BarrierId = barrierId,
                BarrierName = null,
                Status = null,
                AffectedHazopScenarios = new List<BarrierImpactAnalysisDto>(),
                AffectedLopaScenarios = new List<BarrierImpactAnalysisDto>(),
                AffectedBowTieDiagrams = new List<BarrierImpactAnalysisDto>()
            };
        }

        var result = new BarrierFailureImpactDto
        {
            BarrierId = barrierId,
            BarrierName = barrierReader.IsDBNull(3) ? null : barrierReader.GetString(3),
            Status = barrierReader.IsDBNull(12) ? null : barrierReader.GetString(12),
            AffectedHazopScenarios = new List<BarrierImpactAnalysisDto>(),
            AffectedLopaScenarios = new List<BarrierImpactAnalysisDto>(),
            AffectedBowTieDiagrams = new List<BarrierImpactAnalysisDto>()
        };
        await barrierReader.DisposeAsync();

        // Get affected analyses
        const string impactSql = @"
            SELECT * FROM get_barrier_impact_analysis(@barrierId);";

        await using var impactCmd = new NpgsqlCommand(impactSql, conn);
        impactCmd.Parameters.AddWithValue("@barrierId", barrierId);
        await using var impactReader = await impactCmd.ExecuteReaderAsync();

        while (impactReader.Read())
        {
            var analysis = new BarrierImpactAnalysisDto
            {
                AnalysisType = impactReader.IsDBNull(0) ? null : impactReader.GetString(0),
                AnalysisId = impactReader.IsDBNull(1) ? null : impactReader.GetString(1),
                AnalysisTitle = impactReader.IsDBNull(2) ? null : impactReader.GetString(2),
                Severity = impactReader.IsDBNull(3) ? null : impactReader.GetString(3),
                RelatedCount = impactReader.IsDBNull(4) ? 0 : impactReader.GetInt32(4),
                LastUpdated = impactReader.IsDBNull(5) ? null : impactReader.GetDateTime(5)
            };

            switch (analysis.AnalysisType)
            {
                case "HAZOP":
                    result.AffectedHazopScenarios?.Add(analysis);
                    break;
                case "LOPA":
                    result.AffectedLopaScenarios?.Add(analysis);
                    break;
                case "BowTie":
                    result.AffectedBowTieDiagrams?.Add(analysis);
                    break;
            }
        }

        return result;
    }

    public async Task<IEnumerable<BarrierImpactAnalysisDto>> GetBarrierImpactedAnalysesAsync(string barrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM get_barrier_impact_analysis(@barrierId)
            ORDER BY analysis_type, last_updated DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@barrierId", barrierId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<BarrierImpactAnalysisDto>();

        while (reader.Read())
        {
            result.Add(new BarrierImpactAnalysisDto
            {
                AnalysisType = reader.IsDBNull(0) ? null : reader.GetString(0),
                AnalysisId = reader.IsDBNull(1) ? null : reader.GetString(1),
                AnalysisTitle = reader.IsDBNull(2) ? null : reader.GetString(2),
                Severity = reader.IsDBNull(3) ? null : reader.GetString(3),
                RelatedCount = reader.IsDBNull(4) ? 0 : reader.GetInt32(4),
                LastUpdated = reader.IsDBNull(5) ? null : reader.GetDateTime(5)
            });
        }

        return result;
    }

    public async Task<IncidentImpactDto> GetIncidentImpactSummaryAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM get_incident_impact_summary(@incidentId);";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        await using var reader = await cmd.ExecuteReaderAsync();
        if (reader.Read())
        {
            return new IncidentImpactDto
            {
                IncidentId = incidentId,
                HazopScenariosAffected = reader.IsDBNull(0) ? 0 : reader.GetInt32(0),
                LopaStudiesAffected = reader.IsDBNull(1) ? 0 : reader.GetInt32(1),
                BowTieDiagramsAffected = reader.IsDBNull(2) ? 0 : reader.GetInt32(2),
                BarriersFailed = reader.IsDBNull(3) ? 0 : reader.GetInt32(3),
                MaxSeverityHazop = reader.IsDBNull(4) ? null : reader.GetString(4),
                MaxSeverityLopa = reader.IsDBNull(5) ? null : reader.GetDecimal(5)
            };
        }

        return new IncidentImpactDto { IncidentId = incidentId };
    }

    public async Task<LinkedAnalysisDto> GetLinkedAnalysisAsync(string? hazopDeviationId = null)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        var result = new LinkedAnalysisDto { HazopDeviationId = hazopDeviationId };

        if (!string.IsNullOrEmpty(hazopDeviationId))
        {
            // Get HAZOP deviation
            const string hazopSql = "SELECT id, study_id FROM hazop_deviations WHERE id = @id;";
            await using var hazopCmd = new NpgsqlCommand(hazopSql, conn);
            hazopCmd.Parameters.AddWithValue("@id", hazopDeviationId);

            await using var hazopReader = await hazopCmd.ExecuteReaderAsync();
            if (hazopReader.Read())
            {
                result.HazopDeviationId = hazopReader.GetString(0);
                result.HazopStudyId = hazopReader.GetString(1);
            }
        }

        return result;
    }

    public async Task<IEnumerable<IncidentDto>> FindRelatedIncidentsByHazopAsync(string hazopDeviationId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT DISTINCT i.* FROM incidents i
            INNER JOIN incident_hazop_mappings ihm ON i.id = ihm.incident_id
            WHERE ihm.hazop_deviation_id = @deviationId
            ORDER BY i.date_occurred DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@deviationId", hazopDeviationId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<IncidentDto>();
        while (reader.Read())
            result.Add(MapIncidentDto(reader));
        return result;
    }

    public async Task<IEnumerable<IncidentDto>> FindRelatedIncidentsByLopaAsync(string lopaScenarioId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT DISTINCT i.* FROM incidents i
            INNER JOIN incident_lopa_mappings ilm ON i.id = ilm.incident_id
            WHERE ilm.lopa_scenario_id = @scenarioId
            ORDER BY i.date_occurred DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@scenarioId", lopaScenarioId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<IncidentDto>();
        while (reader.Read())
            result.Add(MapIncidentDto(reader));
        return result;
    }

    public async Task<IEnumerable<IncidentDto>> FindRelatedIncidentsByBowTieAsync(string diagramId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT DISTINCT i.* FROM incidents i
            INNER JOIN incident_bowtie_mappings ibm ON i.id = ibm.incident_id
            WHERE ibm.bowtie_diagram_id = @diagramId
            ORDER BY i.date_occurred DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@diagramId", diagramId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<IncidentDto>();
        while (reader.Read())
            result.Add(MapIncidentDto(reader));
        return result;
    }

    public async Task<Dictionary<string, int>> GetIncidentTrendAsync(int monthsBack = 12)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT TO_CHAR(date_occurred, 'YYYY-MM') as month, COUNT(*) as count
            FROM incidents
            WHERE deleted = FALSE AND date_occurred >= NOW() - INTERVAL '1 month' * @monthsBack
            GROUP BY TO_CHAR(date_occurred, 'YYYY-MM')
            ORDER BY month ASC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@monthsBack", monthsBack);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new Dictionary<string, int>();
        while (reader.Read())
            result[(string)reader["month"]] = (int)reader["count"];
        return result;
    }

    public async Task<Dictionary<string, int>> GetBarrierFailurePatternsAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT failure_mode, COUNT(*) as count
            FROM barriers
            WHERE deleted = FALSE AND failure_mode IS NOT NULL
            GROUP BY failure_mode
            ORDER BY count DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        await using var reader = await cmd.ExecuteReaderAsync();

        var result = new Dictionary<string, int>();
        while (reader.Read())
            result[(string)reader["failure_mode"]] = (int)reader["count"];
        return result;
    }

    private IncidentBarrierDto MapIncidentBarrierDto(NpgsqlDataReader reader)
    {
        return new IncidentBarrierDto
        {
            Id = reader.IsDBNull(0) ? null : reader.GetString(0),
            IncidentId = reader.IsDBNull(1) ? null : reader.GetString(1),
            BarrierId = reader.IsDBNull(2) ? null : reader.GetString(2),
            BarrierFailureType = reader.IsDBNull(3) ? null : reader.GetString(3),
            FailureEvidence = reader.IsDBNull(4) ? null : reader.GetString(4),
            ContributionToIncident = reader.IsDBNull(5) ? null : reader.GetDecimal(5),
            CreatedAt = reader.IsDBNull(6) ? null : reader.GetDateTime(6)
        };
    }

    // Private mapping helpers
    private IncidentDto MapIncidentDto(NpgsqlDataReader reader)
    {
        return new IncidentDto
        {
            Id = reader.IsDBNull(0) ? null : reader.GetString(0),
            IncidentNumber = reader.IsDBNull(1) ? null : reader.GetString(1),
            Title = reader.IsDBNull(2) ? null : reader.GetString(2),
            Description = reader.IsDBNull(3) ? null : reader.GetString(3),
            Facility = reader.IsDBNull(4) ? null : reader.GetString(4),
            Unit = reader.IsDBNull(5) ? null : reader.GetString(5),
            DateOccurred = reader.IsDBNull(6) ? null : reader.GetDateTime(6),
            DateReported = reader.IsDBNull(7) ? null : reader.GetDateTime(7),
            ReporterName = reader.IsDBNull(8) ? null : reader.GetString(8),
            ReporterContact = reader.IsDBNull(9) ? null : reader.GetString(9),
            IncidentType = reader.IsDBNull(10) ? null : reader.GetString(10),
            SeverityActual = reader.IsDBNull(11) ? 0 : reader.GetInt32(11),
            RootCause = reader.IsDBNull(12) ? null : reader.GetString(12),
            ImmediateActions = reader.IsDBNull(13) ? null : reader.GetString(13),
            CorrectiveActions = reader.IsDBNull(14) ? null : reader.GetString(14),
            PreventiveActions = reader.IsDBNull(15) ? null : reader.GetString(15),
            Status = reader.IsDBNull(16) ? null : reader.GetString(16),
            InvestigationLead = reader.IsDBNull(17) ? null : reader.GetString(17),
            DateClosed = reader.IsDBNull(18) ? null : reader.GetDateTime(18),
            LessonsLearned = reader.IsDBNull(19) ? null : reader.GetString(19),
            SharedWithIndustry = !reader.IsDBNull(20) && reader.GetBoolean(20),
            CreatedAt = reader.IsDBNull(21) ? null : reader.GetDateTime(21),
            UpdatedAt = reader.IsDBNull(22) ? null : reader.GetDateTime(22),
            Data = reader.IsDBNull(24) ? null : reader.GetString(24)
        };
    }

    private IncidentHazopMappingDto MapHazopMappingDto(NpgsqlDataReader reader)
    {
        return new IncidentHazopMappingDto
        {
            Id = reader.IsDBNull(0) ? null : reader.GetString(0),
            IncidentId = reader.IsDBNull(1) ? null : reader.GetString(1),
            HazopDeviationId = reader.IsDBNull(2) ? null : reader.GetString(2),
            HazopStudyId = reader.IsDBNull(3) ? null : reader.GetString(3),
            RelevanceScore = reader.IsDBNull(4) ? null : reader.GetDecimal(4),
            Notes = reader.IsDBNull(5) ? null : reader.GetString(5),
            CreatedAt = reader.IsDBNull(6) ? null : reader.GetDateTime(6)
        };
    }

    private IncidentLopaMappingDto MapLopaMappingDto(NpgsqlDataReader reader)
    {
        return new IncidentLopaMappingDto
        {
            Id = reader.IsDBNull(0) ? null : reader.GetString(0),
            IncidentId = reader.IsDBNull(1) ? null : reader.GetString(1),
            LopaScenarioId = reader.IsDBNull(2) ? null : reader.GetString(2),
            LopaStudyId = reader.IsDBNull(3) ? null : reader.GetString(3),
            RelevanceScore = reader.IsDBNull(4) ? null : reader.GetDecimal(4),
            IplFailureCount = reader.IsDBNull(5) ? 0 : reader.GetInt32(5),
            Notes = reader.IsDBNull(6) ? null : reader.GetString(6),
            CreatedAt = reader.IsDBNull(7) ? null : reader.GetDateTime(7)
        };
    }

    private IncidentBowTieMappingDto MapBowTieMappingDto(NpgsqlDataReader reader)
    {
        return new IncidentBowTieMappingDto
        {
            Id = reader.IsDBNull(0) ? null : reader.GetString(0),
            IncidentId = reader.IsDBNull(1) ? null : reader.GetString(1),
            BowTieDiagramId = reader.IsDBNull(2) ? null : reader.GetString(2),
            TopEventOccurred = !reader.IsDBNull(3) && reader.GetBoolean(3),
            BarriersFailed = reader.IsDBNull(4) ? 0 : reader.GetInt32(4),
            RelevanceScore = reader.IsDBNull(5) ? null : reader.GetDecimal(5),
            Notes = reader.IsDBNull(6) ? null : reader.GetString(6),
            CreatedAt = reader.IsDBNull(7) ? null : reader.GetDateTime(7)
        };
    }

    // ── IntegratedRiskModelService cross-link implementations ────────────────────

    public async Task LinkHazopToLopaAsync(string hazopDeviationId, string lopaScenarioId,
        string? hazopStudyId, string? lopaStudyId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO hazop_lopa_mappings
                (id, hazop_deviation_id, lopa_scenario_id, hazop_study_id, lopa_study_id, created_at)
            VALUES
                (@id, @hazopDeviationId, @lopaScenarioId, @hazopStudyId, @lopaStudyId, NOW())
            ON CONFLICT (hazop_deviation_id, lopa_scenario_id) DO NOTHING;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", Guid.NewGuid().ToString());
        cmd.Parameters.AddWithValue("@hazopDeviationId", hazopDeviationId);
        cmd.Parameters.AddWithValue("@lopaScenarioId", lopaScenarioId);
        cmd.Parameters.AddWithValue("@hazopStudyId", hazopStudyId ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@lopaStudyId", lopaStudyId ?? (object)DBNull.Value);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task LinkHazopToBowTieAsync(string hazopDeviationId, string bowTieDiagramId,
        string? hazopStudyId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO hazop_bowtie_mappings
                (id, hazop_deviation_id, bowtie_diagram_id, hazop_study_id, created_at)
            VALUES
                (@id, @hazopDeviationId, @bowTieDiagramId, @hazopStudyId, NOW())
            ON CONFLICT (hazop_deviation_id, bowtie_diagram_id) DO NOTHING;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", Guid.NewGuid().ToString());
        cmd.Parameters.AddWithValue("@hazopDeviationId", hazopDeviationId);
        cmd.Parameters.AddWithValue("@bowTieDiagramId", bowTieDiagramId);
        cmd.Parameters.AddWithValue("@hazopStudyId", hazopStudyId ?? (object)DBNull.Value);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<IEnumerable<IncidentHazopMappingDto>> GetIncidentHazopMappingsAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT id, incident_id, hazop_deviation_id, hazop_study_id,
                   relevance_score, notes, created_at
            FROM incident_hazop_mappings
            WHERE incident_id = @incidentId
            ORDER BY created_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        var result = new List<IncidentHazopMappingDto>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new IncidentHazopMappingDto
            {
                Id = reader.IsDBNull(0) ? null : reader.GetString(0),
                IncidentId = reader.IsDBNull(1) ? null : reader.GetString(1),
                HazopDeviationId = reader.IsDBNull(2) ? null : reader.GetString(2),
                HazopStudyId = reader.IsDBNull(3) ? null : reader.GetString(3),
                RelevanceScore = reader.IsDBNull(4) ? null : reader.GetDecimal(4),
                Notes = reader.IsDBNull(5) ? null : reader.GetString(5),
                CreatedAt = reader.IsDBNull(6) ? null : reader.GetDateTime(6)
            });
        }
        return result;
    }

    public async Task<IEnumerable<IncidentLopaMappingDto>> GetIncidentLopaMappingsAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT id, incident_id, lopa_scenario_id, lopa_study_id,
                   relevance_score, ipl_failure_count, notes, created_at
            FROM incident_lopa_mappings
            WHERE incident_id = @incidentId
            ORDER BY created_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        var result = new List<IncidentLopaMappingDto>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(MapLopaMappingDto(reader));
        }
        return result;
    }

    public async Task<IEnumerable<IncidentBowTieMappingDto>> GetIncidentBowTieMappingsAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT id, incident_id, bowtie_diagram_id, top_event_occurred,
                   barriers_failed, relevance_score, notes, created_at
            FROM incident_bowtie_mappings
            WHERE incident_id = @incidentId
            ORDER BY created_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        var result = new List<IncidentBowTieMappingDto>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(MapBowTieMappingDto(reader));
        }
        return result;
    }

    public async Task<IncidentHazopMappingDto> LinkIncidentToHazopAsync(string id, string incidentId,
        string hazopDeviationId, string hazopStudyId, decimal relevanceScore)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO incident_hazop_mappings
                (id, incident_id, hazop_deviation_id, hazop_study_id, relevance_score, created_at)
            VALUES
                (@id, @incidentId, @hazopDeviationId, @hazopStudyId, @relevanceScore, NOW())
            ON CONFLICT (incident_id, hazop_deviation_id) DO UPDATE
                SET relevance_score = EXCLUDED.relevance_score
            RETURNING id, incident_id, hazop_deviation_id, hazop_study_id,
                      relevance_score, notes, created_at;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);
        cmd.Parameters.AddWithValue("@hazopDeviationId", hazopDeviationId);
        cmd.Parameters.AddWithValue("@hazopStudyId", hazopStudyId);
        cmd.Parameters.AddWithValue("@relevanceScore", relevanceScore);

        await using var reader = await cmd.ExecuteReaderAsync();
        await reader.ReadAsync();
        return new IncidentHazopMappingDto
        {
            Id = reader.IsDBNull(0) ? null : reader.GetString(0),
            IncidentId = reader.IsDBNull(1) ? null : reader.GetString(1),
            HazopDeviationId = reader.IsDBNull(2) ? null : reader.GetString(2),
            HazopStudyId = reader.IsDBNull(3) ? null : reader.GetString(3),
            RelevanceScore = reader.IsDBNull(4) ? null : reader.GetDecimal(4),
            Notes = reader.IsDBNull(5) ? null : reader.GetString(5),
            CreatedAt = reader.IsDBNull(6) ? null : reader.GetDateTime(6)
        };
    }

    public async Task<IncidentLopaMappingDto> LinkIncidentToLopaAsync(string id, string incidentId,
        string lopaScenarioId, string lopaStudyId, int iplFailureCount, decimal relevanceScore)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO incident_lopa_mappings
                (id, incident_id, lopa_scenario_id, lopa_study_id, ipl_failure_count,
                 relevance_score, created_at)
            VALUES
                (@id, @incidentId, @lopaScenarioId, @lopaStudyId, @iplFailureCount,
                 @relevanceScore, NOW())
            ON CONFLICT (incident_id, lopa_scenario_id) DO UPDATE
                SET ipl_failure_count = EXCLUDED.ipl_failure_count,
                    relevance_score = EXCLUDED.relevance_score
            RETURNING id, incident_id, lopa_scenario_id, lopa_study_id,
                      relevance_score, ipl_failure_count, notes, created_at;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);
        cmd.Parameters.AddWithValue("@lopaScenarioId", lopaScenarioId);
        cmd.Parameters.AddWithValue("@lopaStudyId", lopaStudyId);
        cmd.Parameters.AddWithValue("@iplFailureCount", iplFailureCount);
        cmd.Parameters.AddWithValue("@relevanceScore", relevanceScore);

        await using var reader = await cmd.ExecuteReaderAsync();
        await reader.ReadAsync();
        return MapLopaMappingDto(reader);
    }

    public async Task<IncidentBowTieMappingDto> LinkIncidentToBowTieAsync(string id, string incidentId,
        string bowTieDiagramId, bool topEventOccurred, int barriersFailed, decimal relevanceScore)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO incident_bowtie_mappings
                (id, incident_id, bowtie_diagram_id, top_event_occurred,
                 barriers_failed, relevance_score, created_at)
            VALUES
                (@id, @incidentId, @bowTieDiagramId, @topEventOccurred,
                 @barriersFailed, @relevanceScore, NOW())
            ON CONFLICT (incident_id, bowtie_diagram_id) DO UPDATE
                SET top_event_occurred = EXCLUDED.top_event_occurred,
                    barriers_failed = EXCLUDED.barriers_failed,
                    relevance_score = EXCLUDED.relevance_score
            RETURNING id, incident_id, bowtie_diagram_id, top_event_occurred,
                      barriers_failed, relevance_score, notes, created_at;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);
        cmd.Parameters.AddWithValue("@bowTieDiagramId", bowTieDiagramId);
        cmd.Parameters.AddWithValue("@topEventOccurred", topEventOccurred);
        cmd.Parameters.AddWithValue("@barriersFailed", barriersFailed);
        cmd.Parameters.AddWithValue("@relevanceScore", relevanceScore);

        await using var reader = await cmd.ExecuteReaderAsync();
        await reader.ReadAsync();
        return MapBowTieMappingDto(reader);
    }
}
