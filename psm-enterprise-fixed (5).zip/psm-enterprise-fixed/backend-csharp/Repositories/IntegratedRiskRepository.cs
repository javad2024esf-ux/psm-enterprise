using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

// ════════════════════════════════════════════════════════════════════════════════════
// BARRIER REPOSITORY INTERFACE
// ════════════════════════════════════════════════════════════════════════════════════

public interface IBarrierRepository
{
    // CRUD Operations
    Task<BarrierDto> CreateBarrierAsync(
        string id, string lopaIplId, string? bowTieBarrierId, string barrierName, 
        string barrierType, string? description, string? ownerDiscipline, 
        string? ownerContact, string? maintenanceFrequency, DateTime? lastTested,
        DateTime? nextTestDue, decimal? effectivenessRating, string status,
        string? failureMode, string? documentationRef, int? silLevel, 
        bool criticalFlag, string? data);

    Task<BarrierDto?> GetBarrierAsync(string id);
    Task<BarrierDto?> GetBarrierByLopaIplAsync(string lopaIplId);
    Task<BarrierDto?> GetBarrierByBowTieAsync(string bowTieBarrierId);

    Task<IEnumerable<BarrierDto>> ListBarriersAsync(
        string? statusFilter = null, string? typeFilter = null, 
        bool? criticalOnly = null);

    Task<IEnumerable<BarrierWithRelatedAnalysisDto>> ListBarriersWithAnalysisAsync();

    Task UpdateBarrierAsync(
        string id, string? barrierName, string? barrierType, string? description,
        string? ownerDiscipline, string? ownerContact, string? maintenanceFrequency,
        DateTime? lastTested, DateTime? nextTestDue, decimal? effectivenessRating,
        string? documentationRef, int? silLevel, bool? criticalFlag, string? data,
        string? updatedBy);

    Task<(bool success, string message)> UpdateBarrierStatusAsync(
        string id, string newStatus, string? reason, string? incidentId, 
        string? changedBy);

    Task<(bool success, string message)> UpdateBarrierStatusCascadeAsync(
        string id, string newStatus, string? reason, string? incidentId, 
        string? changedBy);

    Task<bool> DeleteBarrierAsync(string id);
    Task<bool> SoftDeleteBarrierAsync(string id);
    Task<bool> BarrierExistsAsync(string id);

    // Status History
    Task<IEnumerable<BarrierStatusHistoryDto>> GetBarrierStatusHistoryAsync(string barrierId);
    Task RecordBarrierStatusChangeAsync(
        string barrierId, string previousStatus, string newStatus, 
        string? reason, string? incidentId, string? changedBy);

    // Analytics
    Task<int> GetCriticalBarrierCountAsync();
    Task<int> GetFailedBarrierCountAsync();
    Task<int> GetDegradedBarrierCountAsync();
    Task<Dictionary<string, int>> GetBarrierStatusDistributionAsync();
    Task<Dictionary<string, int>> GetBarrierTypeDistributionAsync();

    // IntegratedRiskModelService overloads
    Task UpdateBarrierStatusAsync(string id, UpdateBarrierStatusRequest req, string userId);
    Task<IEnumerable<BarrierImpactAnalysisDto>> GetBarrierImpactAnalysisAsync(string barrierId);
    Task<int> GetBarrierCountAsync();
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT REPOSITORY INTERFACE
// ════════════════════════════════════════════════════════════════════════════════════

public interface IIncidentRepository
{
    // CRUD Operations
    Task<IncidentDto> CreateIncidentAsync(
        string id, string incidentNumber, string title, string? description,
        string? facility, string? unit, DateTime dateOccurred, 
        string? reporterName, string? reporterContact, string incidentType,
        int severityActual, string? rootCause, string? immediateActions,
        string? correctiveActions, string? preventiveActions, string status,
        string? investigationLead, string? lessonsLearned, bool sharedWithIndustry,
        string? data);

    Task<IncidentDto?> GetIncidentAsync(string id);
    Task<IncidentDto?> GetIncidentByNumberAsync(string incidentNumber);

    Task<IEnumerable<IncidentDto>> ListIncidentsAsync(
        string? statusFilter = null, string? facilityFilter = null,
        int? severityMinimum = null, DateTime? dateFrom = null, 
        DateTime? dateTo = null, int pageNumber = 1, int pageSize = 50);

    Task<IEnumerable<IncidentDto>> SearchIncidentsAsync(string searchTerm);

    Task UpdateIncidentAsync(
        string id, string? title, string? description, string? facility,
        string? unit, string? rootCause, string? immediateActions,
        string? correctiveActions, string? preventiveActions, string? status,
        string? investigationLead, string? lessonsLearned, bool? sharedWithIndustry,
        string? data);

    Task<bool> CloseIncidentAsync(string id, string? lessonsLearned);
    Task<bool> DeleteIncidentAsync(string id);
    Task<bool> SoftDeleteIncidentAsync(string id);
    Task<bool> IncidentExistsAsync(string id);

    // Analytics
    Task<int> GetTotalIncidentsAsync();
    Task<int> GetOpenIncidentsAsync();
    Task<int> GetIncidentsInPeriodAsync(DateTime from, DateTime to);
    Task<Dictionary<string, int>> GetIncidentTypeDistributionAsync();
    Task<Dictionary<int, int>> GetIncidentsBySeverityAsync();

    // IntegratedRiskModelService additions
    Task<IEnumerable<IncidentBarrierDto>> GetIncidentBarriersAsync(string incidentId);
    Task<IncidentBarrierDto> LinkBarrierAsync(string id, string incidentId, string barrierId,
        string? barrierFailureType, string? failureEvidence, decimal contribution);
    Task<int> GetIncidentCountAsync();
    Task<int> GetOpenIncidentsCountAsync();
    Task<int> GetHighSeverityIncidentsCountAsync();
    Task<int> GetIncidentsWithBarrierFailuresCountAsync();
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT-BARRIER RELATIONSHIP REPOSITORY INTERFACE
// ════════════════════════════════════════════════════════════════════════════════════

public interface IIncidentBarrierRepository
{
    Task<IncidentBarrierDto> CreateIncidentBarrierAsync(
        string id, string incidentId, string barrierId, string? barrierFailureType,
        string? failureEvidence, decimal? contributionToIncident);

    Task<IncidentBarrierDto?> GetIncidentBarrierAsync(string id);
    Task<IEnumerable<IncidentBarrierDto>> GetIncidentBarriersAsync(string incidentId);
    Task<IEnumerable<IncidentBarrierDto>> GetBarrierIncidentsAsync(string barrierId);

    Task UpdateIncidentBarrierAsync(
        string id, string? barrierFailureType, string? failureEvidence,
        decimal? contributionToIncident);

    Task<bool> DeleteIncidentBarrierAsync(string id);
    Task<int> GetFailedBarrierCountForIncidentAsync(string incidentId);
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT-HAZOP MAPPING REPOSITORY INTERFACE
// ════════════════════════════════════════════════════════════════════════════════════

public interface IIncidentHazopRepository
{
    Task<IncidentHazopMappingDto> CreateMappingAsync(
        string id, string incidentId, string hazopDeviationId, 
        string hazopStudyId, decimal? relevanceScore, string? notes);

    Task<IncidentHazopMappingDto?> GetMappingAsync(string id);
    Task<IEnumerable<IncidentHazopMappingDto>> GetIncidentHazopMappingsAsync(string incidentId);
    Task<IEnumerable<IncidentHazopMappingDto>> GetHazopIncidentMappingsAsync(string deviationId);

    Task UpdateMappingAsync(
        string id, decimal? relevanceScore, string? notes);

    Task<bool> DeleteMappingAsync(string id);
    Task<int> GetMappedHazopScenariosCountAsync(string incidentId);
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT-LOPA MAPPING REPOSITORY INTERFACE
// ════════════════════════════════════════════════════════════════════════════════════

public interface IIncidentLopaRepository
{
    Task<IncidentLopaMappingDto> CreateMappingAsync(
        string id, string incidentId, string lopaScenarioId, string lopaStudyId,
        decimal? relevanceScore, int? iplFailureCount, string? notes);

    Task<IncidentLopaMappingDto?> GetMappingAsync(string id);
    Task<IEnumerable<IncidentLopaMappingDto>> GetIncidentLopaMappingsAsync(string incidentId);
    Task<IEnumerable<IncidentLopaMappingDto>> GetLopaIncidentMappingsAsync(string lopaScenarioId);

    Task UpdateMappingAsync(
        string id, decimal? relevanceScore, int? iplFailureCount, string? notes);

    Task<bool> DeleteMappingAsync(string id);
    Task<int> GetMappedLopaStudiesCountAsync(string incidentId);
}

// ════════════════════════════════════════════════════════════════════════════════════
// INCIDENT-BOWTIE MAPPING REPOSITORY INTERFACE
// ════════════════════════════════════════════════════════════════════════════════════

public interface IIncidentBowTieRepository
{
    Task<IncidentBowTieMappingDto> CreateMappingAsync(
        string id, string incidentId, string bowTieDiagramId, bool topEventOccurred,
        int? barriersFailed, decimal? relevanceScore, string? notes);

    Task<IncidentBowTieMappingDto?> GetMappingAsync(string id);
    Task<IEnumerable<IncidentBowTieMappingDto>> GetIncidentBowTieMappingsAsync(string incidentId);
    Task<IEnumerable<IncidentBowTieMappingDto>> GetBowTieIncidentMappingsAsync(string diagramId);

    Task UpdateMappingAsync(
        string id, bool? topEventOccurred, int? barriersFailed,
        decimal? relevanceScore, string? notes);

    Task<bool> DeleteMappingAsync(string id);
    Task<int> GetMappedBowTieDiagramsCountAsync(string incidentId);
}

// ════════════════════════════════════════════════════════════════════════════════════
// COMPREHENSIVE CROSS-ANALYSIS REPOSITORY INTERFACE
// ════════════════════════════════════════════════════════════════════════════════════

public interface ICrossAnalysisRepository
{
    // Get all affected analyses for an incident
    Task<IncidentDetailedAnalysisDto> GetIncidentDetailedAnalysisAsync(string incidentId);

    // Get barrier impact across analyses
    Task<BarrierFailureImpactDto> GetBarrierImpactAnalysisAsync(string barrierId);

    // Get all analyses affected when barrier fails
    Task<IEnumerable<BarrierImpactAnalysisDto>> GetBarrierImpactedAnalysesAsync(string barrierId);

    // Get impact summary
    Task<IncidentImpactDto> GetIncidentImpactSummaryAsync(string incidentId);

    // Get linked analyses
    Task<LinkedAnalysisDto> GetLinkedAnalysisAsync(string? hazopDeviationId = null);

    // Search for related incidents across HAZOP
    Task<IEnumerable<IncidentDto>> FindRelatedIncidentsByHazopAsync(string hazopDeviationId);

    // Search for related incidents across LOPA
    Task<IEnumerable<IncidentDto>> FindRelatedIncidentsByLopaAsync(string lopaScenarioId);

    // Search for related incidents across BowTie
    Task<IEnumerable<IncidentDto>> FindRelatedIncidentsByBowTieAsync(string diagramId);

    // Get incident trend data
    Task<Dictionary<string, int>> GetIncidentTrendAsync(int monthsBack = 12);

    // Get barrier failure patterns
    Task<Dictionary<string, int>> GetBarrierFailurePatternsAsync();

    // IntegratedRiskModelService cross-link additions
    Task LinkHazopToLopaAsync(string hazopDeviationId, string lopaScenarioId,
        string? hazopStudyId, string? lopaStudyId);
    Task LinkHazopToBowTieAsync(string hazopDeviationId, string bowTieDiagramId,
        string? hazopStudyId);
    Task<IEnumerable<IncidentHazopMappingDto>> GetIncidentHazopMappingsAsync(string incidentId);
    Task<IEnumerable<IncidentLopaMappingDto>> GetIncidentLopaMappingsAsync(string incidentId);
    Task<IEnumerable<IncidentBowTieMappingDto>> GetIncidentBowTieMappingsAsync(string incidentId);
    Task<IncidentHazopMappingDto> LinkIncidentToHazopAsync(string id, string incidentId,
        string hazopDeviationId, string hazopStudyId, decimal relevanceScore);
    Task<IncidentLopaMappingDto> LinkIncidentToLopaAsync(string id, string incidentId,
        string lopaScenarioId, string lopaStudyId, int iplFailureCount, decimal relevanceScore);
    Task<IncidentBowTieMappingDto> LinkIncidentToBowTieAsync(string id, string incidentId,
        string bowTieDiagramId, bool topEventOccurred, int barriersFailed, decimal relevanceScore);
}
