using System.Text.Json;
using Dapper;
using PSM.Api.Data;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

// ════════════════════════════════════════════════════════════════════════════
// Interface
// ════════════════════════════════════════════════════════════════════════════
public interface IIntegrationRepository
{
    // ── Rules ──────────────────────────────────────────────────────────────
    Task<(IEnumerable<IntegrationRuleDto> Rows, long Total)> ListRulesAsync(
        string? sourceModule, bool? isActive, int limit, int offset);
    Task<IntegrationRuleDto?> GetRuleByIdAsync(string id);
    Task<string> CreateRuleAsync(CreateIntegrationRuleRequest req, string userId);
    Task<bool> UpdateRuleAsync(string id, UpdateIntegrationRuleRequest req);
    Task<bool> DeleteRuleAsync(string id);
    Task<IEnumerable<IntegrationRuleDto>> GetRulesBySourcAndEventAsync(string sourceModule, string triggerEvent);

    // ── Events ─────────────────────────────────────────────────────────────
    Task<(IEnumerable<IntegrationEventDto> Rows, long Total)> ListEventsAsync(
        string? status, string? sourceModule, int limit, int offset);
    Task<IntegrationEventDto?> GetEventByIdAsync(string id);
    Task<string> CreateEventAsync(CreateIntegrationEventRequest req);
    Task<IEnumerable<IntegrationEventDto>> GetPendingEventsAsync(int limit);
    Task UpdateEventStatusAsync(string eventId, string status, string? errorMessage = null);
    Task IncrementEventRetryAsync(string eventId);

    // ── Executions ─────────────────────────────────────────────────────────
    Task<string> CreateExecutionAsync(string eventId, string ruleId, string status,
        JsonElement? result = null, string? errorMessage = null, int? durationMs = null);
    Task<IEnumerable<IntegrationExecutionDto>> GetExecutionsByEventAsync(string eventId);
    Task<IEnumerable<IntegrationExecutionDto>> GetExecutionsByRuleAsync(string ruleId);

    // ── Statistics ─────────────────────────────────────────────────────────
    Task<IntegrationStatsDto> GetStatsAsync();
}

// ════════════════════════════════════════════════════════════════════════════
// Implementation
// ════════════════════════════════════════════════════════════════════════════
public class IntegrationRepository : IIntegrationRepository
{
    private readonly IDbHelper _db;

    public IntegrationRepository(IDbHelper db) => _db = db;

    // ────────────────────────────────────────────────────────────────────────
    // RULES
    // ────────────────────────────────────────────────────────────────────────

    public async Task<(IEnumerable<IntegrationRuleDto> Rows, long Total)> ListRulesAsync(
        string? sourceModule, bool? isActive, int limit, int offset)
    {
        limit  = Math.Clamp(limit, 1, 200);
        offset = Math.Max(offset, 0);

        var where  = new List<string>();
        var parms  = new DynamicParameters();

        parms.Add("limit",  limit);
        parms.Add("offset", offset);

        if (!string.IsNullOrEmpty(sourceModule)) { where.Add("source_module = @source"); parms.Add("source", sourceModule); }
        if (isActive.HasValue) { where.Add("is_active = @active"); parms.Add("active", isActive.Value); }

        var clause = where.Count > 0 ? "WHERE " + string.Join(" AND ", where) : "";

        var sql = $@"
            SELECT id, name, description, source_module, trigger_event, trigger_condition,
                   target_module, action_type, action_template,
                   is_active, priority, created_by, created_at, updated_at,
                   COUNT(*) OVER() AS total_count
            FROM integration_rules
            {clause}
            ORDER BY priority ASC, created_at DESC
            LIMIT @limit OFFSET @offset";

        var rows = (await _db.QueryAsync<dynamic>(sql, parms)).ToList();
        long total = rows.Count > 0 ? (long)(rows[0].total_count ?? 0L) : 0L;

        var dtos = rows.Select(MapRule);
        return (dtos, total);
    }

    public Task<IntegrationRuleDto?> GetRuleByIdAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<IntegrationRuleDto>(@"
            SELECT id, name, description, source_module, trigger_event, trigger_condition,
                   target_module, action_type, action_template,
                   is_active, priority, created_by, created_at, updated_at
            FROM integration_rules
            WHERE id = @id",
            new { id });

    public async Task<string> CreateRuleAsync(CreateIntegrationRuleRequest req, string userId)
    {
        var id = $"irule_{Guid.NewGuid():N}";
        // FIX: DTOs use Dictionary<string,object>? — serialize to JSON string
        var triggerJson = req.TriggerCondition != null
            ? JsonSerializer.Serialize(req.TriggerCondition)
            : "{}";
        var actionJson = req.ActionTemplate != null
            ? JsonSerializer.Serialize(req.ActionTemplate)
            : "{}";

        await _db.ExecuteAsync(@"
            INSERT INTO integration_rules 
              (id, name, description, source_module, trigger_event, trigger_condition,
               target_module, action_type, action_template, is_active, priority, created_by, created_at, updated_at)
            VALUES 
              (@id, @name, @description, @source_module, @trigger_event, @trigger_condition::jsonb,
               @target_module, @action_type, @action_template::jsonb, @is_active, @priority, @created_by, NOW(), NOW())",
            new
            {
                id,
                req.Name,
                req.Description,
                req.SourceModule,
                req.TriggerEvent,
                trigger_condition = triggerJson,
                req.TargetModule,
                req.ActionType,
                action_template = actionJson,
                req.IsActive,
                req.Priority,
                created_by = userId
            });

        return id;
    }

    public async Task<bool> UpdateRuleAsync(string id, UpdateIntegrationRuleRequest req)
    {
        // FIX: DTOs use Dictionary<string,object>? — serialize to JSON string
        var triggerJson = req.TriggerCondition != null
            ? JsonSerializer.Serialize(req.TriggerCondition)
            : (string?)null;
        var actionJson = req.ActionTemplate != null
            ? JsonSerializer.Serialize(req.ActionTemplate)
            : (string?)null;

        var sql = @"
            UPDATE integration_rules
            SET name              = COALESCE(@name, name),
                description       = COALESCE(@description, description),
                trigger_event     = COALESCE(@trigger_event, trigger_event),
                trigger_condition = COALESCE(@trigger_condition::jsonb, trigger_condition),
                action_type       = COALESCE(@action_type, action_type),
                action_template   = COALESCE(@action_template::jsonb, action_template),
                is_active         = COALESCE(@is_active, is_active),
                priority          = COALESCE(@priority, priority),
                updated_at        = NOW()
            WHERE id = @id";

        var rows = await _db.ExecuteAsync(sql, new
        {
            id,
            name              = req.Name,
            description       = req.Description,
            trigger_event     = req.TriggerEvent,
            trigger_condition = triggerJson,
            action_type       = req.ActionType,
            action_template   = actionJson,
            is_active         = req.IsActive,
            priority          = req.Priority
        });
        return rows > 0;
    }

    public async Task<bool> DeleteRuleAsync(string id) =>
        await _db.ExecuteAsync("DELETE FROM integration_rules WHERE id = @id", new { id }) > 0;

    public Task<IEnumerable<IntegrationRuleDto>> GetRulesBySourcAndEventAsync(string sourceModule, string triggerEvent) =>
        _db.QueryAsync<IntegrationRuleDto>(@"
            SELECT id, name, description, source_module, trigger_event, trigger_condition,
                   target_module, action_type, action_template,
                   is_active, priority, created_by, created_at, updated_at
            FROM integration_rules
            WHERE source_module = @source AND trigger_event = @event AND is_active = true
            ORDER BY priority ASC, created_at DESC",
            new { source = sourceModule, @event = triggerEvent });

    // ────────────────────────────────────────────────────────────────────────
    // EVENTS
    // ────────────────────────────────────────────────────────────────────────

    public async Task<(IEnumerable<IntegrationEventDto> Rows, long Total)> ListEventsAsync(
        string? status, string? sourceModule, int limit, int offset)
    {
        limit  = Math.Clamp(limit, 1, 200);
        offset = Math.Max(offset, 0);

        var where  = new List<string>();
        var parms  = new DynamicParameters();

        parms.Add("limit",  limit);
        parms.Add("offset", offset);

        if (!string.IsNullOrEmpty(status))      { where.Add("status = @status");       parms.Add("status", status); }
        if (!string.IsNullOrEmpty(sourceModule)) { where.Add("source_module = @source"); parms.Add("source", sourceModule); }

        var clause = where.Count > 0 ? "WHERE " + string.Join(" AND ", where) : "";

        var sql = $@"
            SELECT id, event_type, source_module, source_id, payload, triggered_by, created_at,
                   status, processed_at, error_message, retry_count,
                   COUNT(*) OVER() AS total_count
            FROM integration_events
            {clause}
            ORDER BY created_at DESC
            LIMIT @limit OFFSET @offset";

        var rows = (await _db.QueryAsync<dynamic>(sql, parms)).ToList();
        long total = rows.Count > 0 ? (long)(rows[0].total_count ?? 0L) : 0L;

        var dtos = rows.Select(MapEvent);
        return (dtos, total);
    }

    public Task<IntegrationEventDto?> GetEventByIdAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<IntegrationEventDto>(@"
            SELECT id, event_type, source_module, source_id, payload, triggered_by, created_at,
                   status, processed_at, error_message, retry_count
            FROM integration_events
            WHERE id = @id",
            new { id });

    public async Task<string> CreateEventAsync(CreateIntegrationEventRequest req)
    {
        var id = $"ievnt_{Guid.NewGuid():N}";
        // FIX: DTOs use Dictionary<string,object>? — serialize to JSON string
        var payloadJson = req.Payload != null
            ? JsonSerializer.Serialize(req.Payload)
            : "{}";

        await _db.ExecuteAsync(@"
            INSERT INTO integration_events
              (id, event_type, source_module, source_id, payload, triggered_by, created_at, status, retry_count)
            VALUES
              (@id, @event_type, @source_module, @source_id, @payload::jsonb, @triggered_by, NOW(), 'pending', 0)",
            new
            {
                id,
                req.EventType,
                req.SourceModule,
                req.SourceId,
                payload = payloadJson,
                req.TriggeredBy
            });

        return id;
    }

    public Task<IEnumerable<IntegrationEventDto>> GetPendingEventsAsync(int limit) =>
        _db.QueryAsync<IntegrationEventDto>(@"
            SELECT id, event_type, source_module, source_id, payload, triggered_by, created_at,
                   status, processed_at, error_message, retry_count
            FROM integration_events
            WHERE status = 'pending' OR status = 'failed'
            ORDER BY created_at ASC
            LIMIT @limit",
            new { limit });

    public Task UpdateEventStatusAsync(string eventId, string status, string? errorMessage = null) =>
        _db.ExecuteAsync(@"
            UPDATE integration_events
            SET status = @status, processed_at = NOW(), error_message = @error_message
            WHERE id = @id",
            new { id = eventId, status, error_message = errorMessage });

    public Task IncrementEventRetryAsync(string eventId) =>
        _db.ExecuteAsync(
            "UPDATE integration_events SET retry_count = retry_count + 1 WHERE id = @id",
            new { id = eventId });

    // ────────────────────────────────────────────────────────────────────────
    // EXECUTIONS
    // ────────────────────────────────────────────────────────────────────────

    public async Task<string> CreateExecutionAsync(string eventId, string ruleId, string status,
        JsonElement? result = null, string? errorMessage = null, int? durationMs = null)
    {
        var id = $"iexec_{Guid.NewGuid():N}";
        var resultJson = result?.GetRawText();

        await _db.ExecuteAsync(@"
            INSERT INTO integration_executions
              (id, event_id, rule_id, status, result, error_message, duration_ms, executed_at)
            VALUES
              (@id, @event_id, @rule_id, @status, @result::jsonb, @error_message, @duration_ms, NOW())",
            new { id, event_id = eventId, rule_id = ruleId, status, result = resultJson, error_message = errorMessage, duration_ms = durationMs });

        return id;
    }

    public Task<IEnumerable<IntegrationExecutionDto>> GetExecutionsByEventAsync(string eventId) =>
        _db.QueryAsync<IntegrationExecutionDto>(@"
            SELECT id, event_id, rule_id, status, result, error_message, duration_ms, executed_at
            FROM integration_executions
            WHERE event_id = @id
            ORDER BY executed_at DESC",
            new { id = eventId });

    public Task<IEnumerable<IntegrationExecutionDto>> GetExecutionsByRuleAsync(string ruleId) =>
        _db.QueryAsync<IntegrationExecutionDto>(@"
            SELECT id, event_id, rule_id, status, result, error_message, duration_ms, executed_at
            FROM integration_executions
            WHERE rule_id = @id
            ORDER BY executed_at DESC
            LIMIT 100",
            new { id = ruleId });

    // ────────────────────────────────────────────────────────────────────────
    // STATISTICS
    // ────────────────────────────────────────────────────────────────────────

    public async Task<IntegrationStatsDto> GetStatsAsync()
    {
        var stats = new IntegrationStatsDto();

        // Counts
        var counts = await _db.QueryFirstOrDefaultAsync<dynamic>(@"
            SELECT
              (SELECT COUNT(*) FROM integration_rules) as total_rules,
              (SELECT COUNT(*) FROM integration_rules WHERE is_active = true) as active_rules,
              (SELECT COUNT(*) FROM integration_events WHERE status = 'pending') as pending_events,
              (SELECT COUNT(*) FROM integration_events WHERE status = 'processing') as processing_events,
              (SELECT COUNT(*) FROM integration_events WHERE status = 'done') as completed_events,
              (SELECT COUNT(*) FROM integration_events WHERE status = 'failed') as failed_events,
              (SELECT COUNT(*) FROM integration_executions WHERE status = 'done') as successful_executions,
              (SELECT COUNT(*) FROM integration_executions WHERE status = 'failed') as failed_executions,
              (SELECT AVG(EXTRACT(EPOCH FROM (completed_at - started_at)) * 1000)
               FROM integration_executions 
               WHERE completed_at IS NOT NULL) as avg_duration_ms,
              (SELECT MAX(created_at) FROM integration_events) as last_activity");

        stats.TotalRules = counts?.total_rules ?? 0;
        stats.ActiveRules = counts?.active_rules ?? 0;
        stats.PendingEvents = counts?.pending_events ?? 0;
        stats.ProcessingEvents = counts?.processing_events ?? 0;
        stats.CompletedEvents = counts?.completed_events ?? 0;
        stats.FailedEvents = counts?.failed_events ?? 0;
        stats.SuccessfulExecutions = counts?.successful_executions ?? 0;
        stats.FailedExecutions = counts?.failed_executions ?? 0;
        stats.AverageExecutionTimeMs = counts?.avg_duration_ms != null
            ? Convert.ToDouble(counts.avg_duration_ms)
            : 0.0;
        stats.LastActivityAt = counts?.last_activity as DateTime?;

        return stats;
    }

    // ────────────────────────────────────────────────────────────────────────
    // Mappers
    // ────────────────────────────────────────────────────────────────────────

    // FIX: JsonElement.Parse() does not exist — use JsonSerializer.Deserialize<JsonElement>()
    // FIX: duplicate variable name 'jsonStr' in MapRule — renamed second one to 'jsonStr2'
    private static IntegrationRuleDto MapRule(dynamic r) => new()
    {
        Id               = (string)r.id,
        Name             = (string)r.name,
        Description      = (string?)r.description,
        SourceModule     = (string)r.source_module,
        TriggerEvent     = (string)r.trigger_event,
        TriggerCondition = r.trigger_condition is string jsonStr
            ? JsonSerializer.Deserialize<Dictionary<string, object>>(jsonStr)
            : null,
        TargetModule     = (string)r.target_module,
        ActionType       = (string)r.action_type,
        ActionTemplate   = r.action_template is string jsonStr2
            ? JsonSerializer.Deserialize<Dictionary<string, object>>(jsonStr2)
            : null,
        IsActive         = (bool)r.is_active,
        Priority         = (int)r.priority,
        CreatedBy        = (string?)r.created_by,
        CreatedAt        = (DateTime)r.created_at,
        UpdatedAt        = (DateTime)r.updated_at,
    };

    private static IntegrationEventDto MapEvent(dynamic e) => new()
    {
        Id           = (string)e.id,
        EventType    = (string)e.event_type,
        SourceModule = (string)e.source_module,
        SourceId     = (string)e.source_id,
        Payload      = e.payload is string jsonStr
            ? JsonSerializer.Deserialize<Dictionary<string, object>>(jsonStr)
            : null,
        TriggeredBy  = (string?)e.triggered_by,
        CreatedAt    = (DateTime)e.created_at,
        Status       = (string)e.status,
        ProcessedAt  = e.processed_at is null ? null : (DateTime?)e.processed_at,
        ErrorMessage = (string?)e.error_message,
        RetryCount   = (int)e.retry_count,
    };
}
