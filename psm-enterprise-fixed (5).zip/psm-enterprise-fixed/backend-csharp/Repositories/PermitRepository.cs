using System.Data;
using Dapper;
using PSM.Api.Data;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

// ════════════════════════════════════════════════════════════════════════════
// Interface
// ════════════════════════════════════════════════════════════════════════════
public interface IPermitRepository
{
    // ── Core CRUD ────────────────────────────────────────────────────────────
    Task<(IEnumerable<PermitListDto> Rows, long Total)> ListAsync(
        string? state, string? permitType, string? riskLevel,
        string? tenantId, int limit, int offset);

    Task<PermitDto?> GetByIdAsync(string id);

    Task<string> CreateAsync(
        IDbConnection conn, IDbTransaction tx,
        string id, string tenantId, string permitType, string jobTitle,
        string? description, string location, DateTime jobDate,
        decimal? estimatedDuration, string contractorName,
        string? contractorLicense, string supervisor,
        string? riskLevel, string[]? requiredPpe, string[]? requiredEquipment,
        string? additionalMeasures, string? watchPerson,
        string[]? tags, string? createdBy);

    Task UpdateAsync(IDbConnection conn, IDbTransaction tx, string id, UpdatePermitRequest req, string userId);

    Task<bool> ExistsAsync(string id);

    Task DeleteAsync(IDbConnection conn, IDbTransaction tx, string id);

    // ── State transitions ─────────────────────────────────────────────────────
    Task UpdateStateAsync(IDbConnection conn, IDbTransaction tx,
        string id, string newState, string userId);

    Task SetApprovalAsync(IDbConnection conn, IDbTransaction tx,
        string id, string level, string userId);

    Task CloseAsync(IDbConnection conn, IDbTransaction tx,
        string id, ClosePermitRequest req, string userId);

    // ── SLA tracking ──────────────────────────────────────────────────────────
    Task InsertSlaEntryAsync(IDbConnection conn, IDbTransaction tx,
        string permitId, string state, decimal targetHours);

    Task ExitSlaEntryAsync(IDbConnection conn, IDbTransaction tx,
        string permitId, string state);

    Task<IEnumerable<PermitSlaTrackingDto>> GetSlaTrackingAsync(string permitId);

    // ── Crew ─────────────────────────────────────────────────────────────────
    Task AddCrewMemberAsync(IDbConnection conn, IDbTransaction tx,
        string permitId, CreateCrewMemberRequest req);

    Task<IEnumerable<PermitCrewDto>> GetCrewAsync(string permitId);

    // ── Safety records ────────────────────────────────────────────────────────
    Task AddSafetyRecordAsync(IDbConnection conn, IDbTransaction tx,
        string permitId, AddSafetyRecordRequest req, string userId);

    Task<IEnumerable<PermitSafetyRecordDto>> GetSafetyRecordsAsync(string permitId);

    // ── Escalations ───────────────────────────────────────────────────────────
    Task InsertEscalationAsync(IDbConnection conn, IDbTransaction tx,
        string permitId, string reason, string[] escalatedTo);

    Task<IEnumerable<PermitEscalationDto>> GetEscalationsAsync(string permitId);

    // ── Lessons learned ───────────────────────────────────────────────────────
    Task AddLessonAsync(IDbConnection conn, IDbTransaction tx,
        string permitId, AddLessonRequest req, string userId);

    Task<IEnumerable<PermitLessonDto>> GetLessonsAsync(string permitId);

    // ── Notifications (work_permit_notifications) ─────────────────────────────
    Task InsertNotificationAsync(string permitId, string? recipientId,
        string notificationType, string subject, string message);

    // ── Transaction helper ────────────────────────────────────────────────────
    Task WithTransactionAsync(Func<IDbConnection, IDbTransaction, Task> fn);
}

// ════════════════════════════════════════════════════════════════════════════
// Implementation
// ════════════════════════════════════════════════════════════════════════════
public class PermitRepository : IPermitRepository
{
    private readonly IDbHelper _db;
    public PermitRepository(IDbHelper db) => _db = db;

    public Task WithTransactionAsync(Func<IDbConnection, IDbTransaction, Task> fn) =>
        _db.WithTransactionAsync(fn);

    // ── List ─────────────────────────────────────────────────────────────────
    public async Task<(IEnumerable<PermitListDto> Rows, long Total)> ListAsync(
        string? state, string? permitType, string? riskLevel,
        string? tenantId, int limit, int offset)
    {
        var where = new List<string>();
        var p = new DynamicParameters();
        p.Add("limit",  Math.Min(limit, 500));
        p.Add("offset", Math.Max(offset, 0));

        if (!string.IsNullOrEmpty(state))      { where.Add("state = @state");           p.Add("state",      state);      }
        if (!string.IsNullOrEmpty(permitType)) { where.Add("permit_type = @permitType"); p.Add("permitType", permitType); }
        if (!string.IsNullOrEmpty(riskLevel))  { where.Add("risk_level = @riskLevel");   p.Add("riskLevel",  riskLevel);  }
        if (!string.IsNullOrEmpty(tenantId))   { where.Add("tenant_id = @tenantId");     p.Add("tenantId",   tenantId);   }

        var clause = where.Count > 0 ? "WHERE " + string.Join(" AND ", where) : "";

        var sql = $@"
            SELECT id, permit_type, job_title, location, job_date, state, risk_level,
                   contractor_name, supervisor, supervisor_approval, hse_approval,
                   area_manager_approval, created_by, created_at, updated_at,
                   COUNT(*) OVER() AS total_count
            FROM work_permits
            {clause}
            ORDER BY created_at DESC
            LIMIT @limit OFFSET @offset";

        var rows = (await _db.QueryAsync<dynamic>(sql, p)).ToList();
        long total = rows.Count > 0 ? (long)(rows[0].total_count ?? 0L) : 0L;

        var dtos = rows.Select(r => new PermitListDto
        {
            Id                  = r.id,
            PermitType          = r.permit_type,
            JobTitle            = r.job_title,
            Location            = r.location,
            JobDate             = r.job_date,
            State               = r.state,
            RiskLevel           = r.risk_level,
            ContractorName      = r.contractor_name,
            Supervisor          = r.supervisor,
            SupervisorApproval  = r.supervisor_approval == true,
            HseApproval         = r.hse_approval == true,
            AreaManagerApproval = r.area_manager_approval == true,
            CreatedBy           = r.created_by,
            CreatedAt           = r.created_at,
            UpdatedAt           = r.updated_at,
        });

        return (dtos, total);
    }

    // ── Get by ID ─────────────────────────────────────────────────────────────
    public Task<PermitDto?> GetByIdAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<PermitDto>(@"
            SELECT id, tenant_id, permit_type, job_title, description, location,
                   job_date, estimated_duration, actual_start_time, actual_end_time,
                   contractor_name, contractor_license, supervisor,
                   state, state_changed_at, risk_level,
                   supervisor_approval, hse_approval, area_manager_approval,
                   escalation_level, form_data::text AS form_data,
                   required_ppe, required_equipment, additional_measures,
                   actual_duration, safety_incidents, issues_encountered,
                   completion_notes, watch_person,
                   safety_briefing_conducted, equipment_status_check,
                   site_restoration, tools_returned,
                   created_by, created_at, last_modified_by, updated_at,
                   tags, custom_fields::text AS custom_fields
            FROM work_permits WHERE id = @id", new { id });

    // ── Exists ────────────────────────────────────────────────────────────────
    public async Task<bool> ExistsAsync(string id)
    {
        var n = await _db.ExecuteScalarAsync<long>(
            "SELECT COUNT(1) FROM work_permits WHERE id = @id", new { id });
        return n > 0;
    }

    // ── Create ────────────────────────────────────────────────────────────────
    public async Task<string> CreateAsync(
        IDbConnection conn, IDbTransaction tx,
        string id, string tenantId, string permitType, string jobTitle,
        string? description, string location, DateTime jobDate,
        decimal? estimatedDuration, string contractorName,
        string? contractorLicense, string supervisor,
        string? riskLevel, string[]? requiredPpe, string[]? requiredEquipment,
        string? additionalMeasures, string? watchPerson,
        string[]? tags, string? createdBy)
    {
        await conn.ExecuteAsync(@"
            INSERT INTO work_permits (
                id, tenant_id, permit_type, job_title, description, location,
                job_date, estimated_duration, contractor_name, contractor_license,
                supervisor, state, state_changed_at, risk_level,
                required_ppe, required_equipment, additional_measures,
                watch_person, tags, created_by, created_at, updated_at,
                supervisor_approval, hse_approval, area_manager_approval
            ) VALUES (
                @id, @tenantId, @permitType, @jobTitle, @description, @location,
                @jobDate, @estimatedDuration, @contractorName, @contractorLicense,
                @supervisor, 'Draft', NOW(), @riskLevel,
                @requiredPpe, @requiredEquipment, @additionalMeasures,
                @watchPerson, @tags, @createdBy, NOW(), NOW(),
                false, false, false
            )",
            new { id, tenantId, permitType, jobTitle, description, location,
                  jobDate, estimatedDuration, contractorName, contractorLicense,
                  supervisor, riskLevel, requiredPpe, requiredEquipment,
                  additionalMeasures, watchPerson, tags, createdBy }, tx);
        return id;
    }

    // ── Update ────────────────────────────────────────────────────────────────
    public Task UpdateAsync(IDbConnection conn, IDbTransaction tx, string id, UpdatePermitRequest req, string userId) =>
        conn.ExecuteAsync(@"
            UPDATE work_permits SET
                permit_type               = COALESCE(@permitType,              permit_type),
                job_title                 = COALESCE(@jobTitle,                job_title),
                description               = COALESCE(@description,             description),
                location                  = COALESCE(@location,                location),
                job_date                  = COALESCE(@jobDate,                 job_date),
                estimated_duration        = COALESCE(@estimatedDuration,       estimated_duration),
                actual_start_time         = COALESCE(@actualStartTime,         actual_start_time),
                actual_end_time           = COALESCE(@actualEndTime,           actual_end_time),
                contractor_name           = COALESCE(@contractorName,          contractor_name),
                contractor_license        = COALESCE(@contractorLicense,       contractor_license),
                supervisor                = COALESCE(@supervisor,              supervisor),
                risk_level                = COALESCE(@riskLevel,               risk_level),
                required_ppe              = COALESCE(@requiredPpe,             required_ppe),
                required_equipment        = COALESCE(@requiredEquipment,       required_equipment),
                additional_measures       = COALESCE(@additionalMeasures,      additional_measures),
                actual_duration           = COALESCE(@actualDuration,          actual_duration),
                safety_incidents          = COALESCE(@safetyIncidents,         safety_incidents),
                issues_encountered        = COALESCE(@issuesEncountered,       issues_encountered),
                completion_notes          = COALESCE(@completionNotes,         completion_notes),
                watch_person              = COALESCE(@watchPerson,             watch_person),
                safety_briefing_conducted = COALESCE(@safetyBriefingConducted, safety_briefing_conducted),
                equipment_status_check    = COALESCE(@equipmentStatusCheck,    equipment_status_check),
                site_restoration          = COALESCE(@siteRestoration,         site_restoration),
                tools_returned            = COALESCE(@toolsReturned,           tools_returned),
                tags                      = COALESCE(@tags,                    tags),
                last_modified_by          = @userId,
                updated_at                = NOW()
            WHERE id = @id",
            new
            {
                id,
                userId,
                permitType              = req.PermitType,
                jobTitle                = req.JobTitle,
                description             = req.Description,
                location                = req.Location,
                jobDate                 = req.JobDate,
                estimatedDuration       = req.EstimatedDuration,
                actualStartTime         = req.ActualStartTime,
                actualEndTime           = req.ActualEndTime,
                contractorName          = req.ContractorName,
                contractorLicense       = req.ContractorLicense,
                supervisor              = req.Supervisor,
                riskLevel               = req.RiskLevel,
                requiredPpe             = req.RequiredPpe,
                requiredEquipment       = req.RequiredEquipment,
                additionalMeasures      = req.AdditionalMeasures,
                actualDuration          = req.ActualDuration,
                safetyIncidents         = req.SafetyIncidents,
                issuesEncountered       = req.IssuesEncountered,
                completionNotes         = req.CompletionNotes,
                watchPerson             = req.WatchPerson,
                safetyBriefingConducted = req.SafetyBriefingConducted,
                equipmentStatusCheck    = req.EquipmentStatusCheck,
                siteRestoration         = req.SiteRestoration,
                toolsReturned           = req.ToolsReturned,
                tags                    = req.Tags,
            }, tx);

    // ── Delete ────────────────────────────────────────────────────────────────
    public Task DeleteAsync(IDbConnection conn, IDbTransaction tx, string id) =>
        conn.ExecuteAsync("DELETE FROM work_permits WHERE id = @id", new { id }, tx);

    // ── State ─────────────────────────────────────────────────────────────────
    public Task UpdateStateAsync(IDbConnection conn, IDbTransaction tx,
        string id, string newState, string userId) =>
        conn.ExecuteAsync(@"
            UPDATE work_permits
            SET state = @newState, state_changed_at = NOW(),
                last_modified_by = @userId, updated_at = NOW()
            WHERE id = @id",
            new { id, newState, userId }, tx);

    // ── Approval columns ──────────────────────────────────────────────────────
    public Task SetApprovalAsync(IDbConnection conn, IDbTransaction tx,
        string id, string level, string userId)
    {
        var col = level.ToLower() switch
        {
            "supervisor"   => "supervisor_approval",
            "hse"          => "hse_approval",
            "area_manager" => "area_manager_approval",
            _              => throw new ArgumentException($"Unknown approval level: {level}")
        };

        // Also advance the workflow state
        var nextState = level.ToLower() switch
        {
            "supervisor"   => "HSE_Review",
            "hse"          => "Area_Manager_Approval",
            "area_manager" => "Active",
            _              => throw new ArgumentException($"Unknown approval level: {level}")
        };

        return conn.ExecuteAsync($@"
            UPDATE work_permits
            SET {col} = true,
                state = @nextState,
                state_changed_at = NOW(),
                last_modified_by = @userId,
                updated_at = NOW()
            WHERE id = @id",
            new { id, nextState, userId }, tx);
    }

    // ── Close ─────────────────────────────────────────────────────────────────
    public Task CloseAsync(IDbConnection conn, IDbTransaction tx,
        string id, ClosePermitRequest req, string userId) =>
        conn.ExecuteAsync(@"
            UPDATE work_permits SET
                state                = 'Closed',
                state_changed_at     = NOW(),
                actual_end_time      = NOW(),
                completion_notes     = COALESCE(@completionNotes,   completion_notes),
                safety_incidents     = COALESCE(@safetyIncidents,   safety_incidents),
                issues_encountered   = COALESCE(@issuesEncountered, issues_encountered),
                actual_duration      = COALESCE(@actualDuration,    actual_duration),
                site_restoration     = @siteRestoration,
                tools_returned       = @toolsReturned,
                last_modified_by     = @userId,
                updated_at           = NOW()
            WHERE id = @id",
            new
            {
                id,
                userId,
                completionNotes   = req.CompletionNotes,
                safetyIncidents   = req.SafetyIncidents,
                issuesEncountered = req.IssuesEncountered,
                actualDuration    = req.ActualDuration,
                siteRestoration   = req.SiteRestoration,
                toolsReturned     = req.ToolsReturned,
            }, tx);

    // ── SLA tracking ──────────────────────────────────────────────────────────
    public Task InsertSlaEntryAsync(IDbConnection conn, IDbTransaction tx,
        string permitId, string state, decimal targetHours) =>
        conn.ExecuteAsync(@"
            INSERT INTO work_permit_sla_tracking (permit_id, state, target_hours, entered_at)
            VALUES (@permitId, @state, @targetHours, NOW())",
            new { permitId, state, targetHours }, tx);

    public Task ExitSlaEntryAsync(IDbConnection conn, IDbTransaction tx,
        string permitId, string state) =>
        conn.ExecuteAsync(@"
            UPDATE work_permit_sla_tracking
            SET exited_at = NOW(),
                exceeded  = (NOW() > entered_at + (target_hours || ' hours')::interval)
            WHERE permit_id = @permitId AND state = @state AND exited_at IS NULL",
            new { permitId, state }, tx);

    public Task<IEnumerable<PermitSlaTrackingDto>> GetSlaTrackingAsync(string permitId) =>
        _db.QueryAsync<PermitSlaTrackingDto>(@"
            SELECT id, permit_id, state, target_hours, entered_at, exited_at, exceeded
            FROM work_permit_sla_tracking
            WHERE permit_id = @permitId
            ORDER BY entered_at ASC", new { permitId });

    // ── Crew ─────────────────────────────────────────────────────────────────
    public Task AddCrewMemberAsync(IDbConnection conn, IDbTransaction tx,
        string permitId, CreateCrewMemberRequest req) =>
        conn.ExecuteAsync(@"
            INSERT INTO work_permit_crew
                (permit_id, crew_member_name, crew_member_id, role, qualifications, trained_for_task)
            VALUES
                (@permitId, @crewMemberName, @crewMemberId, @role, @qualifications, @trainedForTask)",
            new
            {
                permitId,
                crewMemberName  = req.CrewMemberName,
                crewMemberId    = req.CrewMemberId,
                role            = req.Role,
                qualifications  = req.Qualifications,
                trainedForTask  = req.TrainedForTask,
            }, tx);

    public Task<IEnumerable<PermitCrewDto>> GetCrewAsync(string permitId) =>
        _db.QueryAsync<PermitCrewDto>(@"
            SELECT id, permit_id, crew_member_name, crew_member_id, role,
                   qualifications, trained_for_task, added_at
            FROM work_permit_crew
            WHERE permit_id = @permitId
            ORDER BY added_at ASC", new { permitId });

    // ── Safety records ────────────────────────────────────────────────────────
    public Task AddSafetyRecordAsync(IDbConnection conn, IDbTransaction tx,
        string permitId, AddSafetyRecordRequest req, string userId) =>
        conn.ExecuteAsync(@"
            INSERT INTO work_permit_safety_records
                (permit_id, safety_check_type, checked_at, checked_by, status,
                 findings, corrective_actions, follow_up_date)
            VALUES
                (@permitId, @safetyCheckType, NOW(), @userId, @status,
                 @findings, @correctiveActions, @followUpDate)",
            new
            {
                permitId,
                safetyCheckType   = req.SafetyCheckType,
                userId,
                status            = req.Status,
                findings          = req.Findings,
                correctiveActions = req.CorrectiveActions,
                followUpDate      = req.FollowUpDate,
            }, tx);

    public Task<IEnumerable<PermitSafetyRecordDto>> GetSafetyRecordsAsync(string permitId) =>
        _db.QueryAsync<PermitSafetyRecordDto>(@"
            SELECT id, permit_id, safety_check_type, checked_at, checked_by,
                   status, findings, corrective_actions, follow_up_date
            FROM work_permit_safety_records
            WHERE permit_id = @permitId
            ORDER BY checked_at ASC", new { permitId });

    // ── Escalations ───────────────────────────────────────────────────────────
    public Task InsertEscalationAsync(IDbConnection conn, IDbTransaction tx,
        string permitId, string reason, string[] escalatedTo) =>
        conn.ExecuteAsync(@"
            INSERT INTO work_permit_escalations (permit_id, escalation_reason, escalated_to)
            VALUES (@permitId, @reason, @escalatedTo)",
            new { permitId, reason, escalatedTo }, tx);

    public Task<IEnumerable<PermitEscalationDto>> GetEscalationsAsync(string permitId) =>
        _db.QueryAsync<PermitEscalationDto>(@"
            SELECT id, permit_id, escalation_reason, escalated_to,
                   escalated_at, resolved_at, resolved_by, resolution_notes
            FROM work_permit_escalations
            WHERE permit_id = @permitId
            ORDER BY escalated_at DESC", new { permitId });

    // ── Lessons learned ───────────────────────────────────────────────────────
    public Task AddLessonAsync(IDbConnection conn, IDbTransaction tx,
        string permitId, AddLessonRequest req, string userId) =>
        conn.ExecuteAsync(@"
            INSERT INTO work_permit_lessons_learned
                (permit_id, lesson_title, description, lesson_category,
                 shared_organization_wide, created_by)
            VALUES
                (@permitId, @lessonTitle, @description, @lessonCategory,
                 @sharedOrganizationWide, @userId)",
            new
            {
                permitId,
                lessonTitle             = req.LessonTitle,
                description             = req.Description,
                lessonCategory          = req.LessonCategory,
                sharedOrganizationWide  = req.SharedOrganizationWide,
                userId,
            }, tx);

    public Task<IEnumerable<PermitLessonDto>> GetLessonsAsync(string permitId) =>
        _db.QueryAsync<PermitLessonDto>(@"
            SELECT id, permit_id, lesson_title, description, lesson_category,
                   shared_organization_wide, created_at, created_by
            FROM work_permit_lessons_learned
            WHERE permit_id = @permitId
            ORDER BY created_at ASC", new { permitId });

    // ── Notifications ─────────────────────────────────────────────────────────
    public Task InsertNotificationAsync(string permitId, string? recipientId,
        string notificationType, string subject, string message) =>
        _db.ExecuteAsync(@"
            INSERT INTO work_permit_notifications
                (permit_id, recipient_id, notification_type, subject, message, sent_at)
            VALUES (@permitId, @recipientId, @notificationType, @subject, @message, NOW())",
            new { permitId, recipientId, notificationType, subject, message });
}
