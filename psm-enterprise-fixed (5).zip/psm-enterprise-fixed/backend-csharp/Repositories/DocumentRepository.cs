using Dapper;
using PSM.Api.Data;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

// ════════════════════════════════════════════════════════════════════════════
// Interface
// ════════════════════════════════════════════════════════════════════════════
public interface IDocumentRepository
{
    Task<(IEnumerable<DocumentDto> Rows, long Total)> ListAsync(
        string? module, string? tag, int limit, int offset);

    Task<DocumentDto?> GetByIdAsync(string id);

    Task<string> CreateAsync(
        string id, string name, string? module, string[]? tags,
        string filePath, long fileSize, string mimeType, string? createdBy);

    /// <summary>Returns the stored file_path so the caller can delete the physical file.</summary>
    Task<string?> DeleteAsync(string id);
}

// ════════════════════════════════════════════════════════════════════════════
// Implementation
// ════════════════════════════════════════════════════════════════════════════
public class DocumentRepository : IDocumentRepository
{
    private readonly IDbHelper _db;
    public DocumentRepository(IDbHelper db) => _db = db;

    // ── List ─────────────────────────────────────────────────────────────────
    public async Task<(IEnumerable<DocumentDto> Rows, long Total)> ListAsync(
        string? module, string? tag, int limit, int offset)
    {
        limit  = Math.Clamp(limit, 1, 200);
        offset = Math.Max(offset, 0);

        var where = new List<string>();
        var p     = new DynamicParameters();
        p.Add("limit",  limit);
        p.Add("offset", offset);

        if (!string.IsNullOrEmpty(module)) { where.Add("module = @module"); p.Add("module", module); }
        if (!string.IsNullOrEmpty(tag))    { where.Add("@tag = ANY(tags)"); p.Add("tag",    tag);    }

        var clause = where.Count > 0 ? "WHERE " + string.Join(" AND ", where) : "";

        var sql = $@"
            SELECT id, name, module, tags, file_path, file_size, mime_type,
                   created_by, created_at,
                   COUNT(*) OVER() AS total_count
            FROM   documents
            {clause}
            ORDER  BY created_at DESC
            LIMIT  @limit OFFSET @offset";

        var rows = (await _db.QueryAsync<dynamic>(sql, p)).ToList();
        long total = rows.Count > 0 ? (long)(rows[0].total_count ?? 0L) : 0L;

        var dtos = rows.Select(MapRow);
        return (dtos, total);
    }

    // ── Get by ID ─────────────────────────────────────────────────────────────
    public Task<DocumentDto?> GetByIdAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<DocumentDto>(
            @"SELECT id, name, module, tags, file_path, file_size, mime_type,
                     created_by, created_at
              FROM   documents
              WHERE  id = @id",
            new { id });

    // ── Create ────────────────────────────────────────────────────────────────
    public async Task<string> CreateAsync(
        string id, string name, string? module, string[]? tags,
        string filePath, long fileSize, string mimeType, string? createdBy)
    {
        await _db.ExecuteAsync(@"
            INSERT INTO documents (id, name, module, tags, file_path, file_size, mime_type, created_by, created_at)
            VALUES (@id, @name, @module, @tags, @filePath, @fileSize, @mimeType, @createdBy, NOW())",
            new { id, name, module, tags, filePath, fileSize, mimeType, createdBy });
        return id;
    }

    // ── Delete ────────────────────────────────────────────────────────────────
    public async Task<string?> DeleteAsync(string id)
    {
        // Return the stored path so the service can remove the physical file
        var path = await _db.ExecuteScalarAsync<string?>(
            "SELECT file_path FROM documents WHERE id = @id", new { id });

        if (path is null) return null;   // not found

        await _db.ExecuteAsync("DELETE FROM documents WHERE id = @id", new { id });
        return path;
    }

    // ── Row mapper (dynamic → DTO) ────────────────────────────────────────────
    private static DocumentDto MapRow(dynamic r) => new()
    {
        Id        = (string)r.id,
        Name      = (string)r.name,
        Module    = (string?)r.module,
        Tags      = r.tags as string[],
        FilePath  = (string?)r.file_path,
        FileSize  = r.file_size is null ? null : (long?)r.file_size,
        MimeType  = (string?)r.mime_type,
        CreatedBy = (string?)r.created_by,
        CreatedAt = (DateTime)r.created_at,
    };
}
