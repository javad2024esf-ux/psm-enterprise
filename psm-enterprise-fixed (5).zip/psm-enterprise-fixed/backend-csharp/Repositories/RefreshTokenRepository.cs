using PSM.Api.Data;
using PSM.Api.Models;

namespace PSM.Api.Repositories;

public interface IRefreshTokenRepository
{
    Task<RefreshToken?> GetAsync(string token);
    Task CreateAsync(RefreshToken rt);
    Task RevokeAsync(string token);
    Task RevokeAllForUserAsync(string userId);
    Task DeleteExpiredAsync();
}

public class RefreshTokenRepository : IRefreshTokenRepository
{
    private readonly IDbHelper _db;
    public RefreshTokenRepository(IDbHelper db) => _db = db;

    public Task<RefreshToken?> GetAsync(string token) =>
        _db.QueryFirstOrDefaultAsync<RefreshToken>(
            "SELECT * FROM refresh_tokens WHERE token = @token AND revoked = false AND expires_at > NOW()",
            new { token });

    public Task CreateAsync(RefreshToken rt) =>
        _db.ExecuteAsync(@"
            INSERT INTO refresh_tokens (id, user_id, token, expires_at, created_at, revoked)
            VALUES (@Id, @UserId, @Token, @ExpiresAt, @CreatedAt, @Revoked)",
            rt);

    public Task RevokeAsync(string token) =>
        _db.ExecuteAsync(
            "UPDATE refresh_tokens SET revoked = true WHERE token = @token",
            new { token });

    public Task RevokeAllForUserAsync(string userId) =>
        _db.ExecuteAsync(
            "UPDATE refresh_tokens SET revoked = true WHERE user_id = @userId",
            new { userId });

    public Task DeleteExpiredAsync() =>
        _db.ExecuteAsync(
            "DELETE FROM refresh_tokens WHERE expires_at < NOW() OR revoked = true");
}
