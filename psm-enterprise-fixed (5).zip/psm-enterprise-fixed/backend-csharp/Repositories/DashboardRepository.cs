using Dapper;
using PSM.Api.Data;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

/// <summary>
/// Repository for aggregating KPIs across all PSM modules
/// </summary>
public interface IDashboardRepository
{
    Task<HazopKpisDto> GetHazopKpisAsync();
    Task<LopaKpisDto> GetLopaKpisAsync();
    Task<IncidentKpisDto> GetIncidentKpisAsync();
    Task<PermitKpisDto> GetPermitKpisAsync();
    Task<WorkflowKpisDto> GetWorkflowKpisAsync();
    Task<ActionRegisterKpisDto> GetActionRegisterKpisAsync();
    Task<AuditKpisDto> GetAuditKpisAsync();
    Task<DashboardKpisDto> GetAllKpisAsync();
}

public class DashboardRepository : IDashboardRepository
{
    private readonly IDbHelper _db;
    private const string Schema = "public";

    public DashboardRepository(IDbHelper db)
    {
        _db = db;
    }

    public async Task<HazopKpisDto> GetHazopKpisAsync()
    {
        var sql = @"
            SELECT 
                COUNT(DISTINCT hs.id) as total_studies,
                COUNT(DISTINCT CASE WHEN hs.status = 'active' THEN hs.id END) as active_studies,
                COUNT(DISTINCT CASE WHEN hs.status = 'completed' THEN hs.id END) as completed_studies,
                COUNT(DISTINCT hd.id) as total_hazards_identified,
                COUNT(DISTINCT CASE WHEN hd.current_severity >= 4 THEN hd.id END) as high_risk_hazards,
                COUNT(DISTINCT CASE WHEN hd.current_severity = 2 OR hd.current_severity = 3 THEN hd.id END) as medium_risk_hazards,
                COUNT(DISTINCT CASE WHEN hd.current_severity = 1 THEN hd.id END) as low_risk_hazards,
                COUNT(DISTINCT hr.id) as total_recommendations,
                COUNT(DISTINCT CASE WHEN hr.status != 'closed' THEN hr.id END) as open_recommendations,
                COUNT(DISTINCT CASE WHEN hr.status = 'closed' THEN hr.id END) as closed_recommendations,
                COUNT(DISTINCT CASE WHEN hs.review_due_date IS NOT NULL AND hs.review_due_date < CURRENT_DATE THEN hs.id END) as studies_due_for_review,
                COUNT(DISTINCT he.id) as equipment_count,
                MAX(hs.created_at) as last_study_date
            FROM hazop_studies hs
            LEFT JOIN hazop_deviations hd ON hs.id = hd.study_id
            LEFT JOIN hazop_recommendations hr ON hd.id = hr.deviation_id
            LEFT JOIN hazop_equipment he ON hs.id = he.study_id";

        using var conn = _db.GetConnection();
        var result = await conn.QueryFirstOrDefaultAsync<dynamic>(sql);

        if (result == null)
            return new HazopKpisDto();

        var kpi = new HazopKpisDto
        {
            TotalStudies = result.total_studies ?? 0,
            ActiveStudies = result.active_studies ?? 0,
            CompletedStudies = result.completed_studies ?? 0,
            TotalHazardsIdentified = result.total_hazards_identified ?? 0,
            HighRiskHazards = result.high_risk_hazards ?? 0,
            MediumRiskHazards = result.medium_risk_hazards ?? 0,
            LowRiskHazards = result.low_risk_hazards ?? 0,
            TotalRecommendations = result.total_recommendations ?? 0,
            OpenRecommendations = result.open_recommendations ?? 0,
            ClosedRecommendations = result.closed_recommendations ?? 0,
            StudiesDueForReview = result.studies_due_for_review ?? 0,
            EquipmentCount = result.equipment_count ?? 0,
            LastStudyDate = result.last_study_date
        };

        // Calculate closure rate
        kpi.ClosureRate = kpi.TotalRecommendations > 0
            ? Math.Round((decimal)kpi.ClosedRecommendations / kpi.TotalRecommendations * 100, 2)
            : 0;

        // Calculate average days to close
        var closedSql = @"
            SELECT AVG(EXTRACT(DAY FROM (hr.closed_at - hr.created_at))) as avg_days
            FROM hazop_recommendations hr
            WHERE hr.status = 'closed' AND hr.closed_at IS NOT NULL";
        var closedResult = await conn.QueryFirstOrDefaultAsync<dynamic>(closedSql);
        kpi.AverageDaysToClose = closedResult?.avg_days != null ? decimal.Parse(closedResult.avg_days.ToString()) : 0;

        // Count team members engaged
        var teamSql = @"
            SELECT COUNT(DISTINCT team_member_id) as count
            FROM hazop_team_members
            WHERE study_id IS NOT NULL";
        var teamResult = await conn.QueryFirstOrDefaultAsync<dynamic>(teamSql);
        kpi.TeamMembersEngaged = teamResult?.count ?? 0;

        return kpi;
    }

    public async Task<LopaKpisDto> GetLopaKpisAsync()
    {
        var sql = @"
            SELECT 
                COUNT(DISTINCT ls.id) as total_analyses,
                COUNT(DISTINCT CASE WHEN ls.status = 'active' THEN ls.id END) as active_analyses,
                COUNT(DISTINCT CASE WHEN ls.status = 'completed' THEN ls.id END) as completed_analyses,
                COUNT(DISTINCT lsc.id) as total_scenarios,
                COUNT(DISTINCT CASE WHEN lsc.sil_target = 1 THEN lsc.id END) as sil_1_count,
                COUNT(DISTINCT CASE WHEN lsc.sil_target = 2 THEN lsc.id END) as sil_2_count,
                COUNT(DISTINCT CASE WHEN lsc.sil_target = 3 THEN lsc.id END) as sil_3_count,
                COUNT(DISTINCT CASE WHEN lsc.sil_target = 4 THEN lsc.id END) as sil_4_count,
                COUNT(DISTINCT lipl.id) as total_ipls,
                COUNT(DISTINCT CASE WHEN lipl.status = 'implemented' THEN lipl.id END) as ipls_implemented,
                COUNT(DISTINCT CASE WHEN lipl.status != 'implemented' THEN lipl.id END) as ipls_pending,
                COUNT(DISTINCT CASE WHEN lsc.residual_risk >= 0.7 THEN lsc.id END) as high_risk_scenarios,
                MAX(ls.created_at) as last_analysis_date
            FROM lopa_studies ls
            LEFT JOIN lopa_scenarios lsc ON ls.id = lsc.study_id
            LEFT JOIN lopa_ipls lipl ON lsc.id = lipl.scenario_id";

        using var conn = _db.GetConnection();
        var result = await conn.QueryFirstOrDefaultAsync<dynamic>(sql);

        if (result == null)
            return new LopaKpisDto();

        var kpi = new LopaKpisDto
        {
            TotalAnalyses = result.total_analyses ?? 0,
            ActiveAnalyses = result.active_analyses ?? 0,
            CompletedAnalyses = result.completed_analyses ?? 0,
            TotalScenarios = result.total_scenarios ?? 0,
            SIL1Count = result.sil_1_count ?? 0,
            SIL2Count = result.sil_2_count ?? 0,
            SIL3Count = result.sil_3_count ?? 0,
            SIL4Count = result.sil_4_count ?? 0,
            TotalIPLs = result.total_ipls ?? 0,
            IPLsImplemented = result.ipls_implemented ?? 0,
            IPLsPending = result.ipls_pending ?? 0,
            HighRiskScenarios = result.high_risk_scenarios ?? 0,
            LastAnalysisDate = result.last_analysis_date
        };

        // Calculate SIL compliance rate
        kpi.SILComplianceRate = kpi.TotalScenarios > 0
            ? Math.Round((decimal)(kpi.TotalScenarios - kpi.HighRiskScenarios) / kpi.TotalScenarios * 100, 2)
            : 0;

        // Calculate average residual risk
        var riskSql = @"
            SELECT AVG(COALESCE(lsc.residual_risk, 0)) as avg_risk
            FROM lopa_scenarios lsc";
        var riskResult = await conn.QueryFirstOrDefaultAsync<dynamic>(riskSql);
        kpi.AverageResidualRisk = riskResult?.avg_risk != null ? decimal.Parse(riskResult.avg_risk.ToString()) : 0;

        // Mitigated scenarios (those with implemented IPLs)
        var mitigatedSql = @"
            SELECT COUNT(DISTINCT lsc.id) as count
            FROM lopa_scenarios lsc
            WHERE EXISTS (
                SELECT 1 FROM lopa_ipls lipl 
                WHERE lipl.scenario_id = lsc.id AND lipl.status = 'implemented'
            )";
        var mitigatedResult = await conn.QueryFirstOrDefaultAsync<dynamic>(mitigatedSql);
        kpi.MitigatedScenarios = mitigatedResult?.count ?? 0;

        return kpi;
    }

    public async Task<IncidentKpisDto> GetIncidentKpisAsync()
    {
        var sql = @"
            SELECT 
                COUNT(DISTINCT i.id) as total_incidents,
                COUNT(DISTINCT CASE WHEN i.status != 'closed' THEN i.id END) as open_incidents,
                COUNT(DISTINCT CASE WHEN i.status = 'closed' THEN i.id END) as closed_incidents,
                COUNT(DISTINCT CASE WHEN i.severity_actual >= 4 THEN i.id END) as high_severity_incidents,
                COUNT(DISTINCT CASE WHEN i.status = 'under_investigation' THEN i.id END) as under_investigation,
                COUNT(DISTINCT i.id) as with_actions,
                COUNT(DISTINCT ib.id) as barrier_failures,
                COUNT(DISTINCT CASE WHEN EXTRACT(YEAR FROM i.date_occurred) = EXTRACT(YEAR FROM CURRENT_DATE) THEN i.id END) as incidents_this_year,
                COUNT(DISTINCT CASE WHEN i.date_occurred >= CURRENT_DATE - INTERVAL '30 days' THEN i.id END) as incidents_last_month,
                COUNT(DISTINCT CASE WHEN i.date_occurred >= CURRENT_DATE - INTERVAL '7 days' THEN i.id END) as incidents_last_week,
                MAX(i.date_occurred) as last_incident_date
            FROM incidents i
            LEFT JOIN incident_barriers ib ON i.id = ib.incident_id";

        using var conn = _db.GetConnection();
        var result = await conn.QueryFirstOrDefaultAsync<dynamic>(sql);

        if (result == null)
            return new IncidentKpisDto();

        var kpi = new IncidentKpisDto
        {
            TotalIncidents = result.total_incidents ?? 0,
            OpenIncidents = result.open_incidents ?? 0,
            ClosedIncidents = result.closed_incidents ?? 0,
            HighSeverityIncidents = result.high_severity_incidents ?? 0,
            UnderInvestigation = result.under_investigation ?? 0,
            WithActions = result.with_actions ?? 0,
            BarrierFailures = result.barrier_failures ?? 0,
            IncidentsThisYear = result.incidents_this_year ?? 0,
            IncidentsLastMonth = result.incidents_last_month ?? 0,
            IncidentsLastWeek = result.incidents_last_week ?? 0,
            LastIncidentDate = result.last_incident_date
        };

        // Lessons learned count
        var lessonsSQL = @"
            SELECT COUNT(DISTINCT i.id) as count
            FROM incidents i
            WHERE i.lessons_learned IS NOT NULL AND i.lessons_learned != ''";
        var lessonsResult = await conn.QueryFirstOrDefaultAsync<dynamic>(lessonsSQL);
        kpi.LessonsLearnedCount = lessonsResult?.count ?? 0;

        // Average investigation days
        var invDaysSql = @"
            SELECT AVG(EXTRACT(DAY FROM (i.updated_at - i.date_occurred))) as avg_days
            FROM incidents i
            WHERE i.status = 'closed'";
        var invResult = await conn.QueryFirstOrDefaultAsync<dynamic>(invDaysSql);
        kpi.AverageInvestigationDays = invResult?.avg_days != null ? decimal.Parse(invResult.avg_days.ToString()) : 0;

        // Barrier effectiveness average
        var barrierSql = @"
            SELECT AVG(COALESCE(b.effectiveness_rating, 0)) as avg_effectiveness
            FROM barriers b";
        var barrierResult = await conn.QueryFirstOrDefaultAsync<dynamic>(barrierSql);
        kpi.BarrierEffectivenessAverage = barrierResult?.avg_effectiveness != null 
            ? decimal.Parse(barrierResult.avg_effectiveness.ToString()) 
            : 0;

        return kpi;
    }

    public async Task<PermitKpisDto> GetPermitKpisAsync()
    {
        var sql = @"
            SELECT 
                COUNT(DISTINCT wp.id) as total_permits,
                COUNT(DISTINCT CASE WHEN wp.status = 'active' THEN wp.id END) as active_permits,
                COUNT(DISTINCT CASE WHEN wp.expiry_date < CURRENT_DATE THEN wp.id END) as expired_permits,
                COUNT(DISTINCT CASE WHEN wp.expiry_date >= CURRENT_DATE AND wp.expiry_date <= CURRENT_DATE + INTERVAL '30 days' THEN wp.id END) as expiring_within_30,
                COUNT(DISTINCT CASE WHEN wp.status = 'pending_approval' THEN wp.id END) as pending_approval,
                COUNT(DISTINCT CASE WHEN wp.status = 'rejected' THEN wp.id END) as rejected_permits,
                COUNT(DISTINCT CASE WHEN wp.created_at >= CURRENT_DATE - INTERVAL '30 days' THEN wp.id END) as issued_this_month,
                COUNT(DISTINCT CASE WHEN wp.risk_level = 'high' THEN wp.id END) as high_risk_permits,
                MAX(wp.created_at) as latest_permit_date
            FROM work_permits wp";

        using var conn = _db.GetConnection();
        var result = await conn.QueryFirstOrDefaultAsync<dynamic>(sql);

        if (result == null)
            return new PermitKpisDto();

        var kpi = new PermitKpisDto
        {
            TotalPermits = result.total_permits ?? 0,
            ActivePermits = result.active_permits ?? 0,
            ExpiredPermits = result.expired_permits ?? 0,
            ExpiringWithin30Days = result.expiring_within_30 ?? 0,
            PendingApproval = result.pending_approval ?? 0,
            RejectedPermits = result.rejected_permits ?? 0,
            IssuedThisMonth = result.issued_this_month ?? 0,
            HighRiskPermits = result.high_risk_permits ?? 0,
            LatestPermitDate = result.latest_permit_date
        };

        // Permit type breakdown
        var typesSql = @"
            SELECT permit_type, COUNT(*) as count
            FROM work_permits
            GROUP BY permit_type";
        var typesResult = await conn.QueryAsync<dynamic>(typesSql);
        foreach (var row in typesResult)
        {
            kpi.PermitTypeCount[row.permit_type] = row.count;
        }

        // Average approval days
        var approvalSql = @"
            SELECT AVG(EXTRACT(DAY FROM (wp.approved_at - wp.created_at))) as avg_days
            FROM work_permits wp
            WHERE wp.approved_at IS NOT NULL";
        var approvalResult = await conn.QueryFirstOrDefaultAsync<dynamic>(approvalSql);
        kpi.AverageApprovalDays = approvalResult?.avg_days != null 
            ? decimal.Parse(approvalResult.avg_days.ToString()) 
            : 0;

        // Compliance rate (not expired and approved)
        kpi.ComplianceRate = kpi.TotalPermits > 0
            ? Math.Round((decimal)(kpi.TotalPermits - kpi.ExpiredPermits) / kpi.TotalPermits * 100, 2)
            : 0;

        return kpi;
    }

    public async Task<WorkflowKpisDto> GetWorkflowKpisAsync()
    {
        var sql = @"
            SELECT 
                COUNT(DISTINCT wf.id) as total_workflows,
                COUNT(DISTINCT CASE WHEN wf.status = 'active' THEN wf.id END) as active_workflows,
                COUNT(DISTINCT CASE WHEN wf.status = 'completed' THEN wf.id END) as completed_workflows,
                COUNT(DISTINCT CASE WHEN wf.status = 'pending_approval' THEN wf.id END) as pending_approvals,
                COUNT(DISTINCT CASE WHEN wf.status = 'awaiting_review' THEN wf.id END) as awaiting_review,
                COUNT(DISTINCT CASE WHEN wf.due_date < CURRENT_DATE AND wf.status != 'completed' THEN wf.id END) as overdue_workflows,
                COUNT(DISTINCT CASE WHEN wf.status = 'rejected' THEN wf.id END) as rejected_workflows,
                COUNT(DISTINCT CASE WHEN wf.created_at >= CURRENT_DATE - INTERVAL '30 days' THEN wf.id END) as completed_this_month,
                MAX(wf.completed_at) as max_completed_date
            FROM workflows wf";

        using var conn = _db.GetConnection();
        var result = await conn.QueryFirstOrDefaultAsync<dynamic>(sql);

        if (result == null)
            return new WorkflowKpisDto();

        var kpi = new WorkflowKpisDto
        {
            TotalWorkflows = result.total_workflows ?? 0,
            ActiveWorkflows = result.active_workflows ?? 0,
            CompletedWorkflows = result.completed_workflows ?? 0,
            PendingApprovals = result.pending_approvals ?? 0,
            AwaitingReview = result.awaiting_review ?? 0,
            OverdueWorkflows = result.overdue_workflows ?? 0,
            RejectedWorkflows = result.rejected_workflows ?? 0,
            CompletedThisMonth = result.completed_this_month ?? 0
        };

        // Workflow type breakdown
        var typesSql = @"
            SELECT workflow_type, COUNT(*) as count
            FROM workflows
            GROUP BY workflow_type";
        var typesResult = await conn.QueryAsync<dynamic>(typesSql);
        foreach (var row in typesResult)
        {
            kpi.WorkflowTypeCount[row.workflow_type] = row.count;
        }

        // Status breakdown
        var statusSql = @"
            SELECT status, COUNT(*) as count
            FROM workflows
            GROUP BY status";
        var statusResult = await conn.QueryAsync<dynamic>(statusSql);
        foreach (var row in statusResult)
        {
            kpi.StatusBreakdown[row.status] = row.count;
        }

        // Average cycle time
        var cycleSql = @"
            SELECT AVG(EXTRACT(DAY FROM (wf.completed_at - wf.created_at))) as avg_days
            FROM workflows wf
            WHERE wf.completed_at IS NOT NULL";
        var cycleResult = await conn.QueryFirstOrDefaultAsync<dynamic>(cycleSql);
        kpi.AverageCycleTimeDays = cycleResult?.avg_days != null 
            ? decimal.Parse(cycleResult.avg_days.ToString()) 
            : 0;

        // Completion rate
        kpi.CompletionRate = kpi.TotalWorkflows > 0
            ? Math.Round((decimal)kpi.CompletedWorkflows / kpi.TotalWorkflows * 100, 2)
            : 0;

        // Average approval time
        var approvalSql = @"
            SELECT AVG(EXTRACT(EPOCH FROM (COALESCE(wf.approved_at, CURRENT_TIMESTAMP) - wf.created_at))/3600) as avg_hours
            FROM workflows wf
            WHERE wf.status = 'completed'";
        var approvalResult = await conn.QueryFirstOrDefaultAsync<dynamic>(approvalSql);
        kpi.AvgApprovalTimeHours = approvalResult?.avg_hours != null 
            ? decimal.Parse(approvalResult.avg_hours.ToString()) 
            : 0;

        return kpi;
    }

    public async Task<ActionRegisterKpisDto> GetActionRegisterKpisAsync()
    {
        var sql = @"
            SELECT 
                COUNT(DISTINCT ar.id) as total_actions,
                COUNT(DISTINCT CASE WHEN ar.status != 'closed' THEN ar.id END) as open_actions,
                COUNT(DISTINCT CASE WHEN ar.status = 'closed' THEN ar.id END) as closed_actions,
                COUNT(DISTINCT CASE WHEN ar.due_date < CURRENT_DATE AND ar.status != 'closed' THEN ar.id END) as overdue_actions,
                COUNT(DISTINCT CASE WHEN ar.due_date >= CURRENT_DATE AND ar.due_date <= CURRENT_DATE + INTERVAL '30 days' AND ar.status != 'closed' THEN ar.id END) as due_within_30,
                COUNT(DISTINCT CASE WHEN ar.priority = 'high' THEN ar.id END) as high_priority,
                COUNT(DISTINCT CASE WHEN ar.priority = 'medium' THEN ar.id END) as medium_priority,
                COUNT(DISTINCT CASE WHEN ar.priority = 'low' THEN ar.id END) as low_priority,
                COUNT(DISTINCT CASE WHEN ar.created_at >= CURRENT_DATE - INTERVAL '30 days' THEN ar.id END) as created_this_month,
                MAX(ar.created_at) as last_action_date
            FROM action_register ar";

        using var conn = _db.GetConnection();
        var result = await conn.QueryFirstOrDefaultAsync<dynamic>(sql);

        if (result == null)
            return new ActionRegisterKpisDto();

        var kpi = new ActionRegisterKpisDto
        {
            TotalActions = result.total_actions ?? 0,
            OpenActions = result.open_actions ?? 0,
            ClosedActions = result.closed_actions ?? 0,
            OverdueActions = result.overdue_actions ?? 0,
            DueWithin30Days = result.due_within_30 ?? 0,
            HighPriorityActions = result.high_priority ?? 0,
            MediumPriorityActions = result.medium_priority ?? 0,
            LowPriorityActions = result.low_priority ?? 0,
            CreatedThisMonth = result.created_this_month ?? 0,
            LastActionDate = result.last_action_date
        };

        // Source breakdown
        var sourceSql = @"
            SELECT source, COUNT(*) as count
            FROM action_register
            WHERE source IS NOT NULL
            GROUP BY source";
        var sourceResult = await conn.QueryAsync<dynamic>(sourceSql);
        foreach (var row in sourceResult)
        {
            kpi.SourceBreakdown[row.source] = row.count;
        }

        // Owner breakdown
        var ownerSql = @"
            SELECT owner_id, COUNT(*) as count
            FROM action_register
            WHERE owner_id IS NOT NULL
            GROUP BY owner_id
            LIMIT 10";
        var ownerResult = await conn.QueryAsync<dynamic>(ownerSql);
        foreach (var row in ownerResult)
        {
            kpi.OwnerBreakdown[row.owner_id] = row.count;
        }

        // Average closure days
        var closureSql = @"
            SELECT AVG(EXTRACT(DAY FROM (ar.closed_at - ar.created_at))) as avg_days
            FROM action_register ar
            WHERE ar.status = 'closed' AND ar.closed_at IS NOT NULL";
        var closureResult = await conn.QueryFirstOrDefaultAsync<dynamic>(closureSql);
        kpi.AverageClosureDays = closureResult?.avg_days != null 
            ? decimal.Parse(closureResult.avg_days.ToString()) 
            : 0;

        // Closure rate
        kpi.ClosureRate = kpi.TotalActions > 0
            ? Math.Round((decimal)kpi.ClosedActions / kpi.TotalActions * 100, 2)
            : 0;

        // Effectiveness score (combining closure rate and timeliness)
        kpi.EffectivenessScore = (kpi.ClosureRate * 0.6m) + 
            (kpi.AverageClosureDays > 0 ? (100 - Math.Min(kpi.AverageClosureDays, 365) / 3.65m) * 0.4m : 0);

        return kpi;
    }

    public async Task<AuditKpisDto> GetAuditKpisAsync()
    {
        var sql = @"
            SELECT 
                COUNT(DISTINCT al.id) as total_records,
                COUNT(DISTINCT CASE WHEN al.created_at >= CURRENT_DATE - INTERVAL '30 days' THEN al.id END) as this_month,
                COUNT(DISTINCT CASE WHEN EXTRACT(YEAR FROM al.created_at) = EXTRACT(YEAR FROM CURRENT_DATE) THEN al.id END) as this_year,
                COUNT(DISTINCT al.user_id) as unique_users,
                COUNT(DISTINCT CASE WHEN al.action = 'DELETE' OR al.action = 'CRITICAL_UPDATE' THEN al.id END) as critical_changes,
                COUNT(DISTINCT CASE WHEN al.severity = 'high' THEN al.id END) as high_risk_operations,
                COUNT(DISTINCT CASE WHEN al.action LIKE '%COMPLIANCE%' THEN al.id END) as compliance_actions,
                COUNT(DISTINCT CASE WHEN al.action = 'UPDATE' OR al.action = 'CREATE' THEN al.id END) as data_modifications,
                COUNT(DISTINCT CASE WHEN al.severity = 'failed' THEN al.id END) as failed_attempts,
                COUNT(DISTINCT CASE WHEN al.action LIKE '%PERMISSION%' OR al.action LIKE '%ROLE%' THEN al.id END) as permission_changes,
                MAX(al.created_at) as last_audit_date
            FROM audit_logs al";

        using var conn = _db.GetConnection();
        var result = await conn.QueryFirstOrDefaultAsync<dynamic>(sql);

        if (result == null)
            return new AuditKpisDto();

        var kpi = new AuditKpisDto
        {
            TotalAuditRecords = result.total_records ?? 0,
            AuditRecordsThisMonth = result.this_month ?? 0,
            AuditRecordsThisYear = result.this_year ?? 0,
            UniqueUsersAudited = result.unique_users ?? 0,
            CriticalChanges = result.critical_changes ?? 0,
            HighRiskOperations = result.high_risk_operations ?? 0,
            ComplianceActions = result.compliance_actions ?? 0,
            DataModifications = result.data_modifications ?? 0,
            FailedAccessAttempts = result.failed_attempts ?? 0,
            PermissionChanges = result.permission_changes ?? 0,
            LastAuditDate = result.last_audit_date
        };

        // Event type breakdown
        var typeSql = @"
            SELECT action, COUNT(*) as count
            FROM audit_logs
            GROUP BY action
            ORDER BY count DESC
            LIMIT 15";
        var typeResult = await conn.QueryAsync<dynamic>(typeSql);
        foreach (var row in typeResult)
        {
            kpi.EventTypeBreakdown[row.action] = row.count;
        }

        // Top users breakdown
        var usersSql = @"
            SELECT user_id, COUNT(*) as count
            FROM audit_logs
            WHERE user_id IS NOT NULL
            GROUP BY user_id
            ORDER BY count DESC
            LIMIT 10";
        var usersResult = await conn.QueryAsync<dynamic>(usersSql);
        foreach (var row in usersResult)
        {
            kpi.TopUsersBreakdown[row.user_id] = row.count;
        }

        return kpi;
    }

    public async Task<DashboardKpisDto> GetAllKpisAsync()
    {
        var kpis = new DashboardKpisDto
        {
            Timestamp = DateTime.UtcNow,
            HazopKpis = await GetHazopKpisAsync(),
            LopaKpis = await GetLopaKpisAsync(),
            IncidentKpis = await GetIncidentKpisAsync(),
            PermitKpis = await GetPermitKpisAsync(),
            WorkflowKpis = await GetWorkflowKpisAsync(),
            ActionRegisterKpis = await GetActionRegisterKpisAsync(),
            AuditKpis = await GetAuditKpisAsync()
        };

        // Calculate summary
        kpis.Summary = CalculateSummary(kpis);
        return kpis;
    }

    private DashboardSummaryDto CalculateSummary(DashboardKpisDto kpis)
    {
        var summary = new DashboardSummaryDto
        {
            TotalIdentifiedHazards = kpis.HazopKpis.TotalHazardsIdentified,
            TotalOpenActions = kpis.ActionRegisterKpis.OpenActions + kpis.WorkflowKpis.PendingApprovals,
            TotalOverdueItems = kpis.ActionRegisterKpis.OverdueActions + kpis.PermitKpis.ExpiredPermits + kpis.WorkflowKpis.OverdueWorkflows,
            CriticalAlerts = kpis.HazopKpis.HighRiskHazards + kpis.IncidentKpis.HighSeverityIncidents + kpis.PermitKpis.HighRiskPermits,
            BarriersEffective = Math.Max(0, (int)(kpis.IncidentKpis.BarrierEffectivenessAverage > 0.7m ? 10 : 5)),
            BarriersDegraded = Math.Max(0, (int)(kpis.IncidentKpis.BarrierEffectivenessAverage > 0.4m && kpis.IncidentKpis.BarrierEffectivenessAverage <= 0.7m ? 5 : 0)),
            BarriersFailed = kpis.IncidentKpis.BarrierFailures,
            LastUpdateTimestamp = DateTime.UtcNow
        };

        // Overall risk calculation
        var riskScore = 0m;
        riskScore += kpis.HazopKpis.HighRiskHazards * 2;
        riskScore += kpis.IncidentKpis.HighSeverityIncidents * 3;
        riskScore += kpis.LopaKpis.HighRiskScenarios * 2.5m;
        
        var hazardCount = kpis.HazopKpis.TotalHazardsIdentified + kpis.IncidentKpis.TotalIncidents + kpis.LopaKpis.TotalScenarios;
        var avgRisk = hazardCount > 0 ? riskScore / hazardCount : 0;

        summary.OverallRiskLevel = avgRisk switch
        {
            >= 3m => "Critical",
            >= 2m => "High",
            >= 1m => "Moderate",
            _ => "Low"
        };

        // System health
        var healthScore = 100m;
        healthScore -= kpis.ActionRegisterKpis.ClosureRate > 80 ? 0 : 5;
        healthScore -= kpis.PermitKpis.ComplianceRate > 95 ? 0 : 5;
        healthScore -= kpis.WorkflowKpis.CompletionRate > 90 ? 0 : 3;
        healthScore -= summary.TotalOverdueItems > 0 ? (summary.TotalOverdueItems * 2) : 0;
        
        summary.SystemHealthPercentage = Math.Max(0, healthScore);

        summary.ComplianceStatus = summary.SystemHealthPercentage > 80 ? "Compliant" : "Non-Compliant";

        return summary;
    }
}
