using Dapper;
using PSM.Api.Data;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

// ════════════════════════════════════════════════════════════════════════════
// HIRA Repository
// ════════════════════════════════════════════════════════════════════════════
public interface IHiraRepository
{
    Task<IEnumerable<HiraDto>> ListAsync();
    Task<HiraDto?> GetAsync(string id);
    Task<string> CreateAsync(string id, string title, string? facility, string? department, string? assessor, string? status, DateTime? assessmentDate, string? createdBy, string dataJson);
    Task<bool> ExistsAsync(string id);
    Task UpdateAsync(string id, string title, string? facility, string? department, string? assessor, string? status, DateTime? assessmentDate, string dataJson);
    Task SoftDeleteAsync(string id);
    Task<IEnumerable<HiraHazardDto>> ListHazardsAsync(string hiraId);
    Task<string> CreateHazardAsync(string id, string hiraId, string? hazardDescription, string? activity, string? potentialConsequence, string? existingControls, int likelihood, int severity, string? riskLevel, string? recommendedActions, string dataJson);
    Task<bool> HazardExistsAsync(string id);
    Task UpdateHazardAsync(string id, string? hazardDescription, string? activity, string? potentialConsequence, string? existingControls, int likelihood, int severity, string? riskLevel, string? recommendedActions, string dataJson);
    Task DeleteHazardAsync(string id);
}

public class HiraRepository : IHiraRepository
{
    private readonly IDbHelper _db;
    public HiraRepository(IDbHelper db) => _db = db;

    public Task<IEnumerable<HiraDto>> ListAsync() =>
        _db.QueryAsync<HiraDto>("SELECT * FROM hira_assessments WHERE deleted_at IS NULL ORDER BY created_at DESC");

    public Task<HiraDto?> GetAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<HiraDto>("SELECT * FROM hira_assessments WHERE id=@id AND deleted_at IS NULL", new { id });

    public async Task<string> CreateAsync(string id, string title, string? facility, string? department, string? assessor, string? status, DateTime? assessmentDate, string? createdBy, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO hira_assessments (id,title,facility,department,assessor,status,assessment_date,created_by,data)
            VALUES (@id,@title,@facility,@department,@assessor,@status,@assessmentDate,@createdBy,@dataJson::jsonb)",
            new { id, title, facility, department, assessor, status, assessmentDate, createdBy, dataJson });
        return id;
    }

    public Task<bool> ExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM hira_assessments WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateAsync(string id, string title, string? facility, string? department, string? assessor, string? status, DateTime? assessmentDate, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE hira_assessments SET title=@title,facility=@facility,department=@department,assessor=@assessor,status=@status,assessment_date=@assessmentDate,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, title, facility, department, assessor, status, assessmentDate, dataJson });

    public Task SoftDeleteAsync(string id) =>
        _db.ExecuteAsync("UPDATE hira_assessments SET deleted_at=NOW() WHERE id=@id", new { id });

    public Task<IEnumerable<HiraHazardDto>> ListHazardsAsync(string hiraId) =>
        _db.QueryAsync<HiraHazardDto>("SELECT * FROM hira_hazards WHERE hira_id=@hiraId AND deleted_at IS NULL ORDER BY created_at", new { hiraId });

    public async Task<string> CreateHazardAsync(string id, string hiraId, string? hazardDescription, string? activity, string? potentialConsequence, string? existingControls, int likelihood, int severity, string? riskLevel, string? recommendedActions, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO hira_hazards (id,hira_id,hazard_description,activity,potential_consequence,existing_controls,likelihood,severity,risk_level,recommended_actions,data)
            VALUES (@id,@hiraId,@hazardDescription,@activity,@potentialConsequence,@existingControls,@likelihood,@severity,@riskLevel,@recommendedActions,@dataJson::jsonb)",
            new { id, hiraId, hazardDescription, activity, potentialConsequence, existingControls, likelihood, severity, riskLevel, recommendedActions, dataJson });
        return id;
    }

    public Task<bool> HazardExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM hira_hazards WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateHazardAsync(string id, string? hazardDescription, string? activity, string? potentialConsequence, string? existingControls, int likelihood, int severity, string? riskLevel, string? recommendedActions, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE hira_hazards SET hazard_description=@hazardDescription,activity=@activity,potential_consequence=@potentialConsequence,existing_controls=@existingControls,likelihood=@likelihood,severity=@severity,risk_level=@riskLevel,recommended_actions=@recommendedActions,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, hazardDescription, activity, potentialConsequence, existingControls, likelihood, severity, riskLevel, recommendedActions, dataJson });

    public Task DeleteHazardAsync(string id) =>
        _db.ExecuteAsync("UPDATE hira_hazards SET deleted_at=NOW() WHERE id=@id", new { id });
}

// ════════════════════════════════════════════════════════════════════════════
// RCA Repository
// ════════════════════════════════════════════════════════════════════════════
public interface IRcaRepository
{
    Task<IEnumerable<RcaDto>> ListAsync();
    Task<RcaDto?> GetAsync(string id);
    Task<string> CreateAsync(string id, string title, string? incidentDate, string? location, string? description, string? investigator, string? status, string? methodology, string? createdBy, string dataJson);
    Task<bool> ExistsAsync(string id);
    Task UpdateAsync(string id, string title, string? incidentDate, string? location, string? description, string? investigator, string? status, string? methodology, string dataJson);
    Task SoftDeleteAsync(string id);
    Task<IEnumerable<RcaCauseDto>> ListCausesAsync(string rcaId);
    Task<string> CreateCauseAsync(string id, string rcaId, string? causeType, string? description, string? contributingFactor, string? correctiveAction, string dataJson);
    Task UpdateCauseAsync(string id, string? causeType, string? description, string? contributingFactor, string? correctiveAction, string dataJson);
    Task DeleteCauseAsync(string id);
}

public class RcaRepository : IRcaRepository
{
    private readonly IDbHelper _db;
    public RcaRepository(IDbHelper db) => _db = db;

    public Task<IEnumerable<RcaDto>> ListAsync() =>
        _db.QueryAsync<RcaDto>("SELECT * FROM rca_records WHERE deleted_at IS NULL ORDER BY created_at DESC");

    public Task<RcaDto?> GetAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<RcaDto>("SELECT * FROM rca_records WHERE id=@id AND deleted_at IS NULL", new { id });

    public async Task<string> CreateAsync(string id, string title, string? incidentDate, string? location, string? description, string? investigator, string? status, string? methodology, string? createdBy, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO rca_records (id,title,incident_date,location,description,investigator,status,methodology,created_by,data)
            VALUES (@id,@title,@incidentDate,@location,@description,@investigator,@status,@methodology,@createdBy,@dataJson::jsonb)",
            new { id, title, incidentDate, location, description, investigator, status, methodology, createdBy, dataJson });
        return id;
    }

    public Task<bool> ExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM rca_records WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateAsync(string id, string title, string? incidentDate, string? location, string? description, string? investigator, string? status, string? methodology, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE rca_records SET title=@title,incident_date=@incidentDate,location=@location,description=@description,investigator=@investigator,status=@status,methodology=@methodology,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, title, incidentDate, location, description, investigator, status, methodology, dataJson });

    public Task SoftDeleteAsync(string id) =>
        _db.ExecuteAsync("UPDATE rca_records SET deleted_at=NOW() WHERE id=@id", new { id });

    public Task<IEnumerable<RcaCauseDto>> ListCausesAsync(string rcaId) =>
        _db.QueryAsync<RcaCauseDto>("SELECT * FROM rca_causes WHERE rca_id=@rcaId ORDER BY created_at", new { rcaId });

    public async Task<string> CreateCauseAsync(string id, string rcaId, string? causeType, string? description, string? contributingFactor, string? correctiveAction, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO rca_causes (id,rca_id,cause_type,description,contributing_factor,corrective_action,data)
            VALUES (@id,@rcaId,@causeType,@description,@contributingFactor,@correctiveAction,@dataJson::jsonb)",
            new { id, rcaId, causeType, description, contributingFactor, correctiveAction, dataJson });
        return id;
    }

    public Task UpdateCauseAsync(string id, string? causeType, string? description, string? contributingFactor, string? correctiveAction, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE rca_causes SET cause_type=@causeType,description=@description,contributing_factor=@contributingFactor,corrective_action=@correctiveAction,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, causeType, description, contributingFactor, correctiveAction, dataJson });

    public Task DeleteCauseAsync(string id) =>
        _db.ExecuteAsync("DELETE FROM rca_causes WHERE id=@id", new { id });
}

// ════════════════════════════════════════════════════════════════════════════
// Competency Repository
// ════════════════════════════════════════════════════════════════════════════
public interface ICompetencyRepository
{
    Task<IEnumerable<CompetencyDto>> ListAsync();
    Task<CompetencyDto?> GetAsync(string id);
    Task<string> CreateAsync(string id, string title, string? category, string? description, string? level, string dataJson);
    Task<bool> ExistsAsync(string id);
    Task UpdateAsync(string id, string title, string? category, string? description, string? level, string dataJson);
    Task SoftDeleteAsync(string id);
    Task<IEnumerable<CompetencyAssessmentDto>> ListAssessmentsAsync(string competencyId);
    Task<string> CreateAssessmentAsync(string id, string competencyId, string? employeeId, string? employeeName, int score, string? assessor, DateTime? assessmentDate, string? notes, string dataJson);
    Task DeleteAssessmentAsync(string id);
}

public class CompetencyRepository : ICompetencyRepository
{
    private readonly IDbHelper _db;
    public CompetencyRepository(IDbHelper db) => _db = db;

    public Task<IEnumerable<CompetencyDto>> ListAsync() =>
        _db.QueryAsync<CompetencyDto>("SELECT * FROM competencies WHERE deleted_at IS NULL ORDER BY created_at DESC");

    public Task<CompetencyDto?> GetAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<CompetencyDto>("SELECT * FROM competencies WHERE id=@id AND deleted_at IS NULL", new { id });

    public async Task<string> CreateAsync(string id, string title, string? category, string? description, string? level, string dataJson)
    {
        await _db.ExecuteAsync("INSERT INTO competencies (id,title,category,description,level,data) VALUES (@id,@title,@category,@description,@level,@dataJson::jsonb)",
            new { id, title, category, description, level, dataJson });
        return id;
    }

    public Task<bool> ExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM competencies WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateAsync(string id, string title, string? category, string? description, string? level, string dataJson) =>
        _db.ExecuteAsync("UPDATE competencies SET title=@title,category=@category,description=@description,level=@level,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, title, category, description, level, dataJson });

    public Task SoftDeleteAsync(string id) =>
        _db.ExecuteAsync("UPDATE competencies SET deleted_at=NOW() WHERE id=@id", new { id });

    public Task<IEnumerable<CompetencyAssessmentDto>> ListAssessmentsAsync(string competencyId) =>
        _db.QueryAsync<CompetencyAssessmentDto>("SELECT * FROM competency_assessments WHERE competency_id=@competencyId ORDER BY assessment_date DESC", new { competencyId });

    public async Task<string> CreateAssessmentAsync(string id, string competencyId, string? employeeId, string? employeeName, int score, string? assessor, DateTime? assessmentDate, string? notes, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO competency_assessments (id,competency_id,employee_id,employee_name,score,assessor,assessment_date,notes,data)
            VALUES (@id,@competencyId,@employeeId,@employeeName,@score,@assessor,@assessmentDate,@notes,@dataJson::jsonb)",
            new { id, competencyId, employeeId, employeeName, score, assessor, assessmentDate, notes, dataJson });
        return id;
    }

    public Task DeleteAssessmentAsync(string id) =>
        _db.ExecuteAsync("DELETE FROM competency_assessments WHERE id=@id", new { id });
}

// ════════════════════════════════════════════════════════════════════════════
// Training Repository
// ════════════════════════════════════════════════════════════════════════════
public interface ITrainingRepository
{
    Task<IEnumerable<TrainingDto>> ListAsync();
    Task<TrainingDto?> GetAsync(string id);
    Task<string> CreateAsync(string id, string title, string? category, string? trainer, DateTime? scheduledDate, int durationHours, string? location, string? status, string? description, string? createdBy, string dataJson);
    Task<bool> ExistsAsync(string id);
    Task UpdateAsync(string id, string title, string? category, string? trainer, DateTime? scheduledDate, int durationHours, string? location, string? status, string? description, string dataJson);
    Task SoftDeleteAsync(string id);
    Task<IEnumerable<TrainingParticipantDto>> ListParticipantsAsync(string trainingId);
    Task<string> AddParticipantAsync(string id, string trainingId, string? employeeId, string? employeeName, string? status, bool passed, string? notes);
    Task RemoveParticipantAsync(string id);
}

public class TrainingRepository : ITrainingRepository
{
    private readonly IDbHelper _db;
    public TrainingRepository(IDbHelper db) => _db = db;

    public Task<IEnumerable<TrainingDto>> ListAsync() =>
        _db.QueryAsync<TrainingDto>("SELECT * FROM training_sessions WHERE deleted_at IS NULL ORDER BY scheduled_date DESC");

    public Task<TrainingDto?> GetAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<TrainingDto>("SELECT * FROM training_sessions WHERE id=@id AND deleted_at IS NULL", new { id });

    public async Task<string> CreateAsync(string id, string title, string? category, string? trainer, DateTime? scheduledDate, int durationHours, string? location, string? status, string? description, string? createdBy, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO training_sessions (id,title,category,trainer,scheduled_date,duration_hours,location,status,description,created_by,data)
            VALUES (@id,@title,@category,@trainer,@scheduledDate,@durationHours,@location,@status,@description,@createdBy,@dataJson::jsonb)",
            new { id, title, category, trainer, scheduledDate, durationHours, location, status, description, createdBy, dataJson });
        return id;
    }

    public Task<bool> ExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM training_sessions WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateAsync(string id, string title, string? category, string? trainer, DateTime? scheduledDate, int durationHours, string? location, string? status, string? description, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE training_sessions SET title=@title,category=@category,trainer=@trainer,scheduled_date=@scheduledDate,duration_hours=@durationHours,location=@location,status=@status,description=@description,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, title, category, trainer, scheduledDate, durationHours, location, status, description, dataJson });

    public Task SoftDeleteAsync(string id) =>
        _db.ExecuteAsync("UPDATE training_sessions SET deleted_at=NOW() WHERE id=@id", new { id });

    public Task<IEnumerable<TrainingParticipantDto>> ListParticipantsAsync(string trainingId) =>
        _db.QueryAsync<TrainingParticipantDto>("SELECT * FROM training_participants WHERE training_id=@trainingId ORDER BY created_at", new { trainingId });

    public async Task<string> AddParticipantAsync(string id, string trainingId, string? employeeId, string? employeeName, string? status, bool passed, string? notes)
    {
        await _db.ExecuteAsync(@"INSERT INTO training_participants (id,training_id,employee_id,employee_name,status,passed,notes)
            VALUES (@id,@trainingId,@employeeId,@employeeName,@status,@passed,@notes)",
            new { id, trainingId, employeeId, employeeName, status, passed, notes });
        return id;
    }

    public Task RemoveParticipantAsync(string id) =>
        _db.ExecuteAsync("DELETE FROM training_participants WHERE id=@id", new { id });
}

// ════════════════════════════════════════════════════════════════════════════
// Contractors Repository
// ════════════════════════════════════════════════════════════════════════════
public interface IContractorRepository
{
    Task<IEnumerable<ContractorDto>> ListAsync();
    Task<ContractorDto?> GetAsync(string id);
    Task<string> CreateAsync(string id, string name, string? company, string? contactPerson, string? contactEmail, string? contactPhone, string? contractNumber, DateTime? contractStart, DateTime? contractEnd, string? status, string? scopeOfWork, string? createdBy, string dataJson);
    Task<bool> ExistsAsync(string id);
    Task UpdateAsync(string id, string name, string? company, string? contactPerson, string? contactEmail, string? contactPhone, string? contractNumber, DateTime? contractStart, DateTime? contractEnd, string? status, string? scopeOfWork, string dataJson);
    Task SoftDeleteAsync(string id);
}

public class ContractorRepository : IContractorRepository
{
    private readonly IDbHelper _db;
    public ContractorRepository(IDbHelper db) => _db = db;

    public Task<IEnumerable<ContractorDto>> ListAsync() =>
        _db.QueryAsync<ContractorDto>("SELECT * FROM contractors WHERE deleted_at IS NULL ORDER BY created_at DESC");

    public Task<ContractorDto?> GetAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<ContractorDto>("SELECT * FROM contractors WHERE id=@id AND deleted_at IS NULL", new { id });

    public async Task<string> CreateAsync(string id, string name, string? company, string? contactPerson, string? contactEmail, string? contactPhone, string? contractNumber, DateTime? contractStart, DateTime? contractEnd, string? status, string? scopeOfWork, string? createdBy, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO contractors (id,name,company,contact_person,contact_email,contact_phone,contract_number,contract_start,contract_end,status,scope_of_work,created_by,data)
            VALUES (@id,@name,@company,@contactPerson,@contactEmail,@contactPhone,@contractNumber,@contractStart,@contractEnd,@status,@scopeOfWork,@createdBy,@dataJson::jsonb)",
            new { id, name, company, contactPerson, contactEmail, contactPhone, contractNumber, contractStart, contractEnd, status, scopeOfWork, createdBy, dataJson });
        return id;
    }

    public Task<bool> ExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM contractors WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateAsync(string id, string name, string? company, string? contactPerson, string? contactEmail, string? contactPhone, string? contractNumber, DateTime? contractStart, DateTime? contractEnd, string? status, string? scopeOfWork, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE contractors SET name=@name,company=@company,contact_person=@contactPerson,contact_email=@contactEmail,contact_phone=@contactPhone,contract_number=@contractNumber,contract_start=@contractStart,contract_end=@contractEnd,status=@status,scope_of_work=@scopeOfWork,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, name, company, contactPerson, contactEmail, contactPhone, contractNumber, contractStart, contractEnd, status, scopeOfWork, dataJson });

    public Task SoftDeleteAsync(string id) =>
        _db.ExecuteAsync("UPDATE contractors SET deleted_at=NOW() WHERE id=@id", new { id });
}

// ════════════════════════════════════════════════════════════════════════════
// PSI Repository
// ════════════════════════════════════════════════════════════════════════════
public interface IPsiRepository
{
    Task<IEnumerable<PsiDto>> ListAsync();
    Task<PsiDto?> GetAsync(string id);
    Task<string> CreateAsync(string id, string title, string? category, string? documentNumber, string? revision, string? status, string? description, string? responsiblePerson, DateTime? reviewDate, string? createdBy, string dataJson);
    Task<bool> ExistsAsync(string id);
    Task UpdateAsync(string id, string title, string? category, string? documentNumber, string? revision, string? status, string? description, string? responsiblePerson, DateTime? reviewDate, string dataJson);
    Task SoftDeleteAsync(string id);
}

public class PsiRepository : IPsiRepository
{
    private readonly IDbHelper _db;
    public PsiRepository(IDbHelper db) => _db = db;

    public Task<IEnumerable<PsiDto>> ListAsync() =>
        _db.QueryAsync<PsiDto>("SELECT * FROM psi_documents WHERE deleted_at IS NULL ORDER BY created_at DESC");

    public Task<PsiDto?> GetAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<PsiDto>("SELECT * FROM psi_documents WHERE id=@id AND deleted_at IS NULL", new { id });

    public async Task<string> CreateAsync(string id, string title, string? category, string? documentNumber, string? revision, string? status, string? description, string? responsiblePerson, DateTime? reviewDate, string? createdBy, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO psi_documents (id,title,category,document_number,revision,status,description,responsible_person,review_date,created_by,data)
            VALUES (@id,@title,@category,@documentNumber,@revision,@status,@description,@responsiblePerson,@reviewDate,@createdBy,@dataJson::jsonb)",
            new { id, title, category, documentNumber, revision, status, description, responsiblePerson, reviewDate, createdBy, dataJson });
        return id;
    }

    public Task<bool> ExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM psi_documents WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateAsync(string id, string title, string? category, string? documentNumber, string? revision, string? status, string? description, string? responsiblePerson, DateTime? reviewDate, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE psi_documents SET title=@title,category=@category,document_number=@documentNumber,revision=@revision,status=@status,description=@description,responsible_person=@responsiblePerson,review_date=@reviewDate,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, title, category, documentNumber, revision, status, description, responsiblePerson, reviewDate, dataJson });

    public Task SoftDeleteAsync(string id) =>
        _db.ExecuteAsync("UPDATE psi_documents SET deleted_at=NOW() WHERE id=@id", new { id });
}

// ════════════════════════════════════════════════════════════════════════════
// Mechanical Integrity Repository
// ════════════════════════════════════════════════════════════════════════════
public interface IMechanicalIntegrityRepository
{
    Task<IEnumerable<MiEquipmentDto>> ListEquipmentAsync();
    Task<MiEquipmentDto?> GetEquipmentAsync(string id);
    Task<string> CreateEquipmentAsync(string id, string tagNumber, string equipmentName, string? equipmentType, string? location, string? status, DateTime? installationDate, DateTime? nextInspectionDate, string? responsiblePerson, string dataJson);
    Task<bool> EquipmentExistsAsync(string id);
    Task UpdateEquipmentAsync(string id, string tagNumber, string equipmentName, string? equipmentType, string? location, string? status, DateTime? installationDate, DateTime? nextInspectionDate, string? responsiblePerson, string dataJson);
    Task SoftDeleteEquipmentAsync(string id);
    Task<IEnumerable<MiInspectionDto>> ListInspectionsAsync(string equipmentId);
    Task<string> CreateInspectionAsync(string id, string equipmentId, string? inspectionType, DateTime? inspectionDate, string? inspector, string? result, string? findings, string? recommendations, DateTime? nextDueDate, string dataJson);
    Task DeleteInspectionAsync(string id);
}

public class MechanicalIntegrityRepository : IMechanicalIntegrityRepository
{
    private readonly IDbHelper _db;
    public MechanicalIntegrityRepository(IDbHelper db) => _db = db;

    public Task<IEnumerable<MiEquipmentDto>> ListEquipmentAsync() =>
        _db.QueryAsync<MiEquipmentDto>("SELECT * FROM mi_equipment WHERE deleted_at IS NULL ORDER BY created_at DESC");

    public Task<MiEquipmentDto?> GetEquipmentAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<MiEquipmentDto>("SELECT * FROM mi_equipment WHERE id=@id AND deleted_at IS NULL", new { id });

    public async Task<string> CreateEquipmentAsync(string id, string tagNumber, string equipmentName, string? equipmentType, string? location, string? status, DateTime? installationDate, DateTime? nextInspectionDate, string? responsiblePerson, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO mi_equipment (id,tag_number,equipment_name,equipment_type,location,status,installation_date,next_inspection_date,responsible_person,data)
            VALUES (@id,@tagNumber,@equipmentName,@equipmentType,@location,@status,@installationDate,@nextInspectionDate,@responsiblePerson,@dataJson::jsonb)",
            new { id, tagNumber, equipmentName, equipmentType, location, status, installationDate, nextInspectionDate, responsiblePerson, dataJson });
        return id;
    }

    public Task<bool> EquipmentExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM mi_equipment WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateEquipmentAsync(string id, string tagNumber, string equipmentName, string? equipmentType, string? location, string? status, DateTime? installationDate, DateTime? nextInspectionDate, string? responsiblePerson, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE mi_equipment SET tag_number=@tagNumber,equipment_name=@equipmentName,equipment_type=@equipmentType,location=@location,status=@status,installation_date=@installationDate,next_inspection_date=@nextInspectionDate,responsible_person=@responsiblePerson,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, tagNumber, equipmentName, equipmentType, location, status, installationDate, nextInspectionDate, responsiblePerson, dataJson });

    public Task SoftDeleteEquipmentAsync(string id) =>
        _db.ExecuteAsync("UPDATE mi_equipment SET deleted_at=NOW() WHERE id=@id", new { id });

    public Task<IEnumerable<MiInspectionDto>> ListInspectionsAsync(string equipmentId) =>
        _db.QueryAsync<MiInspectionDto>("SELECT * FROM mi_inspections WHERE equipment_id=@equipmentId ORDER BY inspection_date DESC", new { equipmentId });

    public async Task<string> CreateInspectionAsync(string id, string equipmentId, string? inspectionType, DateTime? inspectionDate, string? inspector, string? result, string? findings, string? recommendations, DateTime? nextDueDate, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO mi_inspections (id,equipment_id,inspection_type,inspection_date,inspector,result,findings,recommendations,next_due_date,data)
            VALUES (@id,@equipmentId,@inspectionType,@inspectionDate,@inspector,@result,@findings,@recommendations,@nextDueDate,@dataJson::jsonb)",
            new { id, equipmentId, inspectionType, inspectionDate, inspector, result, findings, recommendations, nextDueDate, dataJson });
        return id;
    }

    public Task DeleteInspectionAsync(string id) =>
        _db.ExecuteAsync("DELETE FROM mi_inspections WHERE id=@id", new { id });
}

// ════════════════════════════════════════════════════════════════════════════
// Emergency Repository
// ════════════════════════════════════════════════════════════════════════════
public interface IEmergencyRepository
{
    Task<IEnumerable<EmergencyPlanDto>> ListAsync();
    Task<EmergencyPlanDto?> GetAsync(string id);
    Task<string> CreateAsync(string id, string title, string? scenarioType, string? location, string? description, string? responseTeam, string? status, DateTime? lastDrillDate, DateTime? nextDrillDate, string? createdBy, string dataJson);
    Task<bool> ExistsAsync(string id);
    Task UpdateAsync(string id, string title, string? scenarioType, string? location, string? description, string? responseTeam, string? status, DateTime? lastDrillDate, DateTime? nextDrillDate, string dataJson);
    Task SoftDeleteAsync(string id);
}

public class EmergencyRepository : IEmergencyRepository
{
    private readonly IDbHelper _db;
    public EmergencyRepository(IDbHelper db) => _db = db;

    public Task<IEnumerable<EmergencyPlanDto>> ListAsync() =>
        _db.QueryAsync<EmergencyPlanDto>("SELECT * FROM emergency_plans WHERE deleted_at IS NULL ORDER BY created_at DESC");

    public Task<EmergencyPlanDto?> GetAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<EmergencyPlanDto>("SELECT * FROM emergency_plans WHERE id=@id AND deleted_at IS NULL", new { id });

    public async Task<string> CreateAsync(string id, string title, string? scenarioType, string? location, string? description, string? responseTeam, string? status, DateTime? lastDrillDate, DateTime? nextDrillDate, string? createdBy, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO emergency_plans (id,title,scenario_type,location,description,response_team,status,last_drill_date,next_drill_date,created_by,data)
            VALUES (@id,@title,@scenarioType,@location,@description,@responseTeam,@status,@lastDrillDate,@nextDrillDate,@createdBy,@dataJson::jsonb)",
            new { id, title, scenarioType, location, description, responseTeam, status, lastDrillDate, nextDrillDate, createdBy, dataJson });
        return id;
    }

    public Task<bool> ExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM emergency_plans WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateAsync(string id, string title, string? scenarioType, string? location, string? description, string? responseTeam, string? status, DateTime? lastDrillDate, DateTime? nextDrillDate, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE emergency_plans SET title=@title,scenario_type=@scenarioType,location=@location,description=@description,response_team=@responseTeam,status=@status,last_drill_date=@lastDrillDate,next_drill_date=@nextDrillDate,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, title, scenarioType, location, description, responseTeam, status, lastDrillDate, nextDrillDate, dataJson });

    public Task SoftDeleteAsync(string id) =>
        _db.ExecuteAsync("UPDATE emergency_plans SET deleted_at=NOW() WHERE id=@id", new { id });
}

// ════════════════════════════════════════════════════════════════════════════
// Participation Repository
// ════════════════════════════════════════════════════════════════════════════
public interface IParticipationRepository
{
    Task<IEnumerable<ParticipationDto>> ListAsync();
    Task<ParticipationDto?> GetAsync(string id);
    Task<string> CreateAsync(string id, string title, string? activityType, DateTime? activityDate, string? organizer, string? department, string? description, string? status, string? createdBy, string dataJson);
    Task<bool> ExistsAsync(string id);
    Task UpdateAsync(string id, string title, string? activityType, DateTime? activityDate, string? organizer, string? department, string? description, string? status, string dataJson);
    Task SoftDeleteAsync(string id);
}

public class ParticipationRepository : IParticipationRepository
{
    private readonly IDbHelper _db;
    public ParticipationRepository(IDbHelper db) => _db = db;

    public Task<IEnumerable<ParticipationDto>> ListAsync() =>
        _db.QueryAsync<ParticipationDto>("SELECT * FROM participation_activities WHERE deleted_at IS NULL ORDER BY activity_date DESC");

    public Task<ParticipationDto?> GetAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<ParticipationDto>("SELECT * FROM participation_activities WHERE id=@id AND deleted_at IS NULL", new { id });

    public async Task<string> CreateAsync(string id, string title, string? activityType, DateTime? activityDate, string? organizer, string? department, string? description, string? status, string? createdBy, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO participation_activities (id,title,activity_type,activity_date,organizer,department,description,status,created_by,data)
            VALUES (@id,@title,@activityType,@activityDate,@organizer,@department,@description,@status,@createdBy,@dataJson::jsonb)",
            new { id, title, activityType, activityDate, organizer, department, description, status, createdBy, dataJson });
        return id;
    }

    public Task<bool> ExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM participation_activities WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateAsync(string id, string title, string? activityType, DateTime? activityDate, string? organizer, string? department, string? description, string? status, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE participation_activities SET title=@title,activity_type=@activityType,activity_date=@activityDate,organizer=@organizer,department=@department,description=@description,status=@status,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, title, activityType, activityDate, organizer, department, description, status, dataJson });

    public Task SoftDeleteAsync(string id) =>
        _db.ExecuteAsync("UPDATE participation_activities SET deleted_at=NOW() WHERE id=@id", new { id });
}

// ════════════════════════════════════════════════════════════════════════════
// Culture Repository
// ════════════════════════════════════════════════════════════════════════════
public interface ICultureRepository
{
    Task<IEnumerable<CultureAssessmentDto>> ListAsync();
    Task<CultureAssessmentDto?> GetAsync(string id);
    Task<string> CreateAsync(string id, string title, string? assessmentType, DateTime? assessmentDate, string? assessor, string? department, string? status, string? createdBy, string dataJson);
    Task<bool> ExistsAsync(string id);
    Task UpdateAsync(string id, string title, string? assessmentType, DateTime? assessmentDate, string? assessor, string? department, string? status, string dataJson);
    Task SoftDeleteAsync(string id);
    Task<IEnumerable<CultureResponseDto>> ListResponsesAsync(string assessmentId);
    Task<string> CreateResponseAsync(string id, string assessmentId, string? questionId, string? questionText, int score, string? comments);
}

public class CultureRepository : ICultureRepository
{
    private readonly IDbHelper _db;
    public CultureRepository(IDbHelper db) => _db = db;

    public Task<IEnumerable<CultureAssessmentDto>> ListAsync() =>
        _db.QueryAsync<CultureAssessmentDto>("SELECT * FROM culture_assessments WHERE deleted_at IS NULL ORDER BY assessment_date DESC");

    public Task<CultureAssessmentDto?> GetAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<CultureAssessmentDto>("SELECT * FROM culture_assessments WHERE id=@id AND deleted_at IS NULL", new { id });

    public async Task<string> CreateAsync(string id, string title, string? assessmentType, DateTime? assessmentDate, string? assessor, string? department, string? status, string? createdBy, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO culture_assessments (id,title,assessment_type,assessment_date,assessor,department,status,created_by,data)
            VALUES (@id,@title,@assessmentType,@assessmentDate,@assessor,@department,@status,@createdBy,@dataJson::jsonb)",
            new { id, title, assessmentType, assessmentDate, assessor, department, status, createdBy, dataJson });
        return id;
    }

    public Task<bool> ExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM culture_assessments WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateAsync(string id, string title, string? assessmentType, DateTime? assessmentDate, string? assessor, string? department, string? status, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE culture_assessments SET title=@title,assessment_type=@assessmentType,assessment_date=@assessmentDate,assessor=@assessor,department=@department,status=@status,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, title, assessmentType, assessmentDate, assessor, department, status, dataJson });

    public Task SoftDeleteAsync(string id) =>
        _db.ExecuteAsync("UPDATE culture_assessments SET deleted_at=NOW() WHERE id=@id", new { id });

    public Task<IEnumerable<CultureResponseDto>> ListResponsesAsync(string assessmentId) =>
        _db.QueryAsync<CultureResponseDto>("SELECT * FROM culture_responses WHERE assessment_id=@assessmentId ORDER BY created_at", new { assessmentId });

    public async Task<string> CreateResponseAsync(string id, string assessmentId, string? questionId, string? questionText, int score, string? comments)
    {
        await _db.ExecuteAsync("INSERT INTO culture_responses (id,assessment_id,question_id,question_text,score,comments) VALUES (@id,@assessmentId,@questionId,@questionText,@score,@comments)",
            new { id, assessmentId, questionId, questionText, score, comments });
        return id;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Stakeholders Repository
// ════════════════════════════════════════════════════════════════════════════
public interface IStakeholderRepository
{
    Task<IEnumerable<StakeholderDto>> ListAsync();
    Task<StakeholderDto?> GetAsync(string id);
    Task<string> CreateAsync(string id, string name, string? organization, string? role, string? email, string? phone, string? interestLevel, string? influenceLevel, string? engagementStrategy, string? createdBy, string dataJson);
    Task<bool> ExistsAsync(string id);
    Task UpdateAsync(string id, string name, string? organization, string? role, string? email, string? phone, string? interestLevel, string? influenceLevel, string? engagementStrategy, string dataJson);
    Task SoftDeleteAsync(string id);
}

public class StakeholderRepository : IStakeholderRepository
{
    private readonly IDbHelper _db;
    public StakeholderRepository(IDbHelper db) => _db = db;

    public Task<IEnumerable<StakeholderDto>> ListAsync() =>
        _db.QueryAsync<StakeholderDto>("SELECT * FROM stakeholders WHERE deleted_at IS NULL ORDER BY name");

    public Task<StakeholderDto?> GetAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<StakeholderDto>("SELECT * FROM stakeholders WHERE id=@id AND deleted_at IS NULL", new { id });

    public async Task<string> CreateAsync(string id, string name, string? organization, string? role, string? email, string? phone, string? interestLevel, string? influenceLevel, string? engagementStrategy, string? createdBy, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO stakeholders (id,name,organization,role,email,phone,interest_level,influence_level,engagement_strategy,created_by,data)
            VALUES (@id,@name,@organization,@role,@email,@phone,@interestLevel,@influenceLevel,@engagementStrategy,@createdBy,@dataJson::jsonb)",
            new { id, name, organization, role, email, phone, interestLevel, influenceLevel, engagementStrategy, createdBy, dataJson });
        return id;
    }

    public Task<bool> ExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM stakeholders WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateAsync(string id, string name, string? organization, string? role, string? email, string? phone, string? interestLevel, string? influenceLevel, string? engagementStrategy, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE stakeholders SET name=@name,organization=@organization,role=@role,email=@email,phone=@phone,interest_level=@interestLevel,influence_level=@influenceLevel,engagement_strategy=@engagementStrategy,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, name, organization, role, email, phone, interestLevel, influenceLevel, engagementStrategy, dataJson });

    public Task SoftDeleteAsync(string id) =>
        _db.ExecuteAsync("UPDATE stakeholders SET deleted_at=NOW() WHERE id=@id", new { id });
}

// ════════════════════════════════════════════════════════════════════════════
// Standards Repository
// ════════════════════════════════════════════════════════════════════════════
public interface IStandardRepository
{
    Task<IEnumerable<StandardDto>> ListAsync();
    Task<StandardDto?> GetAsync(string id);
    Task<string> CreateAsync(string id, string title, string? standardNumber, string? issuingBody, string? category, string? revision, DateTime? issueDate, DateTime? reviewDate, string? status, string? description, string? createdBy, string dataJson);
    Task<bool> ExistsAsync(string id);
    Task UpdateAsync(string id, string title, string? standardNumber, string? issuingBody, string? category, string? revision, DateTime? issueDate, DateTime? reviewDate, string? status, string? description, string dataJson);
    Task SoftDeleteAsync(string id);
}

public class StandardRepository : IStandardRepository
{
    private readonly IDbHelper _db;
    public StandardRepository(IDbHelper db) => _db = db;

    public Task<IEnumerable<StandardDto>> ListAsync() =>
        _db.QueryAsync<StandardDto>("SELECT * FROM standards WHERE deleted_at IS NULL ORDER BY title");

    public Task<StandardDto?> GetAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<StandardDto>("SELECT * FROM standards WHERE id=@id AND deleted_at IS NULL", new { id });

    public async Task<string> CreateAsync(string id, string title, string? standardNumber, string? issuingBody, string? category, string? revision, DateTime? issueDate, DateTime? reviewDate, string? status, string? description, string? createdBy, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO standards (id,title,standard_number,issuing_body,category,revision,issue_date,review_date,status,description,created_by,data)
            VALUES (@id,@title,@standardNumber,@issuingBody,@category,@revision,@issueDate,@reviewDate,@status,@description,@createdBy,@dataJson::jsonb)",
            new { id, title, standardNumber, issuingBody, category, revision, issueDate, reviewDate, status, description, createdBy, dataJson });
        return id;
    }

    public Task<bool> ExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM standards WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateAsync(string id, string title, string? standardNumber, string? issuingBody, string? category, string? revision, DateTime? issueDate, DateTime? reviewDate, string? status, string? description, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE standards SET title=@title,standard_number=@standardNumber,issuing_body=@issuingBody,category=@category,revision=@revision,issue_date=@issueDate,review_date=@reviewDate,status=@status,description=@description,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, title, standardNumber, issuingBody, category, revision, issueDate, reviewDate, status, description, dataJson });

    public Task SoftDeleteAsync(string id) =>
        _db.ExecuteAsync("UPDATE standards SET deleted_at=NOW() WHERE id=@id", new { id });
}

// ════════════════════════════════════════════════════════════════════════════
// Metrics Repository
// ════════════════════════════════════════════════════════════════════════════
public interface IMetricRepository
{
    Task<IEnumerable<MetricDto>> ListAsync();
    Task<MetricDto?> GetAsync(string id);
    Task<string> CreateAsync(string id, string title, string? category, string? metricType, string? unit, double? targetValue, string? frequency, string? responsiblePerson, string? description, string? createdBy, string dataJson);
    Task<bool> ExistsAsync(string id);
    Task UpdateAsync(string id, string title, string? category, string? metricType, string? unit, double? targetValue, string? frequency, string? responsiblePerson, string? description, string dataJson);
    Task SoftDeleteAsync(string id);
    Task<IEnumerable<MetricEntryDto>> ListEntriesAsync(string metricId);
    Task<string> CreateEntryAsync(string id, string metricId, double actualValue, DateTime? periodDate, string? notes, string? recordedBy);
    Task DeleteEntryAsync(string id);
}

public class MetricRepository : IMetricRepository
{
    private readonly IDbHelper _db;
    public MetricRepository(IDbHelper db) => _db = db;

    public Task<IEnumerable<MetricDto>> ListAsync() =>
        _db.QueryAsync<MetricDto>("SELECT * FROM psm_metrics WHERE deleted_at IS NULL ORDER BY category, title");

    public Task<MetricDto?> GetAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<MetricDto>("SELECT * FROM psm_metrics WHERE id=@id AND deleted_at IS NULL", new { id });

    public async Task<string> CreateAsync(string id, string title, string? category, string? metricType, string? unit, double? targetValue, string? frequency, string? responsiblePerson, string? description, string? createdBy, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO psm_metrics (id,title,category,metric_type,unit,target_value,frequency,responsible_person,description,created_by,data)
            VALUES (@id,@title,@category,@metricType,@unit,@targetValue,@frequency,@responsiblePerson,@description,@createdBy,@dataJson::jsonb)",
            new { id, title, category, metricType, unit, targetValue, frequency, responsiblePerson, description, createdBy, dataJson });
        return id;
    }

    public Task<bool> ExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM psm_metrics WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateAsync(string id, string title, string? category, string? metricType, string? unit, double? targetValue, string? frequency, string? responsiblePerson, string? description, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE psm_metrics SET title=@title,category=@category,metric_type=@metricType,unit=@unit,target_value=@targetValue,frequency=@frequency,responsible_person=@responsiblePerson,description=@description,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, title, category, metricType, unit, targetValue, frequency, responsiblePerson, description, dataJson });

    public Task SoftDeleteAsync(string id) =>
        _db.ExecuteAsync("UPDATE psm_metrics SET deleted_at=NOW() WHERE id=@id", new { id });

    public Task<IEnumerable<MetricEntryDto>> ListEntriesAsync(string metricId) =>
        _db.QueryAsync<MetricEntryDto>("SELECT * FROM metric_entries WHERE metric_id=@metricId ORDER BY period_date DESC", new { metricId });

    public async Task<string> CreateEntryAsync(string id, string metricId, double actualValue, DateTime? periodDate, string? notes, string? recordedBy)
    {
        await _db.ExecuteAsync("INSERT INTO metric_entries (id,metric_id,actual_value,period_date,notes,recorded_by) VALUES (@id,@metricId,@actualValue,@periodDate,@notes,@recordedBy)",
            new { id, metricId, actualValue, periodDate, notes, recordedBy });
        return id;
    }

    public Task DeleteEntryAsync(string id) =>
        _db.ExecuteAsync("DELETE FROM metric_entries WHERE id=@id", new { id });
}

// ════════════════════════════════════════════════════════════════════════════
// Management Review Repository
// ════════════════════════════════════════════════════════════════════════════
public interface IManagementReviewRepository
{
    Task<IEnumerable<ManagementReviewDto>> ListAsync();
    Task<ManagementReviewDto?> GetAsync(string id);
    Task<string> CreateAsync(string id, string title, DateTime? reviewDate, string? chairperson, string? location, string? status, string? agenda, string? minutes, string? createdBy, string dataJson);
    Task<bool> ExistsAsync(string id);
    Task UpdateAsync(string id, string title, DateTime? reviewDate, string? chairperson, string? location, string? status, string? agenda, string? minutes, string dataJson);
    Task SoftDeleteAsync(string id);
    Task<IEnumerable<MrActionItemDto>> ListActionItemsAsync(string reviewId);
    Task<string> CreateActionItemAsync(string id, string reviewId, string? description, string? assignedTo, DateTime? dueDate, string? priority, string? status);
    Task UpdateActionItemAsync(string id, string? description, string? assignedTo, DateTime? dueDate, string? priority, string? status);
    Task DeleteActionItemAsync(string id);
}

public class ManagementReviewRepository : IManagementReviewRepository
{
    private readonly IDbHelper _db;
    public ManagementReviewRepository(IDbHelper db) => _db = db;

    public Task<IEnumerable<ManagementReviewDto>> ListAsync() =>
        _db.QueryAsync<ManagementReviewDto>("SELECT * FROM management_reviews WHERE deleted_at IS NULL ORDER BY review_date DESC");

    public Task<ManagementReviewDto?> GetAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<ManagementReviewDto>("SELECT * FROM management_reviews WHERE id=@id AND deleted_at IS NULL", new { id });

    public async Task<string> CreateAsync(string id, string title, DateTime? reviewDate, string? chairperson, string? location, string? status, string? agenda, string? minutes, string? createdBy, string dataJson)
    {
        await _db.ExecuteAsync(@"INSERT INTO management_reviews (id,title,review_date,chairperson,location,status,agenda,minutes,created_by,data)
            VALUES (@id,@title,@reviewDate,@chairperson,@location,@status,@agenda,@minutes,@createdBy,@dataJson::jsonb)",
            new { id, title, reviewDate, chairperson, location, status, agenda, minutes, createdBy, dataJson });
        return id;
    }

    public Task<bool> ExistsAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<bool>("SELECT EXISTS(SELECT 1 FROM management_reviews WHERE id=@id AND deleted_at IS NULL)", new { id });

    public Task UpdateAsync(string id, string title, DateTime? reviewDate, string? chairperson, string? location, string? status, string? agenda, string? minutes, string dataJson) =>
        _db.ExecuteAsync(@"UPDATE management_reviews SET title=@title,review_date=@reviewDate,chairperson=@chairperson,location=@location,status=@status,agenda=@agenda,minutes=@minutes,data=@dataJson::jsonb,updated_at=NOW() WHERE id=@id",
            new { id, title, reviewDate, chairperson, location, status, agenda, minutes, dataJson });

    public Task SoftDeleteAsync(string id) =>
        _db.ExecuteAsync("UPDATE management_reviews SET deleted_at=NOW() WHERE id=@id", new { id });

    public Task<IEnumerable<MrActionItemDto>> ListActionItemsAsync(string reviewId) =>
        _db.QueryAsync<MrActionItemDto>("SELECT * FROM mr_action_items WHERE review_id=@reviewId ORDER BY created_at", new { reviewId });

    public async Task<string> CreateActionItemAsync(string id, string reviewId, string? description, string? assignedTo, DateTime? dueDate, string? priority, string? status)
    {
        await _db.ExecuteAsync("INSERT INTO mr_action_items (id,review_id,description,assigned_to,due_date,priority,status) VALUES (@id,@reviewId,@description,@assignedTo,@dueDate,@priority,@status)",
            new { id, reviewId, description, assignedTo, dueDate, priority, status });
        return id;
    }

    public Task UpdateActionItemAsync(string id, string? description, string? assignedTo, DateTime? dueDate, string? priority, string? status) =>
        _db.ExecuteAsync("UPDATE mr_action_items SET description=@description,assigned_to=@assignedTo,due_date=@dueDate,priority=@priority,status=@status,updated_at=NOW() WHERE id=@id",
            new { id, description, assignedTo, dueDate, priority, status });

    public Task DeleteActionItemAsync(string id) =>
        _db.ExecuteAsync("DELETE FROM mr_action_items WHERE id=@id", new { id });
}
