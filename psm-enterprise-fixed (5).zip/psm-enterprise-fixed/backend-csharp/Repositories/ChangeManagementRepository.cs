using Npgsql;
using NpgsqlTypes;
using PSM.Api.Data;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;
public interface IChangeManagementRepository
{
    Task<string> CreateChangeRequestAsync(CreateChangeRequestDto dto, string userId);
    Task<ChangeRequestDto> GetChangeRequestAsync(string changeId);
    Task<List<ChangeRequestDto>> GetChangeRequestsAsync(ChangeRequestFilterDto filter);
    Task UpdateChangeRequestAsync(string changeId, Dictionary<string, object> updates);
    Task<List<ChangeWorkflowStageDto>> GetWorkflowStagesAsync(string changeId);
    Task<ChangeWorkflowStageDto> GetWorkflowStageAsync(string stageId);
    Task<string> CreateWorkflowStageAsync(string changeId, string stageName);
    Task UpdateWorkflowStageAsync(string stageId, UpdateWorkflowStageDto dto);
    Task<List<ChangeStageActionDto>> GetStageActionsAsync(string stageId);
    Task<string> CreateStageActionAsync(CreateStageActionDto dto);
    Task CompleteActionAsync(string actionId, string notes, string completedBy);
    Task LinkHazopAsync(string changeId, string hazopId, string userId);
    Task LinkLopaAsync(string changeId, string lopaId, string userId);
    Task<List<ChangeHazopMappingDto>> GetLinkedHaZopAsync(string changeId);
    Task<List<ChangeLopaMappingDto>> GetLinkedLopaAsync(string changeId);
    Task<string> CreateTrainingRecordAsync(CreateTrainingRecordDto dto);
    Task CompleteTrainingAsync(string trainingId, string certificateUrl, string notes);
    Task<List<TrainingRecordDto>> GetTrainingRecordsAsync(string changeId);
    Task CreatePssrChecklistAsync(string changeId, string pssrItem, string category);
    Task<List<PssrChecklistItemDto>> GetPssrChecklistAsync(string changeId);
    Task VerifyPssrItemAsync(string pssrItemId, string verifiedBy, string notes);
    Task<StartupGateStatusDto> GetStartupGateStatusAsync(string changeId);
    Task<bool> CheckTrainingCompleteAsync(string changeId);
    Task<bool> CheckPssrCompleteAsync(string changeId);
    Task<bool> CheckHazopActionsClosedAsync(string changeId);
    Task<bool> CheckLopaActionsClosedAsync(string changeId);
    Task ApproveStartupAsync(string changeId, string approvedBy, string comment);
    Task RejectStartupAsync(string changeId, string rejectionReason);
    Task<ChangeDashboardMetricsDto> GetDashboardMetricsAsync();
    Task<List<WorkflowAuditDto>> GetAuditHistoryAsync(string changeId);
    Task RecordAuditLogAsync(string changeId, string action, string fromStage, string toStage, string userId, string comment);
    Task<List<ChangeNotificationDto>> GetNotificationsAsync(string userId, bool unreadOnly = false);
    Task CreateNotificationAsync(string changeId, string notificationType, string title, string message, string recipient);
    Task MarkNotificationAsReadAsync(string notificationId);
}

public class ChangeManagementRepository : IChangeManagementRepository
{
    private readonly IDbConnectionFactory _connectionFactory;

    public ChangeManagementRepository(IDbConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<string> CreateChangeRequestAsync(CreateChangeRequestDto dto, string userId)
    {
        var changeId = Guid.NewGuid().ToString();
        var requestNumber = $"CHG-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid().ToString().Substring(0, 6).ToUpper()}";

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO change_requests (id, request_number, title, description, psi_id, change_type, 
                        priority, impact_area, equipment_ids, requested_by, target_date)
                    VALUES (@id, @request_number, @title, @description, @psi_id, @change_type, 
                        @priority, @impact_area, @equipment_ids, @requested_by, @target_date)";

                cmd.Parameters.AddWithValue("@id", changeId);
                cmd.Parameters.AddWithValue("@request_number", requestNumber);
                cmd.Parameters.AddWithValue("@title", dto.Title);
                cmd.Parameters.AddWithValue("@description", dto.Description ?? "");
                cmd.Parameters.AddWithValue("@psi_id", dto.PsiId ?? "");
                cmd.Parameters.AddWithValue("@change_type", dto.ChangeType ?? "Major");
                cmd.Parameters.AddWithValue("@priority", dto.Priority ?? "Medium");
                cmd.Parameters.AddWithValue("@impact_area", (NpgsqlDbType.Array | NpgsqlDbType.Text), dto.ImpactArea.ToArray());
                cmd.Parameters.AddWithValue("@equipment_ids", (NpgsqlDbType.Array | NpgsqlDbType.Text), dto.EquipmentIds.ToArray());
                cmd.Parameters.AddWithValue("@requested_by", userId);
                cmd.Parameters.AddWithValue("@target_date", dto.TargetDate.HasValue ? (object)dto.TargetDate : DBNull.Value);

                await cmd.ExecuteNonQueryAsync();
            }

            // Create initial workflow stages
            string[] stages = { "PSI_Change", "MOC", "HAZOP_Review", "LOPA_Review", "Procedure_Update", "Training", "PSSR", "Startup_Approval" };
            foreach (var stage in stages)
            {
                await CreateWorkflowStageAsync(changeId, stage);
            }
        }

        return changeId;
    }

    public async Task<ChangeRequestDto> GetChangeRequestAsync(string changeId)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT id, request_number, title, description, psi_id, change_type, priority, 
                           impact_area, equipment_ids, requested_by, requested_at, target_date, 
                           created_at, updated_at
                    FROM change_requests WHERE id = @id";

                cmd.Parameters.AddWithValue("@id", changeId);

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                    {
                        var dto = new ChangeRequestDto
                        {
                            Id = reader.GetString(0),
                            RequestNumber = reader.GetString(1),
                            Title = reader.GetString(2),
                            Description = reader.GetString(3),
                            PsiId = reader.GetString(4),
                            ChangeType = reader.GetString(5),
                            Priority = reader.GetString(6),
                            ImpactArea = new List<string>((string[])reader.GetValue(7)),
                            EquipmentIds = new List<string>((string[])reader.GetValue(8)),
                            RequestedBy = reader.GetString(9),
                            RequestedAt = reader.GetDateTime(10),
                            TargetDate = reader.IsDBNull(11) ? null : reader.GetDateTime(11),
                            CreatedAt = reader.GetDateTime(12),
                            UpdatedAt = reader.GetDateTime(13)
                        };

                        // Get workflow stages
                        dto.Stages = await GetWorkflowStagesAsync(changeId);
                        if (dto.Stages.Count > 0)
                        {
                            var completedStage = dto.Stages.LastOrDefault(s => s.StageStatus == "Completed");
                            var inProgressStage = dto.Stages.FirstOrDefault(s => s.StageStatus == "In_Progress");
                            dto.CurrentStage = (inProgressStage ?? completedStage ?? dto.Stages.FirstOrDefault())?.StageName;
                        }

                        return dto;
                    }
                }
            }
        }

        return null;
    }

    public async Task<List<ChangeRequestDto>> GetChangeRequestsAsync(ChangeRequestFilterDto filter)
    {
        var changes = new List<ChangeRequestDto>();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                var sql = @"
                    SELECT id, request_number, title, description, psi_id, change_type, priority, 
                           impact_area, equipment_ids, requested_by, requested_at, target_date, 
                           created_at, updated_at
                    FROM change_requests
                    WHERE 1=1";

                if (!string.IsNullOrEmpty(filter.ChangeType))
                    sql += " AND change_type = @change_type";
                if (!string.IsNullOrEmpty(filter.Priority))
                    sql += " AND priority = @priority";
                if (filter.FromDate.HasValue)
                    sql += " AND requested_at >= @from_date";
                if (filter.ToDate.HasValue)
                    sql += " AND requested_at <= @to_date";

                sql += " ORDER BY requested_at DESC LIMIT @limit OFFSET @offset";

                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@limit", filter.PageSize);
                cmd.Parameters.AddWithValue("@offset", (filter.PageNumber - 1) * filter.PageSize);

                if (!string.IsNullOrEmpty(filter.ChangeType))
                    cmd.Parameters.AddWithValue("@change_type", filter.ChangeType);
                if (!string.IsNullOrEmpty(filter.Priority))
                    cmd.Parameters.AddWithValue("@priority", filter.Priority);
                if (filter.FromDate.HasValue)
                    cmd.Parameters.AddWithValue("@from_date", filter.FromDate);
                if (filter.ToDate.HasValue)
                    cmd.Parameters.AddWithValue("@to_date", filter.ToDate);

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        changes.Add(new ChangeRequestDto
                        {
                            Id = reader.GetString(0),
                            RequestNumber = reader.GetString(1),
                            Title = reader.GetString(2),
                            Description = reader.GetString(3),
                            PsiId = reader.GetString(4),
                            ChangeType = reader.GetString(5),
                            Priority = reader.GetString(6),
                            ImpactArea = new List<string>((string[])reader.GetValue(7)),
                            EquipmentIds = new List<string>((string[])reader.GetValue(8)),
                            RequestedBy = reader.GetString(9),
                            RequestedAt = reader.GetDateTime(10),
                            TargetDate = reader.IsDBNull(11) ? null : reader.GetDateTime(11),
                            CreatedAt = reader.GetDateTime(12),
                            UpdatedAt = reader.GetDateTime(13)
                        });
                    }
                }
            }
        }

        return changes;
    }

    public async Task UpdateChangeRequestAsync(string changeId, Dictionary<string, object> updates)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                var setParts = new List<string>();
                foreach (var kvp in updates)
                {
                    setParts.Add($"{kvp.Key} = @{kvp.Key}");
                    cmd.Parameters.AddWithValue($"@{kvp.Key}", kvp.Value ?? DBNull.Value);
                }

                cmd.CommandText = $@"UPDATE change_requests SET {string.Join(", ", setParts)}, updated_at = NOW() WHERE id = @id";
                cmd.Parameters.AddWithValue("@id", changeId);

                await cmd.ExecuteNonQueryAsync();
            }
        }
    }

    public async Task<List<ChangeWorkflowStageDto>> GetWorkflowStagesAsync(string changeId)
    {
        var stages = new List<ChangeWorkflowStageDto>();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT id, change_id, stage_name, stage_status, started_at, completed_at, 
                           assigned_to, notes, metadata
                    FROM change_workflow_stages
                    WHERE change_id = @change_id
                    ORDER BY created_at ASC";

                cmd.Parameters.AddWithValue("@change_id", changeId);

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        stages.Add(new ChangeWorkflowStageDto
                        {
                            Id = reader.GetString(0),
                            ChangeId = reader.GetString(1),
                            StageName = reader.GetString(2),
                            StageStatus = reader.GetString(3),
                            StartedAt = reader.IsDBNull(4) ? null : reader.GetDateTime(4),
                            CompletedAt = reader.IsDBNull(5) ? null : reader.GetDateTime(5),
                            AssignedTo = reader.IsDBNull(6) ? null : reader.GetString(6),
                            Notes = reader.IsDBNull(7) ? null : reader.GetString(7)
                        });
                    }
                }
            }
        }

        // Load actions for each stage
        foreach (var stage in stages)
        {
            stage.Actions = await GetStageActionsAsync(stage.Id);
        }

        return stages;
    }

    public async Task<ChangeWorkflowStageDto> GetWorkflowStageAsync(string stageId)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT id, change_id, stage_name, stage_status, started_at, completed_at, 
                           assigned_to, notes, metadata
                    FROM change_workflow_stages WHERE id = @id";

                cmd.Parameters.AddWithValue("@id", stageId);

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                    {
                        return new ChangeWorkflowStageDto
                        {
                            Id = reader.GetString(0),
                            ChangeId = reader.GetString(1),
                            StageName = reader.GetString(2),
                            StageStatus = reader.GetString(3),
                            StartedAt = reader.IsDBNull(4) ? null : reader.GetDateTime(4),
                            CompletedAt = reader.IsDBNull(5) ? null : reader.GetDateTime(5),
                            AssignedTo = reader.IsDBNull(6) ? null : reader.GetString(6),
                            Notes = reader.IsDBNull(7) ? null : reader.GetString(7)
                        };
                    }
                }
            }
        }

        return null;
    }

    public async Task<string> CreateWorkflowStageAsync(string changeId, string stageName)
    {
        var stageId = Guid.NewGuid().ToString();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO change_workflow_stages (id, change_id, stage_name, stage_status)
                    VALUES (@id, @change_id, @stage_name, 'Pending')
                    ON CONFLICT (change_id, stage_name) DO NOTHING";

                cmd.Parameters.AddWithValue("@id", stageId);
                cmd.Parameters.AddWithValue("@change_id", changeId);
                cmd.Parameters.AddWithValue("@stage_name", stageName);

                await cmd.ExecuteNonQueryAsync();
            }
        }

        return stageId;
    }

    public async Task UpdateWorkflowStageAsync(string stageId, UpdateWorkflowStageDto dto)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                var updates = new List<string>();
                
                if (!string.IsNullOrEmpty(dto.StageStatus))
                {
                    updates.Add("stage_status = @stage_status");
                    cmd.Parameters.AddWithValue("@stage_status", dto.StageStatus);
                    
                    if (dto.StageStatus == "In_Progress")
                        updates.Add("started_at = NOW()");
                    else if (dto.StageStatus == "Completed")
                        updates.Add("completed_at = NOW()");
                }

                if (!string.IsNullOrEmpty(dto.AssignedTo))
                {
                    updates.Add("assigned_to = @assigned_to");
                    cmd.Parameters.AddWithValue("@assigned_to", dto.AssignedTo);
                }

                if (!string.IsNullOrEmpty(dto.Notes))
                {
                    updates.Add("notes = @notes");
                    cmd.Parameters.AddWithValue("@notes", dto.Notes);
                }

                if (updates.Count == 0) return;

                updates.Add("updated_at = NOW()");
                cmd.CommandText = $@"UPDATE change_workflow_stages SET {string.Join(", ", updates)} WHERE id = @id";
                cmd.Parameters.AddWithValue("@id", stageId);

                await cmd.ExecuteNonQueryAsync();
            }
        }
    }

    public async Task<List<ChangeStageActionDto>> GetStageActionsAsync(string stageId)
    {
        var actions = new List<ChangeStageActionDto>();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT id, stage_id, action_item, action_type, is_open, assigned_to, due_date, 
                           completed_at, completed_by, notes
                    FROM change_stage_actions
                    WHERE stage_id = @stage_id
                    ORDER BY created_at ASC";

                cmd.Parameters.AddWithValue("@stage_id", stageId);

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        actions.Add(new ChangeStageActionDto
                        {
                            Id = reader.GetString(0),
                            StageId = reader.GetString(1),
                            ActionItem = reader.GetString(2),
                            ActionType = reader.GetString(3),
                            IsOpen = reader.GetBoolean(4),
                            AssignedTo = reader.IsDBNull(5) ? null : reader.GetString(5),
                            DueDate = reader.IsDBNull(6) ? null : reader.GetDateTime(6),
                            CompletedAt = reader.IsDBNull(7) ? null : reader.GetDateTime(7),
                            CompletedBy = reader.IsDBNull(8) ? null : reader.GetString(8),
                            Notes = reader.IsDBNull(9) ? null : reader.GetString(9)
                        });
                    }
                }
            }
        }

        return actions;
    }

    public async Task<string> CreateStageActionAsync(CreateStageActionDto dto)
    {
        var actionId = Guid.NewGuid().ToString();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO change_stage_actions (id, stage_id, action_item, action_type, assigned_to, due_date, notes)
                    VALUES (@id, @stage_id, @action_item, @action_type, @assigned_to, @due_date, @notes)";

                cmd.Parameters.AddWithValue("@id", actionId);
                cmd.Parameters.AddWithValue("@stage_id", dto.StageId);
                cmd.Parameters.AddWithValue("@action_item", dto.ActionItem);
                cmd.Parameters.AddWithValue("@action_type", dto.ActionType);
                cmd.Parameters.AddWithValue("@assigned_to", dto.AssignedTo ?? "");
                cmd.Parameters.AddWithValue("@due_date", dto.DueDate.HasValue ? (object)dto.DueDate : DBNull.Value);
                cmd.Parameters.AddWithValue("@notes", dto.Notes ?? "");

                await cmd.ExecuteNonQueryAsync();
            }
        }

        return actionId;
    }

    public async Task CompleteActionAsync(string actionId, string notes, string completedBy)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    UPDATE change_stage_actions 
                    SET is_open = false, completed_at = NOW(), completed_by = @completed_by, notes = @notes, updated_at = NOW()
                    WHERE id = @id";

                cmd.Parameters.AddWithValue("@id", actionId);
                cmd.Parameters.AddWithValue("@completed_by", completedBy);
                cmd.Parameters.AddWithValue("@notes", notes ?? "");

                await cmd.ExecuteNonQueryAsync();
            }
        }
    }

    public async Task LinkHazopAsync(string changeId, string hazopId, string userId)
    {
        var mappingId = Guid.NewGuid().ToString();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO change_hazop_mapping (id, change_id, hazop_id, mapped_by)
                    VALUES (@id, @change_id, @hazop_id, @mapped_by)
                    ON CONFLICT (change_id, hazop_id) DO NOTHING";

                cmd.Parameters.AddWithValue("@id", mappingId);
                cmd.Parameters.AddWithValue("@change_id", changeId);
                cmd.Parameters.AddWithValue("@hazop_id", hazopId);
                cmd.Parameters.AddWithValue("@mapped_by", userId);

                await cmd.ExecuteNonQueryAsync();
            }
        }
    }

    public async Task LinkLopaAsync(string changeId, string lopaId, string userId)
    {
        var mappingId = Guid.NewGuid().ToString();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO change_lopa_mapping (id, change_id, lopa_id, mapped_by)
                    VALUES (@id, @change_id, @lopa_id, @mapped_by)
                    ON CONFLICT (change_id, lopa_id) DO NOTHING";

                cmd.Parameters.AddWithValue("@id", mappingId);
                cmd.Parameters.AddWithValue("@change_id", changeId);
                cmd.Parameters.AddWithValue("@lopa_id", lopaId);
                cmd.Parameters.AddWithValue("@mapped_by", userId);

                await cmd.ExecuteNonQueryAsync();
            }
        }
    }

    public async Task<List<ChangeHazopMappingDto>> GetLinkedHaZopAsync(string changeId)
    {
        var mappings = new List<ChangeHazopMappingDto>();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT id, change_id, hazop_id, mapped_at, mapped_by
                    FROM change_hazop_mapping
                    WHERE change_id = @change_id
                    ORDER BY mapped_at DESC";

                cmd.Parameters.AddWithValue("@change_id", changeId);

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        mappings.Add(new ChangeHazopMappingDto
                        {
                            Id = reader.GetString(0),
                            ChangeId = reader.GetString(1),
                            HazopId = reader.GetString(2),
                            MappedAt = reader.GetDateTime(3),
                            MappedBy = reader.GetString(4)
                        });
                    }
                }
            }
        }

        return mappings;
    }

    public async Task<List<ChangeLopaMappingDto>> GetLinkedLopaAsync(string changeId)
    {
        var mappings = new List<ChangeLopaMappingDto>();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT id, change_id, lopa_id, sil_determined, mapped_at, mapped_by
                    FROM change_lopa_mapping
                    WHERE change_id = @change_id
                    ORDER BY mapped_at DESC";

                cmd.Parameters.AddWithValue("@change_id", changeId);

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        mappings.Add(new ChangeLopaMappingDto
                        {
                            Id = reader.GetString(0),
                            ChangeId = reader.GetString(1),
                            LopaId = reader.GetString(2),
                            SilDetermined = reader.GetBoolean(3),
                            MappedAt = reader.GetDateTime(4),
                            MappedBy = reader.GetString(5)
                        });
                    }
                }
            }
        }

        return mappings;
    }

    public async Task<string> CreateTrainingRecordAsync(CreateTrainingRecordDto dto)
    {
        var trainingId = Guid.NewGuid().ToString();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO change_training_records (id, change_id, user_id, training_date)
                    VALUES (@id, @change_id, @user_id, @training_date)";

                cmd.Parameters.AddWithValue("@id", trainingId);
                cmd.Parameters.AddWithValue("@change_id", dto.ChangeId);
                cmd.Parameters.AddWithValue("@user_id", dto.UserId);
                cmd.Parameters.AddWithValue("@training_date", dto.TrainingDate);

                await cmd.ExecuteNonQueryAsync();
            }
        }

        return trainingId;
    }

    public async Task CompleteTrainingAsync(string trainingId, string certificateUrl, string notes)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    UPDATE change_training_records 
                    SET completed = true, completion_date = NOW(), certificate_url = @certificate_url, notes = @notes
                    WHERE id = @id";

                cmd.Parameters.AddWithValue("@id", trainingId);
                cmd.Parameters.AddWithValue("@certificate_url", certificateUrl ?? "");
                cmd.Parameters.AddWithValue("@notes", notes ?? "");

                await cmd.ExecuteNonQueryAsync();
            }
        }
    }

    public async Task<List<TrainingRecordDto>> GetTrainingRecordsAsync(string changeId)
    {
        var records = new List<TrainingRecordDto>();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT id, change_id, user_id, training_date, completed, completion_date, certificate_url, notes
                    FROM change_training_records
                    WHERE change_id = @change_id
                    ORDER BY training_date DESC";

                cmd.Parameters.AddWithValue("@change_id", changeId);

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        records.Add(new TrainingRecordDto
                        {
                            Id = reader.GetString(0),
                            ChangeId = reader.GetString(1),
                            UserId = reader.GetString(2),
                            TrainingDate = reader.GetDateTime(3),
                            Completed = reader.GetBoolean(4),
                            CompletionDate = reader.IsDBNull(5) ? null : reader.GetDateTime(5),
                            CertificateUrl = reader.IsDBNull(6) ? null : reader.GetString(6),
                            Notes = reader.IsDBNull(7) ? null : reader.GetString(7)
                        });
                    }
                }
            }
        }

        return records;
    }

    public async Task CreatePssrChecklistAsync(string changeId, string pssrItem, string category)
    {
        var itemId = Guid.NewGuid().ToString();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO change_pssr_checklist (id, change_id, pssr_item, item_category)
                    VALUES (@id, @change_id, @pssr_item, @item_category)";

                cmd.Parameters.AddWithValue("@id", itemId);
                cmd.Parameters.AddWithValue("@change_id", changeId);
                cmd.Parameters.AddWithValue("@pssr_item", pssrItem);
                cmd.Parameters.AddWithValue("@item_category", category);

                await cmd.ExecuteNonQueryAsync();
            }
        }
    }

    public async Task<List<PssrChecklistItemDto>> GetPssrChecklistAsync(string changeId)
    {
        var items = new List<PssrChecklistItemDto>();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT id, change_id, pssr_item, item_category, is_verified, verified_by, verified_at, verification_notes
                    FROM change_pssr_checklist
                    WHERE change_id = @change_id
                    ORDER BY item_category, created_at";

                cmd.Parameters.AddWithValue("@change_id", changeId);

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        items.Add(new PssrChecklistItemDto
                        {
                            Id = reader.GetString(0),
                            ChangeId = reader.GetString(1),
                            PssrItem = reader.GetString(2),
                            ItemCategory = reader.GetString(3),
                            IsVerified = reader.GetBoolean(4),
                            VerifiedBy = reader.IsDBNull(5) ? null : reader.GetString(5),
                            VerifiedAt = reader.IsDBNull(6) ? null : reader.GetDateTime(6),
                            VerificationNotes = reader.IsDBNull(7) ? null : reader.GetString(7)
                        });
                    }
                }
            }
        }

        return items;
    }

    public async Task VerifyPssrItemAsync(string pssrItemId, string verifiedBy, string notes)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    UPDATE change_pssr_checklist 
                    SET is_verified = true, verified_by = @verified_by, verified_at = NOW(), 
                        verification_notes = @notes, updated_at = NOW()
                    WHERE id = @id";

                cmd.Parameters.AddWithValue("@id", pssrItemId);
                cmd.Parameters.AddWithValue("@verified_by", verifiedBy);
                cmd.Parameters.AddWithValue("@notes", notes ?? "");

                await cmd.ExecuteNonQueryAsync();
            }
        }
    }

    public async Task<StartupGateStatusDto> GetStartupGateStatusAsync(string changeId)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT id, change_id, training_complete, pssr_complete, hazop_actions_closed, 
                           lopa_actions_closed, can_startup, approval_status, approved_by, approved_at, rejection_reason
                    FROM change_startup_gates WHERE change_id = @change_id";

                cmd.Parameters.AddWithValue("@change_id", changeId);

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                    {
                        var gate = new StartupGateStatusDto
                        {
                            Id = reader.GetString(0),
                            ChangeId = reader.GetString(1),
                            TrainingComplete = reader.GetBoolean(2),
                            PssrComplete = reader.GetBoolean(3),
                            HazopActionsClosed = reader.GetBoolean(4),
                            LopaActionsClosed = reader.GetBoolean(5),
                            CanStartup = reader.GetBoolean(6),
                            ApprovalStatus = reader.GetString(7),
                            ApprovedBy = reader.IsDBNull(8) ? null : reader.GetString(8),
                            ApprovedAt = reader.IsDBNull(9) ? null : reader.GetDateTime(9),
                            RejectionReason = reader.IsDBNull(10) ? null : reader.GetString(10)
                        };

                        // Build blocking issues list
                        if (!gate.TrainingComplete)
                            gate.BlockingIssues.Add("Training is not complete");
                        if (!gate.PssrComplete)
                            gate.BlockingIssues.Add("PSSR is not complete");
                        if (!gate.HazopActionsClosed)
                            gate.BlockingIssues.Add("HAZOP actions are still open");
                        if (!gate.LopaActionsClosed)
                            gate.BlockingIssues.Add("LOPA actions are still open");

                        return gate;
                    }
                }
            }
        }

        return null;
    }

    public async Task<bool> CheckTrainingCompleteAsync(string changeId)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT COUNT(*) as pending FROM change_training_records
                    WHERE change_id = @change_id AND completed = false";

                cmd.Parameters.AddWithValue("@change_id", changeId);

                var result = await cmd.ExecuteScalarAsync();
                var count = result != null ? (long)result : 0;
                return count == 0;
            }
        }
    }

    public async Task<bool> CheckPssrCompleteAsync(string changeId)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT COUNT(*) as pending FROM change_pssr_checklist
                    WHERE change_id = @change_id AND is_verified = false";

                cmd.Parameters.AddWithValue("@change_id", changeId);

                var result = await cmd.ExecuteScalarAsync();
                var count = result != null ? (long)result : 0;
                return count == 0;
            }
        }
    }

    public async Task<bool> CheckHazopActionsClosedAsync(string changeId)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT COUNT(*) as open_actions FROM change_stage_actions csa
                    JOIN change_workflow_stages cws ON csa.stage_id = cws.id
                    WHERE cws.change_id = @change_id AND cws.stage_name = 'HAZOP_Review' AND csa.is_open = true";

                cmd.Parameters.AddWithValue("@change_id", changeId);

                var result = await cmd.ExecuteScalarAsync();
                var count = result != null ? (long)result : 0;
                return count == 0;
            }
        }
    }

    public async Task<bool> CheckLopaActionsClosedAsync(string changeId)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT COUNT(*) as open_actions FROM change_stage_actions csa
                    JOIN change_workflow_stages cws ON csa.stage_id = cws.id
                    WHERE cws.change_id = @change_id AND cws.stage_name = 'LOPA_Review' AND csa.is_open = true";

                cmd.Parameters.AddWithValue("@change_id", changeId);

                var result = await cmd.ExecuteScalarAsync();
                var count = result != null ? (long)result : 0;
                return count == 0;
            }
        }
    }

    public async Task ApproveStartupAsync(string changeId, string approvedBy, string comment)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    UPDATE change_startup_gates 
                    SET approval_status = 'Approved', approved_by = @approved_by, approved_at = NOW()
                    WHERE change_id = @change_id";

                cmd.Parameters.AddWithValue("@change_id", changeId);
                cmd.Parameters.AddWithValue("@approved_by", approvedBy);

                await cmd.ExecuteNonQueryAsync();
            }

            // Record audit log
            await RecordAuditLogAsync(changeId, "approve_startup", "PSSR", "Startup_Approval", approvedBy, comment);
        }
    }

    public async Task RejectStartupAsync(string changeId, string rejectionReason)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    UPDATE change_startup_gates 
                    SET approval_status = 'Rejected', rejection_reason = @rejection_reason
                    WHERE change_id = @change_id";

                cmd.Parameters.AddWithValue("@change_id", changeId);
                cmd.Parameters.AddWithValue("@rejection_reason", rejectionReason);

                await cmd.ExecuteNonQueryAsync();
            }
        }
    }

    public async Task<ChangeDashboardMetricsDto> GetDashboardMetricsAsync()
    {
        var metrics = new ChangeDashboardMetricsDto();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();

            // Total and status counts
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT 
                        COUNT(*) as total,
                        COUNT(CASE WHEN change_type = 'Major' THEN 1 END) as major,
                        COUNT(CASE WHEN change_type = 'Minor' THEN 1 END) as minor,
                        COUNT(CASE WHEN priority = 'High' THEN 1 END) as high_priority,
                        COUNT(CASE WHEN priority = 'Critical' THEN 1 END) as critical
                    FROM change_requests";

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                    {
                        metrics.TotalChanges = (int)reader.GetInt64(0);
                        metrics.ChangesByType["Major"] = (int)reader.GetInt64(1);
                        metrics.ChangesByType["Minor"] = (int)reader.GetInt64(2);
                        metrics.ChangesByPriority["High"] = (int)reader.GetInt64(3);
                        metrics.ChangesByPriority["Critical"] = (int)reader.GetInt64(4);
                    }
                }
            }

            // Stage breakdown
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT stage_name, COUNT(*) as count
                    FROM change_workflow_stages
                    WHERE stage_status = 'In_Progress'
                    GROUP BY stage_name";

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        metrics.ChangesByStage[reader.GetString(0)] = (int)reader.GetInt64(1);
                    }
                }
            }
        }

        return metrics;
    }

    public async Task<List<WorkflowAuditDto>> GetAuditHistoryAsync(string changeId)
    {
        var audits = new List<WorkflowAuditDto>();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT id, change_id, action, from_stage, to_stage, performed_by, performed_at, comment, metadata
                    FROM change_audit_logs
                    WHERE change_id = @change_id
                    ORDER BY performed_at DESC";

                cmd.Parameters.AddWithValue("@change_id", changeId);

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        audits.Add(new WorkflowAuditDto
                        {
                            Id = reader.GetString(0),
                            ChangeId = reader.GetString(1),
                            Action = reader.GetString(2),
                            FromStage = reader.IsDBNull(3) ? null : reader.GetString(3),
                            ToStage = reader.IsDBNull(4) ? null : reader.GetString(4),
                            PerformedBy = reader.GetString(5),
                            PerformedAt = reader.GetDateTime(6),
                            Comment = reader.IsDBNull(7) ? null : reader.GetString(7)
                        });
                    }
                }
            }
        }

        return audits;
    }

    public async Task RecordAuditLogAsync(string changeId, string action, string fromStage, string toStage, string userId, string comment)
    {
        var auditId = Guid.NewGuid().ToString();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO change_audit_logs (id, change_id, action, from_stage, to_stage, performed_by, comment)
                    VALUES (@id, @change_id, @action, @from_stage, @to_stage, @performed_by, @comment)";

                cmd.Parameters.AddWithValue("@id", auditId);
                cmd.Parameters.AddWithValue("@change_id", changeId);
                cmd.Parameters.AddWithValue("@action", action);
                cmd.Parameters.AddWithValue("@from_stage", fromStage ?? "");
                cmd.Parameters.AddWithValue("@to_stage", toStage ?? "");
                cmd.Parameters.AddWithValue("@performed_by", userId);
                cmd.Parameters.AddWithValue("@comment", comment ?? "");

                await cmd.ExecuteNonQueryAsync();
            }
        }
    }

    public async Task<List<ChangeNotificationDto>> GetNotificationsAsync(string userId, bool unreadOnly = false)
    {
        var notifications = new List<ChangeNotificationDto>();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                var sql = @"
                    SELECT id, change_id, notification_type, title, message, recipient, is_read, created_at
                    FROM change_notifications
                    WHERE recipient = @recipient";

                if (unreadOnly)
                    sql += " AND is_read = false";

                sql += " ORDER BY created_at DESC LIMIT 100";

                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@recipient", userId);

                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        notifications.Add(new ChangeNotificationDto
                        {
                            Id = reader.GetString(0),
                            ChangeId = reader.GetString(1),
                            NotificationType = reader.GetString(2),
                            Title = reader.GetString(3),
                            Message = reader.GetString(4),
                            Recipient = reader.GetString(5),
                            IsRead = reader.GetBoolean(6),
                            CreatedAt = reader.GetDateTime(7)
                        });
                    }
                }
            }
        }

        return notifications;
    }

    public async Task CreateNotificationAsync(string changeId, string notificationType, string title, string message, string recipient)
    {
        var notificationId = Guid.NewGuid().ToString();

        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO change_notifications (id, change_id, notification_type, title, message, recipient)
                    VALUES (@id, @change_id, @notification_type, @title, @message, @recipient)";

                cmd.Parameters.AddWithValue("@id", notificationId);
                cmd.Parameters.AddWithValue("@change_id", changeId);
                cmd.Parameters.AddWithValue("@notification_type", notificationType);
                cmd.Parameters.AddWithValue("@title", title);
                cmd.Parameters.AddWithValue("@message", message);
                cmd.Parameters.AddWithValue("@recipient", recipient);

                await cmd.ExecuteNonQueryAsync();
            }
        }
    }

    public async Task MarkNotificationAsReadAsync(string notificationId)
    {
        using (var connection = _connectionFactory.CreateConnection())
        {
            await connection.OpenAsync();
            using (var cmd = (NpgsqlCommand)connection.CreateCommand())
            {
                cmd.CommandText = @"UPDATE change_notifications SET is_read = true WHERE id = @id";
                cmd.Parameters.AddWithValue("@id", notificationId);
                await cmd.ExecuteNonQueryAsync();
            }
        }
    }
}
