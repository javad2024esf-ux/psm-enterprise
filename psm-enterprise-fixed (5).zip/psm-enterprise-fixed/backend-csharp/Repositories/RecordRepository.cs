using PSM.Api.Data;
using PSM.Api.Models;

namespace PSM.Api.Repositories;

public interface IRecordRepository
{
    Task<(IEnumerable<dynamic> Rows, long Total)> ListAsync(
        string collection, string? unit, string? status, int limit, int offset);
    Task<dynamic?> GetByIdAsync(string id, string collection);
    Task<string> CreateAsync(string id, string collection, string? unit, string? status,
                              string dataJson, string? createdBy);
    Task UpdateAsync(string id, string? unit, string? status, string? dataJson, string updatedBy);
    Task SoftDeleteAsync(string id, string deletedBy);
    Task<long> CountAsync(string collection);
    Task<IEnumerable<dynamic>> SearchAsync(string collection, string query, int limit);
}

public class RecordRepository : IRecordRepository
{
    private readonly IDbHelper _db;
    public RecordRepository(IDbHelper db) => _db = db;

    public async Task<(IEnumerable<dynamic> Rows, long Total)> ListAsync(
        string collection, string? unit, string? status, int limit, int offset)
    {
        var conditions = new List<string> { "collection = @collection", "deleted = false" };
        var parms = new Dapper.DynamicParameters();
        parms.Add("collection", collection);
        parms.Add("limit", limit);
        parms.Add("offset", offset);

        if (!string.IsNullOrEmpty(unit))
        { conditions.Add("unit = @unit"); parms.Add("unit", unit); }
        if (!string.IsNullOrEmpty(status))
        { conditions.Add("status = @status"); parms.Add("status", status); }

        var where = string.Join(" AND ", conditions);
        var sql = $@"
            SELECT id, collection, unit, status, data, created_at, updated_at, created_by,
                   COUNT(*) OVER() AS total_count
            FROM records
            WHERE {where}
            ORDER BY created_at DESC
            LIMIT @limit OFFSET @offset";

        var rows = (await _db.QueryAsync<dynamic>(sql, parms)).ToList();
        long total = rows.Count > 0 ? (long)(rows[0].total_count ?? 0L) : 0L;
        return (rows, total);
    }

    public Task<dynamic?> GetByIdAsync(string id, string collection)
    {
        if (string.IsNullOrEmpty(collection))
            return _db.QueryFirstOrDefaultAsync<dynamic>(
                "SELECT * FROM records WHERE id = @id AND deleted = false",
                new { id });

        return _db.QueryFirstOrDefaultAsync<dynamic>(
            "SELECT * FROM records WHERE id = @id AND collection = @collection AND deleted = false",
            new { id, collection });
    }

    public async Task<string> CreateAsync(string id, string collection, string? unit,
        string? status, string dataJson, string? createdBy)
    {
        await _db.ExecuteAsync(@"
            INSERT INTO records (id, collection, unit, status, data, created_at, updated_at, created_by, deleted)
            VALUES (@id, @collection, @unit, @status, @data::jsonb, NOW(), NOW(), @createdBy, false)",
            new { id, collection, unit, status, data = dataJson, createdBy });
        return id;
    }

    public Task UpdateAsync(string id, string? unit, string? status, string? dataJson, string updatedBy) =>
        _db.ExecuteAsync(@"
            UPDATE records
            SET unit       = COALESCE(@unit, unit),
                status     = COALESCE(@status, status),
                data       = COALESCE(@data::jsonb, data),
                updated_at = NOW()
            WHERE id = @id AND deleted = false",
            new { id, unit, status, data = dataJson });

    public Task SoftDeleteAsync(string id, string deletedBy) =>
        _db.ExecuteAsync(
            "UPDATE records SET deleted = true, updated_at = NOW() WHERE id = @id",
            new { id });

    public async Task<long> CountAsync(string collection)
    {
        var n = await _db.ExecuteScalarAsync<long>(
            "SELECT COUNT(*) FROM records WHERE collection = @collection AND deleted = false",
            new { collection });
        return n;
    }

    public Task<IEnumerable<dynamic>> SearchAsync(string collection, string q, int limit) =>
        _db.QueryAsync<dynamic>(@"
            SELECT id, collection, unit, status, data, created_at
            FROM records
            WHERE collection = @collection AND deleted = false
              AND search_vector @@ plainto_tsquery('simple', @q)
            ORDER BY ts_rank(search_vector, plainto_tsquery('simple', @q)) DESC
            LIMIT @limit",
            new { collection, q, limit });
}
