using Dapper;
using PSM.Api.Data;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

// ════════════════════════════════════════════════════════════════════════════
// Interface
// ════════════════════════════════════════════════════════════════════════════
public interface INotificationRepository
{
    /// <summary>Fetch a page of notifications for a user (or all if userId is null).</summary>
    Task<(IEnumerable<NotificationDto> Rows, long Total, long Unread)> ListAsync(
        string  userId,
        bool    unreadOnly,
        int     limit,
        int     offset);

    Task<NotificationDto?> GetByIdAsync(string id);

    Task<string> CreateAsync(CreateNotificationRequest req);

    /// <summary>Mark a single notification as read. Returns false when not found.</summary>
    Task<bool> MarkReadAsync(string id, string userId);

    /// <summary>Mark every unread notification for a user as read.</summary>
    Task<int> MarkAllReadAsync(string userId);

    /// <summary>Hard-delete a notification. Returns false when not found.</summary>
    Task<bool> DeleteAsync(string id, string userId);

    Task<long> UnreadCountAsync(string userId);
}

// ════════════════════════════════════════════════════════════════════════════
// Implementation
// ════════════════════════════════════════════════════════════════════════════
public class NotificationRepository : INotificationRepository
{
    private readonly IDbHelper _db;
    public NotificationRepository(IDbHelper db) => _db = db;

    // ── List ─────────────────────────────────────────────────────────────────
    public async Task<(IEnumerable<NotificationDto> Rows, long Total, long Unread)> ListAsync(
        string userId, bool unreadOnly, int limit, int offset)
    {
        limit  = Math.Clamp(limit,  1, 200);
        offset = Math.Max(offset, 0);

        var where = new List<string> { "user_id = @userId" };
        if (unreadOnly) where.Add("is_read = FALSE");

        var clause = "WHERE " + string.Join(" AND ", where);

        var sql = $@"
            SELECT id, user_id, type, title, message, module, record_id,
                   is_read, created_at,
                   COUNT(*) OVER() AS total_count
            FROM   notifications
            {clause}
            ORDER  BY created_at DESC
            LIMIT  @limit OFFSET @offset";

        var rows = (await _db.QueryAsync<dynamic>(sql, new { userId, limit, offset })).ToList();

        long total = rows.Count > 0 ? (long)(rows[0].total_count ?? 0L) : 0L;

        var dtos = rows.Select(r => new NotificationDto
        {
            Id        = (string)r.id,
            UserId    = (string?)r.user_id,
            Type      = (string?)r.type,
            Title     = (string?)r.title,
            Message   = (string?)r.message,
            Module    = (string?)r.module,
            RecordId  = (string?)r.record_id,
            IsRead    = (bool)r.is_read,
            CreatedAt = (DateTime)r.created_at,
        });

        long unread = await UnreadCountAsync(userId);
        return (dtos, total, unread);
    }

    // ── Get by ID ─────────────────────────────────────────────────────────────
    public Task<NotificationDto?> GetByIdAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<NotificationDto>(
            @"SELECT id, user_id, type, title, message, module, record_id, is_read, created_at
              FROM   notifications
              WHERE  id = @id",
            new { id });

    // ── Create ────────────────────────────────────────────────────────────────
    public async Task<string> CreateAsync(CreateNotificationRequest req)
    {
        var id = $"notif_{Guid.NewGuid():N}"[..24];
        await _db.ExecuteAsync(@"
            INSERT INTO notifications (id, user_id, type, title, message, module, record_id, is_read, created_at)
            VALUES (@id, @userId, @type, @title, @message, @module, @recordId, FALSE, NOW())",
            new
            {
                id,
                userId   = req.UserId,
                type     = req.Type,
                title    = req.Title,
                message  = req.Message,
                module   = req.Module,
                recordId = req.RecordId,
            });
        return id;
    }

    // ── Mark one read ─────────────────────────────────────────────────────────
    public async Task<bool> MarkReadAsync(string id, string userId)
    {
        // Allow admin to mark any notification; regular users only their own
        var n = await _db.ExecuteAsync(@"
            UPDATE notifications
            SET    is_read = TRUE
            WHERE  id = @id AND (user_id = @userId OR @userId = 'admin')",
            new { id, userId });
        return n > 0;
    }

    // ── Mark all read ─────────────────────────────────────────────────────────
    public Task<int> MarkAllReadAsync(string userId) =>
        _db.ExecuteAsync(@"
            UPDATE notifications
            SET    is_read = TRUE
            WHERE  user_id = @userId AND is_read = FALSE",
            new { userId });

    // ── Delete ────────────────────────────────────────────────────────────────
    public async Task<bool> DeleteAsync(string id, string userId)
    {
        var n = await _db.ExecuteAsync(@"
            DELETE FROM notifications
            WHERE  id = @id AND (user_id = @userId OR @userId = 'admin')",
            new { id, userId });
        return n > 0;
    }

    // ── Unread count ─────────────────────────────────────────────────────────
    public async Task<long> UnreadCountAsync(string userId)
    {
        var n = await _db.ExecuteScalarAsync<long?>(
            "SELECT COUNT(1) FROM notifications WHERE user_id = @userId AND is_read = FALSE",
            new { userId });
        return n ?? 0L;
    }
}
