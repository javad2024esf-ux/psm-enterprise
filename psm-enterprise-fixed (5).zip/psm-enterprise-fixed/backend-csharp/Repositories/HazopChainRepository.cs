using Dapper;
using PSM.Api.Data;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

// ════════════════════════════════════════════════════════════════════════════
// Interface
// ════════════════════════════════════════════════════════════════════════════
public interface IHazopChainRepository
{
    // ─── Causes ─────────────────────────────────────────────────────────────
    Task<IEnumerable<HazopCauseDto>>          ListCausesAsync(string deviationId);
    Task<HazopCauseDto?>                      GetCauseAsync(string id);
    Task<string>                              CreateCauseAsync(string id, string deviationId, string? studyId,
                                                  string description, string causeType, int likelihood,
                                                  string? initiatingEvent, string? frequencyBasis, string? createdBy);
    Task                                      UpdateCauseAsync(string id, string description, string causeType,
                                                  int likelihood, string? initiatingEvent, string? frequencyBasis);
    Task                                      DeleteCauseAsync(string id);

    // ─── Consequences ────────────────────────────────────────────────────────
    Task<IEnumerable<HazopConsequenceDto>>    ListConsequencesAsync(string deviationId);
    Task<HazopConsequenceDto?>                GetConsequenceAsync(string id);
    Task<string>                              CreateConsequenceAsync(string id, string deviationId, string? studyId,
                                                  string description, string category, int severity,
                                                  string? affectedPopulation, bool credible, string? createdBy);
    Task                                      UpdateConsequenceAsync(string id, string description, string category,
                                                  int severity, string? affectedPopulation, bool credible);
    Task                                      DeleteConsequenceAsync(string id);

    // ─── Safeguards ──────────────────────────────────────────────────────────
    Task<IEnumerable<HazopSafeguardDto>>      ListSafeguardsAsync(string deviationId);
    Task<HazopSafeguardDto?>                  GetSafeguardAsync(string id);
    Task<string>                              CreateSafeguardAsync(string id, string deviationId, string? studyId,
                                                  string description, string type, bool iplCredited,
                                                  decimal? pfd, string? tagNumber, string status, string? createdBy);
    Task                                      UpdateSafeguardAsync(string id, string description, string type,
                                                  bool iplCredited, decimal? pfd, string? tagNumber, string status);
    Task                                      DeleteSafeguardAsync(string id);

    // ─── Recommendations (extended) ──────────────────────────────────────────
    Task<IEnumerable<HazopRecommendationDto>> ListRecommendationsAsync(string studyId);
    Task<IEnumerable<HazopRecommendationDto>> ListRecommendationsByDeviationAsync(string deviationId);
    Task<HazopRecommendationDto?>             GetRecommendationAsync(string id);
    Task<string>                              CreateRecommendationAsync(string id, string studyId, string deviationId,
                                                  string? nodeId, string text, string? owner, string priority,
                                                  DateTime? dueDate, string? remarks, string? createdBy);
    Task                                      UpdateRecommendationAsync(string id, string text, string? owner,
                                                  string priority, DateTime? dueDate, string status,
                                                  string approvalStatus, string? approver,
                                                  string? closureEvidence, DateTime? closureDate, string? remarks);
    Task                                      LinkRecommendationToActionAsync(string recommendationId, string actionId);
    Task                                      DeleteRecommendationAsync(string id);

    // ─── Actions (HAZOP-specific) ─────────────────────────────────────────────
    Task<IEnumerable<HazopActionDto>>         ListActionsAsync(string studyId);
    Task<IEnumerable<HazopActionDto>>         ListActionsByDeviationAsync(string deviationId);
    Task<HazopActionDto?>                     GetActionAsync(string id);
    Task<string>                              CreateActionAsync(string id, string studyId, string deviationId,
                                                  string? recommendationId, string? actionRegisterRef,
                                                  string title, string description, string? responsible,
                                                  DateTime? dueDate, string priority, string? createdBy);
    Task                                      UpdateActionStatusAsync(string id, string status,
                                                  DateTime? completedDate, string? verifiedBy, string? verificationNote);
    Task                                      DeleteActionAsync(string id);

    // ─── Workflow ────────────────────────────────────────────────────────────
    Task<HazopWorkflowInstanceDto?>           GetWorkflowInstanceAsync(string entityType, string entityId);
    Task<HazopWorkflowInstanceDto>            StartWorkflowAsync(string instanceId, string entityType, string entityId,
                                                  string? studyId, string? assignedTo, string? assignedRole,
                                                  string? priority, DateTime? dueDate, string? createdBy);
    Task<HazopWorkflowInstanceDto?>           TransitionWorkflowAsync(string entityType, string entityId,
                                                  string action, string toState, string actorId, string actorName, string? comment);
    Task<IEnumerable<HazopWorkflowHistoryDto>> GetWorkflowHistoryAsync(string entityType, string entityId);
    Task<IEnumerable<HazopWorkflowInstanceDto>> ListPendingWorkflowsAsync(string? assignedTo = null);

    // ─── Notifications ───────────────────────────────────────────────────────
    Task<string>                              CreateNotificationAsync(string id, string? studyId, string? entityType,
                                                  string? entityId, string recipientId, string type,
                                                  string title, string? body, string? priority);
    Task<IEnumerable<HazopNotificationDto>>   ListNotificationsAsync(string recipientId, bool unreadOnly = false);
    Task                                      MarkNotificationReadAsync(string id);
    Task                                      MarkAllReadAsync(string recipientId);

    // ─── Audit Trail ─────────────────────────────────────────────────────────
    Task                                      LogAuditAsync(string id, string? studyId, string entityType,
                                                  string entityId, string action, string? actorId, string? actorName,
                                                  object? oldValues, object? newValues, string? ipAddress);
    Task<IEnumerable<HazopAuditTrailDto>>     ListAuditTrailAsync(string entityType, string entityId, int limit = 50);
    Task<IEnumerable<HazopAuditTrailDto>>     ListStudyAuditTrailAsync(string studyId, int limit = 100);

    // ─── Full Chain ───────────────────────────────────────────────────────────
    Task<HazopDeviationFullChainDto?>         GetDeviationFullChainAsync(string deviationId);
    Task<HazopChainAnalyticsDto>              GetChainAnalyticsAsync(string? studyId = null);
}

// ════════════════════════════════════════════════════════════════════════════
// Implementation
// ════════════════════════════════════════════════════════════════════════════
public class HazopChainRepository : IHazopChainRepository
{
    private readonly IDbHelper _db;
    public HazopChainRepository(IDbHelper db) => _db = db;

    // ─── Causes ─────────────────────────────────────────────────────────────
    public Task<IEnumerable<HazopCauseDto>> ListCausesAsync(string deviationId) =>
        _db.QueryAsync<HazopCauseDto>(
            @"SELECT id, deviation_id, study_id, description, cause_type, likelihood,
                     initiating_event, frequency_basis, created_at, created_by
              FROM hazop_causes WHERE deviation_id=@deviationId AND deleted=false
              ORDER BY created_at",
            new { deviationId });

    public Task<HazopCauseDto?> GetCauseAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<HazopCauseDto>(
            "SELECT * FROM hazop_causes WHERE id=@id AND deleted=false", new { id });

    public async Task<string> CreateCauseAsync(string id, string deviationId, string? studyId,
        string description, string causeType, int likelihood, string? initiatingEvent,
        string? frequencyBasis, string? createdBy)
    {
        await _db.ExecuteAsync(
            @"INSERT INTO hazop_causes
                (id,deviation_id,study_id,description,cause_type,likelihood,
                 initiating_event,frequency_basis,created_by,deleted)
              VALUES
                (@id,@deviationId,@studyId,@description,@causeType,@likelihood,
                 @initiatingEvent,@frequencyBasis,@createdBy,false)",
            new { id, deviationId, studyId, description, causeType, likelihood,
                  initiatingEvent, frequencyBasis, createdBy });
        return id;
    }

    public Task UpdateCauseAsync(string id, string description, string causeType,
        int likelihood, string? initiatingEvent, string? frequencyBasis) =>
        _db.ExecuteAsync(
            @"UPDATE hazop_causes
              SET description=@description, cause_type=@causeType, likelihood=@likelihood,
                  initiating_event=@initiatingEvent, frequency_basis=@frequencyBasis, updated_at=NOW()
              WHERE id=@id AND deleted=false",
            new { id, description, causeType, likelihood, initiatingEvent, frequencyBasis });

    public Task DeleteCauseAsync(string id) =>
        _db.ExecuteAsync("UPDATE hazop_causes SET deleted=true, updated_at=NOW() WHERE id=@id", new { id });

    // ─── Consequences ────────────────────────────────────────────────────────
    public Task<IEnumerable<HazopConsequenceDto>> ListConsequencesAsync(string deviationId) =>
        _db.QueryAsync<HazopConsequenceDto>(
            @"SELECT id, deviation_id, study_id, description, consequence_category, severity,
                     affected_population, credible, created_at, created_by
              FROM hazop_consequences WHERE deviation_id=@deviationId AND deleted=false
              ORDER BY created_at",
            new { deviationId });

    public Task<HazopConsequenceDto?> GetConsequenceAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<HazopConsequenceDto>(
            "SELECT * FROM hazop_consequences WHERE id=@id AND deleted=false", new { id });

    public async Task<string> CreateConsequenceAsync(string id, string deviationId, string? studyId,
        string description, string category, int severity, string? affectedPopulation, bool credible, string? createdBy)
    {
        await _db.ExecuteAsync(
            @"INSERT INTO hazop_consequences
                (id,deviation_id,study_id,description,consequence_category,severity,
                 affected_population,credible,created_by,deleted)
              VALUES
                (@id,@deviationId,@studyId,@description,@category,@severity,
                 @affectedPopulation,@credible,@createdBy,false)",
            new { id, deviationId, studyId, description, category, severity,
                  affectedPopulation, credible, createdBy });
        return id;
    }

    public Task UpdateConsequenceAsync(string id, string description, string category,
        int severity, string? affectedPopulation, bool credible) =>
        _db.ExecuteAsync(
            @"UPDATE hazop_consequences
              SET description=@description, consequence_category=@category, severity=@severity,
                  affected_population=@affectedPopulation, credible=@credible, updated_at=NOW()
              WHERE id=@id AND deleted=false",
            new { id, description, category, severity, affectedPopulation, credible });

    public Task DeleteConsequenceAsync(string id) =>
        _db.ExecuteAsync("UPDATE hazop_consequences SET deleted=true, updated_at=NOW() WHERE id=@id", new { id });

    // ─── Safeguards ──────────────────────────────────────────────────────────
    public Task<IEnumerable<HazopSafeguardDto>> ListSafeguardsAsync(string deviationId) =>
        _db.QueryAsync<HazopSafeguardDto>(
            @"SELECT id, deviation_id, study_id, description, safeguard_type,
                     ipl_credited, pfd, tag_number, status, created_at, created_by
              FROM hazop_safeguards WHERE deviation_id=@deviationId AND deleted=false
              ORDER BY created_at",
            new { deviationId });

    public Task<HazopSafeguardDto?> GetSafeguardAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<HazopSafeguardDto>(
            "SELECT * FROM hazop_safeguards WHERE id=@id AND deleted=false", new { id });

    public async Task<string> CreateSafeguardAsync(string id, string deviationId, string? studyId,
        string description, string type, bool iplCredited, decimal? pfd, string? tagNumber, string status, string? createdBy)
    {
        await _db.ExecuteAsync(
            @"INSERT INTO hazop_safeguards
                (id,deviation_id,study_id,description,safeguard_type,ipl_credited,
                 pfd,tag_number,status,created_by,deleted)
              VALUES
                (@id,@deviationId,@studyId,@description,@type,@iplCredited,
                 @pfd,@tagNumber,@status,@createdBy,false)",
            new { id, deviationId, studyId, description, type, iplCredited, pfd, tagNumber, status, createdBy });
        return id;
    }

    public Task UpdateSafeguardAsync(string id, string description, string type,
        bool iplCredited, decimal? pfd, string? tagNumber, string status) =>
        _db.ExecuteAsync(
            @"UPDATE hazop_safeguards
              SET description=@description, safeguard_type=@type, ipl_credited=@iplCredited,
                  pfd=@pfd, tag_number=@tagNumber, status=@status, updated_at=NOW()
              WHERE id=@id AND deleted=false",
            new { id, description, type, iplCredited, pfd, tagNumber, status });

    public Task DeleteSafeguardAsync(string id) =>
        _db.ExecuteAsync("UPDATE hazop_safeguards SET deleted=true, updated_at=NOW() WHERE id=@id", new { id });

    // ─── Recommendations ─────────────────────────────────────────────────────
    public Task<IEnumerable<HazopRecommendationDto>> ListRecommendationsAsync(string studyId) =>
        _db.QueryAsync<HazopRecommendationDto>(
            @"SELECT r.id, r.study_id, r.deviation_id, r.node_id, r.recommendation_text,
                     r.owner, r.priority, r.due_date, r.status, r.approval_status,
                     r.approver, r.closure_evidence, r.closure_date, r.remarks,
                     r.created_at, r.created_by,
                     a.id AS action_id
              FROM hazop_recommendations r
              LEFT JOIN hazop_actions a ON a.recommendation_id = r.id AND a.deleted = false
              WHERE r.study_id=@studyId
              ORDER BY r.created_at DESC",
            new { studyId });

    public Task<IEnumerable<HazopRecommendationDto>> ListRecommendationsByDeviationAsync(string deviationId) =>
        _db.QueryAsync<HazopRecommendationDto>(
            @"SELECT r.*, a.id AS action_id
              FROM hazop_recommendations r
              LEFT JOIN hazop_actions a ON a.recommendation_id = r.id AND a.deleted = false
              WHERE r.deviation_id=@deviationId
              ORDER BY r.created_at",
            new { deviationId });

    public Task<HazopRecommendationDto?> GetRecommendationAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<HazopRecommendationDto>(
            "SELECT * FROM hazop_recommendations WHERE id=@id", new { id });

    public async Task<string> CreateRecommendationAsync(string id, string studyId, string deviationId,
        string? nodeId, string text, string? owner, string priority, DateTime? dueDate, string? remarks, string? createdBy)
    {
        await _db.ExecuteAsync(
            @"INSERT INTO hazop_recommendations
                (id,study_id,deviation_id,node_id,recommendation_text,owner,priority,
                 due_date,status,approval_status,remarks,created_by,created_at)
              VALUES
                (@id,@studyId,@deviationId,@nodeId,@text,@owner,@priority,
                 @dueDate,'Open','Not Submitted',@remarks,@createdBy,NOW())",
            new { id, studyId, deviationId, nodeId, text, owner, priority, dueDate, remarks, createdBy });
        return id;
    }

    public Task UpdateRecommendationAsync(string id, string text, string? owner,
        string priority, DateTime? dueDate, string status, string approvalStatus,
        string? approver, string? closureEvidence, DateTime? closureDate, string? remarks) =>
        _db.ExecuteAsync(
            @"UPDATE hazop_recommendations
              SET recommendation_text=@text, owner=@owner, priority=@priority, due_date=@dueDate,
                  status=@status, approval_status=@approvalStatus, approver=@approver,
                  closure_evidence=@closureEvidence, closure_date=@closureDate,
                  remarks=@remarks, updated_at=NOW()
              WHERE id=@id",
            new { id, text, owner, priority, dueDate, status, approvalStatus,
                  approver, closureEvidence, closureDate, remarks });

    public Task LinkRecommendationToActionAsync(string recommendationId, string actionId) =>
        _db.ExecuteAsync(
            "UPDATE hazop_actions SET recommendation_id=@recommendationId WHERE id=@actionId",
            new { recommendationId, actionId });

    public Task DeleteRecommendationAsync(string id) =>
        _db.ExecuteAsync("DELETE FROM hazop_recommendations WHERE id=@id", new { id });

    // ─── Actions ─────────────────────────────────────────────────────────────
    public Task<IEnumerable<HazopActionDto>> ListActionsAsync(string studyId) =>
        _db.QueryAsync<HazopActionDto>(
            @"SELECT id, study_id, deviation_id, recommendation_id, action_register_ref,
                     title, description, responsible, due_date, status, priority,
                     completed_date, verified_by, verification_note, created_at
              FROM hazop_actions WHERE study_id=@studyId AND deleted=false
              ORDER BY created_at DESC",
            new { studyId });

    public Task<IEnumerable<HazopActionDto>> ListActionsByDeviationAsync(string deviationId) =>
        _db.QueryAsync<HazopActionDto>(
            @"SELECT * FROM hazop_actions WHERE deviation_id=@deviationId AND deleted=false
              ORDER BY created_at",
            new { deviationId });

    public Task<HazopActionDto?> GetActionAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<HazopActionDto>(
            "SELECT * FROM hazop_actions WHERE id=@id AND deleted=false", new { id });

    public async Task<string> CreateActionAsync(string id, string studyId, string deviationId,
        string? recommendationId, string? actionRegisterRef, string title, string description,
        string? responsible, DateTime? dueDate, string priority, string? createdBy)
    {
        await _db.ExecuteAsync(
            @"INSERT INTO hazop_actions
                (id,study_id,deviation_id,recommendation_id,action_register_ref,
                 title,description,responsible,due_date,status,priority,created_at,deleted)
              VALUES
                (@id,@studyId,@deviationId,@recommendationId,@actionRegisterRef,
                 @title,@description,@responsible,@dueDate,'Open',@priority,NOW(),false)",
            new { id, studyId, deviationId, recommendationId, actionRegisterRef,
                  title, description, responsible, dueDate, priority, createdBy });
        return id;
    }

    public Task UpdateActionStatusAsync(string id, string status, DateTime? completedDate,
        string? verifiedBy, string? verificationNote) =>
        _db.ExecuteAsync(
            @"UPDATE hazop_actions
              SET status=@status, completed_date=@completedDate, verified_by=@verifiedBy,
                  verification_note=@verificationNote, updated_at=NOW()
              WHERE id=@id AND deleted=false",
            new { id, status, completedDate, verifiedBy, verificationNote });

    public Task DeleteActionAsync(string id) =>
        _db.ExecuteAsync("UPDATE hazop_actions SET deleted=true WHERE id=@id", new { id });

    // ─── Workflow ────────────────────────────────────────────────────────────
    public async Task<HazopWorkflowInstanceDto?> GetWorkflowInstanceAsync(string entityType, string entityId)
    {
        var inst = await _db.QueryFirstOrDefaultAsync<HazopWorkflowInstanceDto>(
            @"SELECT id, entity_type, entity_id, study_id, current_state, previous_state,
                     assigned_to, assigned_role, due_date, priority, comments, started_at, completed_at
              FROM hazop_workflow_instances WHERE entity_type=@entityType AND entity_id=@entityId AND deleted=false",
            new { entityType, entityId });
        if (inst is null) return null;
        inst.History = (await GetWorkflowHistoryAsync(entityType, entityId)).ToList();
        return inst;
    }

    public async Task<HazopWorkflowInstanceDto> StartWorkflowAsync(string instanceId, string entityType,
        string entityId, string? studyId, string? assignedTo, string? assignedRole,
        string? priority, DateTime? dueDate, string? createdBy)
    {
        await _db.ExecuteAsync(
            @"INSERT INTO hazop_workflow_instances
                (id,entity_type,entity_id,study_id,current_state,assigned_to,
                 assigned_role,priority,due_date,started_at,created_by,deleted)
              VALUES
                (@instanceId,@entityType,@entityId,@studyId,'Draft',@assignedTo,
                 @assignedRole,@priority,@dueDate,NOW(),@createdBy,false)
              ON CONFLICT (entity_type, entity_id) DO NOTHING",
            new { instanceId, entityType, entityId, studyId, assignedTo, assignedRole,
                  priority = priority ?? "Normal", dueDate, createdBy });

        return (await GetWorkflowInstanceAsync(entityType, entityId))!;
    }

    public async Task<HazopWorkflowInstanceDto?> TransitionWorkflowAsync(string entityType, string entityId,
        string action, string toState, string actorId, string actorName, string? comment)
    {
        var inst = await _db.QueryFirstOrDefaultAsync<dynamic>(
            "SELECT id, current_state FROM hazop_workflow_instances WHERE entity_type=@entityType AND entity_id=@entityId AND deleted=false",
            new { entityType, entityId });
        if (inst is null) return null;

        string instanceId = inst.id;
        string fromState  = inst.current_state;

        await _db.ExecuteAsync(
            @"UPDATE hazop_workflow_instances
              SET previous_state=current_state, current_state=@toState, updated_at=NOW()
              WHERE id=@instanceId",
            new { instanceId, toState });

        await _db.ExecuteAsync(
            @"INSERT INTO hazop_workflow_history
                (id,instance_id,entity_type,entity_id,from_state,to_state,action,actor_id,actor_name,comment,transitioned_at)
              VALUES
                (@histId,@instanceId,@entityType,@entityId,@fromState,@toState,@action,@actorId,@actorName,@comment,NOW())",
            new { histId = Guid.NewGuid().ToString(), instanceId, entityType, entityId,
                  fromState, toState, action, actorId, actorName, comment });

        return await GetWorkflowInstanceAsync(entityType, entityId);
    }

    public Task<IEnumerable<HazopWorkflowHistoryDto>> GetWorkflowHistoryAsync(string entityType, string entityId) =>
        _db.QueryAsync<HazopWorkflowHistoryDto>(
            @"SELECT h.id, h.instance_id, h.from_state, h.to_state, h.action,
                     h.actor_id, h.actor_name, h.comment, h.transitioned_at
              FROM hazop_workflow_history h
              JOIN hazop_workflow_instances i ON i.id=h.instance_id
              WHERE i.entity_type=@entityType AND i.entity_id=@entityId
              ORDER BY h.transitioned_at",
            new { entityType, entityId });

    public Task<IEnumerable<HazopWorkflowInstanceDto>> ListPendingWorkflowsAsync(string? assignedTo = null)
    {
        var sql = assignedTo is null
            ? @"SELECT * FROM hazop_workflow_instances
                WHERE current_state NOT IN ('Closed','Archived') AND deleted=false
                ORDER BY due_date NULLS LAST"
            : @"SELECT * FROM hazop_workflow_instances
                WHERE current_state NOT IN ('Closed','Archived') AND deleted=false
                  AND assigned_to=@assignedTo
                ORDER BY due_date NULLS LAST";
        return _db.QueryAsync<HazopWorkflowInstanceDto>(sql, new { assignedTo });
    }

    // ─── Notifications ───────────────────────────────────────────────────────
    public async Task<string> CreateNotificationAsync(string id, string? studyId, string? entityType,
        string? entityId, string recipientId, string type, string title, string? body, string? priority)
    {
        await _db.ExecuteAsync(
            @"INSERT INTO hazop_notifications
                (id,study_id,entity_type,entity_id,recipient_id,notification_type,title,body,priority,created_at)
              VALUES
                (@id,@studyId,@entityType,@entityId,@recipientId,@type,@title,@body,@priority,NOW())",
            new { id, studyId, entityType, entityId, recipientId, type, title, body,
                  priority = priority ?? "Normal" });
        return id;
    }

    public Task<IEnumerable<HazopNotificationDto>> ListNotificationsAsync(string recipientId, bool unreadOnly = false)
    {
        var sql = unreadOnly
            ? @"SELECT * FROM hazop_notifications WHERE recipient_id=@recipientId AND is_read=false ORDER BY created_at DESC LIMIT 100"
            : @"SELECT * FROM hazop_notifications WHERE recipient_id=@recipientId ORDER BY created_at DESC LIMIT 100";
        return _db.QueryAsync<HazopNotificationDto>(sql, new { recipientId });
    }

    public Task MarkNotificationReadAsync(string id) =>
        _db.ExecuteAsync("UPDATE hazop_notifications SET is_read=true, read_at=NOW() WHERE id=@id", new { id });

    public Task MarkAllReadAsync(string recipientId) =>
        _db.ExecuteAsync("UPDATE hazop_notifications SET is_read=true, read_at=NOW() WHERE recipient_id=@recipientId AND is_read=false", new { recipientId });

    // ─── Audit Trail ─────────────────────────────────────────────────────────
    public async Task LogAuditAsync(string id, string? studyId, string entityType, string entityId,
        string action, string? actorId, string? actorName, object? oldValues, object? newValues, string? ipAddress)
    {
        var oldJson = oldValues is null ? null : System.Text.Json.JsonSerializer.Serialize(oldValues);
        var newJson = newValues is null ? null : System.Text.Json.JsonSerializer.Serialize(newValues);

        await _db.ExecuteAsync(
            @"INSERT INTO hazop_audit_trail
                (id,study_id,entity_type,entity_id,action,actor_id,actor_name,
                 old_values,new_values,ip_address,occurred_at)
              VALUES
                (@id,@studyId,@entityType,@entityId,@action,@actorId,@actorName,
                 @oldJson::jsonb,@newJson::jsonb,@ipAddress,NOW())",
            new { id, studyId, entityType, entityId, action, actorId, actorName,
                  oldJson, newJson, ipAddress });
    }

    public Task<IEnumerable<HazopAuditTrailDto>> ListAuditTrailAsync(string entityType, string entityId, int limit = 50) =>
        _db.QueryAsync<HazopAuditTrailDto>(
            @"SELECT id, study_id, entity_type, entity_id, action, actor_id, actor_name,
                     old_values, new_values, occurred_at
              FROM hazop_audit_trail
              WHERE entity_type=@entityType AND entity_id=@entityId
              ORDER BY occurred_at DESC LIMIT @limit",
            new { entityType, entityId, limit });

    public Task<IEnumerable<HazopAuditTrailDto>> ListStudyAuditTrailAsync(string studyId, int limit = 100) =>
        _db.QueryAsync<HazopAuditTrailDto>(
            @"SELECT * FROM hazop_audit_trail WHERE study_id=@studyId ORDER BY occurred_at DESC LIMIT @limit",
            new { studyId, limit });

    // ─── Full Chain ───────────────────────────────────────────────────────────
    public async Task<HazopDeviationFullChainDto?> GetDeviationFullChainAsync(string deviationId)
    {
        var deviation = await _db.QueryFirstOrDefaultAsync<HazopDeviationDto>(
            "SELECT * FROM hazop_deviations WHERE id=@deviationId AND deleted=false", new { deviationId });
        if (deviation is null) return null;

        var causes          = (await ListCausesAsync(deviationId)).ToList();
        var consequences    = (await ListConsequencesAsync(deviationId)).ToList();
        var safeguards      = (await ListSafeguardsAsync(deviationId)).ToList();
        var recs            = (await ListRecommendationsByDeviationAsync(deviationId)).ToList();
        var actions         = (await ListActionsByDeviationAsync(deviationId)).ToList();
        var workflow        = await GetWorkflowInstanceAsync("deviation", deviationId);
        var audit           = (await ListAuditTrailAsync("deviation", deviationId)).ToList();

        return new HazopDeviationFullChainDto
        {
            Deviation       = deviation,
            Causes          = causes,
            Consequences    = consequences,
            Safeguards      = safeguards,
            Recommendations = recs,
            Actions         = actions,
            Workflow        = workflow,
            AuditTrail      = audit,
        };
    }

    public async Task<HazopChainAnalyticsDto> GetChainAnalyticsAsync(string? studyId = null)
    {
        var filter = studyId is not null ? "AND study_id=@studyId" : "";

        var studies = await _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(*) FROM hazop_studies WHERE deleted=false");
        var activeStudies = await _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(*) FROM hazop_studies WHERE deleted=false AND status NOT IN ('Closed','Archived')");
        var nodes = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_nodes WHERE deleted=false {filter}", new { studyId });
        var devs  = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_deviations WHERE deleted=false {filter}", new { studyId });
        var highRisk = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_deviations WHERE deleted=false AND risk_level IN ('High','Critical') {filter}", new { studyId });
        var critRisk = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_deviations WHERE deleted=false AND risk_level='Critical' {filter}", new { studyId });
        var openDevs = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_deviations WHERE deleted=false AND status!='Closed' {filter}", new { studyId });
        var causes   = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_causes WHERE deleted=false {filter}", new { studyId });
        var consequences = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_consequences WHERE deleted=false {filter}", new { studyId });
        var safeguards   = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_safeguards WHERE deleted=false {filter}", new { studyId });
        var iplSafeguards = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_safeguards WHERE deleted=false AND ipl_credited=true {filter}", new { studyId });
        var totalRecs = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_recommendations WHERE true {(studyId!=null?"AND study_id=@studyId":"")}", new { studyId });
        var openRecs  = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_recommendations WHERE status IN ('Open','In Progress') {(studyId!=null?"AND study_id=@studyId":"")}", new { studyId });
        var overdueRecs = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_recommendations WHERE status!='Closed' AND due_date < NOW() {(studyId!=null?"AND study_id=@studyId":"")}", new { studyId });
        var closedRecs  = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_recommendations WHERE status='Closed' {(studyId!=null?"AND study_id=@studyId":"")}", new { studyId });
        var totalActions = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_actions WHERE deleted=false {(studyId!=null?"AND study_id=@studyId":"")}", new { studyId });
        var openActions  = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_actions WHERE deleted=false AND status!='Closed' {(studyId!=null?"AND study_id=@studyId":"")}", new { studyId });
        var closedActions = await _db.ExecuteScalarAsync<int>(
            $"SELECT COUNT(*) FROM hazop_actions WHERE deleted=false AND status='Closed' {(studyId!=null?"AND study_id=@studyId":"")}", new { studyId });
        var wfPending = await _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(*) FROM hazop_workflow_instances WHERE current_state NOT IN ('Closed','Archived') AND deleted=false");

        double closureRate = totalRecs > 0 ? Math.Round((double)closedRecs / totalRecs * 100, 1) : 0;

        return new HazopChainAnalyticsDto
        {
            TotalStudies            = studies,
            ActiveStudies           = activeStudies,
            CompletedStudies        = studies - activeStudies,
            TotalNodes              = nodes,
            TotalDeviations         = devs,
            HighRiskDeviations      = highRisk,
            CriticalDeviations      = critRisk,
            OpenDeviations          = openDevs,
            TotalCauses             = causes,
            TotalConsequences       = consequences,
            TotalSafeguards         = safeguards,
            IplCreditedSafeguards   = iplSafeguards,
            TotalRecommendations    = totalRecs,
            OpenRecommendations     = openRecs,
            OverdueRecommendations  = overdueRecs,
            ClosedRecommendations   = closedRecs,
            TotalActions            = totalActions,
            OpenActions             = openActions,
            ClosedActions           = closedActions,
            WorkflowPending         = wfPending,
            ClosureRate             = closureRate,
            ComplianceScore         = Math.Round((double)(100 - (overdueRecs * 5)), 1),
        };
    }
}
