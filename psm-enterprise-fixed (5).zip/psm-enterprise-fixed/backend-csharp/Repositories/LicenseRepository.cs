using Dapper;
using System.Text.Json;
using PSM.Api.Data;
using PSM.Api.Models;

namespace PSM.Api.Repositories;

public interface ILicenseRepository
{
    Task<LicenseStatus?> GetActiveLicenseAsync();
    Task<bool> ActivateLicenseAsync(string licenseKey, string organization, string contactEmail, string machineId);
    Task<bool> DeactivateLicenseAsync();
    Task<List<LicenseAuditEvent>> GetAuditHistoryAsync(int limit = 100);
}

public class LicenseRepository : ILicenseRepository
{
    private readonly IDbConnectionFactory _factory;

    public LicenseRepository(IDbConnectionFactory factory)
    {
        _factory = factory;
    }

    public async Task<LicenseStatus?> GetActiveLicenseAsync()
    {
        const string sql = @"
            SELECT 
                id, license_key, organization, contact_email, machine_id,
                status, issued_at, activated_at, deactivated_at, expires_at,
                license_type, max_users, current_users, max_projects, current_projects,
                metadata, created_at, updated_at
            FROM license_activations
            WHERE status = 'active'
            ORDER BY activated_at DESC
            LIMIT 1
        ";

        using var conn = _factory.CreateConnection();
        return await conn.QueryFirstOrDefaultAsync<LicenseStatus>(sql);
    }

    public async Task<bool> ActivateLicenseAsync(
        string licenseKey, 
        string organization, 
        string contactEmail, 
        string machineId)
    {
        const string sql = @"
            INSERT INTO license_activations 
                (license_key, organization, contact_email, machine_id, 
                 status, issued_at, activated_at, license_type, metadata, created_at)
            VALUES 
                (@LicenseKey, @Organization, @ContactEmail, @MachineId,
                 'active', NOW() AT TIME ZONE 'UTC', NOW() AT TIME ZONE 'UTC', 
                 'enterprise', @Metadata::jsonb, NOW() AT TIME ZONE 'UTC')
            RETURNING id
        ";

        using var conn = _factory.CreateConnection();

        var metadata = JsonSerializer.Serialize(new
        {
            machineId,
            activationIp = "system",
            activatedBy = "license_service"
        });

        try
        {
            var id = await conn.QueryFirstOrDefaultAsync<long?>(sql, new
            {
                LicenseKey = licenseKey,
                Organization = organization,
                ContactEmail = contactEmail,
                MachineId = machineId,
                Metadata = metadata
            });
            return id.HasValue && id.Value > 0;
        }
        catch
        {
            return false;
        }
    }

    public async Task<bool> DeactivateLicenseAsync()
    {
        const string sql = @"
            UPDATE license_activations
            SET status = 'inactive', deactivated_at = NOW() AT TIME ZONE 'UTC', updated_at = NOW() AT TIME ZONE 'UTC'
            WHERE status = 'active'
        ";

        using var conn = _factory.CreateConnection();
        var affected = await conn.ExecuteAsync(sql);
        return affected > 0;
    }

    public async Task<List<LicenseAuditEvent>> GetAuditHistoryAsync(int limit = 100)
    {
        const string sql = @"
            SELECT 
                id, event_type, license_key, organization, status,
                ip_address, user_agent, timestamp, details
            FROM license_audit_events
            ORDER BY timestamp DESC
            LIMIT @Limit
        ";

        using var conn = _factory.CreateConnection();
        var results = await conn.QueryAsync<LicenseAuditEvent>(sql, new { Limit = limit });
        return results.ToList();
    }
}
