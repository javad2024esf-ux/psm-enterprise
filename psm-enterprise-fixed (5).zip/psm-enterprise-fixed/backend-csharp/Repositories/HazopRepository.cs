using Dapper;
using PSM.Api.Data;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

/// <summary>
/// Enhanced IHazopRepository interface with new methods for HAZOP → Action Register integration
/// </summary>
public interface IHazopRepository
{
    // ─── Existing Methods (Studies, Nodes, Deviations) ──────────────────────

    // Studies
    Task<IEnumerable<HazopStudyWithCountsDto>> ListStudiesAsync();
    Task<HazopStudyDto?> GetStudyAsync(string id);
    Task<string> CreateStudyAsync(string id, string title, string? facility, string? unit,
        string? leadEngineer, string? scope, string? methodology, string? status,
        DateTime? startDate, DateTime? endDate, string? createdBy, string dataJson);
    Task<bool> StudyExistsAsync(string id);
    Task UpdateStudyAsync(string id, string title, string? facility, string? unit,
        string? leadEngineer, string? scope, string? methodology, string? status,
        DateTime? startDate, DateTime? endDate, string dataJson);
    Task SoftDeleteStudyAsync(string id);

    // Nodes
    Task<IEnumerable<HazopNodeWithCountsDto>> ListNodesAsync(string studyId);
    Task<HazopNodeDto?> GetNodeAsync(string id);
    Task<string> CreateNodeAsync(string id, string studyId, string nodeNumber, string description,
        string? processLine, string? designIntent, string? pAndId);
    Task<bool> NodeExistsAsync(string id);
    Task UpdateNodeAsync(string id, string nodeNumber, string description,
        string? processLine, string? designIntent, string? pAndId);
    Task SoftDeleteNodeAsync(string id);

    // Deviations
    Task<IEnumerable<HazopDeviationDto>> ListDeviationsByStudyAsync(string studyId);
    Task<IEnumerable<HazopDeviationDto>> ListDeviationsByNodeAsync(string nodeId);
    Task<HazopDeviationDto?> GetDeviationAsync(string id);
    Task<string?> GetNodeStudyIdAsync(string nodeId);
    Task<string> CreateDeviationAsync(string id, string studyId, string nodeId, string guideWord,
        string parameter, string deviation, string? causes, string? consequences,
        string? existingSafeguards, string? recommendations, int severity, int likelihood,
        string status, string riskLevel, string dataJson);
    Task<bool> DeviationExistsAsync(string id);
    Task UpdateDeviationAsync(string id, string guideWord, string parameter, string deviation,
        string? causes, string? consequences, string? existingSafeguards, string? recommendations,
        int severity, int likelihood, string status, string riskLevel, string dataJson);
    Task SoftDeleteDeviationAsync(string id);

    // Analytics
    Task<HazopAnalyticsDto> GetAnalyticsAsync();

    // Aliases used by IntegratedRiskModelService
    Task<HazopStudyDto?> GetHazopStudyAsync(string id);
    Task<HazopDeviationDto?> GetHazopDeviationAsync(string id);
    Task<int> GetHazopStudyCountAsync();

    // ─── NEW: HAZOP → Action Register Integration Methods ──────────────────

    /// <summary>
    /// Gets a deviation with full context (study info, study title, facility, unit).
    /// Used when creating actions from HAZOP deviations to include complete context.
    /// </summary>
    Task<HazopDeviationWithContextDto?> GetDeviationWithContextAsync(string deviationId);

    /// <summary>
    /// Gets study information for a given deviation ID.
    /// Used to fetch facility, unit, and other study details when linking to actions.
    /// </summary>
    Task<HazopStudyDto?> GetStudyForDeviationAsync(string deviationId);

    /// <summary>
    /// Lists all open (non-closed) deviations for a study.
    /// Used to filter recommendations that need action items.
    /// </summary>
    Task<IEnumerable<HazopDeviationDto>> ListOpenDeviationsByStudyAsync(string studyId);

    /// <summary>
    /// Counts high-risk deviations (risk_level IN ('High', 'Critical'))
    /// Used for dashboard/analytics when tracking actions needed.
    /// </summary>
    Task<int> CountHighRiskDeviationsAsync(string? studyId = null);
}

// ════════════════════════════════════════════════════════════════════════════
// Implementation: HazopRepository (Enhanced)
// ════════════════════════════════════════════════════════════════════════════

public class HazopRepository : IHazopRepository
{
    private readonly IDbHelper _db;
    public HazopRepository(IDbHelper db) => _db = db;

    // ─── Studies ────────────────────────────────────────────────────────────
    public Task<IEnumerable<HazopStudyWithCountsDto>> ListStudiesAsync() =>
        _db.QueryAsync<HazopStudyWithCountsDto>(@"
            SELECT 
              hs.id, hs.title, hs.facility, hs.unit, hs.lead_engineer,
              hs.scope, hs.methodology, hs.status, hs.start_date,
              hs.end_date, hs.created_by, hs.created_at, hs.updated_at,
              hs.data, hs.deleted,
              (SELECT COUNT(*)::int FROM hazop_nodes n 
               WHERE n.study_id=hs.id AND n.deleted=false) AS NodeCount,
              (SELECT COUNT(*)::int FROM hazop_deviations d 
               WHERE d.study_id=hs.id AND d.deleted=false) AS DeviationCount
            FROM hazop_studies hs 
            WHERE hs.deleted=false 
            ORDER BY hs.created_at DESC");

    public Task<HazopStudyDto?> GetStudyAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<HazopStudyDto>(
            @"SELECT id, title, facility, unit, lead_engineer, scope, methodology,
                     status, start_date, end_date, created_by, created_at, updated_at,
                     data, deleted
              FROM hazop_studies WHERE id=@id AND deleted=false", 
            new { id });

    public async Task<bool> StudyExistsAsync(string id)
    {
        var n = await _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM hazop_studies WHERE id=@id AND deleted=false", new { id });
        return n > 0;
    }

    public async Task<string> CreateStudyAsync(string id, string title, string? facility, string? unit,
        string? leadEngineer, string? scope, string? methodology, string? status,
        DateTime? startDate, DateTime? endDate, string? createdBy, string dataJson)
    {
        await _db.ExecuteAsync(@"
            INSERT INTO hazop_studies
              (id,title,facility,unit,lead_engineer,scope,methodology,status,
               start_date,end_date,created_by,data,deleted)
            VALUES
              (@id,@title,@facility,@unit,@leadEngineer,@scope,@methodology,@status,
               @startDate,@endDate,@createdBy,@data::jsonb,false)",
            new { id, title, facility, unit, leadEngineer, scope, methodology, status, 
                  startDate, endDate, createdBy, data = dataJson });
        return id;
    }

    public Task UpdateStudyAsync(string id, string title, string? facility, string? unit,
        string? leadEngineer, string? scope, string? methodology, string? status,
        DateTime? startDate, DateTime? endDate, string dataJson) =>
        _db.ExecuteAsync(@"
            UPDATE hazop_studies 
            SET title=@title, facility=@facility, unit=@unit, lead_engineer=@leadEngineer,
              scope=@scope, methodology=@methodology, status=@status, start_date=@startDate,
              end_date=@endDate, data=@data::jsonb, updated_at=NOW()
            WHERE id=@id AND deleted=false",
            new { id, title, facility, unit, leadEngineer, scope, methodology, status, 
                  startDate, endDate, data = dataJson });

    public Task SoftDeleteStudyAsync(string id) =>
        _db.ExecuteAsync("UPDATE hazop_studies SET deleted=true, updated_at=NOW() WHERE id=@id", 
            new { id });

    // ─── Nodes ──────────────────────────────────────────────────────────────
    public Task<IEnumerable<HazopNodeWithCountsDto>> ListNodesAsync(string studyId) =>
        _db.QueryAsync<HazopNodeWithCountsDto>(@"
            SELECT n.id, n.study_id, n.node_number, n.description, n.process_line,
              n.design_intent, n.p_and_id, n.created_at, n.updated_at, n.deleted,
              (SELECT COUNT(*)::int FROM hazop_deviations d 
               WHERE d.node_id=n.id AND d.deleted=false) AS DeviationCount
            FROM hazop_nodes n 
            WHERE n.study_id=@studyId AND n.deleted=false 
            ORDER BY n.node_number",
            new { studyId });

    public Task<HazopNodeDto?> GetNodeAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<HazopNodeDto>(
            @"SELECT id, study_id, node_number, description, process_line,
                     design_intent, p_and_id, created_at, updated_at, deleted
              FROM hazop_nodes WHERE id=@id AND deleted=false",
            new { id });

    public async Task<bool> NodeExistsAsync(string id)
    {
        var n = await _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM hazop_nodes WHERE id=@id AND deleted=false", new { id });
        return n > 0;
    }

    public async Task<string> CreateNodeAsync(string id, string studyId, string nodeNumber, string description,
        string? processLine, string? designIntent, string? pAndId)
    {
        await _db.ExecuteAsync(@"
            INSERT INTO hazop_nodes
              (id, study_id, node_number, description, process_line, design_intent, p_and_id, deleted)
            VALUES
              (@id, @studyId, @nodeNumber, @description, @processLine, @designIntent, @pAndId, false)",
            new { id, studyId, nodeNumber, description, processLine, designIntent, pAndId });
        return id;
    }

    public Task UpdateNodeAsync(string id, string nodeNumber, string description,
        string? processLine, string? designIntent, string? pAndId) =>
        _db.ExecuteAsync(@"
            UPDATE hazop_nodes
            SET node_number=@nodeNumber, description=@description, process_line=@processLine,
              design_intent=@designIntent, p_and_id=@pAndId, updated_at=NOW()
            WHERE id=@id AND deleted=false",
            new { id, nodeNumber, description, processLine, designIntent, pAndId });

    public Task SoftDeleteNodeAsync(string id) =>
        _db.ExecuteAsync("UPDATE hazop_nodes SET deleted=true, updated_at=NOW() WHERE id=@id", 
            new { id });

    // ─── Deviations ─────────────────────────────────────────────────────────
    public Task<IEnumerable<HazopDeviationDto>> ListDeviationsByStudyAsync(string studyId) =>
        _db.QueryAsync<HazopDeviationDto>(@"
            SELECT id, study_id, node_id, guide_word, parameter, deviation, causes,
              consequences, existing_safeguards, recommendations, severity, likelihood,
              risk_level, status, created_at, updated_at, data, deleted
            FROM hazop_deviations
            WHERE study_id=@studyId AND deleted=false
            ORDER BY created_at DESC",
            new { studyId });

    public Task<IEnumerable<HazopDeviationDto>> ListDeviationsByNodeAsync(string nodeId) =>
        _db.QueryAsync<HazopDeviationDto>(@"
            SELECT id, study_id, node_id, guide_word, parameter, deviation, causes,
              consequences, existing_safeguards, recommendations, severity, likelihood,
              risk_level, status, created_at, updated_at, data, deleted
            FROM hazop_deviations
            WHERE node_id=@nodeId AND deleted=false
            ORDER BY created_at DESC",
            new { nodeId });

    public Task<HazopDeviationDto?> GetDeviationAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<HazopDeviationDto>(
            @"SELECT id, study_id, node_id, guide_word, parameter, deviation, causes,
                     consequences, existing_safeguards, recommendations, severity, likelihood,
                     risk_level, status, created_at, updated_at, data, deleted
              FROM hazop_deviations WHERE id=@id AND deleted=false",
            new { id });

    public Task<string?> GetNodeStudyIdAsync(string nodeId) =>
        _db.QueryFirstOrDefaultAsync<string?>(
            "SELECT study_id FROM hazop_nodes WHERE id=@nodeId AND deleted=false",
            new { nodeId });

    public async Task<bool> DeviationExistsAsync(string id)
    {
        var n = await _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM hazop_deviations WHERE id=@id AND deleted=false", new { id });
        return n > 0;
    }

    public async Task<string> CreateDeviationAsync(string id, string studyId, string nodeId, string guideWord,
        string parameter, string deviation, string? causes, string? consequences,
        string? existingSafeguards, string? recommendations, int severity, int likelihood,
        string status, string riskLevel, string dataJson)
    {
        await _db.ExecuteAsync(@"
            INSERT INTO hazop_deviations
              (id, study_id, node_id, guide_word, parameter, deviation, causes, consequences,
               existing_safeguards, recommendations, severity, likelihood, risk_level, 
               status, data, deleted)
            VALUES
              (@id, @studyId, @nodeId, @guideWord, @parameter, @deviation, @causes, 
               @consequences, @existingSafeguards, @recommendations, @severity, @likelihood,
               @riskLevel, @status, @data::jsonb, false)",
            new { id, studyId, nodeId, guideWord, parameter, deviation, causes, consequences,
                  existingSafeguards, recommendations, severity, likelihood, riskLevel, status,
                  data = dataJson });
        return id;
    }

    public Task UpdateDeviationAsync(string id, string guideWord, string parameter, string deviation,
        string? causes, string? consequences, string? existingSafeguards, string? recommendations,
        int severity, int likelihood, string status, string riskLevel, string dataJson) =>
        _db.ExecuteAsync(@"
            UPDATE hazop_deviations
            SET guide_word=@guideWord, parameter=@parameter, deviation=@deviation,
              causes=@causes, consequences=@consequences, existing_safeguards=@existingSafeguards,
              recommendations=@recommendations, severity=@severity, likelihood=@likelihood,
              risk_level=@riskLevel, status=@status, data=@data::jsonb, updated_at=NOW()
            WHERE id=@id AND deleted=false",
            new { id, guideWord, parameter, deviation, causes, consequences, existingSafeguards,
                  recommendations, severity, likelihood, riskLevel, status, data = dataJson });

    public Task SoftDeleteDeviationAsync(string id) =>
        _db.ExecuteAsync("UPDATE hazop_deviations SET deleted=true, updated_at=NOW() WHERE id=@id",
            new { id });

    // ─── Analytics ──────────────────────────────────────────────────────────
    public async Task<HazopAnalyticsDto> GetAnalyticsAsync()
    {
        var studiesTask = _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(*)::int FROM hazop_studies WHERE deleted=false");
        var nodesTask = _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(*)::int FROM hazop_nodes WHERE deleted=false");
        var devsTask = _db.QueryFirstOrDefaultAsync<dynamic>(@"
            SELECT
                COUNT(*)::int                                                    AS Total,
                COUNT(*) FILTER (WHERE risk_level IN ('High','Critical'))::int   AS High,
                COUNT(*) FILTER (WHERE risk_level = 'Medium')::int               AS Medium,
                COUNT(*) FILTER (WHERE risk_level = 'Low')::int                  AS Low
            FROM hazop_deviations WHERE deleted=false");

        var studies = await studiesTask;
        var nodes = await nodesTask;
        var d = await devsTask;

        return new HazopAnalyticsDto
        {
            TotalStudies    = studies,
            TotalNodes      = nodes,
            TotalDeviations = d != null ? (int)(d.Total  ?? 0) : 0,
            HighRiskCount   = d != null ? (int)(d.High   ?? 0) : 0,
            MediumRiskCount = d != null ? (int)(d.Medium ?? 0) : 0,
            LowRiskCount    = d != null ? (int)(d.Low    ?? 0) : 0,
        };
    }

    // ─── Aliases for IntegratedRiskModelService ─────────────────────────────
    public Task<HazopStudyDto?> GetHazopStudyAsync(string id) => GetStudyAsync(id);

    public Task<HazopDeviationDto?> GetHazopDeviationAsync(string id) => GetDeviationAsync(id);

    public Task<int> GetHazopStudyCountAsync() =>
        _db.ExecuteScalarAsync<int>("SELECT COUNT(*)::int FROM hazop_studies WHERE deleted=false");

    // ─── NEW: HAZOP → Action Register Integration Methods ──────────────────

    public Task<HazopDeviationWithContextDto?> GetDeviationWithContextAsync(string deviationId) =>
        _db.QueryFirstOrDefaultAsync<HazopDeviationWithContextDto>(@"
            SELECT 
              d.id, d.study_id, d.node_id, d.guide_word, d.parameter, d.deviation, d.causes,
              d.consequences, d.existing_safeguards, d.recommendations, d.severity, d.likelihood,
              d.risk_level, d.status, d.created_at, d.updated_at, d.data, d.deleted,
              s.title AS StudyTitle, s.facility, s.unit, s.status AS StudyStatus
            FROM hazop_deviations d
            INNER JOIN hazop_studies s ON d.study_id = s.id
            WHERE d.id=@deviationId AND d.deleted=false AND s.deleted=false",
            new { deviationId });

    public Task<HazopStudyDto?> GetStudyForDeviationAsync(string deviationId) =>
        _db.QueryFirstOrDefaultAsync<HazopStudyDto>(@"
            SELECT s.id, s.title, s.facility, s.unit, s.lead_engineer, s.scope, s.methodology,
              s.status, s.start_date, s.end_date, s.created_by, s.created_at, s.updated_at,
              s.data, s.deleted
            FROM hazop_studies s
            INNER JOIN hazop_deviations d ON s.id = d.study_id
            WHERE d.id=@deviationId AND s.deleted=false AND d.deleted=false",
            new { deviationId });

    public Task<IEnumerable<HazopDeviationDto>> ListOpenDeviationsByStudyAsync(string studyId) =>
        _db.QueryAsync<HazopDeviationDto>(@"
            SELECT id, study_id, node_id, guide_word, parameter, deviation, causes,
              consequences, existing_safeguards, recommendations, severity, likelihood,
              risk_level, status, created_at, updated_at, data, deleted
            FROM hazop_deviations
            WHERE study_id=@studyId AND deleted=false AND status NOT IN ('Closed')
            ORDER BY risk_level DESC, created_at DESC",
            new { studyId });

    public Task<int> CountHighRiskDeviationsAsync(string? studyId = null)
    {
        if (string.IsNullOrEmpty(studyId))
        {
            return _db.ExecuteScalarAsync<int>(
                "SELECT COUNT(*)::int FROM hazop_deviations WHERE deleted=false AND risk_level IN ('High', 'Critical')");
        }
        else
        {
            return _db.ExecuteScalarAsync<int>(
                @"SELECT COUNT(*)::int FROM hazop_deviations 
                  WHERE study_id=@studyId AND deleted=false AND risk_level IN ('High', 'Critical')",
                new { studyId });
        }
    }
}
