using PSM.Api.Data;
using PSM.Api.Models;

namespace PSM.Api.Repositories;

public interface IUserRepository
{
    Task<User?> GetByUsernameAsync(string username);
    Task<User?> GetByIdAsync(string id);
    Task<IEnumerable<User>> GetAllActiveAsync();
    Task<string> CreateAsync(User user);
    Task UpdateAsync(string id, object changes);
    Task IncrementFailedAttemptsAsync(string id);
    Task ResetFailedAttemptsAsync(string id);
    Task LockAsync(string id, DateTime until);
    Task UpdateLastLoginAsync(string id);
    Task<bool> ExistsUsernameAsync(string username);
}

public class UserRepository : IUserRepository
{
    private readonly IDbHelper _db;
    public UserRepository(IDbHelper db) => _db = db;

    public Task<User?> GetByUsernameAsync(string username) =>
        _db.QueryFirstOrDefaultAsync<User>(
            "SELECT * FROM users WHERE username = @username AND status != 'Deleted'",
            new { username });

    public Task<User?> GetByIdAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<User>(
            "SELECT * FROM users WHERE id = @id",
            new { id });

    public Task<IEnumerable<User>> GetAllActiveAsync() =>
        _db.QueryAsync<User>(
            "SELECT * FROM users WHERE status != 'Deleted' ORDER BY created_at DESC");

    public async Task<string> CreateAsync(User user)
    {
        await _db.ExecuteAsync(@"
            INSERT INTO users
                (id, username, password_hash, full_name, email, role, department, unit,
                 status, failed_attempts, mfa_enabled, must_change_password, created_at)
            VALUES
                (@Id, @Username, @PasswordHash, @FullName, @Email, @Role, @Department, @Unit,
                 @Status, @FailedAttempts, @MfaEnabled, @MustChangePassword, @CreatedAt)",
            user);
        return user.Id;
    }

    public Task UpdateAsync(string id, object changes) =>
        _db.ExecuteAsync(
            @"UPDATE users SET 
                full_name=COALESCE(@FullName, full_name),
                email=COALESCE(@Email, email),
                role=COALESCE(@Role, role),
                department=COALESCE(@Department, department),
                unit=COALESCE(@Unit, unit),
                status=COALESCE(@Status, status),
                password_hash=COALESCE(@PasswordHash, password_hash),
                must_change_password=COALESCE(@MustChangePassword, must_change_password)
              WHERE id=@Id",
            changes);

    public Task IncrementFailedAttemptsAsync(string id) =>
        _db.ExecuteAsync(
            "UPDATE users SET failed_attempts = failed_attempts + 1 WHERE id = @id",
            new { id });

    public Task ResetFailedAttemptsAsync(string id) =>
        _db.ExecuteAsync(
            "UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = @id",
            new { id });

    public Task LockAsync(string id, DateTime until) =>
        _db.ExecuteAsync(
            "UPDATE users SET locked_until = @until WHERE id = @id",
            new { id, until });

    public Task UpdateLastLoginAsync(string id) =>
        _db.ExecuteAsync(
            "UPDATE users SET last_login = NOW() WHERE id = @id",
            new { id });

    public async Task<bool> ExistsUsernameAsync(string username)
    {
        var count = await _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM users WHERE username = @username", new { username });
        return count > 0;
    }
}
