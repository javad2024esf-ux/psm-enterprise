using System.Text.Json;
using Dapper;
using PSM.Api.Data;
using PSM.Api.Models;
using PSM.Api.Services;

namespace PSM.Api.Repositories;

public interface IAuditRepository
{
    Task CreateAsync(AuditEntry entry);
    Task<AuditPage> QueryAsync(AuditQuery q);
}

public class AuditRepository : IAuditRepository
{
    private readonly IDbHelper _db;
    public AuditRepository(IDbHelper db) => _db = db;

    public Task CreateAsync(AuditEntry entry) => _db.ExecuteAsync(@"
        INSERT INTO psm_audit_entries (
            event_id, action, severity,
            user_id, username, user_full_name, user_role,
            ip_address, user_agent,
            module, record_id, record_title,
            old_values, new_values, changed_fields,
            outcome, failure_reason, metadata,
            created_at
        ) VALUES (
            @EventId, @Action, @Severity,
            @UserId, @Username, @UserFullName, @UserRole,
            @IpAddress, @UserAgent,
            @Module, @RecordId, @RecordTitle,
            @OldValues::jsonb, @NewValues::jsonb, @ChangedFields::jsonb,
            @Outcome, @FailureReason, @Metadata::jsonb,
            @CreatedAt
        )",
        new
        {
            entry.EventId,
            entry.Action,
            entry.Severity,
            entry.UserId,
            entry.Username,
            entry.UserFullName,
            entry.UserRole,
            entry.IpAddress,
            entry.UserAgent,
            entry.Module,
            entry.RecordId,
            entry.RecordTitle,
            OldValues     = Serialize(entry.OldValues),
            NewValues     = Serialize(entry.NewValues),
            ChangedFields = Serialize(entry.ChangedFields),
            entry.Outcome,
            entry.FailureReason,
            Metadata      = Serialize(entry.Metadata),
            entry.CreatedAt,
        });

    public async Task<AuditPage> QueryAsync(AuditQuery q)
    {
        var where  = new List<string>();
        var p      = new DynamicParameters();
        int limit  = Math.Min(q.Limit, 1000);
        int offset = Math.Max(q.Offset, 0);

        p.Add("limit",  limit);
        p.Add("offset", offset);

        if (!string.IsNullOrEmpty(q.UserId))
            { where.Add("user_id   = @userId");   p.Add("userId",   q.UserId); }
        if (!string.IsNullOrEmpty(q.Module))
            { where.Add("module    = @module");   p.Add("module",   q.Module.ToLower()); }
        if (!string.IsNullOrEmpty(q.Action))
            { where.Add("action    = @action");   p.Add("action",   q.Action); }
        if (!string.IsNullOrEmpty(q.Severity))
            { where.Add("severity  = @severity"); p.Add("severity", q.Severity); }
        if (!string.IsNullOrEmpty(q.RecordId))
            { where.Add("record_id = @recordId"); p.Add("recordId", q.RecordId); }
        if (!string.IsNullOrEmpty(q.Outcome))
            { where.Add("outcome   = @outcome");  p.Add("outcome",  q.Outcome); }
        if (q.From.HasValue)
            { where.Add("created_at >= @from");   p.Add("from",     q.From.Value); }
        if (q.To.HasValue)
            { where.Add("created_at <= @to");     p.Add("to",       q.To.Value); }
        if (!string.IsNullOrEmpty(q.Search))
        {
            where.Add("(username ILIKE @search OR record_title ILIKE @search OR ip_address ILIKE @search)");
            p.Add("search", $"%{q.Search}%");
        }

        var filter = where.Count > 0 ? "WHERE " + string.Join(" AND ", where) : "";

        var countSql = $"SELECT COUNT(*) FROM psm_audit_entries {filter}";
        var dataSql  = $@"
            SELECT * FROM psm_audit_entries
            {filter}
            ORDER BY created_at DESC
            LIMIT @limit OFFSET @offset";

        var total   = await _db.ExecuteScalarAsync<long>(countSql, p);
        var rawRows = await _db.QueryAsync<AuditEntryRow>(dataSql, p);

        var data = rawRows.Select(MapRow);

        return new AuditPage { Data = data, Total = total, Limit = limit, Offset = offset };
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private static string? Serialize(JsonDocument? doc) =>
        doc is null ? null : doc.RootElement.GetRawText();

    private static AuditEntry MapRow(AuditEntryRow r) => new()
    {
        Id            = r.Id,
        EventId       = r.EventId,
        Action        = r.Action,
        Severity      = r.Severity,
        UserId        = r.UserId,
        Username      = r.Username,
        UserFullName  = r.UserFullName,
        UserRole      = r.UserRole,
        IpAddress     = r.IpAddress,
        UserAgent     = r.UserAgent,
        Module        = r.Module,
        RecordId      = r.RecordId,
        RecordTitle   = r.RecordTitle,
        OldValues     = ParseJson(r.OldValues),
        NewValues     = ParseJson(r.NewValues),
        ChangedFields = ParseJson(r.ChangedFields),
        Outcome       = r.Outcome,
        FailureReason = r.FailureReason,
        Metadata      = ParseJson(r.Metadata),
        CreatedAt     = r.CreatedAt,
    };

    private static JsonDocument? ParseJson(string? raw) =>
        raw is null ? null : JsonDocument.Parse(raw);

    // Dapper flat row — JSONB ستون‌ها به‌عنوان string می‌آیند
    private sealed class AuditEntryRow
    {
        public long     Id            { get; set; }
        public string   EventId       { get; set; } = "";
        public string   Action        { get; set; } = "";
        public string   Severity      { get; set; } = "";
        public string?  UserId        { get; set; }
        public string?  Username      { get; set; }
        public string?  UserFullName  { get; set; }
        public string?  UserRole      { get; set; }
        public string?  IpAddress     { get; set; }
        public string?  UserAgent     { get; set; }
        public string?  Module        { get; set; }
        public string?  RecordId      { get; set; }
        public string?  RecordTitle   { get; set; }
        public string?  OldValues     { get; set; }
        public string?  NewValues     { get; set; }
        public string?  ChangedFields { get; set; }
        public string?  Outcome       { get; set; }
        public string?  FailureReason { get; set; }
        public string?  Metadata      { get; set; }
        public DateTime CreatedAt     { get; set; }
    }
}
