namespace PSM.Api.Repositories;

using Npgsql;
using PSM.Api.DTOs;

// ════════════════════════════════════════════════════════════════════════════════════
// UNIFIED BARRIER REPOSITORY INTERFACE
// ════════════════════════════════════════════════════════════════════════════════════

public interface IUnifiedBarrierRepository
{
    // ─────────────────────────────────────────────────────────────────────────────────
    // BARRIER CORE OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────────────

    Task<BarrierWithLinksDto?> GetBarrierWithLinksAsync(string barrierId);
    Task<List<BarrierWithLinksDto>> GetAllBarriersWithLinksAsync();
    Task<BarrierWithLinksDto> CreateBarrierAsync(CreateBarrierDto dto, string createdBy);
    Task<BarrierWithLinksDto> UpdateBarrierAsync(string barrierId, UpdateBarrierDto dto, string updatedBy);
    Task<bool> DeleteBarrierAsync(string barrierId);

    // ─────────────────────────────────────────────────────────────────────────────────
    // BARRIER STATUS OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────────────

    Task<BarrierWithLinksDto> UpdateBarrierStatusAsync(string barrierId, string newStatus, string reason, string? incidentId, string changedBy);
    Task<List<BarrierStatusHistoryDto>> GetBarrierStatusHistoryAsync(string barrierId);
    Task<BarrierStatusHistoryDto> RecordStatusChangeAsync(string barrierId, string previousStatus, string newStatus, string? reason, string? incidentId, string changedBy);

    // ─────────────────────────────────────────────────────────────────────────────────
    // LOPA IPL INTEGRATION
    // ─────────────────────────────────────────────────────────────────────────────────

    Task<BarrierDto?> CreateBarrierFromLopaIplAsync(string lopaIplId, CreateBarrierDto barrierDto, string createdBy);
    Task<BarrierWithLinksDto?> GetBarrierByLopaIplAsync(string lopaIplId);
    Task<List<BarrierWithLinksDto>> GetBarriersByLopaScenarioAsync(string lopaScenarioId);
    Task<List<BarrierWithLinksDto>> GetBarriersByLopaStudyAsync(string lopaStudyId);
    Task<LopaIplWithBarrierDto?> GetLopaIplWithBarrierAsync(string lopaIplId);
    Task SyncBarrierToLopaIplAsync(string barrierId, string lopaIplId);

    // ─────────────────────────────────────────────────────────────────────────────────
    // BOWTIE BARRIER INTEGRATION
    // ─────────────────────────────────────────────────────────────────────────────────

    Task<BarrierDto?> CreateBarrierFromBowTieBarrierAsync(string bowTieBarrierId, CreateBarrierDto barrierDto, string createdBy);
    Task<BarrierWithLinksDto?> GetBarrierByBowTieBarrierAsync(string bowTieBarrierId);
    Task<List<BarrierWithLinksDto>> GetBarriersByBowTieDiagramAsync(string bowTieDiagramId);
    Task<BowTieBarrierWithLinksDto?> GetBowTieBarrierWithLinksAsync(string bowTieBarrierId);
    Task SyncBarrierToBowTieBarrierAsync(string barrierId, string bowTieBarrierId);

    // ─────────────────────────────────────────────────────────────────────────────────
    // INCIDENT INTEGRATION
    // ─────────────────────────────────────────────────────────────────────────────────

    Task<List<BarrierWithLinksDto>> GetBarriersLinkedToIncidentAsync(string incidentId);
    Task LinkBarrierToIncidentAsync(string incidentId, string barrierId, string? failureType, string? failureEvidence, decimal? contribution);
    Task UnlinkBarrierFromIncidentAsync(string incidentId, string barrierId);
    Task<IncidentWithBarriersDto?> GetIncidentWithBarriersAsync(string incidentId);
    Task<List<IncidentWithBarriersDto>> GetIncidentsAffectedByBarrierStatusChangeAsync(string barrierId);

    // ─────────────────────────────────────────────────────────────────────────────────
    // IMPACT ANALYSIS
    // ─────────────────────────────────────────────────────────────────────────────────

    Task<BarrierImpactDto> GetBarrierImpactAsync(string barrierId);
    Task<IncidentImpactDto> GetIncidentImpactAsync(string incidentId);
    Task<List<BarrierImpactDto>> AnalyzeBarrierFailureImpactAsync(string barrierId, DateTime fromDate, DateTime toDate);

    // ─────────────────────────────────────────────────────────────────────────────────
    // CROSS-REFERENCE OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────────────

    Task<BarrierCrossReferenceDto> GetBarrierCrossReferencesAsync(string barrierId);
    Task<List<BarrierWithLinksDto>> GetBarriersForHazopStudyAsync(string hazopStudyId);
    Task<List<BarrierWithLinksDto>> GetBarriersForHazopDeviationAsync(string hazopDeviationId);
    Task<List<BarrierWithLinksDto>> GetBarriersForBowTieDiagramAsync(string bowTieDiagramId);

    // ─────────────────────────────────────────────────────────────────────────────────
    // SYNCHRONIZATION OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────────────

    Task<SyncResultDto> SyncBarrierStatusAsync(string barrierId, string newStatus, string reason, string changedBy);
    Task<List<string>> GetBarriersSyncRequiredAsync();

    // ─────────────────────────────────────────────────────────────────────────────────
    // SUMMARY AND ANALYTICS
    // ─────────────────────────────────────────────────────────────────────────────────

    Task<BarrierSummaryDto> GetBarrierSummaryAsync();
    Task<List<BarrierWithLinksDto>> GetCriticalBarriersAsync();
    Task<List<BarrierWithLinksDto>> GetBarriersNeedingMaintenanceAsync();
    Task<List<BarrierWithLinksDto>> GetBarriersOverdueAsync();
    Task<List<BarrierWithLinksDto>> GetBarriersByStatusAsync(string status);
    Task<List<BarrierWithLinksDto>> GetBarriersByTypeAsync(string barrierType);

    // ─────────────────────────────────────────────────────────────────────────────────
    // SEARCH AND FILTER
    // ─────────────────────────────────────────────────────────────────────────────────

    Task<List<BarrierWithLinksDto>> SearchBarriersAsync(string searchTerm);
    Task<List<BarrierWithLinksDto>> FilterBarriersAsync(Dictionary<string, object> filters);
}

// ════════════════════════════════════════════════════════════════════════════════════
// UNIFIED BARRIER REPOSITORY IMPLEMENTATION
// ════════════════════════════════════════════════════════════════════════════════════

public class UnifiedBarrierRepository : IUnifiedBarrierRepository
{
    private readonly string _connectionString;
    private readonly IBarrierRepository _barrierRepository;
    private readonly ILopaRepository _lopaRepository;
    private readonly IBowTieRepository _bowTieRepository;

    public UnifiedBarrierRepository(
        IConfiguration config,
        IBarrierRepository barrierRepository,
        ILopaRepository lopaRepository,
        IBowTieRepository bowTieRepository)
    {
        _connectionString = config.GetConnectionString("DefaultConnection")!;
        _barrierRepository = barrierRepository;
        _lopaRepository = lopaRepository;
        _bowTieRepository = bowTieRepository;
    }

    // ─────────────────────────────────────────────────────────────────────────────────
    // BARRIER CORE OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────────────

    public async Task<BarrierWithLinksDto?> GetBarrierWithLinksAsync(string barrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT b.*, 
                   li.ipl_name as lopa_ipl_name,
                   bd.title as bowtie_diagram_title
            FROM barriers b
            LEFT JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
            LEFT JOIN bowtie_barriers bb ON b.bowtie_barrier_id = bb.id
            LEFT JOIN bowtie_diagrams bd ON bb.diagram_id = bd.id
            WHERE b.id = @id AND b.deleted = FALSE";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", barrierId);

        await using var reader = await cmd.ExecuteReaderAsync();
        if (!reader.Read()) return null;

        var barrier = MapBarrierWithLinksDto(reader);
        
        // Get status history
        barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrierId);
        
        return barrier;
    }

    public async Task<List<BarrierWithLinksDto>> GetAllBarriersWithLinksAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT b.*, 
                   li.ipl_name as lopa_ipl_name,
                   bd.title as bowtie_diagram_title
            FROM barriers b
            LEFT JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
            LEFT JOIN bowtie_barriers bb ON b.bowtie_barrier_id = bb.id
            LEFT JOIN bowtie_diagrams bd ON bb.diagram_id = bd.id
            WHERE b.deleted = FALSE
            ORDER BY b.barrier_name";

        await using var cmd = new NpgsqlCommand(sql, conn);
        await using var reader = await cmd.ExecuteReaderAsync();

        var barriers = new List<BarrierWithLinksDto>();
        while (reader.Read())
        {
            barriers.Add(MapBarrierWithLinksDto(reader));
        }

        // Load status history for each
        foreach (var barrier in barriers)
        {
            barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        }

        return barriers;
    }

    public async Task<BarrierWithLinksDto> CreateBarrierAsync(CreateBarrierDto dto, string createdBy)
    {
        var id = Guid.NewGuid().ToString();
        var status = dto.Status ?? "Active";

        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO barriers (
                id, barrier_name, barrier_type, description, owner_discipline,
                owner_contact, maintenance_frequency, effectiveness_rating,
                status, sil_level, documentation_ref, critical_flag, created_at, updated_at
            ) VALUES (
                @id, @barrierName, @barrierType, @description, @ownerDiscipline,
                @ownerContact, @maintenanceFrequency, @effectivenessRating,
                @status, @silLevel, @documentationRef, @criticalFlag, NOW(), NOW()
            ) RETURNING *";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@barrierName", dto.BarrierName ?? "");
        cmd.Parameters.AddWithValue("@barrierType", dto.BarrierType ?? "");
        cmd.Parameters.AddWithValue("@description", dto.Description ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@ownerDiscipline", dto.OwnerDiscipline ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@ownerContact", dto.OwnerContact ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@maintenanceFrequency", dto.MaintenanceFrequency ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@effectivenessRating", dto.EffectivenessRating ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@status", status);
        cmd.Parameters.AddWithValue("@silLevel", dto.SilLevel ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@documentationRef", dto.DocumentationRef ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@criticalFlag", dto.CriticalFlag);

        await using var reader = await cmd.ExecuteReaderAsync();
        reader.Read();
        var result = MapBarrierWithLinksDto(reader);
        result.StatusHistory = new List<BarrierStatusHistoryDto>();
        return result;
    }

    public async Task<BarrierWithLinksDto> UpdateBarrierAsync(string barrierId, UpdateBarrierDto dto, string updatedBy)
    {
        var fields = new StringBuilder();
        var parameters = new List<NpgsqlParameter>();

        if (!string.IsNullOrEmpty(dto.BarrierName))
        {
            fields.Append("barrier_name = @barrierName, ");
            parameters.Add(new NpgsqlParameter("@barrierName", dto.BarrierName));
        }

        if (!string.IsNullOrEmpty(dto.BarrierType))
        {
            fields.Append("barrier_type = @barrierType, ");
            parameters.Add(new NpgsqlParameter("@barrierType", dto.BarrierType));
        }

        if (dto.Description != null)
        {
            fields.Append("description = @description, ");
            parameters.Add(new NpgsqlParameter("@description", dto.Description ?? (object)DBNull.Value));
        }

        if (dto.OwnerDiscipline != null)
        {
            fields.Append("owner_discipline = @ownerDiscipline, ");
            parameters.Add(new NpgsqlParameter("@ownerDiscipline", dto.OwnerDiscipline ?? (object)DBNull.Value));
        }

        if (dto.MaintenanceFrequency != null)
        {
            fields.Append("maintenance_frequency = @maintenanceFrequency, ");
            parameters.Add(new NpgsqlParameter("@maintenanceFrequency", dto.MaintenanceFrequency ?? (object)DBNull.Value));
        }

        if (dto.LastTested.HasValue)
        {
            fields.Append("last_tested = @lastTested, ");
            parameters.Add(new NpgsqlParameter("@lastTested", dto.LastTested));
        }

        if (dto.NextTestDue.HasValue)
        {
            fields.Append("next_test_due = @nextTestDue, ");
            parameters.Add(new NpgsqlParameter("@nextTestDue", dto.NextTestDue));
        }

        if (dto.EffectivenessRating.HasValue)
        {
            fields.Append("effectiveness_rating = @effectivenessRating, ");
            parameters.Add(new NpgsqlParameter("@effectivenessRating", dto.EffectivenessRating));
        }

        if (dto.PfdActual.HasValue)
        {
            fields.Append("pfd_actual = @pfdActual, ");
            parameters.Add(new NpgsqlParameter("@pfdActual", dto.PfdActual));
        }

        if (dto.SilLevel.HasValue)
        {
            fields.Append("sil_level = @silLevel, ");
            parameters.Add(new NpgsqlParameter("@silLevel", dto.SilLevel));
        }

        fields.Append("updated_at = NOW(), updated_by = @updatedBy");
        parameters.Add(new NpgsqlParameter("@updatedBy", updatedBy));
        parameters.Add(new NpgsqlParameter("@id", barrierId));

        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        var sql = $@"
            UPDATE barriers 
            SET {fields}
            WHERE id = @id AND deleted = FALSE
            RETURNING *";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddRange(parameters.ToArray());

        await using var reader = await cmd.ExecuteReaderAsync();
        reader.Read();
        var result = MapBarrierWithLinksDto(reader);
        result.StatusHistory = await GetBarrierStatusHistoryAsync(barrierId);
        return result;
    }

    public async Task<bool> DeleteBarrierAsync(string barrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            UPDATE barriers 
            SET deleted = TRUE, updated_at = NOW()
            WHERE id = @id
            RETURNING TRUE";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", barrierId);

        var result = await cmd.ExecuteScalarAsync();
        return result != null;
    }

    // ─────────────────────────────────────────────────────────────────────────────────
    // BARRIER STATUS OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────────────

    public async Task<BarrierWithLinksDto> UpdateBarrierStatusAsync(string barrierId, string newStatus, string reason, string? incidentId, string changedBy)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        // Get current status
        const string getCurrentSql = "SELECT status FROM barriers WHERE id = @id AND deleted = FALSE";
        await using var getCurrentCmd = new NpgsqlCommand(getCurrentSql, conn);
        getCurrentCmd.Parameters.AddWithValue("@id", barrierId);
        var currentStatus = await getCurrentCmd.ExecuteScalarAsync() as string;

        // Update barrier status
        const string updateSql = @"
            UPDATE barriers 
            SET status = @status, updated_at = NOW(), updated_by = @changedBy
            WHERE id = @id AND deleted = FALSE
            RETURNING *";

        await using var updateCmd = new NpgsqlCommand(updateSql, conn);
        updateCmd.Parameters.AddWithValue("@status", newStatus);
        updateCmd.Parameters.AddWithValue("@changedBy", changedBy);
        updateCmd.Parameters.AddWithValue("@id", barrierId);

        await using var reader = await updateCmd.ExecuteReaderAsync();
        reader.Read();
        var barrier = MapBarrierWithLinksDto(reader);

        // Record status change
        await RecordStatusChangeAsync(barrierId, currentStatus ?? "", newStatus, reason, incidentId, changedBy);

        barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrierId);
        return barrier;
    }

    public async Task<List<BarrierStatusHistoryDto>> GetBarrierStatusHistoryAsync(string barrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM barrier_status_history
            WHERE barrier_id = @id
            ORDER BY changed_at DESC";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", barrierId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var history = new List<BarrierStatusHistoryDto>();

        while (reader.Read())
        {
            history.Add(new BarrierStatusHistoryDto
            {
                Id = reader["id"].ToString(),
                PreviousStatus = reader["previous_status"] as string,
                NewStatus = reader["new_status"] as string,
                Reason = reader["reason"] as string,
                TriggeredByIncidentId = reader["triggered_by_incident"] as string,
                ChangedBy = reader["changed_by"] as string,
                ChangedAt = reader["changed_at"] is DBNull ? null : (DateTime?)reader["changed_at"]
            });
        }

        return history;
    }

    public async Task<BarrierStatusHistoryDto> RecordStatusChangeAsync(string barrierId, string previousStatus, string newStatus, string? reason, string? incidentId, string changedBy)
    {
        var id = Guid.NewGuid().ToString();

        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO barrier_status_history (
                id, barrier_id, previous_status, new_status, reason,
                triggered_by_incident, changed_by, changed_at
            ) VALUES (
                @id, @barrierId, @previousStatus, @newStatus, @reason,
                @incidentId, @changedBy, NOW()
            ) RETURNING *";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@barrierId", barrierId);
        cmd.Parameters.AddWithValue("@previousStatus", previousStatus ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@newStatus", newStatus);
        cmd.Parameters.AddWithValue("@reason", reason ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@incidentId", incidentId ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@changedBy", changedBy);

        await using var reader = await cmd.ExecuteReaderAsync();
        reader.Read();

        return new BarrierStatusHistoryDto
        {
            Id = reader["id"].ToString(),
            PreviousStatus = reader["previous_status"] as string,
            NewStatus = reader["new_status"] as string,
            Reason = reader["reason"] as string,
            TriggeredByIncidentId = reader["triggered_by_incident"] as string,
            ChangedBy = reader["changed_by"] as string,
            ChangedAt = (DateTime?)reader["changed_at"]
        };
    }

    // ─────────────────────────────────────────────────────────────────────────────────
    // LOPA IPL INTEGRATION
    // ─────────────────────────────────────────────────────────────────────────────────

    public async Task<BarrierDto?> CreateBarrierFromLopaIplAsync(string lopaIplId, CreateBarrierDto barrierDto, string createdBy)
    {
        var barrierId = Guid.NewGuid().ToString();

        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO barriers (
                id, lopa_ipl_id, barrier_name, barrier_type, description,
                owner_discipline, owner_contact, maintenance_frequency,
                effectiveness_rating, status, sil_level, documentation_ref,
                critical_flag, created_at, updated_at
            ) VALUES (
                @id, @lopaIplId, @barrierName, @barrierType, @description,
                @ownerDiscipline, @ownerContact, @maintenanceFrequency,
                @effectivenessRating, @status, @silLevel, @documentationRef,
                @criticalFlag, NOW(), NOW()
            ) RETURNING *";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", barrierId);
        cmd.Parameters.AddWithValue("@lopaIplId", lopaIplId);
        cmd.Parameters.AddWithValue("@barrierName", barrierDto.BarrierName ?? "");
        cmd.Parameters.AddWithValue("@barrierType", barrierDto.BarrierType ?? "");
        cmd.Parameters.AddWithValue("@description", barrierDto.Description ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@ownerDiscipline", barrierDto.OwnerDiscipline ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@ownerContact", barrierDto.OwnerContact ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@maintenanceFrequency", barrierDto.MaintenanceFrequency ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@effectivenessRating", barrierDto.EffectivenessRating ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@status", barrierDto.Status ?? "Active");
        cmd.Parameters.AddWithValue("@silLevel", barrierDto.SilLevel ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@documentationRef", barrierDto.DocumentationRef ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@criticalFlag", barrierDto.CriticalFlag);

        await using var reader = await cmd.ExecuteReaderAsync();
        return reader.Read() ? MapBarrierDto(reader) : null;
    }

    public async Task<BarrierWithLinksDto?> GetBarrierByLopaIplAsync(string lopaIplId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT b.*, li.ipl_name as lopa_ipl_name
            FROM barriers b
            LEFT JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
            WHERE b.lopa_ipl_id = @lopaIplId AND b.deleted = FALSE";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@lopaIplId", lopaIplId);

        await using var reader = await cmd.ExecuteReaderAsync();
        if (!reader.Read()) return null;

        var barrier = MapBarrierWithLinksDto(reader);
        barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        return barrier;
    }

    public async Task<List<BarrierWithLinksDto>> GetBarriersByLopaScenarioAsync(string lopaScenarioId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT DISTINCT b.*, li.ipl_name as lopa_ipl_name
            FROM barriers b
            INNER JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
            WHERE li.scenario_id = @scenarioId AND b.deleted = FALSE";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@scenarioId", lopaScenarioId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var barriers = new List<BarrierWithLinksDto>();

        while (reader.Read())
        {
            barriers.Add(MapBarrierWithLinksDto(reader));
        }

        foreach (var barrier in barriers)
        {
            barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        }

        return barriers;
    }

    public async Task<List<BarrierWithLinksDto>> GetBarriersByLopaStudyAsync(string lopaStudyId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT DISTINCT b.*, li.ipl_name as lopa_ipl_name
            FROM barriers b
            INNER JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
            INNER JOIN lopa_scenarios ls ON li.scenario_id = ls.id
            WHERE ls.study_id = @studyId AND b.deleted = FALSE";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@studyId", lopaStudyId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var barriers = new List<BarrierWithLinksDto>();

        while (reader.Read())
        {
            barriers.Add(MapBarrierWithLinksDto(reader));
        }

        foreach (var barrier in barriers)
        {
            barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        }

        return barriers;
    }

    public async Task<LopaIplWithBarrierDto?> GetLopaIplWithBarrierAsync(string lopaIplId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT li.*, b.* FROM lopa_ipls li
            LEFT JOIN barriers b ON li.id = b.lopa_ipl_id
            WHERE li.id = @id AND li.deleted = FALSE";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", lopaIplId);

        await using var reader = await cmd.ExecuteReaderAsync();
        if (!reader.Read()) return null;

        var dto = new LopaIplWithBarrierDto
        {
            Id = reader["id"].ToString(),
            IplName = reader["ipl_name"] as string,
            IplType = reader["ipl_type"] as string,
            Description = reader["description"] as string,
            Owner = reader["owner"] as string,
            AuditInterval = reader["audit_interval"] as string,
            CreatedAt = reader["created_at"] is DBNull ? null : (DateTime?)reader["created_at"]
        };

        if (reader["barrier_name"] != DBNull.Value)
        {
            dto.LinkedBarrier = MapBarrierDto(reader);
            dto.LinkedBarrierId = reader["id"].ToString();
        }

        return dto;
    }

    public async Task SyncBarrierToLopaIplAsync(string barrierId, string lopaIplId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            UPDATE barriers 
            SET lopa_ipl_id = @lopaIplId, updated_at = NOW()
            WHERE id = @id";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", barrierId);
        cmd.Parameters.AddWithValue("@lopaIplId", lopaIplId);

        await cmd.ExecuteNonQueryAsync();
    }

    // ─────────────────────────────────────────────────────────────────────────────────
    // BOWTIE BARRIER INTEGRATION
    // ─────────────────────────────────────────────────────────────────────────────────

    public async Task<BarrierDto?> CreateBarrierFromBowTieBarrierAsync(string bowTieBarrierId, CreateBarrierDto barrierDto, string createdBy)
    {
        var barrierId = Guid.NewGuid().ToString();

        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO barriers (
                id, bowtie_barrier_id, barrier_name, barrier_type, description,
                owner_discipline, owner_contact, maintenance_frequency,
                effectiveness_rating, status, sil_level, documentation_ref,
                critical_flag, created_at, updated_at
            ) VALUES (
                @id, @bowTieBarrierId, @barrierName, @barrierType, @description,
                @ownerDiscipline, @ownerContact, @maintenanceFrequency,
                @effectivenessRating, @status, @silLevel, @documentationRef,
                @criticalFlag, NOW(), NOW()
            ) RETURNING *";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", barrierId);
        cmd.Parameters.AddWithValue("@bowTieBarrierId", bowTieBarrierId);
        cmd.Parameters.AddWithValue("@barrierName", barrierDto.BarrierName ?? "");
        cmd.Parameters.AddWithValue("@barrierType", barrierDto.BarrierType ?? "");
        cmd.Parameters.AddWithValue("@description", barrierDto.Description ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@ownerDiscipline", barrierDto.OwnerDiscipline ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@ownerContact", barrierDto.OwnerContact ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@maintenanceFrequency", barrierDto.MaintenanceFrequency ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@effectivenessRating", barrierDto.EffectivenessRating ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@status", barrierDto.Status ?? "Active");
        cmd.Parameters.AddWithValue("@silLevel", barrierDto.SilLevel ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@documentationRef", barrierDto.DocumentationRef ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@criticalFlag", barrierDto.CriticalFlag);

        await using var reader = await cmd.ExecuteReaderAsync();
        return reader.Read() ? MapBarrierDto(reader) : null;
    }

    public async Task<BarrierWithLinksDto?> GetBarrierByBowTieBarrierAsync(string bowTieBarrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT b.*, bd.title as bowtie_diagram_title
            FROM barriers b
            LEFT JOIN bowtie_barriers bb ON b.bowtie_barrier_id = bb.id
            LEFT JOIN bowtie_diagrams bd ON bb.diagram_id = bd.id
            WHERE b.bowtie_barrier_id = @bowTieBarrierId AND b.deleted = FALSE";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@bowTieBarrierId", bowTieBarrierId);

        await using var reader = await cmd.ExecuteReaderAsync();
        if (!reader.Read()) return null;

        var barrier = MapBarrierWithLinksDto(reader);
        barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        return barrier;
    }

    public async Task<List<BarrierWithLinksDto>> GetBarriersByBowTieDiagramAsync(string bowTieDiagramId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT DISTINCT b.*, bd.title as bowtie_diagram_title
            FROM barriers b
            INNER JOIN bowtie_barriers bb ON b.bowtie_barrier_id = bb.id
            INNER JOIN bowtie_diagrams bd ON bb.diagram_id = bd.id
            WHERE bd.id = @diagramId AND b.deleted = FALSE";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@diagramId", bowTieDiagramId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var barriers = new List<BarrierWithLinksDto>();

        while (reader.Read())
        {
            barriers.Add(MapBarrierWithLinksDto(reader));
        }

        foreach (var barrier in barriers)
        {
            barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        }

        return barriers;
    }

    public async Task<BowTieBarrierWithLinksDto?> GetBowTieBarrierWithLinksAsync(string bowTieBarrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT bb.*, b.*, bd.title as bowtie_diagram_title
            FROM bowtie_barriers bb
            LEFT JOIN barriers b ON bb.id = b.bowtie_barrier_id
            LEFT JOIN bowtie_diagrams bd ON bb.diagram_id = bd.id
            WHERE bb.id = @id";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", bowTieBarrierId);

        await using var reader = await cmd.ExecuteReaderAsync();
        if (!reader.Read()) return null;

        var dto = new BowTieBarrierWithLinksDto
        {
            Id = reader["id"].ToString(),
            DiagramId = reader["diagram_id"].ToString(),
            Description = reader["description"] as string,
            Type = reader["type"] as string,
            RiskReduction = reader["risk_reduction"] as string,
            SortOrder = reader["sort_order"] is DBNull ? 0 : (int)reader["sort_order"],
            BarrierStatus = reader["barrier_status"] as string,
            LastTested = reader["last_tested"] is DBNull ? null : (DateTime?)reader["last_tested"],
            CreatedAt = reader["created_at"] is DBNull ? null : (DateTime?)reader["created_at"]
        };

        if (reader["barrier_name"] != DBNull.Value)
        {
            dto.LinkedBarrier = MapBarrierDto(reader);
            dto.LinkedBarrierId = reader["id"].ToString();
        }

        return dto;
    }

    public async Task SyncBarrierToBowTieBarrierAsync(string barrierId, string bowTieBarrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            UPDATE barriers 
            SET bowtie_barrier_id = @bowTieBarrierId, updated_at = NOW()
            WHERE id = @id";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", barrierId);
        cmd.Parameters.AddWithValue("@bowTieBarrierId", bowTieBarrierId);

        await cmd.ExecuteNonQueryAsync();
    }

    // ─────────────────────────────────────────────────────────────────────────────────
    // INCIDENT INTEGRATION
    // ─────────────────────────────────────────────────────────────────────────────────

    public async Task<List<BarrierWithLinksDto>> GetBarriersLinkedToIncidentAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT DISTINCT b.*, li.ipl_name as lopa_ipl_name
            FROM barriers b
            INNER JOIN incident_barriers ib ON b.id = ib.barrier_id
            LEFT JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
            WHERE ib.incident_id = @incidentId AND b.deleted = FALSE";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var barriers = new List<BarrierWithLinksDto>();

        while (reader.Read())
        {
            barriers.Add(MapBarrierWithLinksDto(reader));
        }

        foreach (var barrier in barriers)
        {
            barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        }

        return barriers;
    }

    public async Task LinkBarrierToIncidentAsync(string incidentId, string barrierId, string? failureType, string? failureEvidence, decimal? contribution)
    {
        var id = Guid.NewGuid().ToString();

        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO incident_barriers (
                id, incident_id, barrier_id, barrier_failure_type,
                failure_evidence, contribution_to_incident, created_at
            ) VALUES (
                @id, @incidentId, @barrierId, @failureType,
                @failureEvidence, @contribution, NOW()
            ) ON CONFLICT (incident_id, barrier_id) DO UPDATE
            SET barrier_failure_type = @failureType,
                failure_evidence = @failureEvidence,
                contribution_to_incident = @contribution";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);
        cmd.Parameters.AddWithValue("@barrierId", barrierId);
        cmd.Parameters.AddWithValue("@failureType", failureType ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@failureEvidence", failureEvidence ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@contribution", contribution ?? (object)DBNull.Value);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task UnlinkBarrierFromIncidentAsync(string incidentId, string barrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            DELETE FROM incident_barriers
            WHERE incident_id = @incidentId AND barrier_id = @barrierId";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);
        cmd.Parameters.AddWithValue("@barrierId", barrierId);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<IncidentWithBarriersDto?> GetIncidentWithBarriersAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        // Get incident
        const string incidentSql = @"
            SELECT * FROM incidents
            WHERE id = @id AND deleted = FALSE";

        await using var incidentCmd = new NpgsqlCommand(incidentSql, conn);
        incidentCmd.Parameters.AddWithValue("@id", incidentId);

        await using var incidentReader = await incidentCmd.ExecuteReaderAsync();
        if (!incidentReader.Read()) return null;

        var dto = new IncidentWithBarriersDto
        {
            Id = incidentReader["id"].ToString(),
            IncidentNumber = incidentReader["incident_number"] as string,
            Title = incidentReader["title"] as string,
            Description = incidentReader["description"] as string,
            Facility = incidentReader["facility"] as string,
            Unit = incidentReader["unit"] as string,
            DateOccurred = incidentReader["date_occurred"] is DBNull ? null : (DateTime?)incidentReader["date_occurred"],
            DateReported = incidentReader["date_reported"] is DBNull ? null : (DateTime?)incidentReader["date_reported"],
            ReporterName = incidentReader["reporter_name"] as string,
            IncidentType = incidentReader["incident_type"] as string,
            SeverityActual = incidentReader["severity_actual"] is DBNull ? 0 : (int)incidentReader["severity_actual"],
            Status = incidentReader["status"] as string,
            CreatedAt = incidentReader["created_at"] is DBNull ? null : (DateTime?)incidentReader["created_at"],
            UpdatedAt = incidentReader["updated_at"] is DBNull ? null : (DateTime?)incidentReader["updated_at"]
        };

        // Get barriers linked to incident
        const string barriersSql = @"
            SELECT b.*, ib.barrier_failure_type, ib.failure_evidence,
                   ib.contribution_to_incident, ib.created_at as linked_at
            FROM incident_barriers ib
            INNER JOIN barriers b ON ib.barrier_id = b.id
            WHERE ib.incident_id = @incidentId";

        await using var barriersCmd = new NpgsqlCommand(barriersSql, conn);
        barriersCmd.Parameters.AddWithValue("@incidentId", incidentId);

        await using var barriersReader = await barriersCmd.ExecuteReaderAsync();
        while (barriersReader.Read())
        {
            dto.Barriers.Add(new IncidentBarrierDto
            {
                BarrierId = barriersReader["id"].ToString(),
                BarrierName = barriersReader["barrier_name"] as string,
                BarrierType = barriersReader["barrier_type"] as string,
                BarrierStatus = barriersReader["status"] as string,
                BarrierFailureType = barriersReader["barrier_failure_type"] as string,
                FailureEvidence = barriersReader["failure_evidence"] as string,
                ContributionToIncident = barriersReader["contribution_to_incident"] is DBNull ? null : (decimal?)barriersReader["contribution_to_incident"],
                CreatedAt = barriersReader["linked_at"] is DBNull ? null : (DateTime?)barriersReader["linked_at"]
            });
        }

        // Get related HAZOP mappings
        const string hazopSql = @"
            SELECT DISTINCT hazop_study_id, hazop_deviation_id
            FROM incident_hazop_mappings
            WHERE incident_id = @incidentId";

        await using var hazopCmd = new NpgsqlCommand(hazopSql, conn);
        hazopCmd.Parameters.AddWithValue("@incidentId", incidentId);

        await using var hazopReader = await hazopCmd.ExecuteReaderAsync();
        dto.RelatedHazopStudyIds = new List<string>();
        dto.RelatedHazopDeviationIds = new List<string>();

        while (hazopReader.Read())
        {
            dto.RelatedHazopStudyIds.Add(hazopReader["hazop_study_id"].ToString());
            dto.RelatedHazopDeviationIds.Add(hazopReader["hazop_deviation_id"].ToString());
        }

        // Get related LOPA mappings
        const string lopaSql = @"
            SELECT DISTINCT lopa_study_id, lopa_scenario_id
            FROM incident_lopa_mappings
            WHERE incident_id = @incidentId";

        await using var lopaCmd = new NpgsqlCommand(lopaSql, conn);
        lopaCmd.Parameters.AddWithValue("@incidentId", incidentId);

        await using var lopaReader = await lopaCmd.ExecuteReaderAsync();
        dto.RelatedLopaStudyIds = new List<string>();
        dto.RelatedLopaScenarioIds = new List<string>();

        while (lopaReader.Read())
        {
            dto.RelatedLopaStudyIds.Add(lopaReader["lopa_study_id"].ToString());
            dto.RelatedLopaScenarioIds.Add(lopaReader["lopa_scenario_id"].ToString());
        }

        // Get related BowTie mappings
        const string bowTieSql = @"
            SELECT DISTINCT bowtie_diagram_id
            FROM incident_bowtie_mappings
            WHERE incident_id = @incidentId";

        await using var bowTieCmd = new NpgsqlCommand(bowTieSql, conn);
        bowTieCmd.Parameters.AddWithValue("@incidentId", incidentId);

        await using var bowTieReader = await bowTieCmd.ExecuteReaderAsync();
        dto.RelatedBowTieDiagramIds = new List<string>();

        while (bowTieReader.Read())
        {
            dto.RelatedBowTieDiagramIds.Add(bowTieReader["bowtie_diagram_id"].ToString());
        }

        return dto;
    }

    public async Task<List<IncidentWithBarriersDto>> GetIncidentsAffectedByBarrierStatusChangeAsync(string barrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT DISTINCT i.* FROM incidents i
            INNER JOIN incident_barriers ib ON i.id = ib.incident_id
            WHERE ib.barrier_id = @barrierId AND i.deleted = FALSE
            ORDER BY i.date_occurred DESC";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@barrierId", barrierId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var incidents = new List<IncidentWithBarriersDto>();

        while (reader.Read())
        {
            var incidentId = reader["id"].ToString();
            var incident = await GetIncidentWithBarriersAsync(incidentId);
            if (incident != null) incidents.Add(incident);
        }

        return incidents;
    }

    // ─────────────────────────────────────────────────────────────────────────────────
    // IMPACT ANALYSIS
    // ─────────────────────────────────────────────────────────────────────────────────

    public async Task<BarrierImpactDto> GetBarrierImpactAsync(string barrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        // Single CTE query replaces 8 sequential round-trips
        const string sql = @"
            WITH b AS (
                SELECT id, barrier_name, status, effectiveness_rating
                FROM barriers WHERE id = @barrierId AND deleted = FALSE
            ),
            hazop_study_count AS (
                SELECT COUNT(DISTINCT h.id) AS cnt
                FROM hazop_studies h
                INNER JOIN hazop_deviations hd ON h.id = hd.study_id
                INNER JOIN incident_hazop_mappings ihm ON hd.id = ihm.hazop_deviation_id
                INNER JOIN incident_barriers ib ON ihm.incident_id = ib.incident_id
                WHERE ib.barrier_id = @barrierId
            ),
            hazop_dev_count AS (
                SELECT COUNT(DISTINCT hd.id) AS cnt
                FROM hazop_deviations hd
                INNER JOIN incident_hazop_mappings ihm ON hd.id = ihm.hazop_deviation_id
                INNER JOIN incident_barriers ib ON ihm.incident_id = ib.incident_id
                WHERE ib.barrier_id = @barrierId
            ),
            lopa_study_count AS (
                SELECT COUNT(DISTINCT ls.id) AS cnt
                FROM lopa_studies ls
                INNER JOIN lopa_scenarios lsc ON ls.id = lsc.study_id
                INNER JOIN incident_lopa_mappings ilm ON lsc.id = ilm.lopa_scenario_id
                INNER JOIN incident_barriers ib ON ilm.incident_id = ib.incident_id
                WHERE ib.barrier_id = @barrierId
            ),
            lopa_scenario_count AS (
                SELECT COUNT(DISTINCT lsc.id) AS cnt
                FROM lopa_scenarios lsc
                INNER JOIN incident_lopa_mappings ilm ON lsc.id = ilm.lopa_scenario_id
                INNER JOIN incident_barriers ib ON ilm.incident_id = ib.incident_id
                WHERE ib.barrier_id = @barrierId
            ),
            lopa_ipl_count AS (
                SELECT COUNT(DISTINCT li.id) AS cnt
                FROM lopa_ipls li
                WHERE li.id = (SELECT lopa_ipl_id FROM barriers WHERE id = @barrierId)
            ),
            bowtie_count AS (
                SELECT COUNT(DISTINCT bd.id) AS cnt
                FROM bowtie_diagrams bd
                INNER JOIN bowtie_barriers bb ON bd.id = bb.diagram_id
                INNER JOIN barriers bx ON bb.id = bx.bowtie_barrier_id
                WHERE bx.id = @barrierId
            ),
            incident_count AS (
                SELECT COUNT(DISTINCT i.id) AS cnt
                FROM incidents i
                INNER JOIN incident_barriers ib ON i.id = ib.incident_id
                WHERE ib.barrier_id = @barrierId
            ),
            incident_nums AS (
                SELECT ARRAY_AGG(DISTINCT i.incident_number) AS nums
                FROM incidents i
                INNER JOIN incident_barriers ib ON i.id = ib.incident_id
                WHERE ib.barrier_id = @barrierId
            )
            SELECT
                b.id, b.barrier_name, b.status, b.effectiveness_rating,
                (SELECT cnt FROM hazop_study_count)    AS linked_hazop_studies,
                (SELECT cnt FROM hazop_dev_count)      AS linked_hazop_deviations,
                (SELECT cnt FROM lopa_study_count)     AS linked_lopa_studies,
                (SELECT cnt FROM lopa_scenario_count)  AS linked_lopa_scenarios,
                (SELECT cnt FROM lopa_ipl_count)       AS linked_lopa_ipls,
                (SELECT cnt FROM bowtie_count)         AS linked_bowtie_diagrams,
                (SELECT cnt FROM incident_count)       AS linked_incidents,
                (SELECT nums FROM incident_nums)       AS incident_numbers
            FROM b";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@barrierId", barrierId);

        await using var reader = await cmd.ExecuteReaderAsync();
        if (!reader.Read()) return new BarrierImpactDto { BarrierId = barrierId };

        var dto = new BarrierImpactDto
        {
            BarrierId              = barrierId,
            BarrierName            = reader["barrier_name"] as string,
            Status                 = reader["status"] as string,
            EffectivenessRating    = reader["effectiveness_rating"] is DBNull ? null : (decimal?)reader["effectiveness_rating"],
            LinkedHazopStudies     = reader["linked_hazop_studies"]    is DBNull ? 0 : Convert.ToInt32(reader["linked_hazop_studies"]),
            LinkedHazopDeviations  = reader["linked_hazop_deviations"] is DBNull ? 0 : Convert.ToInt32(reader["linked_hazop_deviations"]),
            LinkedLopaStudies      = reader["linked_lopa_studies"]     is DBNull ? 0 : Convert.ToInt32(reader["linked_lopa_studies"]),
            LinkedLopaScenarios    = reader["linked_lopa_scenarios"]   is DBNull ? 0 : Convert.ToInt32(reader["linked_lopa_scenarios"]),
            LinkedLopaIpls         = reader["linked_lopa_ipls"]        is DBNull ? 0 : Convert.ToInt32(reader["linked_lopa_ipls"]),
            LinkedBowTieDiagrams   = reader["linked_bowtie_diagrams"]  is DBNull ? 0 : Convert.ToInt32(reader["linked_bowtie_diagrams"]),
            LinkedIncidents        = reader["linked_incidents"]         is DBNull ? 0 : Convert.ToInt32(reader["linked_incidents"]),
            RelatedIncidentNumbers = new List<string>(),
        };

        if (reader["incident_numbers"] is string[] nums)
            dto.RelatedIncidentNumbers?.AddRange(nums.Where(n => n != null));

        return dto;
    }

    public async Task<IncidentImpactDto> GetIncidentImpactAsync(string incidentId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        // Single CTE replaces 7 sequential round-trips
        const string sql = @"
            WITH inc AS (
                SELECT id, incident_number, title, date_occurred, severity_actual
                FROM incidents WHERE id = @incidentId AND deleted = FALSE
            ),
            barrier_counts AS (
                SELECT
                    COUNT(*)::int                                                    AS total,
                    COUNT(*) FILTER (WHERE b.critical_flag = TRUE)::int             AS critical,
                    AVG(ib.contribution_to_incident)                                AS avg_contribution,
                    ARRAY_AGG(DISTINCT ib.barrier_id)                               AS barrier_ids
                FROM incident_barriers ib
                LEFT JOIN barriers b ON ib.barrier_id = b.id
                WHERE ib.incident_id = @incidentId
            ),
            lopa_ids AS (
                SELECT ARRAY_AGG(DISTINCT lopa_study_id) AS ids
                FROM incident_lopa_mappings WHERE incident_id = @incidentId
            ),
            bowtie_ids AS (
                SELECT ARRAY_AGG(DISTINCT bowtie_diagram_id) AS ids
                FROM incident_bowtie_mappings WHERE incident_id = @incidentId
            )
            SELECT
                inc.id, inc.incident_number, inc.title, inc.date_occurred, inc.severity_actual,
                (SELECT total              FROM barrier_counts) AS barriers_involved,
                (SELECT critical           FROM barrier_counts) AS critical_barriers,
                (SELECT avg_contribution   FROM barrier_counts) AS avg_contribution,
                (SELECT barrier_ids        FROM barrier_counts) AS barrier_ids,
                (SELECT ids                FROM lopa_ids)       AS lopa_study_ids,
                (SELECT ids                FROM bowtie_ids)     AS bowtie_diagram_ids
            FROM inc";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@incidentId", incidentId);

        await using var reader = await cmd.ExecuteReaderAsync();
        if (!reader.Read()) return new IncidentImpactDto { IncidentId = incidentId };

        var dto = new IncidentImpactDto
        {
            IncidentId                       = incidentId,
            IncidentNumber                   = reader["incident_number"] as string,
            Title                            = reader["title"] as string,
            DateOccurred                     = reader["date_occurred"] is DBNull ? null : (DateTime?)reader["date_occurred"],
            SeverityActual                   = reader["severity_actual"] is DBNull ? 0 : (int)reader["severity_actual"],
            BarriersInvolved                 = reader["barriers_involved"]  is DBNull ? 0 : Convert.ToInt32(reader["barriers_involved"]),
            CriticalBarriersAffected         = reader["critical_barriers"]  is DBNull ? 0 : Convert.ToInt32(reader["critical_barriers"]),
            AverageBarrierFailureContribution= reader["avg_contribution"]   is DBNull ? null : (decimal?)Convert.ToDecimal(reader["avg_contribution"]),
            AffectedBarrierIds               = new List<string>(),
            AffectedLopaStudyIds             = new List<string>(),
            AffectedBowTieDiagramIds         = new List<string>(),
        };

        if (reader["barrier_ids"]       is string[] barrierIds)   dto.AffectedBarrierIds?.AddRange(barrierIds.Where(x => x != null));
        if (reader["lopa_study_ids"]    is string[] lopaIds)       dto.AffectedLopaStudyIds?.AddRange(lopaIds.Where(x => x != null));
        if (reader["bowtie_diagram_ids"]is string[] bowTieIds)     dto.AffectedBowTieDiagramIds?.AddRange(bowTieIds.Where(x => x != null));

        return dto;
    }

    public async Task<List<BarrierImpactDto>> AnalyzeBarrierFailureImpactAsync(string barrierId, DateTime fromDate, DateTime toDate)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT DISTINCT b.id, b.barrier_name, b.status, b.effectiveness_rating
            FROM barriers b
            INNER JOIN incident_barriers ib ON b.id = ib.barrier_id
            INNER JOIN incidents i ON ib.incident_id = i.id
            WHERE b.id = @barrierId AND i.date_occurred BETWEEN @fromDate AND @toDate
            AND b.deleted = FALSE";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@barrierId", barrierId);
        cmd.Parameters.AddWithValue("@fromDate", fromDate);
        cmd.Parameters.AddWithValue("@toDate", toDate);

        await using var reader = await cmd.ExecuteReaderAsync();
        var impacts = new List<BarrierImpactDto>();

        while (reader.Read())
        {
            var barrierIdStr = reader["id"].ToString();
            var impact = await GetBarrierImpactAsync(barrierIdStr);
            impacts.Add(impact);
        }

        return impacts;
    }

    // ─────────────────────────────────────────────────────────────────────────────────
    // CROSS-REFERENCE OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────────────

    public async Task<BarrierCrossReferenceDto> GetBarrierCrossReferencesAsync(string barrierId)
    {
        var dto = new BarrierCrossReferenceDto
        {
            BarrierId = barrierId,
            LinkedLopaIpls = new List<LopaIplDto>(),
            LinkedBowTieBarriers = new List<BowTieBarrierDto>(),
            LinkedIncidents = new List<IncidentDto>()
        };

        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        // Get linked LOPA IPLs
        const string lopaIplsSql = @"
            SELECT DISTINCT li.id, li.ipl_name, li.ipl_type
            FROM lopa_ipls li
            INNER JOIN barriers b ON li.id = b.lopa_ipl_id
            WHERE b.id = @barrierId";

        await using var lopaIplsCmd = new NpgsqlCommand(lopaIplsSql, conn);
        lopaIplsCmd.Parameters.AddWithValue("@barrierId", barrierId);

        await using var lopaIplsReader = await lopaIplsCmd.ExecuteReaderAsync();
        while (lopaIplsReader.Read())
        {
            dto.LinkedLopaIpls?.Add(new LopaIplDto
            {
                Id = lopaIplsReader["id"].ToString(),
                IplName = lopaIplsReader["ipl_name"] as string,
                IplType = lopaIplsReader["ipl_type"] as string
            });
        }

        // Get linked BowTie barriers
        const string bowTieBarriersSql = @"
            SELECT DISTINCT bb.id, bb.description, bb.type
            FROM bowtie_barriers bb
            INNER JOIN barriers b ON bb.id = b.bowtie_barrier_id
            WHERE b.id = @barrierId";

        await using var bowTieBarriersCmd = new NpgsqlCommand(bowTieBarriersSql, conn);
        bowTieBarriersCmd.Parameters.AddWithValue("@barrierId", barrierId);

        await using var bowTieBarriersReader = await bowTieBarriersCmd.ExecuteReaderAsync();
        while (bowTieBarriersReader.Read())
        {
            dto.LinkedBowTieBarriers?.Add(new BowTieBarrierDto
            {
                Id = bowTieBarriersReader["id"].ToString(),
                Description = bowTieBarriersReader["description"] as string,
                Type = bowTieBarriersReader["type"] as string
            });
        }

        // Get linked incidents
        const string incidentsSql = @"
            SELECT DISTINCT i.id, i.incident_number, i.title
            FROM incidents i
            INNER JOIN incident_barriers ib ON i.id = ib.incident_id
            WHERE ib.barrier_id = @barrierId AND i.deleted = FALSE";

        await using var incidentsCmd = new NpgsqlCommand(incidentsSql, conn);
        incidentsCmd.Parameters.AddWithValue("@barrierId", barrierId);

        await using var incidentsReader = await incidentsCmd.ExecuteReaderAsync();
        while (incidentsReader.Read())
        {
            dto.LinkedIncidents?.Add(new IncidentDto
            {
                Id = incidentsReader["id"].ToString(),
                IncidentNumber = incidentsReader["incident_number"] as string,
                Title = incidentsReader["title"] as string
            });
        }

        dto.TotalReferences = (dto.LinkedLopaIpls?.Count ?? 0) + (dto.LinkedBowTieBarriers?.Count ?? 0) + (dto.LinkedIncidents?.Count ?? 0);

        return dto;
    }

    public async Task<List<BarrierWithLinksDto>> GetBarriersForHazopStudyAsync(string hazopStudyId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT DISTINCT b.*, li.ipl_name as lopa_ipl_name
            FROM barriers b
            INNER JOIN incident_barriers ib ON b.id = ib.barrier_id
            INNER JOIN incidents i ON ib.incident_id = i.id
            INNER JOIN incident_hazop_mappings ihm ON i.id = ihm.incident_id
            LEFT JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
            WHERE ihm.hazop_study_id = @studyId AND b.deleted = FALSE";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@studyId", hazopStudyId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var barriers = new List<BarrierWithLinksDto>();

        while (reader.Read())
        {
            barriers.Add(MapBarrierWithLinksDto(reader));
        }

        foreach (var barrier in barriers)
        {
            barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        }

        return barriers;
    }

    public async Task<List<BarrierWithLinksDto>> GetBarriersForHazopDeviationAsync(string hazopDeviationId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT DISTINCT b.*, li.ipl_name as lopa_ipl_name
            FROM barriers b
            INNER JOIN incident_barriers ib ON b.id = ib.barrier_id
            INNER JOIN incidents i ON ib.incident_id = i.id
            INNER JOIN incident_hazop_mappings ihm ON i.id = ihm.incident_id
            LEFT JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
            WHERE ihm.hazop_deviation_id = @deviationId AND b.deleted = FALSE";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@deviationId", hazopDeviationId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var barriers = new List<BarrierWithLinksDto>();

        while (reader.Read())
        {
            barriers.Add(MapBarrierWithLinksDto(reader));
        }

        foreach (var barrier in barriers)
        {
            barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        }

        return barriers;
    }

    public async Task<List<BarrierWithLinksDto>> GetBarriersForBowTieDiagramAsync(string bowTieDiagramId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT DISTINCT b.*, bd.title as bowtie_diagram_title
            FROM barriers b
            INNER JOIN bowtie_barriers bb ON b.bowtie_barrier_id = bb.id
            INNER JOIN bowtie_diagrams bd ON bb.diagram_id = bd.id
            WHERE bd.id = @diagramId AND b.deleted = FALSE";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@diagramId", bowTieDiagramId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var barriers = new List<BarrierWithLinksDto>();

        while (reader.Read())
        {
            barriers.Add(MapBarrierWithLinksDto(reader));
        }

        foreach (var barrier in barriers)
        {
            barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        }

        return barriers;
    }

    // ─────────────────────────────────────────────────────────────────────────────────
    // SYNCHRONIZATION OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────────────

    public async Task<SyncResultDto> SyncBarrierStatusAsync(string barrierId, string newStatus, string reason, string changedBy)
    {
        var result = new SyncResultDto
        {
            Success = false,
            SyncedLopaIpls = new List<string>(),
            SyncedBowTieBarriers = new List<string>(),
            AuditLogIds = new List<string>()
        };

        try
        {
            // Update barrier
            result.UpdatedBarrier = await UpdateBarrierStatusAsync(barrierId, newStatus, reason, null, changedBy);

            // Update LOPA IPL if linked
            const string lopaIplSql = "SELECT lopa_ipl_id FROM barriers WHERE id = @id";
            await using var lopaIplCmd = new NpgsqlCommand(lopaIplSql, new NpgsqlConnection(_connectionString));
            lopaIplCmd.Parameters.AddWithValue("@id", barrierId);
            await lopaIplCmd.Connection.OpenAsync();
            var lopaIplId = await lopaIplCmd.ExecuteScalarAsync();

            if (lopaIplId != null && lopaIplId != DBNull.Value)
            {
                result.SyncedLopaIpls?.Add(lopaIplId.ToString());
            }

            // Update BowTie barrier if linked
            const string bowTieBarrierSql = "SELECT bowtie_barrier_id FROM barriers WHERE id = @id";
            await using var bowTieBarrierCmd = new NpgsqlCommand(bowTieBarrierSql, new NpgsqlConnection(_connectionString));
            bowTieBarrierCmd.Parameters.AddWithValue("@id", barrierId);
            await bowTieBarrierCmd.Connection.OpenAsync();
            var bowTieBarrierId = await bowTieBarrierCmd.ExecuteScalarAsync();

            if (bowTieBarrierId != null && bowTieBarrierId != DBNull.Value)
            {
                result.SyncedBowTieBarriers?.Add(bowTieBarrierId.ToString());
            }

            result.Success = true;
            result.Message = "Barrier status synchronized successfully";
        }
        catch (Exception ex)
        {
            result.Success = false;
            result.Message = $"Synchronization failed: {ex.Message}";
        }

        return result;
    }

    public async Task<List<string>> GetBarriersSyncRequiredAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT DISTINCT b.id FROM barriers b
            WHERE (b.status = @failed OR b.status = @degraded)
            AND b.deleted = FALSE";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@failed", "Failed");
        cmd.Parameters.AddWithValue("@degraded", "Degraded");

        await using var reader = await cmd.ExecuteReaderAsync();
        var barrierIds = new List<string>();

        while (reader.Read())
        {
            barrierIds.Add(reader[0].ToString());
        }

        return barrierIds;
    }

    // ─────────────────────────────────────────────────────────────────────────────────
    // SUMMARY AND ANALYTICS
    // ─────────────────────────────────────────────────────────────────────────────────

    public async Task<BarrierSummaryDto> GetBarrierSummaryAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        var dto = new BarrierSummaryDto
        {
            BarrierTypeDistribution = new Dictionary<string, int>(),
            SilLevelDistribution = new Dictionary<string, int>()
        };

        // Total barriers
        const string totalSql = "SELECT COUNT(*) FROM barriers WHERE deleted = FALSE";
        await using var totalCmd = new NpgsqlCommand(totalSql, conn);
        dto.TotalBarriers = (int?)(await totalCmd.ExecuteScalarAsync() ?? 0) ?? 0;

        // Barriers by status
        const string statusSql = @"
            SELECT status, COUNT(*) as count FROM barriers
            WHERE deleted = FALSE GROUP BY status";

        await using var statusCmd = new NpgsqlCommand(statusSql, conn);
        await using var statusReader = await statusCmd.ExecuteReaderAsync();

        while (statusReader.Read())
        {
            var status = statusReader["status"].ToString();
            var count = (int)statusReader["count"];

            switch (status)
            {
                case "Active":
                    dto.ActiveBarriers = count;
                    break;
                case "Degraded":
                    dto.DegradedBarriers = count;
                    break;
                case "Failed":
                    dto.FailedBarriers = count;
                    break;
                case "OutOfService":
                    dto.OutOfServiceBarriers = count;
                    break;
            }
        }

        // Critical barriers
        const string criticalSql = "SELECT COUNT(*) FROM barriers WHERE critical_flag = TRUE AND deleted = FALSE";
        await using var criticalCmd = new NpgsqlCommand(criticalSql, conn);
        dto.CriticalBarriers = (int?)(await criticalCmd.ExecuteScalarAsync() ?? 0) ?? 0;

        // Average effectiveness rating
        const string avgEffectivenessSql = "SELECT AVG(effectiveness_rating) FROM barriers WHERE deleted = FALSE";
        await using var avgEffectivenessCmd = new NpgsqlCommand(avgEffectivenessSql, conn);
        var avgEffectivenessResult = await avgEffectivenessCmd.ExecuteScalarAsync();
        dto.AverageEffectivenessRating = avgEffectivenessResult != null && avgEffectivenessResult != DBNull.Value ? (decimal?)(double)avgEffectivenessResult ?? 0 : 0;

        // Barriers needing maintenance
        const string maintenanceSql = @"
            SELECT COUNT(*) FROM barriers
            WHERE next_test_due <= NOW() AND deleted = FALSE";

        await using var maintenanceCmd = new NpgsqlCommand(maintenanceSql, conn);
        var maintenanceResult = await maintenanceCmd.ExecuteScalarAsync();
        dto.BarriersNeedingMaintenance = maintenanceResult != null ? (int?)(maintenanceResult) ?? 0 : 0;

        // Barriers overdue
        dto.BarriersOverdue = dto.BarriersNeedingMaintenance;

        // Barrier type distribution
        const string typeSql = @"
            SELECT barrier_type, COUNT(*) as count FROM barriers
            WHERE deleted = FALSE GROUP BY barrier_type";

        await using var typeCmd = new NpgsqlCommand(typeSql, conn);
        await using var typeReader = await typeCmd.ExecuteReaderAsync();

        while (typeReader.Read())
        {
            dto.BarrierTypeDistribution![typeReader["barrier_type"].ToString()] = (int)typeReader["count"];
        }

        // SIL level distribution
        const string silSql = @"
            SELECT sil_level, COUNT(*) as count FROM barriers
            WHERE sil_level IS NOT NULL AND deleted = FALSE GROUP BY sil_level";

        await using var silCmd = new NpgsqlCommand(silSql, conn);
        await using var silReader = await silCmd.ExecuteReaderAsync();

        while (silReader.Read())
        {
            dto.SilLevelDistribution![$"SIL{silReader["sil_level"]}"] = (int)silReader["count"];
        }

        return dto;
    }

    public async Task<List<BarrierWithLinksDto>> GetCriticalBarriersAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT b.*, li.ipl_name as lopa_ipl_name
            FROM barriers b
            LEFT JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
            WHERE b.critical_flag = TRUE AND b.deleted = FALSE
            ORDER BY b.barrier_name";

        await using var cmd = new NpgsqlCommand(sql, conn);
        await using var reader = await cmd.ExecuteReaderAsync();

        var barriers = new List<BarrierWithLinksDto>();
        while (reader.Read())
        {
            barriers.Add(MapBarrierWithLinksDto(reader));
        }

        foreach (var barrier in barriers)
        {
            barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        }

        return barriers;
    }

    public async Task<List<BarrierWithLinksDto>> GetBarriersNeedingMaintenanceAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT b.*, li.ipl_name as lopa_ipl_name
            FROM barriers b
            LEFT JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
            WHERE (next_test_due IS NULL OR next_test_due <= NOW()) AND b.deleted = FALSE
            ORDER BY b.next_test_due ASC";

        await using var cmd = new NpgsqlCommand(sql, conn);
        await using var reader = await cmd.ExecuteReaderAsync();

        var barriers = new List<BarrierWithLinksDto>();
        while (reader.Read())
        {
            barriers.Add(MapBarrierWithLinksDto(reader));
        }

        foreach (var barrier in barriers)
        {
            barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        }

        return barriers;
    }

    public async Task<List<BarrierWithLinksDto>> GetBarriersOverdueAsync()
    {
        return await GetBarriersNeedingMaintenanceAsync();
    }

    public async Task<List<BarrierWithLinksDto>> GetBarriersByStatusAsync(string status)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT b.*, li.ipl_name as lopa_ipl_name
            FROM barriers b
            LEFT JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
            WHERE b.status = @status AND b.deleted = FALSE
            ORDER BY b.barrier_name";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@status", status);
        await using var reader = await cmd.ExecuteReaderAsync();

        var barriers = new List<BarrierWithLinksDto>();
        while (reader.Read())
        {
            barriers.Add(MapBarrierWithLinksDto(reader));
        }

        foreach (var barrier in barriers)
        {
            barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        }

        return barriers;
    }

    public async Task<List<BarrierWithLinksDto>> GetBarriersByTypeAsync(string barrierType)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT b.*, li.ipl_name as lopa_ipl_name
            FROM barriers b
            LEFT JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
            WHERE b.barrier_type = @type AND b.deleted = FALSE
            ORDER BY b.barrier_name";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@type", barrierType);
        await using var reader = await cmd.ExecuteReaderAsync();

        var barriers = new List<BarrierWithLinksDto>();
        while (reader.Read())
        {
            barriers.Add(MapBarrierWithLinksDto(reader));
        }

        foreach (var barrier in barriers)
        {
            barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        }

        return barriers;
    }

    // ─────────────────────────────────────────────────────────────────────────────────
    // SEARCH AND FILTER
    // ─────────────────────────────────────────────────────────────────────────────────

    public async Task<List<BarrierWithLinksDto>> SearchBarriersAsync(string searchTerm)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT b.*, li.ipl_name as lopa_ipl_name
            FROM barriers b
            LEFT JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
            WHERE (b.barrier_name ILIKE @search OR b.description ILIKE @search 
                   OR b.barrier_type ILIKE @search OR b.owner_discipline ILIKE @search)
            AND b.deleted = FALSE
            ORDER BY b.barrier_name";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@search", $"%{searchTerm}%");
        await using var reader = await cmd.ExecuteReaderAsync();

        var barriers = new List<BarrierWithLinksDto>();
        while (reader.Read())
        {
            barriers.Add(MapBarrierWithLinksDto(reader));
        }

        foreach (var barrier in barriers)
        {
            barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        }

        return barriers;
    }

    public async Task<List<BarrierWithLinksDto>> FilterBarriersAsync(Dictionary<string, object> filters)
    {
        var sql = new StringBuilder(@"
            SELECT b.*, li.ipl_name as lopa_ipl_name
            FROM barriers b
            LEFT JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
            WHERE b.deleted = FALSE");

        var parameters = new List<NpgsqlParameter>();

        if (filters.TryGetValue("status", out var statusFilter))
        {
            sql.Append(" AND b.status = @status");
            parameters.Add(new NpgsqlParameter("@status", statusFilter));
        }

        if (filters.TryGetValue("type", out var typeFilter))
        {
            sql.Append(" AND b.barrier_type = @type");
            parameters.Add(new NpgsqlParameter("@type", typeFilter));
        }

        if (filters.TryGetValue("criticalOnly", out var criticalFilter) && (bool)criticalFilter)
        {
            sql.Append(" AND b.critical_flag = TRUE");
        }

        if (filters.TryGetValue("silLevel", out var silFilter))
        {
            sql.Append(" AND b.sil_level = @silLevel");
            parameters.Add(new NpgsqlParameter("@silLevel", silFilter));
        }

        sql.Append(" ORDER BY b.barrier_name");

        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        await using var cmd = new NpgsqlCommand(sql.ToString(), conn);
        cmd.Parameters.AddRange(parameters.ToArray());

        await using var reader = await cmd.ExecuteReaderAsync();

        var barriers = new List<BarrierWithLinksDto>();
        while (reader.Read())
        {
            barriers.Add(MapBarrierWithLinksDto(reader));
        }

        foreach (var barrier in barriers)
        {
            barrier.StatusHistory = await GetBarrierStatusHistoryAsync(barrier.Id ?? "");
        }

        return barriers;
    }

    // ─────────────────────────────────────────────────────────────────────────────────
    // HELPER METHODS
    // ─────────────────────────────────────────────────────────────────────────────────

    private BarrierDto MapBarrierDto(NpgsqlDataReader reader)
    {
        return new BarrierDto
        {
            Id = reader["id"].ToString(),
            BarrierName = reader["barrier_name"] as string,
            BarrierType = reader["barrier_type"] as string,
            Description = reader["description"] as string,
            OwnerDiscipline = reader["owner_discipline"] as string,
            OwnerContact = reader["owner_contact"] as string,
            MaintenanceFrequency = reader["maintenance_frequency"] as string,
            LastTested = reader["last_tested"] is DBNull ? null : (DateTime?)reader["last_tested"],
            NextTestDue = reader["next_test_due"] is DBNull ? null : (DateTime?)reader["next_test_due"],
            EffectivenessRating = reader["effectiveness_rating"] is DBNull ? null : (decimal?)reader["effectiveness_rating"],
            Status = reader["status"] as string,
            FailureMode = reader["failure_mode"] as string,
            FailureReason = reader["failure_reason"] as string,
            FailureDate = reader["failure_date"] is DBNull ? null : (DateTime?)reader["failure_date"],
            RemediationPlan = reader["remediation_plan"] as string,
            RemediationDueDate = reader["remediation_due_date"] is DBNull ? null : (DateTime?)reader["remediation_due_date"],
            PfdActual = reader["pfd_actual"] is DBNull ? null : (decimal?)reader["pfd_actual"],
            SilLevel = reader["sil_level"] is DBNull ? null : (int?)reader["sil_level"],
            DocumentationRef = reader["documentation_ref"] as string,
            CriticalFlag = reader["critical_flag"] is DBNull ? false : (bool)reader["critical_flag"],
            CreatedAt = reader["created_at"] is DBNull ? null : (DateTime?)reader["created_at"],
            UpdatedAt = reader["updated_at"] is DBNull ? null : (DateTime?)reader["updated_at"],
            UpdatedBy = reader["updated_by"] as string,
            Deleted = reader["deleted"] is DBNull ? false : (bool)reader["deleted"]
        };
    }

    private BarrierWithLinksDto MapBarrierWithLinksDto(NpgsqlDataReader reader)
    {
        var baseDto = MapBarrierDto(reader);
        return new BarrierWithLinksDto
        {
            Id = baseDto.Id,
            BarrierName = baseDto.BarrierName,
            BarrierType = baseDto.BarrierType,
            Description = baseDto.Description,
            OwnerDiscipline = baseDto.OwnerDiscipline,
            OwnerContact = baseDto.OwnerContact,
            MaintenanceFrequency = baseDto.MaintenanceFrequency,
            LastTested = baseDto.LastTested,
            NextTestDue = baseDto.NextTestDue,
            EffectivenessRating = baseDto.EffectivenessRating,
            Status = baseDto.Status,
            FailureMode = baseDto.FailureMode,
            FailureReason = baseDto.FailureReason,
            FailureDate = baseDto.FailureDate,
            RemediationPlan = baseDto.RemediationPlan,
            RemediationDueDate = baseDto.RemediationDueDate,
            PfdActual = baseDto.PfdActual,
            SilLevel = baseDto.SilLevel,
            DocumentationRef = baseDto.DocumentationRef,
            CriticalFlag = baseDto.CriticalFlag,
            CreatedAt = baseDto.CreatedAt,
            UpdatedAt = baseDto.UpdatedAt,
            UpdatedBy = baseDto.UpdatedBy,
            Deleted = baseDto.Deleted,
            LopaIplId = reader["lopa_ipl_id"] is DBNull ? null : reader["lopa_ipl_id"].ToString(),
            LopaIplName = reader["lopa_ipl_name"] as string,
            BowTieBarrierId = reader["bowtie_barrier_id"] is DBNull ? null : reader["bowtie_barrier_id"].ToString(),
            BowTieDiagramTitle = reader["bowtie_diagram_title"] as string
        };
    }
}
