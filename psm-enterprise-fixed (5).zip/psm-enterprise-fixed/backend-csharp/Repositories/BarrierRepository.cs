using Npgsql;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

// ════════════════════════════════════════════════════════════════════════════════════
// BARRIER REPOSITORY IMPLEMENTATION
// ════════════════════════════════════════════════════════════════════════════════════

public class BarrierRepository : IBarrierRepository
{
    private readonly string _connectionString;

    public BarrierRepository(IConfiguration config)
    {
        _connectionString = config.GetConnectionString("DefaultConnection")!;
    }

    public async Task<BarrierDto> CreateBarrierAsync(
        string id, string lopaIplId, string? bowTieBarrierId, string barrierName,
        string barrierType, string? description, string? ownerDiscipline,
        string? ownerContact, string? maintenanceFrequency, DateTime? lastTested,
        DateTime? nextTestDue, decimal? effectivenessRating, string status,
        string? failureMode, string? documentationRef, int? silLevel,
        bool criticalFlag, string? data)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO barriers (
                id, lopa_ipl_id, bowtie_barrier_id, barrier_name, barrier_type,
                description, owner_discipline, owner_contact, maintenance_frequency,
                last_tested, next_test_due, effectiveness_rating, status,
                failure_mode, documentation_ref, sil_level, critical_flag, data
            ) VALUES (
                @id, @lopaIplId, @bowTieBarrierId, @barrierName, @barrierType,
                @description, @ownerDiscipline, @ownerContact, @maintenanceFrequency,
                @lastTested, @nextTestDue, @effectivenessRating, @status,
                @failureMode, @documentationRef, @silLevel, @criticalFlag, @data::jsonb
            ) RETURNING *;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@lopaIplId", lopaIplId);
        cmd.Parameters.AddWithValue("@bowTieBarrierId", bowTieBarrierId ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@barrierName", barrierName);
        cmd.Parameters.AddWithValue("@barrierType", barrierType);
        cmd.Parameters.AddWithValue("@description", description ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@ownerDiscipline", ownerDiscipline ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@ownerContact", ownerContact ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@maintenanceFrequency", maintenanceFrequency ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@lastTested", lastTested ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@nextTestDue", nextTestDue ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@effectivenessRating", effectivenessRating ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@status", status);
        cmd.Parameters.AddWithValue("@failureMode", failureMode ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@documentationRef", documentationRef ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@silLevel", silLevel ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@criticalFlag", criticalFlag);
        cmd.Parameters.AddWithValue("@data", data ?? "{}");

        await using var reader = await cmd.ExecuteReaderAsync();
        reader.Read();
        return MapBarrierDto(reader);
    }

    public async Task<BarrierDto?> GetBarrierAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM barriers 
            WHERE id = @id AND deleted = FALSE;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        await using var reader = await cmd.ExecuteReaderAsync();
        return reader.Read() ? MapBarrierDto(reader) : null;
    }

    public async Task<BarrierDto?> GetBarrierByLopaIplAsync(string lopaIplId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM barriers 
            WHERE lopa_ipl_id = @lopaIplId AND deleted = FALSE;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@lopaIplId", lopaIplId);

        await using var reader = await cmd.ExecuteReaderAsync();
        return reader.Read() ? MapBarrierDto(reader) : null;
    }

    public async Task<BarrierDto?> GetBarrierByBowTieAsync(string bowTieBarrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM barriers 
            WHERE bowtie_barrier_id = @bowTieBarrierId AND deleted = FALSE;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@bowTieBarrierId", bowTieBarrierId);

        await using var reader = await cmd.ExecuteReaderAsync();
        return reader.Read() ? MapBarrierDto(reader) : null;
    }

    public async Task<IEnumerable<BarrierDto>> ListBarriersAsync(
        string? statusFilter = null, string? typeFilter = null, bool? criticalOnly = null)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        var sql = @"
            SELECT * FROM barriers 
            WHERE deleted = FALSE";

        if (!string.IsNullOrEmpty(statusFilter))
            sql += " AND status = @status";
        if (!string.IsNullOrEmpty(typeFilter))
            sql += " AND barrier_type = @type";
        if (criticalOnly.HasValue && criticalOnly.Value)
            sql += " AND critical_flag = TRUE";

        sql += " ORDER BY created_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        if (!string.IsNullOrEmpty(statusFilter))
            cmd.Parameters.AddWithValue("@status", statusFilter);
        if (!string.IsNullOrEmpty(typeFilter))
            cmd.Parameters.AddWithValue("@type", typeFilter);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<BarrierDto>();
        while (reader.Read())
            result.Add(MapBarrierDto(reader));
        return result;
    }

    public async Task<IEnumerable<BarrierWithRelatedAnalysisDto>> ListBarriersWithAnalysisAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT 
                b.*,
                COALESCE(COUNT(DISTINCT ib.incident_id), 0) as linked_incidents,
                COALESCE(COUNT(DISTINCT ihm.hazop_deviation_id), 0) as affected_hazop_scenarios,
                COALESCE(COUNT(DISTINCT ilm.lopa_scenario_id), 0) as affected_lopa_scenarios,
                COALESCE(COUNT(DISTINCT ibm.bowtie_diagram_id), 0) as affected_bowtie_diagrams
            FROM barriers b
            LEFT JOIN incident_barriers ib ON b.id = ib.barrier_id
            LEFT JOIN incidents inc ON ib.incident_id = inc.id
            LEFT JOIN incident_hazop_mappings ihm ON inc.id = ihm.incident_id
            LEFT JOIN incident_lopa_mappings ilm ON inc.id = ilm.incident_id
            LEFT JOIN incident_bowtie_mappings ibm ON inc.id = ibm.incident_id
            WHERE b.deleted = FALSE
            GROUP BY b.id
            ORDER BY b.created_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<BarrierWithRelatedAnalysisDto>();
        while (reader.Read())
            result.Add(MapBarrierWithAnalysisDto(reader));
        return result;
    }

    public async Task UpdateBarrierAsync(
        string id, string? barrierName, string? barrierType, string? description,
        string? ownerDiscipline, string? ownerContact, string? maintenanceFrequency,
        DateTime? lastTested, DateTime? nextTestDue, decimal? effectivenessRating,
        string? documentationRef, int? silLevel, bool? criticalFlag, string? data,
        string? updatedBy)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            UPDATE barriers SET
                barrier_name = COALESCE(@barrierName, barrier_name),
                barrier_type = COALESCE(@barrierType, barrier_type),
                description = COALESCE(@description, description),
                owner_discipline = COALESCE(@ownerDiscipline, owner_discipline),
                owner_contact = COALESCE(@ownerContact, owner_contact),
                maintenance_frequency = COALESCE(@maintenanceFrequency, maintenance_frequency),
                last_tested = COALESCE(@lastTested, last_tested),
                next_test_due = COALESCE(@nextTestDue, next_test_due),
                effectiveness_rating = COALESCE(@effectivenessRating, effectiveness_rating),
                documentation_ref = COALESCE(@documentationRef, documentation_ref),
                sil_level = COALESCE(@silLevel, sil_level),
                critical_flag = COALESCE(@criticalFlag, critical_flag),
                data = COALESCE(@data::jsonb, data),
                updated_by = COALESCE(@updatedBy, updated_by),
                updated_at = NOW()
            WHERE id = @id AND deleted = FALSE;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@barrierName", barrierName ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@barrierType", barrierType ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@description", description ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@ownerDiscipline", ownerDiscipline ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@ownerContact", ownerContact ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@maintenanceFrequency", maintenanceFrequency ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@lastTested", lastTested ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@nextTestDue", nextTestDue ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@effectivenessRating", effectivenessRating ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@documentationRef", documentationRef ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@silLevel", silLevel ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@criticalFlag", criticalFlag ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@data", data ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@updatedBy", updatedBy ?? (object)DBNull.Value);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<(bool success, string message)> UpdateBarrierStatusAsync(
        string id, string newStatus, string? reason, string? incidentId, string? changedBy)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        // Get current status
        const string getSql = "SELECT status FROM barriers WHERE id = @id AND deleted = FALSE;";
        await using var getCmd = new NpgsqlCommand(getSql, conn);
        getCmd.Parameters.AddWithValue("@id", id);

        var oldStatus = (string?)await getCmd.ExecuteScalarAsync();
        if (oldStatus == null)
            return (false, "Barrier not found");

        // Update barrier status
        const string updateSql = @"
            UPDATE barriers 
            SET status = @newStatus, updated_at = NOW(), updated_by = @changedBy
            WHERE id = @id AND deleted = FALSE;";

        await using var updateCmd = new NpgsqlCommand(updateSql, conn);
        updateCmd.Parameters.AddWithValue("@id", id);
        updateCmd.Parameters.AddWithValue("@newStatus", newStatus);
        updateCmd.Parameters.AddWithValue("@changedBy", changedBy ?? (object)DBNull.Value);
        await updateCmd.ExecuteNonQueryAsync();

        // Record history
        const string historySql = @"
            INSERT INTO barrier_status_history 
            (id, barrier_id, previous_status, new_status, reason, triggered_by_incident, changed_by)
            VALUES (@id, @barrierId, @previousStatus, @newStatus, @reason, @incidentId, @changedBy);";

        await using var historyCmd = new NpgsqlCommand(historySql, conn);
        historyCmd.Parameters.AddWithValue("@id", Guid.NewGuid().ToString());
        historyCmd.Parameters.AddWithValue("@barrierId", id);
        historyCmd.Parameters.AddWithValue("@previousStatus", oldStatus);
        historyCmd.Parameters.AddWithValue("@newStatus", newStatus);
        historyCmd.Parameters.AddWithValue("@reason", reason ?? (object)DBNull.Value);
        historyCmd.Parameters.AddWithValue("@incidentId", incidentId ?? (object)DBNull.Value);
        historyCmd.Parameters.AddWithValue("@changedBy", changedBy ?? (object)DBNull.Value);
        await historyCmd.ExecuteNonQueryAsync();

        return (true, "Barrier status updated successfully");
    }

    public async Task<(bool success, string message)> UpdateBarrierStatusCascadeAsync(
        string id, string newStatus, string? reason, string? incidentId, string? changedBy)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT update_barrier_status_cascade(@barrierId, @newStatus, @reason, @incidentId, @changedBy);";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@barrierId", id);
        cmd.Parameters.AddWithValue("@newStatus", newStatus);
        cmd.Parameters.AddWithValue("@reason", reason ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@incidentId", incidentId ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@changedBy", changedBy ?? (object)DBNull.Value);

        try
        {
            await cmd.ExecuteNonQueryAsync();
            return (true, "Barrier status updated with cascade");
        }
        catch (Exception ex)
        {
            return (false, $"Error: {ex.Message}");
        }
    }

    public async Task<bool> DeleteBarrierAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = "DELETE FROM barriers WHERE id = @id;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<bool> SoftDeleteBarrierAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            UPDATE barriers 
            SET deleted = TRUE, updated_at = NOW()
            WHERE id = @id;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        return await cmd.ExecuteNonQueryAsync() > 0;
    }

    public async Task<bool> BarrierExistsAsync(string id)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = "SELECT 1 FROM barriers WHERE id = @id AND deleted = FALSE;";
        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);

        return await cmd.ExecuteScalarAsync() != null;
    }

    public async Task<IEnumerable<BarrierStatusHistoryDto>> GetBarrierStatusHistoryAsync(string barrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT * FROM barrier_status_history
            WHERE barrier_id = @barrierId
            ORDER BY changed_at DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@barrierId", barrierId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<BarrierStatusHistoryDto>();
        while (reader.Read())
            result.Add(MapBarrierStatusHistoryDto(reader));
        return result;
    }

    public async Task RecordBarrierStatusChangeAsync(
        string barrierId, string previousStatus, string newStatus, string? reason,
        string? incidentId, string? changedBy)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            INSERT INTO barrier_status_history 
            (id, barrier_id, previous_status, new_status, reason, triggered_by_incident, changed_by)
            VALUES (@id, @barrierId, @previousStatus, @newStatus, @reason, @incidentId, @changedBy);";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", Guid.NewGuid().ToString());
        cmd.Parameters.AddWithValue("@barrierId", barrierId);
        cmd.Parameters.AddWithValue("@previousStatus", previousStatus);
        cmd.Parameters.AddWithValue("@newStatus", newStatus);
        cmd.Parameters.AddWithValue("@reason", reason ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@incidentId", incidentId ?? (object)DBNull.Value);
        cmd.Parameters.AddWithValue("@changedBy", changedBy ?? (object)DBNull.Value);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<int> GetCriticalBarrierCountAsync()
    {
        return (int?)await GetBarrierCountByCondition("critical_flag = TRUE") ?? 0;
    }

    public async Task<int> GetFailedBarrierCountAsync()
    {
        return (int?)await GetBarrierCountByCondition("status = 'Failed'") ?? 0;
    }

    public async Task<int> GetDegradedBarrierCountAsync()
    {
        return (int?)await GetBarrierCountByCondition("status = 'Degraded'") ?? 0;
    }

    public async Task<Dictionary<string, int>> GetBarrierStatusDistributionAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT status, COUNT(*) as count
            FROM barriers
            WHERE deleted = FALSE
            GROUP BY status
            ORDER BY count DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        await using var reader = await cmd.ExecuteReaderAsync();

        var result = new Dictionary<string, int>();
        while (reader.Read())
            result[(string)reader["status"]] = (int)reader["count"];
        return result;
    }

    public async Task<Dictionary<string, int>> GetBarrierTypeDistributionAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            SELECT barrier_type, COUNT(*) as count
            FROM barriers
            WHERE deleted = FALSE
            GROUP BY barrier_type
            ORDER BY count DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        await using var reader = await cmd.ExecuteReaderAsync();

        var result = new Dictionary<string, int>();
        while (reader.Read())
            result[(string)reader["barrier_type"]] = (int)reader["count"];
        return result;
    }

    public async Task UpdateBarrierStatusAsync(string id, UpdateBarrierStatusRequest req, string userId)
    {
        // Reuse existing UpdateBarrierStatusAsync logic with request object mapping
        var newStatus = req.new_status ?? "Unknown";
        var reason = req.reason;
        var incidentId = req.incident_id;

        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        // Get current status
        const string getSql = "SELECT status FROM barriers WHERE id = @id AND deleted = FALSE;";
        await using var getCmd = new NpgsqlCommand(getSql, conn);
        getCmd.Parameters.AddWithValue("@id", id);

        var oldStatus = (string?)await getCmd.ExecuteScalarAsync();
        if (oldStatus == null)
            return;

        // Update barrier status
        const string updateSql = @"
            UPDATE barriers 
            SET status = @newStatus, updated_at = NOW(), updated_by = @changedBy
            WHERE id = @id AND deleted = FALSE;";

        await using var updateCmd = new NpgsqlCommand(updateSql, conn);
        updateCmd.Parameters.AddWithValue("@id", id);
        updateCmd.Parameters.AddWithValue("@newStatus", newStatus);
        updateCmd.Parameters.AddWithValue("@changedBy", userId);
        await updateCmd.ExecuteNonQueryAsync();

        // Record history
        const string historySql = @"
            INSERT INTO barrier_status_history 
            (id, barrier_id, previous_status, new_status, reason, triggered_by_incident, changed_by)
            VALUES (@id, @barrierId, @previousStatus, @newStatus, @reason, @incidentId, @changedBy);";

        await using var historyCmd = new NpgsqlCommand(historySql, conn);
        historyCmd.Parameters.AddWithValue("@id", Guid.NewGuid().ToString());
        historyCmd.Parameters.AddWithValue("@barrierId", id);
        historyCmd.Parameters.AddWithValue("@previousStatus", oldStatus);
        historyCmd.Parameters.AddWithValue("@newStatus", newStatus);
        historyCmd.Parameters.AddWithValue("@reason", reason ?? (object)DBNull.Value);
        historyCmd.Parameters.AddWithValue("@incidentId", incidentId ?? (object)DBNull.Value);
        historyCmd.Parameters.AddWithValue("@changedBy", userId);
        await historyCmd.ExecuteNonQueryAsync();
    }

    public async Task<IEnumerable<BarrierImpactAnalysisDto>> GetBarrierImpactAnalysisAsync(string barrierId)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        const string sql = @"
            WITH barrier_hazop_impact AS (
                SELECT 
                    'HAZOP' as analysis_type,
                    hd.id as analysis_id,
                    hs.study_name as analysis_title,
                    hd.severity_category as severity,
                    COUNT(DISTINCT hd.id) as related_count,
                    MAX(hd.updated_at) as last_updated
                FROM barriers b
                INNER JOIN lopa_ipls li ON b.lopa_ipl_id = li.id
                INNER JOIN hazop_deviations hd ON li.hazop_deviation_id = hd.id
                INNER JOIN hazop_studies hs ON hd.hazop_study_id = hs.id
                WHERE b.id = @barrierId AND b.deleted = FALSE
                GROUP BY hd.id, hs.study_name, hd.severity_category, hd.updated_at
            ),
            barrier_lopa_impact AS (
                SELECT 
                    'LOPA' as analysis_type,
                    ls.id as analysis_id,
                    ls.study_name as analysis_title,
                    lsc.severity_category as severity,
                    COUNT(DISTINCT ls.id) as related_count,
                    MAX(lsc.updated_at) as last_updated
                FROM barriers b
                INNER JOIN lopa_ipls li ON b.id = li.id
                INNER JOIN lopa_scenarios lsc ON li.id = lsc.lopa_ipl_id
                INNER JOIN lopa_studies ls ON lsc.lopa_study_id = ls.id
                WHERE b.id = @barrierId AND b.deleted = FALSE
                GROUP BY ls.id, ls.study_name, lsc.severity_category, lsc.updated_at
            ),
            barrier_bowtie_impact AS (
                SELECT 
                    'BowTie' as analysis_type,
                    bd.id as analysis_id,
                    bd.diagram_name as analysis_title,
                    bd.top_event_severity as severity,
                    COUNT(DISTINCT bd.id) as related_count,
                    MAX(bd.updated_at) as last_updated
                FROM barriers b
                INNER JOIN bowtie_barriers bb ON b.bowtie_barrier_id = bb.id
                INNER JOIN bowtie_diagrams bd ON bb.bowtie_diagram_id = bd.id
                WHERE b.id = @barrierId AND b.deleted = FALSE
                GROUP BY bd.id, bd.diagram_name, bd.top_event_severity, bd.updated_at
            )
            SELECT analysis_type, analysis_id, analysis_title, severity, related_count, last_updated
            FROM (
                SELECT * FROM barrier_hazop_impact
                UNION ALL
                SELECT * FROM barrier_lopa_impact
                UNION ALL
                SELECT * FROM barrier_bowtie_impact
            ) AS all_impacts
            ORDER BY last_updated DESC;";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@barrierId", barrierId);

        await using var reader = await cmd.ExecuteReaderAsync();
        var result = new List<BarrierImpactAnalysisDto>();
        while (reader.Read())
        {
            result.Add(new BarrierImpactAnalysisDto
            {
                AnalysisType = reader.IsDBNull(0) ? null : reader.GetString(0),
                AnalysisId = reader.IsDBNull(1) ? null : reader.GetString(1),
                AnalysisTitle = reader.IsDBNull(2) ? null : reader.GetString(2),
                Severity = reader.IsDBNull(3) ? null : reader.GetString(3),
                RelatedCount = reader.IsDBNull(4) ? 0 : reader.GetInt32(4),
                LastUpdated = reader.IsDBNull(5) ? null : reader.GetDateTime(5)
            });
        }
        return result;
    }

    public async Task<int> GetBarrierCountAsync()
    {
        return (int?)await GetBarrierCountByCondition("1=1") ?? 0;
    }

    // Private helpers
    private async Task<object?> GetBarrierCountByCondition(string condition)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync();

        var sql = $"SELECT COUNT(*) FROM barriers WHERE deleted = FALSE AND {condition};";
        await using var cmd = new NpgsqlCommand(sql, conn);
        return await cmd.ExecuteScalarAsync();
    }

    private BarrierDto MapBarrierDto(NpgsqlDataReader reader)
    {
        return new BarrierDto
        {
            Id = reader.IsDBNull(0) ? null : reader.GetString(0),
            LopaIplId = reader.IsDBNull(1) ? null : reader.GetString(1),
            BowTieBarrierId = reader.IsDBNull(2) ? null : reader.GetString(2),
            BarrierName = reader.IsDBNull(3) ? null : reader.GetString(3),
            BarrierType = reader.IsDBNull(4) ? null : reader.GetString(4),
            Description = reader.IsDBNull(5) ? null : reader.GetString(5),
            OwnerDiscipline = reader.IsDBNull(6) ? null : reader.GetString(6),
            OwnerContact = reader.IsDBNull(7) ? null : reader.GetString(7),
            MaintenanceFrequency = reader.IsDBNull(8) ? null : reader.GetString(8),
            LastTested = reader.IsDBNull(9) ? null : reader.GetDateTime(9),
            NextTestDue = reader.IsDBNull(10) ? null : reader.GetDateTime(10),
            EffectivenessRating = reader.IsDBNull(11) ? null : reader.GetDecimal(11),
            Status = reader.IsDBNull(12) ? null : reader.GetString(12),
            FailureMode = reader.IsDBNull(13) ? null : reader.GetString(13),
            FailureReason = reader.IsDBNull(14) ? null : reader.GetString(14),
            FailureDate = reader.IsDBNull(15) ? null : reader.GetDateTime(15),
            RemediationPlan = reader.IsDBNull(16) ? null : reader.GetString(16),
            RemediationDueDate = reader.IsDBNull(17) ? null : reader.GetDateTime(17),
            PfdActual = reader.IsDBNull(18) ? null : reader.GetDecimal(18),
            SilLevel = reader.IsDBNull(19) ? null : reader.GetInt32(19),
            DocumentationRef = reader.IsDBNull(20) ? null : reader.GetString(20),
            CriticalFlag = reader.GetBoolean(21),
            CreatedAt = reader.IsDBNull(22) ? null : reader.GetDateTime(22),
            UpdatedAt = reader.IsDBNull(23) ? null : reader.GetDateTime(23),
            UpdatedBy = reader.IsDBNull(24) ? null : reader.GetString(24),
            Data = reader.IsDBNull(26) ? null : reader.GetString(26)
        };
    }

    private BarrierWithRelatedAnalysisDto MapBarrierWithAnalysisDto(NpgsqlDataReader reader)
    {
        var barrier = MapBarrierDto(reader);
        return new BarrierWithRelatedAnalysisDto
        {
            Id = barrier.Id,
            LopaIplId = barrier.LopaIplId,
            BowTieBarrierId = barrier.BowTieBarrierId,
            BarrierName = barrier.BarrierName,
            BarrierType = barrier.BarrierType,
            Description = barrier.Description,
            OwnerDiscipline = barrier.OwnerDiscipline,
            OwnerContact = barrier.OwnerContact,
            MaintenanceFrequency = barrier.MaintenanceFrequency,
            LastTested = barrier.LastTested,
            NextTestDue = barrier.NextTestDue,
            EffectivenessRating = barrier.EffectivenessRating,
            Status = barrier.Status,
            FailureMode = barrier.FailureMode,
            FailureReason = barrier.FailureReason,
            FailureDate = barrier.FailureDate,
            RemediationPlan = barrier.RemediationPlan,
            RemediationDueDate = barrier.RemediationDueDate,
            PfdActual = barrier.PfdActual,
            SilLevel = barrier.SilLevel,
            DocumentationRef = barrier.DocumentationRef,
            CriticalFlag = barrier.CriticalFlag,
            CreatedAt = barrier.CreatedAt,
            UpdatedAt = barrier.UpdatedAt,
            UpdatedBy = barrier.UpdatedBy,
            Data = barrier.Data,
            LinkedIncidents = reader.IsDBNull(27) ? 0 : reader.GetInt32(27),
            AffectedHazopScenarios = reader.IsDBNull(28) ? 0 : reader.GetInt32(28),
            AffectedLopaScenarios = reader.IsDBNull(29) ? 0 : reader.GetInt32(29),
            AffectedBowTieDiagrams = reader.IsDBNull(30) ? 0 : reader.GetInt32(30)
        };
    }

    private BarrierStatusHistoryDto MapBarrierStatusHistoryDto(NpgsqlDataReader reader)
    {
        return new BarrierStatusHistoryDto
        {
            Id = reader.IsDBNull(0) ? null : reader.GetString(0),
            BarrierId = reader.IsDBNull(1) ? null : reader.GetString(1),
            PreviousStatus = reader.IsDBNull(2) ? null : reader.GetString(2),
            NewStatus = reader.IsDBNull(3) ? null : reader.GetString(3),
            Reason = reader.IsDBNull(4) ? null : reader.GetString(4),
            TriggeredByIncident = reader.IsDBNull(5) ? null : reader.GetString(5),
            ChangedBy = reader.IsDBNull(6) ? null : reader.GetString(6),
            ChangedAt = reader.IsDBNull(7) ? null : reader.GetDateTime(7)
        };
    }
}
