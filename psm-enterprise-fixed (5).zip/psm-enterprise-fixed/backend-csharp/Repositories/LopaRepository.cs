using Dapper;
using PSM.Api.Data;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

public interface ILopaRepository
{
    // Studies
    Task<IEnumerable<LopaStudyWithCountsDto>> ListStudiesAsync(string? hazopStudyId);
    Task<LopaStudyDto?> GetStudyAsync(string id);
    Task<bool> StudyExistsAsync(string id);
    Task<string> CreateStudyAsync(string id, string title, string? hazopStudyId, string? facility,
        string? unit, string? leadEngineer, string? status, string? createdBy, string dataJson);
    Task UpdateStudyAsync(string id, string title, string? hazopStudyId, string? facility,
        string? unit, string? leadEngineer, string? status, string dataJson);
    Task SoftDeleteStudyAsync(string id);

    // Scenarios
    Task<IEnumerable<LopaScenarioDto>> ListScenariosAsync(string studyId);
    Task<LopaScenarioDto?> GetScenarioRawAsync(string id);
    Task<LopaScenarioDto?> GetScenarioAsync(string id);
    Task<bool> ScenarioExistsAsync(string id);
    Task<string> CreateScenarioAsync(string id, string studyId, string? hazopDeviationId, string scenarioNumber,
        string initiatingEvent, double initiatingFrequency, string? consequenceDescription,
        int consequenceSeverity, double targetRisk, string? notes, string dataJson);
    Task UpdateScenarioAsync(string id, string scenarioNumber, string initiatingEvent, double initiatingFrequency,
        string? consequenceDescription, int consequenceSeverity, double targetRisk, string? notes, string dataJson);
    Task SoftDeleteScenarioAsync(string id);
    Task UpdateScenarioCalcAsync(string id, double mitigatedFrequency, double riskGap, bool riskGapMet,
        double requiredRrfSis, string silRequired, double achievedRrfSis, string silAchieved,
        bool silGapMet, double pfdNonSis, double pfdSis);

    // IPLs
    Task<IEnumerable<LopaIplForCalcDto>> ListIplsForCalcAsync(string scenarioId);
    Task<IEnumerable<LopaIplDto>> ListIplsAsync(string scenarioId);
    Task<LopaIplDto?> GetIplAsync(string id);
    Task<string?> GetIplScenarioIdAsync(string id);
    Task<string> CreateIplAsync(string id, string scenarioId, string iplName, string iplType,
        string? description, double pfd, bool isValidated, string? owner, string? auditInterval);
    Task UpdateIplAsync(string id, string iplName, string iplType, string? description,
        double pfd, bool isValidated, string? owner, string? auditInterval);
    Task SoftDeleteIplAsync(string id);
    /// <summary>Back-link a LOPA IPL to the unified risk barrier created from it.</summary>
    Task UpdateIplRiskBarrierIdAsync(string iplId, string riskBarrierId);

    // SIL summary / HAZOP integration / dashboard
    Task<IEnumerable<LopaSilBandDto>> GetSilBandsAsync(string studyId);
    Task<int> CountScenariosBySilGapAsync(string studyId, bool met);
    Task<IEnumerable<HazopDeviationDto>> GetHazopDeviationsAsync(string hazopStudyId);
    Task<IEnumerable<HazopStudyDto>> GetHazopStudiesBriefAsync();
    Task<LopaDashboardSummaryDto> GetDashboardSummaryAsync();

    // Cross-module integration helpers
    /// <summary>Returns the BowTie diagram already linked to this scenario (if any), so a newly
    /// auto-created Barrier can also be wired into that diagram's barrier list.</summary>
    Task<string?> GetScenarioBowTieDiagramIdAsync(string scenarioId);
    /// <summary>Links a LOPA scenario to a BowTie diagram (set when a BowTie is created from a HAZOP
    /// deviation that already has a related LOPA scenario, or vice-versa).</summary>
    Task LinkScenarioToBowTieAsync(string scenarioId, string bowTieDiagramId);

    // Service overloads
    Task<LopaStudyDto?> GetLopaStudyByHazopAsync(string hazopStudyId);
    Task<LopaStudyDto> CreateLopaStudyAsync(string id, string title, string? hazopStudyId, string? facility, string? unit, string? leadEngineer, string? status, string? createdBy, string? dataJson);
    Task<LopaScenarioDto> CreateLopaScenarioAsync(string id, string studyId, string? hazopDeviationId, string scenarioNumber, string initiatingEvent, double initiatingFrequency, string? consequenceDescription, int consequenceSeverity, double targetRisk, string? notes, string? dataJson);
    Task<LopaStudyDto?> GetLopaStudyAsync(string id);
    Task<IEnumerable<LopaScenarioDto>> ListScenariosByStudyAsync(string studyId);
    Task<IEnumerable<LopaIplDto>> ListIplsByScenarioAsync(string scenarioId);
    Task<IEnumerable<LopaScenarioDto>> ListAllScenariosAsync();
    Task<LopaIplDto?> GetLopaIplAsync(string id);
    Task<LopaScenarioDto?> GetLopaScenarioAsync(string id);
    Task<int> GetLopaStudyCountAsync();
}

public class LopaRepository : ILopaRepository
{
    private readonly IDbHelper _db;
    public LopaRepository(IDbHelper db) => _db = db;

    // ─── Studies ────────────────────────────────────────────────────────────
    public async Task<IEnumerable<LopaStudyWithCountsDto>> ListStudiesAsync(string? hazopStudyId)
    {
        var sql = @"SELECT 
                ls.id, ls.title, ls.hazop_study_id, ls.facility, ls.unit, ls.lead_engineer,
                ls.status, ls.created_by, ls.created_at, ls.updated_at, ls.data, ls.deleted,
                (SELECT COUNT(*)::int FROM lopa_scenarios sc 
                 WHERE sc.lopa_study_id=ls.id AND sc.deleted=false) AS ScenarioCount
            FROM lopa_studies ls WHERE ls.deleted=false";
        
        if (!string.IsNullOrEmpty(hazopStudyId)) 
            sql += " AND ls.hazop_study_id=@hazopStudyId";
        sql += " ORDER BY ls.created_at DESC";
        
        return await _db.QueryAsync<LopaStudyWithCountsDto>(sql, new { hazopStudyId });
    }

    public Task<LopaStudyDto?> GetStudyAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<LopaStudyDto>(
            @"SELECT id, title, hazop_study_id, facility, unit, lead_engineer, status,
                     created_by, created_at, updated_at, data, deleted
              FROM lopa_studies WHERE id=@id AND deleted=false", 
            new { id });

    public async Task<bool> StudyExistsAsync(string id) =>
        await _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM lopa_studies WHERE id=@id AND deleted=false", new { id }) > 0;

    public async Task<string> CreateStudyAsync(string id, string title, string? hazopStudyId, string? facility,
        string? unit, string? leadEngineer, string? status, string? createdBy, string dataJson)
    {
        await _db.ExecuteAsync(@"
            INSERT INTO lopa_studies 
              (id,title,hazop_study_id,facility,unit,lead_engineer,status,created_by,data,deleted)
            VALUES 
              (@id,@title,@hazopStudyId,@facility,@unit,@leadEngineer,@status,@createdBy,@data::jsonb,false)",
            new { id, title, hazopStudyId, facility, unit, leadEngineer, status, createdBy, data = dataJson });
        return id;
    }

    public Task UpdateStudyAsync(string id, string title, string? hazopStudyId, string? facility,
        string? unit, string? leadEngineer, string? status, string dataJson) =>
        _db.ExecuteAsync(@"
            UPDATE lopa_studies 
            SET title=@title, hazop_study_id=@hazopStudyId, facility=@facility, unit=@unit,
              lead_engineer=@leadEngineer, status=@status, data=@data::jsonb, updated_at=NOW()
            WHERE id=@id AND deleted=false",
            new { id, title, hazopStudyId, facility, unit, leadEngineer, status, data = dataJson });

    public Task SoftDeleteStudyAsync(string id) =>
        _db.ExecuteAsync(
            "UPDATE lopa_studies SET deleted=true, updated_at=NOW() WHERE id=@id", new { id });

    // ─── Scenarios ──────────────────────────────────────────────────────────
    public Task<IEnumerable<LopaScenarioDto>> ListScenariosAsync(string studyId) =>
        _db.QueryAsync<LopaScenarioDto>(@"
            SELECT 
              sc.id, sc.lopa_study_id, sc.hazop_deviation_id, sc.scenario_number,
              sc.initiating_event, sc.initiating_frequency, sc.consequence_description,
              sc.consequence_severity, sc.target_risk, sc.residual_risk, sc.risk_gap,
              sc.risk_gap_met, sc.required_rrf_sis, sc.sil_required, sc.achieved_rrf_sis,
              sc.sil_achieved, sc.sil_gap_met, sc.pfd_non_sis, sc.pfd_sis, sc.notes,
              sc.created_at, sc.updated_at, sc.data, sc.deleted
            FROM lopa_scenarios sc
            WHERE sc.lopa_study_id=@studyId AND sc.deleted=false
            ORDER BY sc.scenario_number", 
            new { studyId });

    public Task<LopaScenarioDto?> GetScenarioRawAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<LopaScenarioDto>(
            @"SELECT 
                id, lopa_study_id, hazop_deviation_id, scenario_number, initiating_event,
                initiating_frequency, consequence_description, consequence_severity, target_risk,
                residual_risk, risk_gap, risk_gap_met, required_rrf_sis, sil_required,
                achieved_rrf_sis, sil_achieved, sil_gap_met, pfd_non_sis, pfd_sis, notes,
                created_at, updated_at, data, deleted
              FROM lopa_scenarios WHERE id=@id AND deleted=false", 
            new { id });

    public Task<LopaScenarioDto?> GetScenarioAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<LopaScenarioDto>(
            @"SELECT 
                id, lopa_study_id, hazop_deviation_id, scenario_number, initiating_event,
                initiating_frequency, consequence_description, consequence_severity, target_risk,
                residual_risk, risk_gap, risk_gap_met, required_rrf_sis, sil_required,
                achieved_rrf_sis, sil_achieved, sil_gap_met, pfd_non_sis, pfd_sis, notes,
                created_at, updated_at, data, deleted
              FROM lopa_scenarios WHERE id=@id AND deleted=false", 
            new { id });

    public async Task<bool> ScenarioExistsAsync(string id) =>
        await _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM lopa_scenarios WHERE id=@id AND deleted=false", new { id }) > 0;

    public async Task<string> CreateScenarioAsync(string id, string studyId, string? hazopDeviationId, string scenarioNumber,
        string initiatingEvent, double initiatingFrequency, string? consequenceDescription,
        int consequenceSeverity, double targetRisk, string? notes, string dataJson)
    {
        await _db.ExecuteAsync(@"
            INSERT INTO lopa_scenarios
              (id,lopa_study_id,hazop_deviation_id,scenario_number,initiating_event,
               initiating_frequency,consequence_description,consequence_severity,target_risk,
               notes,data,deleted)
            VALUES
              (@id,@studyId,@hazopDeviationId,@scenarioNumber,@initiatingEvent,
               @initiatingFrequency,@consequenceDescription,@consequenceSeverity,@targetRisk,
               @notes,@data::jsonb,false)",
            new
            {
                id, studyId, hazopDeviationId, scenarioNumber, initiatingEvent, initiatingFrequency,
                consequenceDescription, consequenceSeverity, targetRisk, notes, data = dataJson
            });
        return id;
    }

    public Task UpdateScenarioAsync(string id, string scenarioNumber, string initiatingEvent, double initiatingFrequency,
        string? consequenceDescription, int consequenceSeverity, double targetRisk, string? notes, string dataJson) =>
        _db.ExecuteAsync(@"
            UPDATE lopa_scenarios 
            SET scenario_number=@scenarioNumber, initiating_event=@initiatingEvent,
              initiating_frequency=@initiatingFrequency, consequence_description=@consequenceDescription,
              consequence_severity=@consequenceSeverity, target_risk=@targetRisk, notes=@notes,
              data=@data::jsonb, updated_at=NOW()
            WHERE id=@id AND deleted=false",
            new
            {
                id, scenarioNumber, initiatingEvent, initiatingFrequency, consequenceDescription,
                consequenceSeverity, targetRisk, notes, data = dataJson
            });

    public Task SoftDeleteScenarioAsync(string id) =>
        _db.ExecuteAsync("UPDATE lopa_scenarios SET deleted=true, updated_at=NOW() WHERE id=@id", new { id });

    public Task UpdateScenarioCalcAsync(string id, double mitigatedFrequency, double riskGap, bool riskGapMet,
        double requiredRrfSis, string silRequired, double achievedRrfSis, string silAchieved,
        bool silGapMet, double pfdNonSis, double pfdSis) =>
        _db.ExecuteAsync(@"
            UPDATE lopa_scenarios SET
              residual_risk=@mitigatedFrequency, risk_gap=@riskGap, risk_gap_met=@riskGapMet,
              required_rrf_sis=@requiredRrfSis, sil_required=@silRequired,
              achieved_rrf_sis=@achievedRrfSis, sil_achieved=@silAchieved, sil_gap_met=@silGapMet,
              pfd_non_sis=@pfdNonSis, pfd_sis=@pfdSis, updated_at=NOW()
            WHERE id=@id",
            new
            {
                id, mitigatedFrequency, riskGap, riskGapMet, requiredRrfSis, silRequired,
                achievedRrfSis, silAchieved, silGapMet, pfdNonSis, pfdSis
            });

    // ─── IPLs ───────────────────────────────────────────────────────────────
    public Task<IEnumerable<LopaIplForCalcDto>> ListIplsForCalcAsync(string scenarioId) =>
        _db.QueryAsync<LopaIplForCalcDto>(
            "SELECT id, ipl_name, ipl_type, pfd, is_validated FROM lopa_ipls WHERE scenario_id=@scenarioId AND deleted=false ORDER BY created_at",
            new { scenarioId });

    public Task<IEnumerable<LopaIplDto>> ListIplsAsync(string scenarioId) =>
        _db.QueryAsync<LopaIplDto>(
            @"SELECT id, scenario_id, ipl_name, ipl_type, description, pfd, is_validated,
                     owner, audit_interval, status, last_tested, failure_count, bowtie_barrier_id, 
                     risk_barrier_id, created_at, updated_at, deleted
              FROM lopa_ipls WHERE scenario_id=@scenarioId AND deleted=false ORDER BY created_at",
            new { scenarioId });

    public Task<LopaIplDto?> GetIplAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<LopaIplDto>(
            @"SELECT id, scenario_id, ipl_name, ipl_type, description, pfd, is_validated,
                     owner, audit_interval, status, last_tested, failure_count, bowtie_barrier_id,
                     risk_barrier_id, created_at, updated_at, deleted
              FROM lopa_ipls WHERE id=@id AND deleted=false", 
            new { id });

    public Task<string?> GetIplScenarioIdAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<string?>(
            "SELECT scenario_id FROM lopa_ipls WHERE id=@id AND deleted=false", new { id });

    public async Task<string> CreateIplAsync(string id, string scenarioId, string iplName, string iplType,
        string? description, double pfd, bool isValidated, string? owner, string? auditInterval)
    {
        await _db.ExecuteAsync(@"
            INSERT INTO lopa_ipls 
              (id,scenario_id,ipl_name,ipl_type,description,pfd,is_validated,owner,audit_interval,deleted)
            VALUES 
              (@id,@scenarioId,@iplName,@iplType,@description,@pfd,@isValidated,@owner,@auditInterval,false)",
            new { id, scenarioId, iplName, iplType, description, pfd, isValidated, owner, auditInterval });
        return id;
    }

    public Task UpdateIplAsync(string id, string iplName, string iplType, string? description,
        double pfd, bool isValidated, string? owner, string? auditInterval) =>
        _db.ExecuteAsync(@"
            UPDATE lopa_ipls 
            SET ipl_name=@iplName, ipl_type=@iplType, description=@description, pfd=@pfd,
              is_validated=@isValidated, owner=@owner, audit_interval=@auditInterval, updated_at=NOW()
            WHERE id=@id AND deleted=false",
            new { id, iplName, iplType, description, pfd, isValidated, owner, auditInterval });

    public Task UpdateIplRiskBarrierIdAsync(string iplId, string riskBarrierId) =>
        _db.ExecuteAsync(
            "UPDATE lopa_ipls SET risk_barrier_id = @riskBarrierId, last_status_sync = NOW() WHERE id = @iplId",
            new { iplId, riskBarrierId });

    public Task<string?> GetScenarioBowTieDiagramIdAsync(string scenarioId) =>
        _db.ExecuteScalarAsync<string?>(
            "SELECT bowtie_diagram_id FROM lopa_scenarios WHERE id = @scenarioId AND deleted = false",
            new { scenarioId });

    public Task LinkScenarioToBowTieAsync(string scenarioId, string bowTieDiagramId) =>
        _db.ExecuteAsync(
            "UPDATE lopa_scenarios SET bowtie_diagram_id = @bowTieDiagramId, updated_at = NOW() WHERE id = @scenarioId",
            new { scenarioId, bowTieDiagramId });

    public Task SoftDeleteIplAsync(string id) =>
        _db.ExecuteAsync("UPDATE lopa_ipls SET deleted=true, updated_at=NOW() WHERE id=@id", new { id });

    // ─── SIL summary / HAZOP integration / dashboard ───────────────────────
    public async Task<IEnumerable<LopaSilBandDto>> GetSilBandsAsync(string studyId) =>
        (await _db.QueryAsync<(string? silLevel, int count)>(
            @"SELECT sil_required AS silLevel, COUNT(*)::int AS count
              FROM lopa_scenarios WHERE lopa_study_id=@studyId AND deleted=false
              GROUP BY sil_required ORDER BY count DESC", 
            new { studyId }))
        .Select(x => new LopaSilBandDto 
        { 
            SilLevel = x.silLevel, 
            ScenarioCount = x.count 
        });

    public Task<int> CountScenariosBySilGapAsync(string studyId, bool met) =>
        _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(*)::int FROM lopa_scenarios WHERE lopa_study_id=@studyId AND deleted=false AND sil_gap_met=@met",
            new { studyId, met })!;

    public Task<IEnumerable<HazopDeviationDto>> GetHazopDeviationsAsync(string hazopStudyId) =>
        _db.QueryAsync<HazopDeviationDto>(@"
            SELECT 
              d.id, d.study_id, d.node_id, d.guide_word, d.parameter, d.deviation,
              d.causes, d.consequences, d.existing_safeguards, d.recommendations,
              d.severity, d.likelihood, d.risk_level, d.status, d.created_at, d.updated_at,
              d.data, d.deleted
            FROM hazop_deviations d
            WHERE d.study_id=@hazopStudyId AND d.deleted=false
            ORDER BY d.created_at", 
            new { hazopStudyId });

    public Task<IEnumerable<HazopStudyDto>> GetHazopStudiesBriefAsync() =>
        _db.QueryAsync<HazopStudyDto>(@"
            SELECT id, title, facility, unit, status, created_at,
                   NULL::datetime as created_by, NULL::datetime as start_date,
                   NULL::datetime as end_date, NULL::text as lead_engineer, NULL::text as scope,
                   NULL::text as methodology, NULL::text as data, false as deleted, 
                   NULL::datetime as updated_at
            FROM hazop_studies WHERE deleted=false ORDER BY created_at DESC");

    public async Task<LopaDashboardSummaryDto> GetDashboardSummaryAsync()
    {
        var studiesTask = _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(*)::int FROM lopa_studies WHERE deleted=false");

        var iplsTask = _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(*)::int FROM lopa_ipls WHERE deleted=false");

        var scenariosTask = _db.QueryFirstOrDefaultAsync<dynamic>(@"
            SELECT
                COUNT(*)::int                                                   AS Total,
                COUNT(*) FILTER (WHERE sil_gap_met = true)::int                 AS GapMet,
                COUNT(*) FILTER (WHERE sil_gap_met = false)::int                AS GapNotMet,
                COUNT(*) FILTER (WHERE sil_required = 'SIL 1')::int             AS SIL1,
                COUNT(*) FILTER (WHERE sil_required = 'SIL 2')::int             AS SIL2,
                COUNT(*) FILTER (WHERE sil_required = 'SIL 3')::int             AS SIL3,
                COUNT(*) FILTER (WHERE sil_required = 'SIL 4')::int             AS SIL4
            FROM lopa_scenarios WHERE deleted=false");

        var statusTask = _db.QueryAsync<(string?, int)>(
            "SELECT status, COUNT(*)::int FROM lopa_scenarios WHERE deleted=false GROUP BY status");

        var studies = await studiesTask;
        var ipls = await iplsTask;
        var s = await scenariosTask;
        var statusDistribution = await statusTask;

        var result = new LopaDashboardSummaryDto
        {
            TotalStudies     = studies,
            TotalScenarios   = s != null ? (int)(s.Total       ?? 0) : 0,
            TotalIpls        = ipls,
            SilGapMetCount   = s != null ? (int)(s.GapMet      ?? 0) : 0,
            SilGapNotMetCount= s != null ? (int)(s.GapNotMet   ?? 0) : 0,
            SIL1Count        = s != null ? (int)(s.SIL1        ?? 0) : 0,
            SIL2Count        = s != null ? (int)(s.SIL2        ?? 0) : 0,
            SIL3Count        = s != null ? (int)(s.SIL3        ?? 0) : 0,
            SIL4Count        = s != null ? (int)(s.SIL4        ?? 0) : 0,
        };

        result.StatusDistribution = statusDistribution
            .Where(x => x.Item1 != null)
            .ToDictionary(x => x.Item1!, x => x.Item2);

        return result;
    }

    // Service overloads
    public Task<LopaStudyDto?> GetLopaStudyByHazopAsync(string hazopStudyId) =>
        _db.QueryFirstOrDefaultAsync<LopaStudyDto>(
            "SELECT id, title, hazop_study_id, facility, unit, lead_engineer, status, created_by, created_at, updated_at, data, deleted FROM lopa_studies WHERE hazop_study_id=@hazopStudyId AND deleted=false ORDER BY created_at DESC LIMIT 1",
            new { hazopStudyId });

    public async Task<LopaStudyDto> CreateLopaStudyAsync(string id, string title, string? hazopStudyId, string? facility, string? unit, string? leadEngineer, string? status, string? createdBy, string? dataJson)
    {
        await CreateStudyAsync(id, title, hazopStudyId, facility, unit, leadEngineer, status, createdBy, dataJson ?? "{}");
        return (await GetStudyAsync(id))!;
    }

    public async Task<LopaScenarioDto> CreateLopaScenarioAsync(string id, string studyId, string? hazopDeviationId, string scenarioNumber, string initiatingEvent, double initiatingFrequency, string? consequenceDescription, int consequenceSeverity, double targetRisk, string? notes, string? dataJson)
    {
        await CreateScenarioAsync(id, studyId, hazopDeviationId, scenarioNumber, initiatingEvent, initiatingFrequency, consequenceDescription, consequenceSeverity, targetRisk, notes, dataJson ?? "{}");
        return (await GetScenarioAsync(id))!;
    }

    public Task<LopaStudyDto?> GetLopaStudyAsync(string id) => GetStudyAsync(id);

    public Task<IEnumerable<LopaScenarioDto>> ListScenariosByStudyAsync(string studyId) => ListScenariosAsync(studyId);

    public Task<IEnumerable<LopaIplDto>> ListIplsByScenarioAsync(string scenarioId) => ListIplsAsync(scenarioId);

    public Task<IEnumerable<LopaScenarioDto>> ListAllScenariosAsync() =>
        _db.QueryAsync<LopaScenarioDto>(
            @"SELECT id, lopa_study_id, hazop_deviation_id, scenario_number, initiating_event,
                initiating_frequency, consequence_description, consequence_severity, target_risk,
                residual_risk, risk_gap, risk_gap_met, required_rrf_sis, sil_required,
                achieved_rrf_sis, sil_achieved, sil_gap_met, pfd_non_sis, pfd_sis, notes,
                created_at, updated_at, data, deleted
              FROM lopa_scenarios WHERE deleted=false ORDER BY created_at DESC");

    public Task<LopaIplDto?> GetLopaIplAsync(string id) => GetIplAsync(id);

    public Task<LopaScenarioDto?> GetLopaScenarioAsync(string id) => GetScenarioAsync(id);

    public async Task<int> GetLopaStudyCountAsync() =>
        await _db.ExecuteScalarAsync<int>(
            "SELECT COUNT(*)::int FROM lopa_studies WHERE deleted=false");
}
