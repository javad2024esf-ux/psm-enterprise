using Dapper;
using PSM.Api.Data;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

public interface IHazopLopaIntegrationRepository
{
    // ─── Study-Level Integration ─────────────────────────────────────────
    Task<List<LopaStudyDto>> GetLopaStudiesByHazopStudyAsync(string hazopStudyId);
    Task<HazopLopaIntegrationSummaryDto> GetIntegrationSummaryAsync(string hazopStudyId);
    
    // ─── Deviation-Level Integration ─────────────────────────────────────
    Task<List<LopaScenarioDto>> GetLopaScenariosByHazopDeviationAsync(string hazopDeviationId);
    Task<HazopDeviationDto?> GetHazopDeviationByLopaScenarioAsync(string lopaScenarioId);
    
    // ─── Traceability Updates ────────────────────────────────────────────
    Task UpdateLopaScenarioHazopReferencesAsync(string lopaScenarioId, string hazopStudyId, 
        string hazopNodeId, string hazopDeviationId);
    Task UpdateLopaStudyHazopReferenceAsync(string lopaStudyId, string hazopStudyId);
    
    // ─── Audit Trail ────────────────────────────────────────────────────
    Task LogIntegrationActionAsync(string action, string? hazopStudyId, string? hazopNodeId,
        string? hazopDeviationId, string? lopaStudyId, string? lopaScenarioId, string? performedBy,
        string? ipAddress, string? userAgent, Dictionary<string, object>? details);
    
    Task<List<HazopLopaAuditTrailDto>> GetAuditTrailAsync(string? hazopStudyId = null, 
        string? lopaStudyId = null, int limit = 100, int offset = 0);
    
    Task<List<HazopLopaAuditTrailDto>> GetAuditTrailByDeviationAsync(string hazopDeviationId, 
        int limit = 50);
    
    Task<int> GetAuditTrailCountAsync(string? hazopStudyId = null, string? lopaStudyId = null);
}

public class HazopLopaIntegrationRepository : IHazopLopaIntegrationRepository
{
    private readonly IDbHelper _db;
    
    public HazopLopaIntegrationRepository(IDbHelper db) => _db = db;

    // ─── Study-Level Integration ─────────────────────────────────────────
    public async Task<List<LopaStudyDto>> GetLopaStudiesByHazopStudyAsync(string hazopStudyId) =>
        new List<LopaStudyDto>(await _db.QueryAsync<LopaStudyDto>(@"
            SELECT 
              id, title, hazop_study_id, created_from_hazop_study_id, creation_method,
              facility, unit, lead_engineer, status, created_at, updated_at,
              created_by, data, deleted
            FROM lopa_studies
            WHERE (hazop_study_id = @hazopStudyId OR created_from_hazop_study_id = @hazopStudyId)
              AND deleted = false
            ORDER BY created_at DESC",
            new { hazopStudyId }));

    public async Task<HazopLopaIntegrationSummaryDto> GetIntegrationSummaryAsync(string hazopStudyId)
    {
        var summary = await _db.QueryFirstOrDefaultAsync<dynamic>(@"
            SELECT 
              @hazopStudyId as hazop_study_id,
              hs.title as hazop_study_title,
              (SELECT COUNT(*) FROM hazop_deviations 
               WHERE study_id = @hazopStudyId AND deleted = false) as total_deviations,
              (SELECT COUNT(*) FROM hazop_deviations hd
               WHERE hd.study_id = @hazopStudyId 
                 AND hd.deleted = false
                 AND EXISTS (SELECT 1 FROM lopa_scenarios ls 
                            WHERE ls.hazop_deviation_id = hd.id AND ls.deleted = false)) 
                as deviations_with_lopa,
              (SELECT COUNT(DISTINCT lopa_study_id) FROM lopa_scenarios
               WHERE hazop_study_id = @hazopStudyId AND deleted = false) as linked_studies_count,
              MAX(ls.updated_at) as last_integration_update
            FROM hazop_studies hs
            LEFT JOIN lopa_scenarios ls ON ls.hazop_study_id = hs.id
            WHERE hs.id = @hazopStudyId AND hs.deleted = false
            GROUP BY hs.id, hs.title",
            new { hazopStudyId });

        if (summary == null)
            return new HazopLopaIntegrationSummaryDto 
            { 
                HazopStudyId = hazopStudyId,
                TotalDeviations = 0,
                DeviationsWithLopaScenarios = 0
            };

        var totalDeviations = (int?)summary.total_deviations ?? 0;
        var deviationsWithLopa = (int?)summary.deviations_with_lopa ?? 0;
        var coverage = totalDeviations > 0 ? (deviationsWithLopa * 100.0 / totalDeviations) : 0.0;

        var linkedStudies = await _db.QueryAsync<string>(@"
            SELECT DISTINCT lopa_study_id 
            FROM lopa_scenarios
            WHERE hazop_study_id = @hazopStudyId AND deleted = false",
            new { hazopStudyId });

        return new HazopLopaIntegrationSummaryDto
        {
            HazopStudyId = hazopStudyId,
            HazopStudyTitle = summary.hazop_study_title,
            TotalDeviations = totalDeviations,
            DeviationsWithLopaScenarios = deviationsWithLopa,
            CoveragePercentage = coverage,
            LinkedLopaStudyIds = linkedStudies.ToList(),
            LastIntegrationUpdate = summary.last_integration_update
        };
    }

    // ─── Deviation-Level Integration ─────────────────────────────────────
    public async Task<List<LopaScenarioDto>> GetLopaScenariosByHazopDeviationAsync(string hazopDeviationId) =>
        new List<LopaScenarioDto>(await _db.QueryAsync<LopaScenarioDto>(@"
            SELECT 
              id, lopa_study_id as study_id, hazop_study_id, hazop_node_id, 
              hazop_deviation_id, scenario_number, initiating_event, initiating_frequency,
              consequence_description, consequence_severity, target_risk, 
              residual_risk as mitigated_frequency, risk_gap, risk_gap_met,
              0 as required_rrf_sis, '' as sil_required, 0 as achieved_rrf_sis, 
              '' as sil_achieved, false as sil_gap_met, 0 as pfd_non_sis, 0 as pfd_sis,
              notes, related_recommendation_ids, created_at, updated_at, data, deleted
            FROM lopa_scenarios
            WHERE hazop_deviation_id = @hazopDeviationId AND deleted = false
            ORDER BY created_at DESC",
            new { hazopDeviationId }));

    public Task<HazopDeviationDto?> GetHazopDeviationByLopaScenarioAsync(string lopaScenarioId) =>
        _db.QueryFirstOrDefaultAsync<HazopDeviationDto>(@"
            SELECT 
              hd.id, hd.study_id, hd.node_id, hd.guide_word, hd.parameter,
              hd.deviation, hd.causes, hd.consequences, hd.existing_safeguards,
              hd.recommendations, hd.severity, hd.likelihood, hd.risk_level,
              hd.status, hd.created_at, hd.updated_at, hd.data, hd.deleted
            FROM hazop_deviations hd
            INNER JOIN lopa_scenarios ls ON ls.hazop_deviation_id = hd.id
            WHERE ls.id = @lopaScenarioId AND hd.deleted = false",
            new { lopaScenarioId });

    // ─── Traceability Updates ────────────────────────────────────────────
    public Task UpdateLopaScenarioHazopReferencesAsync(string lopaScenarioId, string hazopStudyId,
        string hazopNodeId, string hazopDeviationId) =>
        _db.ExecuteAsync(@"
            UPDATE lopa_scenarios
            SET hazop_study_id = @hazopStudyId,
                hazop_node_id = @hazopNodeId,
                hazop_deviation_id = @hazopDeviationId,
                updated_at = NOW()
            WHERE id = @lopaScenarioId AND deleted = false",
            new { lopaScenarioId, hazopStudyId, hazopNodeId, hazopDeviationId });

    public Task UpdateLopaStudyHazopReferenceAsync(string lopaStudyId, string hazopStudyId) =>
        _db.ExecuteAsync(@"
            UPDATE lopa_studies
            SET hazop_study_id = @hazopStudyId, updated_at = NOW()
            WHERE id = @lopaStudyId AND deleted = false",
            new { lopaStudyId, hazopStudyId });

    // ─── Audit Trail ────────────────────────────────────────────────────
    public Task LogIntegrationActionAsync(string action, string? hazopStudyId, string? hazopNodeId,
        string? hazopDeviationId, string? lopaStudyId, string? lopaScenarioId, string? performedBy,
        string? ipAddress, string? userAgent, Dictionary<string, object>? details) =>
        _db.ExecuteAsync(@"
            INSERT INTO hazop_lopa_audit_trail 
              (action, hazop_study_id, hazop_node_id, hazop_deviation_id, 
               lopa_study_id, lopa_scenario_id, performed_by, ip_address, user_agent, details)
            VALUES 
              (@action, @hazopStudyId, @hazopNodeId, @hazopDeviationId,
               @lopaStudyId, @lopaScenarioId, @performedBy, @ipAddress, @userAgent, @details::jsonb)",
            new
            {
                action,
                hazopStudyId,
                hazopNodeId,
                hazopDeviationId,
                lopaStudyId,
                lopaScenarioId,
                performedBy,
                ipAddress,
                userAgent,
                details = details != null ? System.Text.Json.JsonSerializer.Serialize(details) : "{}"
            });

    public async Task<List<HazopLopaAuditTrailDto>> GetAuditTrailAsync(string? hazopStudyId = null,
        string? lopaStudyId = null, int limit = 100, int offset = 0)
    {
        var sql = @"
            SELECT 
              id, action, hazop_study_id, hazop_node_id, hazop_deviation_id,
              lopa_study_id, lopa_scenario_id, performed_by, performed_at,
              details, ip_address, user_agent
            FROM hazop_lopa_audit_trail
            WHERE 1=1";

        var parameters = new Dictionary<string, object>();

        if (!string.IsNullOrEmpty(hazopStudyId))
        {
            sql += " AND hazop_study_id = @hazopStudyId";
            parameters["hazopStudyId"] = hazopStudyId;
        }

        if (!string.IsNullOrEmpty(lopaStudyId))
        {
            sql += " AND lopa_study_id = @lopaStudyId";
            parameters["lopaStudyId"] = lopaStudyId;
        }

        sql += " ORDER BY performed_at DESC LIMIT @limit OFFSET @offset";
        parameters["limit"] = limit;
        parameters["offset"] = offset;

        return new List<HazopLopaAuditTrailDto>(
            await _db.QueryAsync<HazopLopaAuditTrailDto>(sql, new DynamicParameters(parameters)));
    }

    public async Task<List<HazopLopaAuditTrailDto>> GetAuditTrailByDeviationAsync(string hazopDeviationId,
        int limit = 50) =>
        new List<HazopLopaAuditTrailDto>(await _db.QueryAsync<HazopLopaAuditTrailDto>(@"
            SELECT 
              id, action, hazop_study_id, hazop_node_id, hazop_deviation_id,
              lopa_study_id, lopa_scenario_id, performed_by, performed_at,
              details, ip_address, user_agent
            FROM hazop_lopa_audit_trail
            WHERE hazop_deviation_id = @hazopDeviationId
            ORDER BY performed_at DESC
            LIMIT @limit",
            new { hazopDeviationId, limit }));

    public Task<int> GetAuditTrailCountAsync(string? hazopStudyId = null, string? lopaStudyId = null)
    {
        var sql = "SELECT COUNT(*) FROM hazop_lopa_audit_trail WHERE 1=1";
        var parameters = new Dictionary<string, object>();

        if (!string.IsNullOrEmpty(hazopStudyId))
        {
            sql += " AND hazop_study_id = @hazopStudyId";
            parameters["hazopStudyId"] = hazopStudyId;
        }

        if (!string.IsNullOrEmpty(lopaStudyId))
        {
            sql += " AND lopa_study_id = @lopaStudyId";
            parameters["lopaStudyId"] = lopaStudyId;
        }

        return _db.ExecuteScalarAsync<int>(sql, new DynamicParameters(parameters));
    }
}
