// ⚠️ DEPRECATED: Legacy Entity Framework Core code - NOT USED
// This file is kept for reference but is NOT compiled into the application.
// The application uses Dapper ORM exclusively for all database operations.

namespace PSM.Api.Repositories;

/// <summary>
/// DEPRECATED - Legacy EF Core Generic Repository (Not Used)
/// 
/// This class exists only for reference and is not used in the current application.
/// All database operations use Dapper ORM through specific repository implementations.
/// </summary>
[Obsolete("Use Dapper repositories instead. See PSM.Api.Repositories.*", true)]
public class GenericRepository<T> where T : class
{
    public GenericRepository()
    {
        throw new NotSupportedException(
            "GenericRepository is deprecated. This application uses Dapper ORM. " +
            "Use specific repository implementations in PSM.Api.Repositories namespace instead.");
    }
}
