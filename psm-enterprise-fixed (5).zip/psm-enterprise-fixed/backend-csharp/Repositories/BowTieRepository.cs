using System.Data;
using Npgsql;
using NpgsqlTypes;
using PSM.Api.Data;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;
public interface IBowTieRepository
{
    // Diagrams
    Task<List<BowTieDiagramDto>> GetDiagramsAsync(string? hazopStudyId = null, string? lopaStudyId = null);
    Task<BowTieDiagramDetailDto?> GetDiagramAsync(string id);
    Task<string> CreateDiagramAsync(CreateBowTieDiagramDto dto, string userId);
    Task UpdateDiagramAsync(string id, UpdateBowTieDiagramDto dto, string userId);
    Task DeleteDiagramAsync(string id);

    // Causes
    Task<List<BowTieCauseDto>> GetCausesAsync(string diagramId);
    Task<string> CreateCauseAsync(CreateBowTieCauseDto dto, string userId);
    Task UpdateCauseAsync(string id, UpdateBowTieCauseDto dto, string userId);
    Task DeleteCauseAsync(string id);

    // Consequences
    Task<List<BowTieConsequenceDto>> GetConsequencesAsync(string diagramId);
    Task<string> CreateConsequenceAsync(CreateBowTieConsequenceDto dto, string userId);
    Task UpdateConsequenceAsync(string id, UpdateBowTieConsequenceDto dto, string userId);
    Task DeleteConsequenceAsync(string id);

    // Barriers
    Task<List<BowTieBarrierDto>> GetBarriersAsync(string diagramId);
    Task<string> CreateBarrierAsync(CreateBowTieBarrierDto dto, string userId);
    Task UpdateBarrierAsync(string id, UpdateBowTieBarrierDto dto, string userId);
    Task DeleteBarrierAsync(string id);

    // Controls
    Task<string> CreateControlAsync(CreateBowTieControlDto dto, string userId);
    Task UpdateControlAsync(string id, UpdateBowTieControlDto dto, string userId);
    Task DeleteControlAsync(string id);

    // Integration
    Task<BowTieSummaryDto> GetSummaryAsync();

    // Service overloads
    Task<BowTieDiagramDetailDto?> GetBowTieDiagramAsync(string id);
    Task<string> CreateBowTieDiagramAsync(CreateBowTieDiagramDto dto, string userId);
    Task<string> CreateBowTieBarrierAsync(CreateBowTieBarrierDto dto, string userId);
    Task<int> GetBowTieDiagramCountAsync();
}

public class BowTieRepository : IBowTieRepository
{
    private readonly IDbConnectionFactory _connectionFactory;

    public BowTieRepository(IDbConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // DIAGRAMS
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<List<BowTieDiagramDto>> GetDiagramsAsync(string? hazopStudyId = null, string? lopaStudyId = null)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        var query = @"
            SELECT bd.*,
                (SELECT COUNT(*)::int FROM bowtie_causes c 
                 WHERE c.diagram_id=bd.id AND c.deleted=false) AS cause_count,
                (SELECT COUNT(*)::int FROM bowtie_consequences co 
                 WHERE co.diagram_id=bd.id AND co.deleted=false) AS consequence_count,
                (SELECT COUNT(*)::int FROM bowtie_barriers b 
                 WHERE b.diagram_id=bd.id AND b.deleted=false) AS barrier_count
            FROM bowtie_diagrams bd
            WHERE bd.deleted=false";

        var parameters = new List<NpgsqlParameter>();

        if (!string.IsNullOrEmpty(hazopStudyId))
        {
            query += " AND bd.hazop_study_id=$" + (parameters.Count + 1);
            parameters.Add(new NpgsqlParameter { Value = hazopStudyId });
        }

        if (!string.IsNullOrEmpty(lopaStudyId))
        {
            query += " AND bd.lopa_study_id=$" + (parameters.Count + 1);
            parameters.Add(new NpgsqlParameter { Value = lopaStudyId });
        }

        query += " ORDER BY bd.created_at DESC";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddRange(parameters.ToArray());

        var result = new List<BowTieDiagramDto>();
        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new BowTieDiagramDto
            {
                Id = reader.GetString(reader.GetOrdinal("id")),
                Title = reader.GetString(reader.GetOrdinal("title")),
                Description = reader.IsDBNull(reader.GetOrdinal("description")) ? null : reader.GetString(reader.GetOrdinal("description")),
                HazopStudyId = reader.IsDBNull(reader.GetOrdinal("hazop_study_id")) ? null : reader.GetString(reader.GetOrdinal("hazop_study_id")),
                LopaStudyId = reader.IsDBNull(reader.GetOrdinal("lopa_study_id")) ? null : reader.GetString(reader.GetOrdinal("lopa_study_id")),
                TopEventId = reader.IsDBNull(reader.GetOrdinal("top_event_id")) ? null : reader.GetString(reader.GetOrdinal("top_event_id")),
                TopEventDescription = reader.IsDBNull(reader.GetOrdinal("top_event_description")) ? null : reader.GetString(reader.GetOrdinal("top_event_description")),
                CauseCount = reader.IsDBNull(reader.GetOrdinal("cause_count")) ? null : reader.GetInt32(reader.GetOrdinal("cause_count")),
                ConsequenceCount = reader.IsDBNull(reader.GetOrdinal("consequence_count")) ? null : reader.GetInt32(reader.GetOrdinal("consequence_count")),
                BarrierCount = reader.IsDBNull(reader.GetOrdinal("barrier_count")) ? null : reader.GetInt32(reader.GetOrdinal("barrier_count")),
                CreatedAt = reader.GetDateTime(reader.GetOrdinal("created_at")),
                UpdatedAt = reader.GetDateTime(reader.GetOrdinal("updated_at")),
                CreatedBy = reader.IsDBNull(reader.GetOrdinal("created_by")) ? null : reader.GetString(reader.GetOrdinal("created_by")),
            });
        }

        return result;
    }

    public async Task<BowTieDiagramDetailDto?> GetDiagramAsync(string id)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        var query = @"
            SELECT bd.*,
                COALESCE(
                    (SELECT json_agg(c ORDER BY c.sort_order, c.created_at)
                     FROM bowtie_causes c WHERE c.diagram_id=bd.id AND c.deleted=false),
                    '[]'
                ) AS causes,
                COALESCE(
                    (SELECT json_agg(b ORDER BY b.sort_order, b.created_at)
                     FROM bowtie_barriers b WHERE b.diagram_id=bd.id AND b.deleted=false),
                    '[]'
                ) AS barriers,
                COALESCE(
                    (SELECT json_agg(co ORDER BY co.sort_order, co.created_at)
                     FROM bowtie_consequences co WHERE co.diagram_id=bd.id AND co.deleted=false),
                    '[]'
                ) AS consequences,
                COALESCE(
                    (SELECT json_agg(ct ORDER BY ct.created_at)
                     FROM bowtie_controls ct WHERE ct.diagram_id=bd.id AND ct.deleted=false),
                    '[]'
                ) AS controls
            FROM bowtie_diagrams bd
            WHERE bd.id=$1 AND bd.deleted=false";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", id);

        using var reader = await cmd.ExecuteReaderAsync();
        if (!await reader.ReadAsync())
            return null;

        // Design: JSON arrays for causes, barriers, consequences, controls are loaded
        // in separate queries for better performance and flexibility. The detailed data
        // structure is populated by service layer methods (GetCausesAsync, etc.)

        return new BowTieDiagramDetailDto
        {
            Id = reader.GetString(reader.GetOrdinal("id")),
            Title = reader.GetString(reader.GetOrdinal("title")),
            Description = reader.IsDBNull(reader.GetOrdinal("description")) ? null : reader.GetString(reader.GetOrdinal("description")),
            HazopStudyId = reader.IsDBNull(reader.GetOrdinal("hazop_study_id")) ? null : reader.GetString(reader.GetOrdinal("hazop_study_id")),
            LopaStudyId = reader.IsDBNull(reader.GetOrdinal("lopa_study_id")) ? null : reader.GetString(reader.GetOrdinal("lopa_study_id")),
            TopEventId = reader.IsDBNull(reader.GetOrdinal("top_event_id")) ? null : reader.GetString(reader.GetOrdinal("top_event_id")),
            TopEventDescription = reader.IsDBNull(reader.GetOrdinal("top_event_description")) ? null : reader.GetString(reader.GetOrdinal("top_event_description")),
            CreatedAt = reader.GetDateTime(reader.GetOrdinal("created_at")),
            UpdatedAt = reader.GetDateTime(reader.GetOrdinal("updated_at")),
            CreatedBy = reader.IsDBNull(reader.GetOrdinal("created_by")) ? null : reader.GetString(reader.GetOrdinal("created_by")),
        };
    }

    public async Task<string> CreateDiagramAsync(CreateBowTieDiagramDto dto, string userId)
    {
        var id = Guid.NewGuid().ToString();
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            INSERT INTO bowtie_diagrams 
                (id, title, description, hazop_study_id, lopa_study_id, 
                 top_event_id, top_event_description, created_by, updated_by, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW())";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", id);
        cmd.Parameters.AddWithValue("$2", dto.Title);
        cmd.Parameters.AddWithValue("$3", (object?)dto.Description ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$4", (object?)dto.HazopStudyId ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$5", (object?)dto.LopaStudyId ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$6", (object?)dto.TopEventId ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$7", (object?)dto.TopEventDescription ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$8", userId);
        cmd.Parameters.AddWithValue("$9", userId);

        await cmd.ExecuteNonQueryAsync();
        return id;
    }

    public async Task UpdateDiagramAsync(string id, UpdateBowTieDiagramDto dto, string userId)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            UPDATE bowtie_diagrams
            SET title=$1, description=$2, top_event_id=$3, top_event_description=$4,
                updated_by=$5, updated_at=NOW()
            WHERE id=$6 AND deleted=false";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", dto.Title);
        cmd.Parameters.AddWithValue("$2", (object?)dto.Description ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$3", (object?)dto.TopEventId ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$4", (object?)dto.TopEventDescription ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$5", userId);
        cmd.Parameters.AddWithValue("$6", id);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task DeleteDiagramAsync(string id)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            UPDATE bowtie_diagrams SET deleted=true, updated_at=NOW() WHERE id=$1";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", id);

        await cmd.ExecuteNonQueryAsync();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CAUSES
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<List<BowTieCauseDto>> GetCausesAsync(string diagramId)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            SELECT * FROM bowtie_causes
            WHERE diagram_id=$1 AND deleted=false
            ORDER BY sort_order, created_at";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", diagramId);

        var result = new List<BowTieCauseDto>();
        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new BowTieCauseDto
            {
                Id = reader.GetString(reader.GetOrdinal("id")),
                DiagramId = reader.GetString(reader.GetOrdinal("diagram_id")),
                Description = reader.GetString(reader.GetOrdinal("description")),
                Category = reader.IsDBNull(reader.GetOrdinal("category")) ? null : reader.GetString(reader.GetOrdinal("category")),
                SortOrder = reader.GetInt32(reader.GetOrdinal("sort_order")),
                CreatedAt = reader.GetDateTime(reader.GetOrdinal("created_at")),
                UpdatedAt = reader.GetDateTime(reader.GetOrdinal("updated_at")),
            });
        }

        return result;
    }

    public async Task<string> CreateCauseAsync(CreateBowTieCauseDto dto, string userId)
    {
        var id = Guid.NewGuid().ToString();
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        // lopa_scenario_id column added in migration 035_lopa_bowtie_integration.sql
        const string query = @"
            INSERT INTO bowtie_causes (id, diagram_id, description, category, sort_order,
                                       lopa_scenario_id, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", id);
        cmd.Parameters.AddWithValue("$2", dto.DiagramId);
        cmd.Parameters.AddWithValue("$3", dto.Description);
        cmd.Parameters.AddWithValue("$4", (object?)dto.Category ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$5", dto.SortOrder);
        cmd.Parameters.AddWithValue("$6", (object?)dto.LopaScenarioId ?? DBNull.Value);

        await cmd.ExecuteNonQueryAsync();
        return id;
    }

    public async Task UpdateCauseAsync(string id, UpdateBowTieCauseDto dto, string userId)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            UPDATE bowtie_causes
            SET description=$1, category=$2, sort_order=$3, updated_at=NOW()
            WHERE id=$4 AND deleted=false";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", dto.Description);
        cmd.Parameters.AddWithValue("$2", (object?)dto.Category ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$3", dto.SortOrder);
        cmd.Parameters.AddWithValue("$4", id);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task DeleteCauseAsync(string id)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            UPDATE bowtie_causes SET deleted=true, updated_at=NOW() WHERE id=$1";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", id);

        await cmd.ExecuteNonQueryAsync();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CONSEQUENCES
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<List<BowTieConsequenceDto>> GetConsequencesAsync(string diagramId)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            SELECT * FROM bowtie_consequences
            WHERE diagram_id=$1 AND deleted=false
            ORDER BY sort_order, created_at";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", diagramId);

        var result = new List<BowTieConsequenceDto>();
        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new BowTieConsequenceDto
            {
                Id = reader.GetString(reader.GetOrdinal("id")),
                DiagramId = reader.GetString(reader.GetOrdinal("diagram_id")),
                Description = reader.GetString(reader.GetOrdinal("description")),
                Severity = reader.IsDBNull(reader.GetOrdinal("severity")) ? null : reader.GetString(reader.GetOrdinal("severity")),
                SortOrder = reader.GetInt32(reader.GetOrdinal("sort_order")),
                CreatedAt = reader.GetDateTime(reader.GetOrdinal("created_at")),
                UpdatedAt = reader.GetDateTime(reader.GetOrdinal("updated_at")),
            });
        }

        return result;
    }

    public async Task<string> CreateConsequenceAsync(CreateBowTieConsequenceDto dto, string userId)
    {
        var id = Guid.NewGuid().ToString();
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        // lopa_scenario_id, mitigated_frequency, target_risk, sil_required columns
        // added in migration 035_lopa_bowtie_integration.sql.
        const string query = @"
            INSERT INTO bowtie_consequences (id, diagram_id, description, severity, sort_order,
                                              lopa_scenario_id, mitigated_frequency,
                                              target_risk, sil_required, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW())";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", id);
        cmd.Parameters.AddWithValue("$2", dto.DiagramId);
        cmd.Parameters.AddWithValue("$3", dto.Description);
        cmd.Parameters.AddWithValue("$4", (object?)dto.Severity ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$5", dto.SortOrder);
        cmd.Parameters.AddWithValue("$6", (object?)dto.LopaScenarioId ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$7", dto.MitigatedFrequency.HasValue
            ? (object)dto.MitigatedFrequency.Value : DBNull.Value);
        cmd.Parameters.AddWithValue("$8", dto.TargetRisk.HasValue
            ? (object)dto.TargetRisk.Value : DBNull.Value);
        cmd.Parameters.AddWithValue("$9", (object?)dto.SilRequired ?? DBNull.Value);

        await cmd.ExecuteNonQueryAsync();
        return id;
    }

    public async Task UpdateConsequenceAsync(string id, UpdateBowTieConsequenceDto dto, string userId)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            UPDATE bowtie_consequences
            SET description=$1, severity=$2, sort_order=$3, updated_at=NOW()
            WHERE id=$4 AND deleted=false";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", dto.Description);
        cmd.Parameters.AddWithValue("$2", (object?)dto.Severity ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$3", dto.SortOrder);
        cmd.Parameters.AddWithValue("$4", id);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task DeleteConsequenceAsync(string id)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            UPDATE bowtie_consequences SET deleted=true, updated_at=NOW() WHERE id=$1";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", id);

        await cmd.ExecuteNonQueryAsync();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // BARRIERS
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<List<BowTieBarrierDto>> GetBarriersAsync(string diagramId)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            SELECT * FROM bowtie_barriers
            WHERE diagram_id=$1 AND deleted=false
            ORDER BY sort_order, created_at";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", diagramId);

        var result = new List<BowTieBarrierDto>();
        using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            result.Add(new BowTieBarrierDto
            {
                Id = reader.GetString(reader.GetOrdinal("id")),
                DiagramId = reader.GetString(reader.GetOrdinal("diagram_id")),
                Description = reader.GetString(reader.GetOrdinal("description")),
                Type = reader.IsDBNull(reader.GetOrdinal("type")) ? null : reader.GetString(reader.GetOrdinal("type")),
                RiskReduction = reader.IsDBNull(reader.GetOrdinal("risk_reduction")) ? null : reader.GetString(reader.GetOrdinal("risk_reduction")),
                SortOrder = reader.GetInt32(reader.GetOrdinal("sort_order")),
                CreatedAt = reader.GetDateTime(reader.GetOrdinal("created_at")),
                UpdatedAt = reader.GetDateTime(reader.GetOrdinal("updated_at")),
            });
        }

        return result;
    }

    public async Task<string> CreateBarrierAsync(CreateBowTieBarrierDto dto, string userId)
    {
        var id = Guid.NewGuid().ToString();
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            INSERT INTO bowtie_barriers (id, diagram_id, description, type, risk_reduction, sort_order, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", id);
        cmd.Parameters.AddWithValue("$2", dto.DiagramId);
        cmd.Parameters.AddWithValue("$3", dto.Description);
        cmd.Parameters.AddWithValue("$4", (object?)dto.Type ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$5", (object?)dto.RiskReduction ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$6", dto.SortOrder);

        await cmd.ExecuteNonQueryAsync();
        return id;
    }

    public async Task UpdateBarrierAsync(string id, UpdateBowTieBarrierDto dto, string userId)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            UPDATE bowtie_barriers
            SET description=$1, type=$2, risk_reduction=$3, sort_order=$4, updated_at=NOW()
            WHERE id=$5 AND deleted=false";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", dto.Description);
        cmd.Parameters.AddWithValue("$2", (object?)dto.Type ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$3", (object?)dto.RiskReduction ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$4", dto.SortOrder);
        cmd.Parameters.AddWithValue("$5", id);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task DeleteBarrierAsync(string id)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            UPDATE bowtie_barriers SET deleted=true, updated_at=NOW() WHERE id=$1";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", id);

        await cmd.ExecuteNonQueryAsync();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CONTROLS
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<string> CreateControlAsync(CreateBowTieControlDto dto, string userId)
    {
        var id = Guid.NewGuid().ToString();
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            INSERT INTO bowtie_controls 
                (id, barrier_id, diagram_id, description, control_type, frequency, is_active, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), NOW())";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", id);
        cmd.Parameters.AddWithValue("$2", dto.BarrierId);
        cmd.Parameters.AddWithValue("$3", dto.BarrierId); // diagram_id to be populated from barrier
        cmd.Parameters.AddWithValue("$4", dto.Description);
        cmd.Parameters.AddWithValue("$5", (object?)dto.ControlType ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$6", (object?)dto.Frequency ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$7", dto.IsActive);

        await cmd.ExecuteNonQueryAsync();
        return id;
    }

    public async Task UpdateControlAsync(string id, UpdateBowTieControlDto dto, string userId)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            UPDATE bowtie_controls
            SET description=$1, control_type=$2, frequency=$3, is_active=$4, updated_at=NOW()
            WHERE id=$5 AND deleted=false";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", dto.Description);
        cmd.Parameters.AddWithValue("$2", (object?)dto.ControlType ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$3", (object?)dto.Frequency ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$4", dto.IsActive);
        cmd.Parameters.AddWithValue("$5", id);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task DeleteControlAsync(string id)
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            UPDATE bowtie_controls SET deleted=true, updated_at=NOW() WHERE id=$1";

        using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("$1", id);

        await cmd.ExecuteNonQueryAsync();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // SUMMARY & STATS
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<BowTieSummaryDto> GetSummaryAsync()
    {
        using var conn = (Npgsql.NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();

        const string query = @"
            SELECT
                (SELECT COUNT(*) FROM bowtie_diagrams WHERE deleted=false) AS total_diagrams,
                (SELECT COUNT(*) FROM bowtie_diagrams WHERE hazop_study_id IS NOT NULL AND deleted=false) AS hazop_linked,
                (SELECT COUNT(*) FROM bowtie_diagrams WHERE lopa_study_id IS NOT NULL AND deleted=false) AS lopa_linked,
                (SELECT COUNT(*) FROM bowtie_causes WHERE deleted=false) AS total_causes,
                (SELECT COUNT(*) FROM bowtie_consequences WHERE deleted=false) AS total_consequences,
                (SELECT COUNT(*) FROM bowtie_barriers WHERE deleted=false) AS total_barriers,
                (SELECT COUNT(*) FROM bowtie_controls WHERE deleted=false) AS total_controls,
                (SELECT AVG(bc)::numeric FROM 
                    (SELECT COUNT(*) as bc FROM bowtie_barriers WHERE deleted=false GROUP BY diagram_id) t) AS avg_barriers,
                (SELECT AVG(cc)::numeric FROM 
                    (SELECT COUNT(*) as cc FROM bowtie_controls WHERE deleted=false GROUP BY barrier_id) t) AS avg_controls";

        using var cmd = new NpgsqlCommand(query, conn);
        using var reader = await cmd.ExecuteReaderAsync();

        if (await reader.ReadAsync())
        {
            return new BowTieSummaryDto
            {
                TotalDiagrams = reader.GetInt32(reader.GetOrdinal("total_diagrams")),
                DiagramsLinkedToHazop = reader.GetInt32(reader.GetOrdinal("hazop_linked")),
                DiagramsLinkedToLopa = reader.GetInt32(reader.GetOrdinal("lopa_linked")),
                TotalCauses = reader.GetInt32(reader.GetOrdinal("total_causes")),
                TotalConsequences = reader.GetInt32(reader.GetOrdinal("total_consequences")),
                TotalBarriers = reader.GetInt32(reader.GetOrdinal("total_barriers")),
                TotalControls = reader.GetInt32(reader.GetOrdinal("total_controls")),
                AverageBarriersPerDiagram = reader.IsDBNull(reader.GetOrdinal("avg_barriers")) ? 0 : Convert.ToDouble(reader.GetDecimal(reader.GetOrdinal("avg_barriers"))),
                AverageControlsPerBarrier = reader.IsDBNull(reader.GetOrdinal("avg_controls")) ? 0 : Convert.ToDouble(reader.GetDecimal(reader.GetOrdinal("avg_controls"))),
            };
        }

        return new BowTieSummaryDto();
    }

    // Service overloads
    public Task<BowTieDiagramDetailDto?> GetBowTieDiagramAsync(string id) => GetDiagramAsync(id);

    public Task<string> CreateBowTieDiagramAsync(CreateBowTieDiagramDto dto, string userId) => CreateDiagramAsync(dto, userId);

    public Task<string> CreateBowTieBarrierAsync(CreateBowTieBarrierDto dto, string userId) => CreateBarrierAsync(dto, userId);

    public async Task<int> GetBowTieDiagramCountAsync()
    {
        using var conn = (NpgsqlConnection)await _connectionFactory.CreateOpenConnectionAsync();
        const string query = "SELECT COUNT(*)::int FROM bowtie_diagrams WHERE deleted=false";
        using var cmd = new NpgsqlCommand(query, conn);
        return (int?)(await cmd.ExecuteScalarAsync()) ?? 0;
    }
}
