using PSM.Api.DTOs;
using PSM.Api.Data;
using Npgsql;
using NpgsqlTypes;

namespace PSM.Api.Repositories;

/// <summary>
/// Interface for document attachment operations.
/// Manages linking documents to module records across all modules.
/// </summary>
public interface IDocumentAttachmentRepository
{
    // ─── Attachments ──────────────────────────────────────────────────────────
    Task<DocumentAttachmentDto?> GetAttachmentAsync(string attachmentId);
    Task<List<DocumentAttachmentDto>> GetAttachmentsByModuleRecordAsync(
        string module, string recordId);
    Task<List<DocumentAttachmentDto>> GetAttachmentsByDocumentAsync(string documentId);
    Task<DocumentAttachmentDto> CreateAttachmentAsync(AttachDocumentRequest request);
    Task<bool> DetachDocumentAsync(string attachmentId);
    Task<bool> ReorderAttachmentsAsync(string recordId, string module, Dictionary<string, int> sortOrders);
    
    // ─── Versions ─────────────────────────────────────────────────────────────
    Task<DocumentVersionDto?> GetVersionAsync(string versionId);
    Task<List<DocumentVersionDto>> GetVersionsByDocumentAsync(string documentId);
    Task<DocumentVersionDto> CreateVersionAsync(string documentId, UploadDocumentVersionRequest request);
    Task<bool> RestoreVersionAsync(string documentId, int versionNumber);
    Task<int> GetLatestVersionNumberAsync(string documentId);
    
    // ─── Previews ─────────────────────────────────────────────────────────────
    Task<DocumentPreviewDto?> GetPreviewAsync(string documentId, string? previewType = null);
    Task<DocumentPreviewDto> SavePreviewAsync(DocumentPreviewDto preview);
    Task<bool> DeletePreviewAsync(string previewId);
    
    // ─── Access Tracking ──────────────────────────────────────────────────────
    Task LogAccessAsync(DocumentAccessLogDto log);
    Task<List<DocumentAccessLogDto>> GetAccessLogAsync(string documentId, int limit = 100);
    Task<int> GetAccessCountAsync(string documentId);
    
    // ─── Module-specific queries ──────────────────────────────────────────────
    Task<ModuleDocumentSummaryDto> GetModuleDocumentSummaryAsync(string module, string recordId);
    Task<List<DocumentWithAttachmentsDto>> GetDocumentsWithAttachmentsAsync(
        string module, string recordId);
}

/// <summary>
/// Implementation of document attachment and versioning repository.
/// </summary>
public class DocumentAttachmentRepository : IDocumentAttachmentRepository
{
    private readonly IDbConnectionFactory _connectionFactory;
    private readonly ILogger<DocumentAttachmentRepository> _log;

    public DocumentAttachmentRepository(
        IDbConnectionFactory factory,
        ILogger<DocumentAttachmentRepository> log)
    {
        _connectionFactory = factory;
        _log = log;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Attachments
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<DocumentAttachmentDto?> GetAttachmentAsync(string attachmentId)
    {
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        const string sql = @"
            SELECT id, document_id, module, record_id, attachment_type, attachment_category,
                   description, sort_order, created_by, created_at, updated_at
            FROM document_attachments
            WHERE id = @id";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", attachmentId);

        await using var reader = await cmd.ExecuteReaderAsync();
        return await reader.ReadAsync() ? MapAttachment(reader) : null;
    }

    public async Task<List<DocumentAttachmentDto>> GetAttachmentsByModuleRecordAsync(
        string module, string recordId)
    {
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        const string sql = @"
            SELECT id, document_id, module, record_id, attachment_type, attachment_category,
                   description, sort_order, created_by, created_at, updated_at
            FROM document_attachments
            WHERE module = @module AND record_id = @recordId
            ORDER BY sort_order ASC, created_at DESC";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@module", module);
        cmd.Parameters.AddWithValue("@recordId", recordId);

        var attachments = new List<DocumentAttachmentDto>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            attachments.Add(MapAttachment(reader));
        }
        return attachments;
    }

    public async Task<List<DocumentAttachmentDto>> GetAttachmentsByDocumentAsync(string documentId)
    {
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        const string sql = @"
            SELECT id, document_id, module, record_id, attachment_type, attachment_category,
                   description, sort_order, created_by, created_at, updated_at
            FROM document_attachments
            WHERE document_id = @documentId
            ORDER BY created_at DESC";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@documentId", documentId);

        var attachments = new List<DocumentAttachmentDto>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            attachments.Add(MapAttachment(reader));
        }
        return attachments;
    }

    public async Task<DocumentAttachmentDto> CreateAttachmentAsync(AttachDocumentRequest request)
    {
        var id = Guid.NewGuid().ToString();
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        
        const string sql = @"
            INSERT INTO document_attachments
            (id, document_id, module, record_id, attachment_type, attachment_category,
             description, sort_order, created_by, created_at, updated_at)
            VALUES (@id, @documentId, @module, @recordId, @type, @category, @desc, @sort, @createdBy, NOW(), NOW())
            RETURNING id, document_id, module, record_id, attachment_type, attachment_category,
                      description, sort_order, created_by, created_at, updated_at";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@documentId", request.DocumentId);
        cmd.Parameters.AddWithValue("@module", request.Module);
        cmd.Parameters.AddWithValue("@recordId", request.RecordId);
        cmd.Parameters.AddWithValue("@type", (object?)request.AttachmentType ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@category", (object?)request.AttachmentCategory ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@desc", (object?)request.Description ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@sort", request.SortOrder);
        cmd.Parameters.AddWithValue("@createdBy", (object?)request.DocumentId ?? DBNull.Value);

        await using var reader = await cmd.ExecuteReaderAsync();
        await reader.ReadAsync();
        return MapAttachment(reader);
    }

    public async Task<bool> DetachDocumentAsync(string attachmentId)
    {
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        const string sql = "DELETE FROM document_attachments WHERE id = @id";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", attachmentId);

        var affectedRows = await cmd.ExecuteNonQueryAsync();
        return affectedRows > 0;
    }

    public async Task<bool> ReorderAttachmentsAsync(
        string recordId, string module, Dictionary<string, int> sortOrders)
    {
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        
        foreach (var (attachmentId, sortOrder) in sortOrders)
        {
            const string sql = @"
                UPDATE document_attachments
                SET sort_order = @sort, updated_at = NOW()
                WHERE id = @id AND module = @module AND record_id = @recordId";

            await using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", attachmentId);
            cmd.Parameters.AddWithValue("@module", module);
            cmd.Parameters.AddWithValue("@recordId", recordId);
            cmd.Parameters.AddWithValue("@sort", sortOrder);

            await cmd.ExecuteNonQueryAsync();
        }

        return true;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Versions
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<DocumentVersionDto?> GetVersionAsync(string versionId)
    {
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        const string sql = @"
            SELECT id, document_id, version_number, previous_id, file_path, file_size,
                   mime_type, change_summary, change_type, created_by, created_at
            FROM document_versions
            WHERE id = @id";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", versionId);

        await using var reader = await cmd.ExecuteReaderAsync();
        return await reader.ReadAsync() ? MapVersion(reader) : null;
    }

    public async Task<List<DocumentVersionDto>> GetVersionsByDocumentAsync(string documentId)
    {
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        const string sql = @"
            SELECT id, document_id, version_number, previous_id, file_path, file_size,
                   mime_type, change_summary, change_type, created_by, created_at
            FROM document_versions
            WHERE document_id = @documentId
            ORDER BY version_number DESC";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@documentId", documentId);

        var versions = new List<DocumentVersionDto>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            versions.Add(MapVersion(reader));
        }
        return versions;
    }

    public async Task<DocumentVersionDto> CreateVersionAsync(
        string documentId, UploadDocumentVersionRequest request)
    {
        var versionId = Guid.NewGuid().ToString();
        var latestVersion = await GetLatestVersionNumberAsync(documentId);
        var newVersionNumber = latestVersion + 1;

        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        const string sql = @"
            INSERT INTO document_versions
            (id, document_id, version_number, file_path, file_size, mime_type,
             change_summary, change_type, created_by, created_at)
            SELECT @id, document_id, @versionNum, file_path, file_size, mime_type,
                   @summary, @changeType, @createdBy, NOW()
            FROM documents
            WHERE id = @documentId
            RETURNING id, document_id, version_number, NULL as previous_id, file_path, file_size,
                      mime_type, change_summary, change_type, created_by, created_at";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", versionId);
        cmd.Parameters.AddWithValue("@documentId", documentId);
        cmd.Parameters.AddWithValue("@versionNum", newVersionNumber);
        cmd.Parameters.AddWithValue("@summary", (object?)request.ChangeSummary ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@changeType", (object?)request.ChangeType ?? "updated");
        cmd.Parameters.AddWithValue("@createdBy", "system");

        await using var reader = await cmd.ExecuteReaderAsync();
        await reader.ReadAsync();
        return MapVersion(reader);
    }

    public async Task<bool> RestoreVersionAsync(string documentId, int versionNumber)
    {
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        const string sql = @"
            UPDATE documents
            SET file_path = (SELECT file_path FROM document_versions 
                           WHERE document_id = @documentId AND version_number = @versionNum),
                file_size = (SELECT file_size FROM document_versions 
                           WHERE document_id = @documentId AND version_number = @versionNum),
                updated_at = NOW()
            WHERE id = @documentId";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@documentId", documentId);
        cmd.Parameters.AddWithValue("@versionNum", versionNumber);

        var affectedRows = await cmd.ExecuteNonQueryAsync();
        return affectedRows > 0;
    }

    public async Task<int> GetLatestVersionNumberAsync(string documentId)
    {
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        const string sql = @"
            SELECT COALESCE(MAX(version_number), 0) as latest
            FROM document_versions
            WHERE document_id = @documentId";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@documentId", documentId);

        await using var reader = await cmd.ExecuteReaderAsync();
        await reader.ReadAsync();
        return reader.GetInt32(0);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Previews
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<DocumentPreviewDto?> GetPreviewAsync(string documentId, string? previewType = null)
    {
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        
        var sql = @"
            SELECT id, document_id, preview_type, thumbnail_path, page_count,
                   preview_url, generated_at, expires_at
            FROM document_previews
            WHERE document_id = @documentId";

        if (!string.IsNullOrEmpty(previewType))
            sql += " AND preview_type = @previewType";

        sql += " ORDER BY generated_at DESC LIMIT 1";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@documentId", documentId);
        if (!string.IsNullOrEmpty(previewType))
            cmd.Parameters.AddWithValue("@previewType", previewType);

        await using var reader = await cmd.ExecuteReaderAsync();
        return await reader.ReadAsync() ? MapPreview(reader) : null;
    }

    public async Task<DocumentPreviewDto> SavePreviewAsync(DocumentPreviewDto preview)
    {
        var previewId = preview.Id ?? Guid.NewGuid().ToString();
        
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        const string sql = @"
            INSERT INTO document_previews
            (id, document_id, preview_type, thumbnail_path, page_count, preview_url, generated_at, expires_at)
            VALUES (@id, @documentId, @type, @thumb, @pages, @url, NOW(), @expires)
            ON CONFLICT (document_id, preview_type) DO UPDATE
            SET thumbnail_path = @thumb, page_count = @pages, preview_url = @url, generated_at = NOW()
            RETURNING id, document_id, preview_type, thumbnail_path, page_count, preview_url, generated_at, expires_at";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", previewId);
        cmd.Parameters.AddWithValue("@documentId", preview.DocumentId);
        cmd.Parameters.AddWithValue("@type", (object?)preview.PreviewType ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@thumb", (object?)preview.ThumbnailPath ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@pages", (object?)preview.PageCount ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@url", (object?)preview.PreviewUrl ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@expires", (object?)preview.ExpiresAt ?? DBNull.Value);

        await using var reader = await cmd.ExecuteReaderAsync();
        await reader.ReadAsync();
        return MapPreview(reader);
    }

    public async Task<bool> DeletePreviewAsync(string previewId)
    {
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        const string sql = "DELETE FROM document_previews WHERE id = @id";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", previewId);

        var affectedRows = await cmd.ExecuteNonQueryAsync();
        return affectedRows > 0;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Access Tracking
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task LogAccessAsync(DocumentAccessLogDto log)
    {
        var logId = Guid.NewGuid().ToString();
        
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        const string sql = @"
            INSERT INTO document_access_log
            (id, document_id, user_id, action_type, access_time, ip_address, user_agent)
            VALUES (@id, @documentId, @userId, @action, NOW(), @ip, @agent)";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", logId);
        cmd.Parameters.AddWithValue("@documentId", log.DocumentId);
        cmd.Parameters.AddWithValue("@userId", (object?)log.UserId ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@action", log.ActionType ?? "view");
        cmd.Parameters.AddWithValue("@ip", (object?)log.IpAddress ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@agent", (object?)log.UserAgent ?? DBNull.Value);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<List<DocumentAccessLogDto>> GetAccessLogAsync(string documentId, int limit = 100)
    {
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        const string sql = @"
            SELECT id, document_id, user_id, action_type, access_time, ip_address, user_agent
            FROM document_access_log
            WHERE document_id = @documentId
            ORDER BY access_time DESC
            LIMIT @limit";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@documentId", documentId);
        cmd.Parameters.AddWithValue("@limit", limit);

        var logs = new List<DocumentAccessLogDto>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            logs.Add(MapAccessLog(reader));
        }
        return logs;
    }

    public async Task<int> GetAccessCountAsync(string documentId)
    {
        await using var conn = await _connectionFactory.CreateOpenConnectionAsync();
        const string sql = @"
            SELECT COUNT(*) FROM document_access_log
            WHERE document_id = @documentId AND action_type = 'download'";

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@documentId", documentId);

        var result = await cmd.ExecuteScalarAsync();
        return result != null ? Convert.ToInt32(result) : 0;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Module-specific Queries
    // ═══════════════════════════════════════════════════════════════════════════

    public async Task<ModuleDocumentSummaryDto> GetModuleDocumentSummaryAsync(string module, string recordId)
    {
        var attachments = await GetAttachmentsByModuleRecordAsync(module, recordId);
        
        var summary = new ModuleDocumentSummaryDto
        {
            Module = module,
            RecordId = recordId,
            TotalDocuments = attachments.Count,
            Attachments = attachments,
        };

        // Count all versions
        int totalVersions = 0;
        foreach (var attachment in attachments)
        {
            var versions = await GetVersionsByDocumentAsync(attachment.DocumentId);
            totalVersions += versions.Count;
        }

        summary.TotalVersions = totalVersions;
        summary.LastDocumentAdded = attachments.FirstOrDefault()?.CreatedAt;

        return summary;
    }

    public async Task<List<DocumentWithAttachmentsDto>> GetDocumentsWithAttachmentsAsync(
        string module, string recordId)
    {
        var attachments = await GetAttachmentsByModuleRecordAsync(module, recordId);
        var results = new List<DocumentWithAttachmentsDto>();

        foreach (var attachment in attachments)
        {
            // Note: Would need to implement GetDocumentAsync from DocumentRepository
            var item = new DocumentWithAttachmentsDto
            {
                Attachments = new List<DocumentAttachmentDto> { attachment },
            };
            results.Add(item);
        }

        return results;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Mappers
    // ═══════════════════════════════════════════════════════════════════════════

    private static DocumentAttachmentDto MapAttachment(NpgsqlDataReader reader)
    {
        return new DocumentAttachmentDto
        {
            Id = reader.GetString(0),
            DocumentId = reader.GetString(1),
            Module = reader.GetString(2),
            RecordId = reader.GetString(3),
            AttachmentType = reader.IsDBNull(4) ? null : reader.GetString(4),
            AttachmentCategory = reader.IsDBNull(5) ? null : reader.GetString(5),
            Description = reader.IsDBNull(6) ? null : reader.GetString(6),
            SortOrder = reader.GetInt32(7),
            CreatedBy = reader.IsDBNull(8) ? null : reader.GetString(8),
            CreatedAt = reader.GetDateTime(9),
            UpdatedAt = reader.GetDateTime(10),
        };
    }

    private static DocumentVersionDto MapVersion(NpgsqlDataReader reader)
    {
        return new DocumentVersionDto
        {
            Id = reader.GetString(0),
            DocumentId = reader.GetString(1),
            VersionNumber = reader.GetInt32(2),
            PreviousId = reader.IsDBNull(3) ? null : reader.GetString(3),
            FilePath = reader.IsDBNull(4) ? null : reader.GetString(4),
            FileSize = reader.IsDBNull(5) ? null : reader.GetInt64(5),
            MimeType = reader.IsDBNull(6) ? null : reader.GetString(6),
            ChangeSummary = reader.IsDBNull(7) ? null : reader.GetString(7),
            ChangeType = reader.IsDBNull(8) ? null : reader.GetString(8),
            CreatedBy = reader.IsDBNull(9) ? null : reader.GetString(9),
            CreatedAt = reader.GetDateTime(10),
        };
    }

    private static DocumentPreviewDto MapPreview(NpgsqlDataReader reader)
    {
        return new DocumentPreviewDto
        {
            Id = reader.GetString(0),
            DocumentId = reader.GetString(1),
            PreviewType = reader.IsDBNull(2) ? null : reader.GetString(2),
            ThumbnailPath = reader.IsDBNull(3) ? null : reader.GetString(3),
            PageCount = reader.IsDBNull(4) ? null : reader.GetInt32(4),
            PreviewUrl = reader.IsDBNull(5) ? null : reader.GetString(5),
            GeneratedAt = reader.GetDateTime(6),
            ExpiresAt = reader.IsDBNull(7) ? null : reader.GetDateTime(7),
        };
    }

    private static DocumentAccessLogDto MapAccessLog(NpgsqlDataReader reader)
    {
        return new DocumentAccessLogDto
        {
            Id = reader.GetString(0),
            DocumentId = reader.GetString(1),
            UserId = reader.IsDBNull(2) ? null : reader.GetString(2),
            ActionType = reader.IsDBNull(3) ? null : reader.GetString(3),
            AccessTime = reader.GetDateTime(4),
            IpAddress = reader.IsDBNull(5) ? null : reader.GetString(5),
            UserAgent = reader.IsDBNull(6) ? null : reader.GetString(6),
        };
    }
}
