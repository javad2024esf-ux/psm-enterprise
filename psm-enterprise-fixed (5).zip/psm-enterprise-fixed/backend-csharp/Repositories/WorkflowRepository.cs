using System.Data;
using Dapper;
using PSM.Api.Data;
using PSM.Api.DTOs;

namespace PSM.Api.Repositories;

public interface IWorkflowRepository
{
    // ── Definitions ─────────────────────────────────────────────────────────
    Task<IEnumerable<WorkflowDefinitionDto>> ListDefinitionsAsync();
    Task<WorkflowDefinitionDto?> GetActiveDefinitionByModuleAsync(string module);
    Task<WorkflowDefinitionDto?> GetDefinitionByIdAsync(string id);
    Task<IEnumerable<WorkflowStateDto>> GetStatesAsync(string workflowId);
    Task<IEnumerable<WorkflowTransitionDto>> GetTransitionsAsync(string workflowId);
    Task<WorkflowTransitionDto?> FindTransitionAsync(string workflowId, string fromState, string action);
    Task<WorkflowStateDto?> GetStateAsync(string workflowId, string stateName);
    Task<bool> StatesExistAsync(string workflowId);

    // ── Records (FK guard — workflow_instances.record_id → records.id) ─────
    Task<bool> RecordExistsAsync(string recordId);
    Task SyncRecordStatusAsync(IDbConnection conn, IDbTransaction tx, string recordId, string status, string updatedBy);

    // ── Instances ────────────────────────────────────────────────────────────
    Task<WorkflowInstanceDto?> GetInstanceByRecordIdAsync(string recordId);
    Task<WorkflowInstanceDto?> GetInstanceByIdAsync(string instanceId);
    Task<string> CreateInstanceAsync(IDbConnection conn, IDbTransaction tx, string id, string recordId,
        string workflowId, string collection, string currentState, DateTime? dueAt,
        string escalationPolicy, string? createdBy);
    Task UpdateInstanceStateAsync(IDbConnection conn, IDbTransaction tx, string instanceId,
        string newState, DateTime? dueAt, DateTime? completedAt);
    Task MarkInstanceCompletedAsync(IDbConnection conn, IDbTransaction tx, string instanceId);

    // ── History ──────────────────────────────────────────────────────────────
    Task InsertHistoryAsync(IDbConnection conn, IDbTransaction tx, string id, string instanceId,
        string action, string? fromState, string? toState, string comment, string performedBy);
    Task<IEnumerable<WorkflowHistoryDto>> GetHistoryAsync(string instanceId);

    // ── Pending approvals ────────────────────────────────────────────────────
    Task InsertPendingApprovalAsync(IDbConnection conn, IDbTransaction tx, string id, string instanceId,
        string role, DateTime? dueAt, int priority);
    Task ResolveOpenApprovalsAsync(IDbConnection conn, IDbTransaction tx, string instanceId,
        string response, string? comment);
    Task<IEnumerable<PendingApprovalDto>> GetPendingForRoleAsync(string role, string? userId);
    Task<int> CountPendingAsync();

    // ── Escalations ──────────────────────────────────────────────────────────
    Task<IEnumerable<(string InstanceId, string EscalationPolicy, DateTime DueAt)>> GetOverdueInstancesRawAsync();
    Task<string?> GetEscalationPolicyRulesAsync(string policyName);
    Task<bool> EscalationExistsAsync(string instanceId, int level);
    Task InsertEscalationAsync(string id, string instanceId, string escalateTo, string[] notifyRoles,
        int level, string? reason);
    Task MarkApprovalsEscalatedAsync(string instanceId, string escalateTo);
    Task<IEnumerable<EscalationDto>> GetRecentEscalationsAsync(int limit = 10);
    Task<int> CountUnacknowledgedEscalationsAsync();

    // ── SLA breaches ─────────────────────────────────────────────────────────
    Task ResolveOpenBreachesAsync(IDbConnection conn, IDbTransaction tx, string instanceId);
    Task<int> CountActiveBreachesAsync();

    // ── Audit trail (domain-specific, workflow_audit_trail table) ───────────
    Task InsertAuditTrailAsync(IDbConnection conn, IDbTransaction tx, string id, string instanceId,
        string action, string? changeBeforeJson, string? changeAfterJson, string changedBy, string? reason);

    // ── Dashboard / analytics ───────────────────────────────────────────────
    Task<WorkflowDashboardDto> GetDashboardSummaryAsync();
    Task<IEnumerable<WorkflowInstanceDto>> GetOverdueInstancesAsync(int limit = 20);
    Task<IEnumerable<ModuleStatDto>> GetModuleStatsAsync();

    // ── Transaction helper (delegates to IDbHelper) ──────────────────────────
    Task WithTransactionAsync(Func<IDbConnection, IDbTransaction, Task> fn);
}

public class WorkflowRepository : IWorkflowRepository
{
    private readonly IDbHelper _db;
    public WorkflowRepository(IDbHelper db) => _db = db;

    public Task WithTransactionAsync(Func<IDbConnection, IDbTransaction, Task> fn) =>
        _db.WithTransactionAsync(fn);

    // ─── Definitions ────────────────────────────────────────────────────────
    public Task<IEnumerable<WorkflowDefinitionDto>> ListDefinitionsAsync() =>
        _db.QueryAsync<WorkflowDefinitionDto>(@"
            SELECT id, name, module, version, config::text AS config, is_active,
                   created_by, created_at, updated_at
            FROM workflow_definitions
            ORDER BY module, version DESC");

    public Task<WorkflowDefinitionDto?> GetActiveDefinitionByModuleAsync(string module) =>
        _db.QueryFirstOrDefaultAsync<WorkflowDefinitionDto>(@"
            SELECT id, name, module, version, config::text AS config, is_active,
                   created_by, created_at, updated_at
            FROM workflow_definitions
            WHERE module = @module AND is_active = true
            ORDER BY version DESC
            LIMIT 1", new { module });

    public Task<WorkflowDefinitionDto?> GetDefinitionByIdAsync(string id) =>
        _db.QueryFirstOrDefaultAsync<WorkflowDefinitionDto>(@"
            SELECT id, name, module, version, config::text AS config, is_active,
                   created_by, created_at, updated_at
            FROM workflow_definitions WHERE id = @id", new { id });

    public Task<IEnumerable<WorkflowStateDto>> GetStatesAsync(string workflowId) =>
        _db.QueryAsync<WorkflowStateDto>(@"
            SELECT id, workflow_id, name, label, is_initial, is_final, sla_hours, required_role, color
            FROM workflow_states WHERE workflow_id = @workflowId", new { workflowId });

    public Task<IEnumerable<WorkflowTransitionDto>> GetTransitionsAsync(string workflowId) =>
        _db.QueryAsync<WorkflowTransitionDto>(@"
            SELECT id, workflow_id, from_state, to_state, action, label, required_role
            FROM workflow_transitions WHERE workflow_id = @workflowId", new { workflowId });

    public Task<WorkflowTransitionDto?> FindTransitionAsync(string workflowId, string fromState, string action) =>
        _db.QueryFirstOrDefaultAsync<WorkflowTransitionDto>(@"
            SELECT id, workflow_id, from_state, to_state, action, label, required_role
            FROM workflow_transitions
            WHERE workflow_id = @workflowId AND from_state = @fromState AND action = @action
            LIMIT 1", new { workflowId, fromState, action });

    public Task<WorkflowStateDto?> GetStateAsync(string workflowId, string stateName) =>
        _db.QueryFirstOrDefaultAsync<WorkflowStateDto>(@"
            SELECT id, workflow_id, name, label, is_initial, is_final, sla_hours, required_role, color
            FROM workflow_states WHERE workflow_id = @workflowId AND name = @stateName
            LIMIT 1", new { workflowId, stateName });

    public async Task<bool> StatesExistAsync(string workflowId)
    {
        var count = await _db.ExecuteScalarAsync<long>(
            "SELECT COUNT(1) FROM workflow_states WHERE workflow_id = @workflowId", new { workflowId });
        return count > 0;
    }

    // ─── Records FK guard ───────────────────────────────────────────────────
    public async Task<bool> RecordExistsAsync(string recordId)
    {
        var count = await _db.ExecuteScalarAsync<long>(
            "SELECT COUNT(1) FROM records WHERE id = @recordId AND deleted = false", new { recordId });
        return count > 0;
    }

    public Task SyncRecordStatusAsync(IDbConnection conn, IDbTransaction tx, string recordId, string status, string updatedBy) =>
        conn.ExecuteAsync(
            "UPDATE records SET status = @status, updated_at = NOW() WHERE id = @recordId",
            new { status, recordId }, tx);

    // ─── Instances ──────────────────────────────────────────────────────────
    public Task<WorkflowInstanceDto?> GetInstanceByRecordIdAsync(string recordId) =>
        _db.QueryFirstOrDefaultAsync<WorkflowInstanceDto>(@"
            SELECT id, record_id, workflow_id, collection, current_state, due_at, completed_at,
                   escalation_policy, created_by, created_at, updated_at
            FROM workflow_instances WHERE record_id = @recordId", new { recordId });

    public Task<WorkflowInstanceDto?> GetInstanceByIdAsync(string instanceId) =>
        _db.QueryFirstOrDefaultAsync<WorkflowInstanceDto>(@"
            SELECT id, record_id, workflow_id, collection, current_state, due_at, completed_at,
                   escalation_policy, created_by, created_at, updated_at
            FROM workflow_instances WHERE id = @instanceId", new { instanceId });

    public async Task<string> CreateInstanceAsync(IDbConnection conn, IDbTransaction tx, string id, string recordId,
        string workflowId, string collection, string currentState, DateTime? dueAt,
        string escalationPolicy, string? createdBy)
    {
        await conn.ExecuteAsync(@"
            INSERT INTO workflow_instances
                (id, record_id, workflow_id, collection, current_state, due_at,
                 escalation_policy, created_by, created_at, updated_at)
            VALUES
                (@id, @recordId, @workflowId, @collection, @currentState, @dueAt,
                 @escalationPolicy, @createdBy, NOW(), NOW())",
            new { id, recordId, workflowId, collection, currentState, dueAt, escalationPolicy, createdBy }, tx);
        return id;
    }

    public Task UpdateInstanceStateAsync(IDbConnection conn, IDbTransaction tx, string instanceId,
        string newState, DateTime? dueAt, DateTime? completedAt) =>
        conn.ExecuteAsync(@"
            UPDATE workflow_instances
            SET current_state = @newState, due_at = @dueAt, completed_at = @completedAt, updated_at = NOW()
            WHERE id = @instanceId",
            new { instanceId, newState, dueAt, completedAt }, tx);

    public Task MarkInstanceCompletedAsync(IDbConnection conn, IDbTransaction tx, string instanceId) =>
        conn.ExecuteAsync(@"
            UPDATE workflow_instances SET completed_at = NOW(), updated_at = NOW()
            WHERE id = @instanceId AND completed_at IS NULL", new { instanceId }, tx);

    // ─── History ────────────────────────────────────────────────────────────
    public Task InsertHistoryAsync(IDbConnection conn, IDbTransaction tx, string id, string instanceId,
        string action, string? fromState, string? toState, string comment, string performedBy) =>
        conn.ExecuteAsync(@"
            INSERT INTO workflow_history (id, instance_id, action, from_state, to_state, comment, performed_by, performed_at)
            VALUES (@id, @instanceId, @action, @fromState, @toState, @comment, @performedBy, NOW())",
            new { id, instanceId, action, fromState, toState, comment, performedBy }, tx);

    public Task<IEnumerable<WorkflowHistoryDto>> GetHistoryAsync(string instanceId) =>
        _db.QueryAsync<WorkflowHistoryDto>(@"
            SELECT h.id, h.instance_id, h.action, h.from_state, h.to_state, h.comment,
                   h.performed_by, u.full_name AS performed_by_name, h.performed_at
            FROM workflow_history h
            LEFT JOIN users u ON u.id = h.performed_by
            WHERE h.instance_id = @instanceId
            ORDER BY h.performed_at ASC", new { instanceId });

    // ─── Pending approvals ──────────────────────────────────────────────────
    public Task InsertPendingApprovalAsync(IDbConnection conn, IDbTransaction tx, string id, string instanceId,
        string role, DateTime? dueAt, int priority) =>
        conn.ExecuteAsync(@"
            INSERT INTO workflow_pending_approvals (id, instance_id, role, status, assigned_at, due_at, priority)
            VALUES (@id, @instanceId, @role, 'pending', NOW(), @dueAt, @priority)",
            new { id, instanceId, role, dueAt, priority }, tx);

    public Task ResolveOpenApprovalsAsync(IDbConnection conn, IDbTransaction tx, string instanceId,
        string response, string? comment) =>
        conn.ExecuteAsync(@"
            UPDATE workflow_pending_approvals
            SET status = @response, responded_at = NOW(), response = @response, response_comment = @comment
            WHERE instance_id = @instanceId AND status = 'pending'",
            new { instanceId, response, comment }, tx);

    public Task<IEnumerable<PendingApprovalDto>> GetPendingForRoleAsync(string role, string? userId) =>
        _db.QueryAsync<PendingApprovalDto>(@"
            SELECT pa.id, pa.instance_id, pa.role, pa.assigned_to, pa.status, pa.assigned_at,
                   pa.due_at, pa.priority, pa.escalated, wi.record_id, wi.collection
            FROM workflow_pending_approvals pa
            JOIN workflow_instances wi ON wi.id = pa.instance_id
            WHERE pa.status = 'pending' AND (pa.role = @role OR pa.assigned_to = @userId)
            ORDER BY pa.priority DESC, pa.due_at ASC NULLS LAST
            LIMIT 50", new { role, userId });

    public async Task<int> CountPendingAsync() =>
        (int)await _db.ExecuteScalarAsync<long>("SELECT COUNT(1) FROM workflow_pending_approvals WHERE status='pending'");

    // ─── Escalations ────────────────────────────────────────────────────────
    public Task<IEnumerable<(string InstanceId, string EscalationPolicy, DateTime DueAt)>> GetOverdueInstancesRawAsync()
        => GetOverdueInstancesRawInternalAsync();

    private async Task<IEnumerable<(string InstanceId, string EscalationPolicy, DateTime DueAt)>> GetOverdueInstancesRawInternalAsync()
    {
        var rows = await _db.QueryAsync<(string Id, string EscalationPolicy, DateTime DueAt)>(@"
            SELECT id, escalation_policy, due_at
            FROM workflow_instances
            WHERE completed_at IS NULL AND due_at IS NOT NULL AND due_at < NOW()");
        return rows.Select(r => (r.Id, r.EscalationPolicy, r.DueAt));
    }

    public Task<string?> GetEscalationPolicyRulesAsync(string policyName) =>
        _db.ExecuteScalarAsync<string?>(@"
            SELECT rules::text FROM workflow_escalation_policies
            WHERE name = @policyName AND is_active = true LIMIT 1", new { policyName });

    public async Task<bool> EscalationExistsAsync(string instanceId, int level)
    {
        var count = await _db.ExecuteScalarAsync<long>(@"
            SELECT COUNT(1) FROM workflow_escalations
            WHERE instance_id = @instanceId AND escalation_level = @level", new { instanceId, level });
        return count > 0;
    }

    public Task InsertEscalationAsync(string id, string instanceId, string escalateTo, string[] notifyRoles,
        int level, string? reason) =>
        _db.ExecuteAsync(@"
            INSERT INTO workflow_escalations
                (id, instance_id, escalate_to, notify_roles, escalation_level, reason,
                 notification_sent, sent_at, escalated_at)
            VALUES (@id, @instanceId, @escalateTo, @notifyRoles, @level, @reason, true, NOW(), NOW())
            ON CONFLICT DO NOTHING",
            new { id, instanceId, escalateTo, notifyRoles, level, reason });

    public Task MarkApprovalsEscalatedAsync(string instanceId, string escalateTo) =>
        _db.ExecuteAsync(@"
            UPDATE workflow_pending_approvals
            SET escalated = true, escalated_at = NOW(), escalated_to = @escalateTo
            WHERE instance_id = @instanceId AND status = 'pending' AND escalated = false",
            new { instanceId, escalateTo });

    public Task<IEnumerable<EscalationDto>> GetRecentEscalationsAsync(int limit = 10) =>
        _db.QueryAsync<EscalationDto>(@"
            SELECT id, instance_id, escalate_to, notify_roles, escalation_level, reason,
                   notification_sent, acknowledged, escalated_at
            FROM workflow_escalations
            WHERE acknowledged = false
            ORDER BY escalated_at DESC
            LIMIT @limit", new { limit });

    public async Task<int> CountUnacknowledgedEscalationsAsync() =>
        (int)await _db.ExecuteScalarAsync<long>("SELECT COUNT(1) FROM workflow_escalations WHERE acknowledged = false");

    // ─── SLA breaches ───────────────────────────────────────────────────────
    public Task ResolveOpenBreachesAsync(IDbConnection conn, IDbTransaction tx, string instanceId) =>
        conn.ExecuteAsync(@"
            UPDATE workflow_sla_breaches SET resolved = true, resolved_at = NOW()
            WHERE instance_id = @instanceId AND resolved = false", new { instanceId }, tx);

    public async Task<int> CountActiveBreachesAsync() =>
        (int)await _db.ExecuteScalarAsync<long>("SELECT COUNT(1) FROM workflow_sla_breaches WHERE resolved = false");

    // ─── Audit trail ────────────────────────────────────────────────────────
    public Task InsertAuditTrailAsync(IDbConnection conn, IDbTransaction tx, string id, string instanceId,
        string action, string? changeBeforeJson, string? changeAfterJson, string changedBy, string? reason) =>
        conn.ExecuteAsync(@"
            INSERT INTO workflow_audit_trail
                (id, instance_id, action, change_before, change_after, changed_by, changed_at, reason)
            VALUES (@id, @instanceId, @action, @changeBeforeJson::jsonb, @changeAfterJson::jsonb, @changedBy, NOW(), @reason)",
            new { id, instanceId, action, changeBeforeJson, changeAfterJson, changedBy, reason }, tx);

    // ─── Dashboard / analytics ──────────────────────────────────────────────
    public async Task<WorkflowDashboardDto> GetDashboardSummaryAsync()
    {
        // Column names in the view (active_workflows, overdue_workflows, ...) map
        // directly onto the DTO's PascalCase properties via Dapper's global
        // MatchNamesWithUnderscores setting (see Program.cs).
        var row = await _db.QueryFirstOrDefaultAsync<WorkflowDashboardDto>(
            "SELECT * FROM workflow_dashboard_summary");
        return row ?? new WorkflowDashboardDto();
    }

    public Task<IEnumerable<WorkflowInstanceDto>> GetOverdueInstancesAsync(int limit = 20) =>
        _db.QueryAsync<WorkflowInstanceDto>(@"
            SELECT id, record_id, workflow_id, collection, current_state, due_at, completed_at,
                   escalation_policy, created_by, created_at, updated_at
            FROM workflow_instances
            WHERE completed_at IS NULL AND due_at IS NOT NULL AND due_at < NOW()
            ORDER BY due_at ASC
            LIMIT @limit", new { limit });

    public Task<IEnumerable<ModuleStatDto>> GetModuleStatsAsync() =>
        _db.QueryAsync<ModuleStatDto>(@"
            SELECT wd.module AS Module,
                   COUNT(*) FILTER (WHERE wi.completed_at IS NULL)::int AS ActiveCount,
                   COUNT(*) FILTER (WHERE wi.completed_at IS NOT NULL)::int AS CompletedCount,
                   ROUND(AVG(EXTRACT(EPOCH FROM (wi.completed_at - wi.created_at)) / 3600.0)
                         FILTER (WHERE wi.completed_at IS NOT NULL))::float AS AvgCompletionHours
            FROM workflow_instances wi
            JOIN workflow_definitions wd ON wd.id = wi.workflow_id
            GROUP BY wd.module
            ORDER BY wd.module");
}
