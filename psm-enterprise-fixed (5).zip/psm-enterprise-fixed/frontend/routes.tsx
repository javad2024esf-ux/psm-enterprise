import { Route } from 'react-router-dom';
import LOPADashboard from './components/LOPADashboard'; <Route path="/lopa" element={<LOPADashboard />} errorElement={<ErrorPage />} />
