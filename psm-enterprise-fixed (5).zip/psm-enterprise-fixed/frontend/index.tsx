import React from 'react';
import ReactDOM from 'react-dom/client';
import Root from './Root';
import './index.css'; // ─── Web mode: webApi به‌طور مستقیم در App.tsx و PSMContext ایمپورت می‌شود
// نیازی به inject به window.api نیست const rootElement = document?.getElementById('root');
if (!rootElement) throw new Error('Could not find root element'); ReactDOM?.createRoot(rootElement)?.render( <React.StrictMode> <Root /> </React.StrictMode>
);
