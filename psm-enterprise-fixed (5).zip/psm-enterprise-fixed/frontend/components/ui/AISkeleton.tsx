
import React from 'react'; export const AISkeleton: React.FC = () => ( <div className="animate-pulse space-y-3 p-4 bg-gray-50 rounded-lg"> <div className="h-4 bg-gray-200 rounded w-3/4"></div> <div className="h-4 bg-gray-200 rounded w-1/2"></div> <div className="h-8 bg-gray-200 rounded w-full"></div> </div>;
);
