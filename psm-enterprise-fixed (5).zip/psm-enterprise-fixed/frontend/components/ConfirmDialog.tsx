import React, { useState, useCallback, useRef, FC, ReactNode } from 'react';
import { AlertTriangle, Trash2, X, Check } from 'lucide-react';

export interface ConfirmOptions {
  title?: string; message: string; confirmLabel?: string; cancelLabel?: string; danger?: boolean;
}

interface ConfirmState extends ConfirmOptions { resolve: (v: boolean) => void; }

let _openConfirm: ((opts: ConfirmOptions) => Promise<boolean>) | null = null;

export function confirm(message: string, opts?: Partial<ConfirmOptions>): Promise<boolean> {
  if (_openConfirm) return _openConfirm({ message, ...opts });
  return Promise.resolve(false);
}

export const ConfirmProvider: FC<{ children: ReactNode }> = ({ children }) => {
  const [state, setState] = useState<ConfirmState | null>(null);
  const resolveRef = useRef<((v: boolean) => void) | null>(null);

  const openConfirm = useCallback((opts: ConfirmOptions): Promise<boolean> => {
    return new Promise(resolve => {
      resolveRef.current = resolve;
      setState({ ...opts, resolve });
    });
  }, []);

  React.useEffect(() => { _openConfirm = openConfirm; return () => { _openConfirm = null; }; }, [openConfirm]);

  const handleClose = useCallback((val: boolean) => {
    state?.resolve(val);
    setState(null);
  }, [state]);

  return (
    <>
      {children}
      {state && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-sm" dir="rtl">
          <div className="w-full max-w-sm mx-4 rounded-2xl shadow-2xl overflow-hidden"
            style={{ background: 'linear-gradient(135deg, #101827 0%, #0c1422 100%)', border: '1px solid rgba(255,255,255,0.1)' }}>
            <div className="flex items-center gap-3 px-5 py-4" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${state.danger ? 'bg-red-500/15' : 'bg-amber-500/15'}`}>
                {state.danger ? <Trash2 size={18} className="text-red-400" /> : <AlertTriangle size={18} className="text-amber-400" />}
              </div>
              <h3 className="text-[14px] font-semibold text-slate-200">{state.title ?? 'تأیید عملیات'}</h3>
              <button onClick={() => handleClose(false)} className="mr-auto p-1 rounded-lg hover:bg-white/8 text-slate-500"><X size={15} /></button>
            </div>
            <div className="px-5 py-4">
              <p className="text-[13px] text-slate-400 leading-relaxed">{state.message}</p>
            </div>
            <div className="flex gap-2 px-5 pb-4">
              <button onClick={() => handleClose(false)}
                className="flex-1 px-4 py-2 rounded-xl text-[13px] font-medium transition-colors hover:bg-white/8"
                style={{ background: 'rgba(255,255,255,0.05)', color: 'rgba(148,163,184,0.8)', border: '1px solid rgba(255,255,255,0.08)' }}>
                {state.cancelLabel ?? 'انصراف'}
              </button>
              <button onClick={() => handleClose(true)}
                className="flex-1 px-4 py-2 rounded-xl text-[13px] font-bold flex items-center justify-center gap-1.5 transition-all"
                style={{ background: state.danger ? 'linear-gradient(135deg,#ef4444,#dc2626)' : 'linear-gradient(135deg,#3b82f6,#2563eb)', color: 'white' }}>
                {state.danger ? <Trash2 size={14} /> : <Check size={14} />}
                {state.confirmLabel ?? 'تأیید'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ConfirmProvider;
