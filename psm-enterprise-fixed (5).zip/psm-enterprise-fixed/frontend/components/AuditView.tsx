import React, { FC } from 'react';
interface Props { token?: string; activeUnit?: string; onExport?: () => void; [key: string]: unknown; }
const AuditView: FC<Props> = () => (
  <div className="flex items-center justify-center h-64 text-slate-500 text-sm" dir="rtl">ممیزی و بازرسی</div>
);

export default AuditView;
