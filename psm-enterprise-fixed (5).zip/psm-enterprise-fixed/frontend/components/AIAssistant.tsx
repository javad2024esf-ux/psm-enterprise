import React, { FC } from 'react';
interface Props { token?: string; activeUnit?: string; onExport?: () => void; [key: string]: unknown; }
const AIAssistant: FC<Props> = () => (
  <div className="flex items-center justify-center h-64 text-slate-500 text-sm" dir="rtl">دستیار هوش مصنوعی</div>
);
export const AIAssistPanel: React.FC<Props> = () => <div className="hidden" />;  // stub
export default AIAssistant;
