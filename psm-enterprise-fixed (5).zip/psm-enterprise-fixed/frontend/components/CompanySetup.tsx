import React, { useState, FC } from 'react';
import { Building2, CheckCircle2, Loader2 } from 'lucide-react';
import { webApi } from '../src/webApi';
import { useAuth } from '../src/context/AuthContext';

export interface CompanySetupProps { onComplete: () => void; }

const CompanySetup: FC<CompanySetupProps> = ({ onComplete }) => {
  const { token } = useAuth();
  const [companyName, setCompanyName] = useState('');
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyName.trim()) return;
    setLoading(true);
    try {
      await (webApi as { updateCompanyConfig: (token: string, data: unknown) => Promise<unknown> }).updateCompanyConfig(token!, { companyName });
      setDone(true);
      setTimeout(onComplete, 800);
    } catch {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#060b17]" dir="rtl">
      <div className="w-full max-w-md mx-4 rounded-2xl p-8" style={{ background: 'linear-gradient(135deg,#101827,#0c1422)', border: '1px solid rgba(255,255,255,0.08)' }}>
        <div className="text-center mb-6">
          <Building2 size={40} className="text-sky-400 mx-auto mb-3" />
          <h2 className="text-xl font-bold text-slate-100">راه‌اندازی اولیه</h2>
          <p className="text-slate-400 text-sm mt-1">نام شرکت خود را وارد کنید</p>
        </div>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <input value={companyName} onChange={e => setCompanyName(e.target.value)}
            className="w-full px-4 py-3 rounded-xl text-slate-200 outline-none text-sm"
            style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
            placeholder="نام شرکت یا مجتمع صنعتی" />
          <button type="submit" disabled={loading || !companyName.trim()}
            className="w-full py-3 rounded-xl text-sm font-bold text-white flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            style={{ background: 'linear-gradient(135deg,#0ea5e9,#6366f1)' }}>
            {done ? <CheckCircle2 size={16} /> : loading ? <Loader2 size={16} className="animate-spin" /> : null}
            {done ? 'ذخیره شد!' : loading ? 'در حال ذخیره...' : 'ادامه'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default CompanySetup;
