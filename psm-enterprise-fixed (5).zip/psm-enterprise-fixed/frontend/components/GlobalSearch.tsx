import React, { useState, useEffect, useRef, FC, ReactNode } from 'react';
import { Search, X, Command, FileText, ShieldAlert, RefreshCcw, AlertTriangle, Flame,
  ClipboardCheck, Wrench, SearchCheck, GraduationCap, Heart, Scroll, Binary, Users,
  Globe, BookOpen, HardHat, LifeBuoy, Radio, Gauge, Lock, ListChecks, Target,
  LayoutDashboard, Settings, Zap, ChevronRight } from 'lucide-react';
import { PSMElement } from '../types';

export interface SearchResult {
  id: string; title: string; subtitle?: string; type: 'module' | 'record' | 'action';
  module: string; moduleLabel: string; icon: ReactNode; navigateTo: string; keywords?: string[];
}

export interface GlobalSearchProps {
  isOpen: boolean; onClose: () => void; onNavigate: (element: string) => void;
}

const MODULE_ICONS: Record<string, ReactNode> = {
  DASHBOARD: <LayoutDashboard size={15} className="text-sky-400" />,
  GAP_ANALYSIS: <Target size={15} className="text-violet-400" />,
  [PSMElement.ACTION_REGISTER]: <ListChecks size={15} className="text-teal-400" />,
  [PSMElement.CULTURE]: <Heart size={15} className="text-rose-400" />,
  [PSMElement.STANDARDS]: <Scroll size={15} className="text-amber-400" />,
  [PSMElement.COMPETENCY]: <Binary size={15} className="text-indigo-400" />,
  [PSMElement.WORKFORCE]: <Users size={15} className="text-blue-400" />,
  [PSMElement.STAKEHOLDER]: <Globe size={15} className="text-green-400" />,
  [PSMElement.KNOWLEDGE]: <FileText size={15} className="text-orange-400" />,
  [PSMElement.HIRA]: <ShieldAlert size={15} className="text-red-400" />,
  [PSMElement.PROCEDURES]: <BookOpen size={15} className="text-purple-400" />,
  [PSMElement.SAFE_WORK]: <Flame size={15} className="text-yellow-400" />,
  [PSMElement.ASSET_INTEGRITY]: <Wrench size={15} className="text-slate-400" />,
  [PSMElement.CONTRACTOR]: <HardHat size={15} className="text-lime-400" />,
  [PSMElement.TRAINING]: <GraduationCap size={15} className="text-cyan-400" />,
  [PSMElement.MOC]: <RefreshCcw size={15} className="text-sky-400" />,
  [PSMElement.READINESS]: <ClipboardCheck size={15} className="text-emerald-400" />,
  [PSMElement.CONDUCT_OPS]: <Radio size={15} className="text-fuchsia-400" />,
  [PSMElement.EMERGENCY]: <LifeBuoy size={15} className="text-red-400" />,
  [PSMElement.INCIDENT]: <AlertTriangle size={15} className="text-orange-400" />,
  [PSMElement.METRICS]: <Gauge size={15} className="text-blue-400" />,
  [PSMElement.AUDIT]: <SearchCheck size={15} className="text-green-400" />,
  [PSMElement.MANAGEMENT_REVIEW]: <RefreshCcw size={15} className="text-violet-400" />,
  [PSMElement.TRADE_SECRET]: <Lock size={15} className="text-slate-400" />,
  SETTINGS: <Settings size={15} className="text-slate-400" />,
};

const ELEMENT_LABELS: Partial<Record<PSMElement, string>> = {
  [PSMElement.CULTURE]: 'فرهنگ ایمنی',
  [PSMElement.STANDARDS]: 'استانداردها',
  [PSMElement.COMPETENCY]: 'شایستگی',
  [PSMElement.WORKFORCE]: 'مشارکت نیروکار',
  [PSMElement.STAKEHOLDER]: 'ذینفعان',
  [PSMElement.KNOWLEDGE]: 'PSI - اطلاعات فرآیند',
  [PSMElement.HIRA]: 'HAZOP / HIRA',
  [PSMElement.PROCEDURES]: 'رویه‌های عملیاتی',
  [PSMElement.SAFE_WORK]: 'مجوز کار ایمن',
  [PSMElement.ASSET_INTEGRITY]: 'یکپارچگی دارایی‌ها',
  [PSMElement.CONTRACTOR]: 'پیمانکاران',
  [PSMElement.TRAINING]: 'آموزش',
  [PSMElement.MOC]: 'مدیریت تغییر',
  [PSMElement.READINESS]: 'PSSR',
  [PSMElement.CONDUCT_OPS]: 'انضباط عملیاتی',
  [PSMElement.EMERGENCY]: 'آمادگی اضطراری',
  [PSMElement.INCIDENT]: 'بررسی حوادث',
  [PSMElement.METRICS]: 'شاخص‌های عملکرد',
  [PSMElement.AUDIT]: 'ممیزی و بازرسی',
  [PSMElement.MANAGEMENT_REVIEW]: 'بازنگری مدیریت',
  [PSMElement.TRADE_SECRET]: 'اطلاعات محرمانه',
  [PSMElement.ACTION_REGISTER]: 'ثبت اقدام مرکزی',
};

const SYSTEM_MODULES: SearchResult[] = [
  { id: 'mod-dashboard', title: 'داشبورد عملیاتی', subtitle: 'نمای کلی وضعیت سیستم', type: 'module', module: 'DASHBOARD', moduleLabel: 'سیستم', icon: MODULE_ICONS['DASHBOARD'], navigateTo: 'DASHBOARD', keywords: ['dashboard', 'home', 'خانه'] },
  { id: 'mod-gap', title: 'آنالیز شکاف (Gap Analysis)', subtitle: 'ارزیابی سطح انطباق ۲۰ عنصر RBPS', type: 'module', module: 'GAP_ANALYSIS', moduleLabel: 'تحلیل', icon: MODULE_ICONS['GAP_ANALYSIS'], navigateTo: 'GAP_ANALYSIS', keywords: ['gap', 'شکاف', 'انطباق'] },
  ...Object.values(PSMElement).map(el => ({
    id: `mod-${el}`, title: ELEMENT_LABELS[el as PSMElement] ?? el, subtitle: `ماژول PSM`, type: 'module' as const,
    module: el, moduleLabel: 'ماژول PSM', icon: MODULE_ICONS[el] ?? <FileText size={15} />, navigateTo: el, keywords: [el.toLowerCase()],
  })),
  { id: 'mod-settings', title: 'تنظیمات', subtitle: 'پیکربندی حساب کاربری', type: 'module', module: 'SETTINGS', moduleLabel: 'سیستم', icon: MODULE_ICONS['SETTINGS'], navigateTo: 'SETTINGS', keywords: ['settings', 'تنظیمات'] },
];

const QUICK_ACTIONS: SearchResult[] = [
  { id: 'qa-moc', title: 'ایجاد درخواست MOC', subtitle: 'مدیریت تغییر', type: 'action', module: PSMElement.MOC, moduleLabel: 'اقدام سریع', icon: <Zap size={15} className="text-amber-400" />, navigateTo: PSMElement.MOC, keywords: ['new moc', 'تغییر'] },
  { id: 'qa-incident', title: 'ثبت حادثه جدید', subtitle: 'گزارش‌دهی حوادث', type: 'action', module: PSMElement.INCIDENT, moduleLabel: 'اقدام سریع', icon: <Zap size={15} className="text-red-400" />, navigateTo: PSMElement.INCIDENT, keywords: ['incident', 'حادثه'] },
  { id: 'qa-permit', title: 'صدور مجوز کار', subtitle: 'Permit to Work', type: 'action', module: PSMElement.SAFE_WORK, moduleLabel: 'اقدام سریع', icon: <Zap size={15} className="text-yellow-400" />, navigateTo: PSMElement.SAFE_WORK, keywords: ['permit', 'مجوز'] },
  { id: 'qa-hazop', title: 'شروع مطالعه HAZOP', subtitle: 'شناسایی خطرات', type: 'action', module: PSMElement.HIRA, moduleLabel: 'اقدام سریع', icon: <Zap size={15} className="text-red-400" />, navigateTo: PSMElement.HIRA, keywords: ['hazop', 'hira'] },
];

const GlobalSearch: FC<GlobalSearchProps> = ({ isOpen, onClose, onNavigate }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [selected, setSelected] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { if (isOpen) { setTimeout(() => inputRef.current?.focus(), 50); } else { setQuery(''); } }, [isOpen]);

  useEffect(() => {
    const q = query.toLowerCase().trim();
    if (!q) { setResults(QUICK_ACTIONS); setSelected(0); return; }
    const filtered = SYSTEM_MODULES.filter(m =>
      m.title.toLowerCase().includes(q) ||
      m.subtitle?.toLowerCase().includes(q) ||
      m.keywords?.some(k => k.includes(q)) ||
      m.module.toLowerCase().includes(q)
    );
    setResults(filtered.slice(0, 10));
    setSelected(0);
  }, [query]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'Escape') { onClose(); return; }
      if (e.key === 'ArrowDown') { e.preventDefault(); setSelected(s => Math.min(s + 1, results.length - 1)); }
      if (e.key === 'ArrowUp') { e.preventDefault(); setSelected(s => Math.max(s - 1, 0)); }
      if (e.key === 'Enter' && results[selected]) { onNavigate(results[selected].navigateTo); }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [isOpen, results, selected, onClose, onNavigate]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[500] flex items-start justify-center pt-[12vh]" dir="rtl">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg mx-4 rounded-2xl overflow-hidden shadow-2xl"
        style={{ background: 'linear-gradient(180deg, #111827 0%, #0c1422 100%)', border: '1px solid rgba(255,255,255,0.1)' }}>

        {/* Search input */}
        <div className="flex items-center gap-3 px-4 py-3.5" style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
          <Search size={17} className="text-slate-500 shrink-0" />
          <input ref={inputRef} value={query} onChange={e => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-slate-200 text-sm outline-none placeholder-slate-600"
            placeholder="جستجو در ماژول‌ها، اقدامات، و..." />
          <div className="flex items-center gap-1.5 shrink-0">
            <kbd className="text-[10px] px-1.5 py-0.5 rounded font-mono text-slate-600" style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}>ESC</kbd>
            <button onClick={onClose} className="p-1 rounded-lg hover:bg-white/8 text-slate-500"><X size={14} /></button>
          </div>
        </div>

        {/* Results */}
        <div className="overflow-y-auto max-h-80">
          {!query && (
            <div className="px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wider text-slate-600">اقدامات سریع</div>
          )}
          {results.length === 0 && (
            <div className="py-10 text-center text-slate-600 text-sm">نتیجه‌ای یافت نشد</div>
          )}
          {results.map((r, i) => (
            <button key={r.id} onClick={() => onNavigate(r.navigateTo)}
              className="w-full text-right flex items-center gap-3 px-4 py-3 transition-colors"
              style={{ background: i === selected ? 'rgba(255,255,255,0.06)' : 'transparent', borderBottom: '1px solid rgba(255,255,255,0.03)' }}
              onMouseEnter={() => setSelected(i)}>
              <span className="shrink-0 w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.06)' }}>{r.icon}</span>
              <div className="flex-1 min-w-0">
                <div className="text-[13px] font-medium text-slate-200">{r.title}</div>
                {r.subtitle && <div className="text-[11px] text-slate-600">{r.subtitle}</div>}
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded text-slate-600 shrink-0" style={{ background: 'rgba(255,255,255,0.04)' }}>{r.moduleLabel}</span>
              <ChevronRight size={13} className="text-slate-700 shrink-0" />
            </button>
          ))}
        </div>

        {/* Footer */}
        <div className="flex items-center gap-3 px-4 py-2.5 text-[11px] text-slate-700" style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}>
          <span className="flex items-center gap-1"><Command size={10} />K جستجو</span>
          <span>↑↓ انتخاب</span>
          <span>↵ رفتن</span>
          <span>ESC بستن</span>
        </div>
      </div>
    </div>
  );
};

export default GlobalSearch;
