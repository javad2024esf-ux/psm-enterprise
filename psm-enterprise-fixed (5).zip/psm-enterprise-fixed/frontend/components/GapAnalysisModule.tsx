import React, { FC } from 'react';
import { GapAssessment } from '../types';
interface Props { token?: string; activeUnit?: string; onExport?: () => void; onAssessmentChange?: (a: GapAssessment | null) => void; }
export const GapAnalysisModule: FC<Props> = () => (
  <div className="flex items-center justify-center h-64 text-slate-500 text-sm" dir="rtl">آنالیز شکاف RBPS</div>
);
export default GapAnalysisModule;
