import React, { FC } from 'react';
interface Props { token?: string; activeUnit?: string; [key: string]: unknown; }
const PSSRWorkflowView: FC<Props> = () => (
  <div className="flex items-center justify-center h-64 text-slate-500 text-sm" dir="rtl">گردش‌کار PSSR</div>
);
export const PSSRList: FC<Props> = () => null;
export const PSSRDetail: FC<Props> = () => null;
export const PSSRCreate: FC<Props> = () => null;
export default PSSRWorkflowView;
