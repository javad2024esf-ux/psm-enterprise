import React, { FC } from 'react';
interface Props { page?: number; total?: number; onChange?: (p: number) => void; }
const Pagination: FC<Props> = () => null;
export default Pagination;
