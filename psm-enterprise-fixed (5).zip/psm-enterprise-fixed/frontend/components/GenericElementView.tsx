import React, { useState, useEffect, FC } from 'react';
import { webApi } from '../src/webApi';
import { PSMElement } from '../types';
import { Loader2 } from 'lucide-react';

interface Props { element: PSMElement | string; token?: string; activeUnit?: string; onExport?: () => void; }

const GenericElementView: FC<Props> = ({ element, token }) => {
  const [records, setRecords] = useState<unknown[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token) { setLoading(false); return; }
    webApi.getRecords({ element: String(element), token })
      .then(r => { setRecords(Array.isArray(r) ? r : []); setLoading(false); })
      .catch(() => setLoading(false));
  }, [element, token]);

  if (loading) return (
    <div className="flex items-center justify-center h-64 gap-3" dir="rtl">
      <Loader2 size={20} className="animate-spin text-sky-400" />
      <span className="text-slate-400 text-sm">در حال بارگذاری...</span>
    </div>
  );

  return (
    <div className="p-4" dir="rtl">
      <div className="text-slate-300 text-sm mb-4">{records.length} رکورد یافت شد</div>
    </div>
  );
};

export default GenericElementView;
