import React, { useState, memo, FC } from 'react';
import { useAuth } from '../src/context/AuthContext';
import { ShieldCheck, Eye, EyeOff, Lock, User, AlertCircle, Loader2, Shield } from 'lucide-react';

const LoginView: FC = memo(() => {
  const { login } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) { setError('نام کاربری و رمز عبور الزامی است'); return; }
    setLoading(true); setError('');
    const res = await login(username, password);
    setLoading(false);
    if (!res.success) setError(res.error ?? 'خطای ورود');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#060b17] relative overflow-hidden" dir="rtl">
      {/* Background glows */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-sky-500/6 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-indigo-500/6 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-sm mx-4">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex w-16 h-16 rounded-2xl items-center justify-center mb-4"
            style={{ background: 'linear-gradient(135deg, #0ea5e9 0%, #6366f1 100%)', boxShadow: '0 0 40px rgba(14,165,233,0.3)' }}>
            <Shield size={32} className="text-white" />
          </div>
          <h1 className="text-xl font-bold text-slate-100">PSM Enterprise</h1>
          <p className="text-sm text-slate-500 mt-1">سیستم مدیریت ایمنی فرآیند</p>
        </div>

        {/* Card */}
        <div className="rounded-2xl p-6" style={{
          background: 'linear-gradient(135deg, #101827 0%, #0c1422 100%)',
          border: '1px solid rgba(255,255,255,0.08)',
          boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
        }}>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {/* Username */}
            <div>
              <label className="text-xs font-medium text-slate-400 mb-1.5 block">نام کاربری</label>
              <div className="relative">
                <User size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
                <input
                  value={username} onChange={e => setUsername(e.target.value)}
                  className="w-full pr-9 pl-3 py-2.5 rounded-xl text-sm text-slate-200 placeholder-slate-600 outline-none transition-all"
                  style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}
                  placeholder="نام کاربری را وارد کنید" autoComplete="username"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="text-xs font-medium text-slate-400 mb-1.5 block">رمز عبور</label>
              <div className="relative">
                <Lock size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
                <input
                  type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)}
                  className="w-full pr-9 pl-9 py-2.5 rounded-xl text-sm text-slate-200 placeholder-slate-600 outline-none transition-all"
                  style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}
                  placeholder="رمز عبور را وارد کنید" autoComplete="current-password"
                />
                <button type="button" onClick={() => setShowPw(v => !v)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-400 transition-colors">
                  {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm" style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)', color: '#f87171' }}>
                <AlertCircle size={14} />
                <span>{error}</span>
              </div>
            )}

            <button type="submit" disabled={loading}
              className="w-full py-2.5 rounded-xl text-sm font-bold text-white flex items-center justify-center gap-2 transition-all disabled:opacity-60"
              style={{ background: 'linear-gradient(135deg, #0ea5e9 0%, #6366f1 100%)', boxShadow: '0 4px 20px rgba(14,165,233,0.25)' }}>
              {loading ? <Loader2 size={16} className="animate-spin" /> : <ShieldCheck size={16} />}
              {loading ? 'در حال ورود...' : 'ورود به سیستم'}
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-slate-600 mt-6">
          PSM Enterprise v9.0 — سیستم مدیریت ایمنی فرآیند
        </p>
      </div>
    </div>
  );
});

LoginView.displayName = 'LoginView';
export default LoginView;
