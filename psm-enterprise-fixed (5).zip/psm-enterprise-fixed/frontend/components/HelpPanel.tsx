import React, { FC } from 'react';
import { X } from 'lucide-react';
interface Props { activeElement?: string; onClose?: () => void; }
const HelpPanel: FC<Props> = ({ onClose }) => (
  <div className="fixed inset-0 z-[400] bg-black/60 flex items-center justify-center" dir="rtl" onClick={onClose}>
    <div className="bg-slate-900 border border-white/10 rounded-2xl p-6 w-full max-w-md mx-4" onClick={e => e.stopPropagation()}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-slate-200 font-semibold">راهنما</h3>
        <button onClick={onClose} className="text-slate-500 hover:text-slate-400"><X size={18}/></button>
      </div>
      <p className="text-slate-500 text-sm">راهنمای این ماژول در حال توسعه است.</p>
    </div>
  </div>
);
export default HelpPanel;
