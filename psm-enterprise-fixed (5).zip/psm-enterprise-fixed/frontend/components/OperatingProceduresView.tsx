import React, { FC } from 'react';
import { Loader2 } from 'lucide-react';

interface Props { token?: string; activeUnit?: string; onExport?: () => void; [key: string]: unknown; }

const OperatingProceduresView: FC<Props> = () => (
  <div className="flex flex-col items-center justify-center h-64 gap-3" dir="rtl">
    <Loader2 size={24} className="text-sky-400 animate-spin" />
    <p className="text-slate-400 text-sm">رویه‌های عملیاتی</p>
  </div>
);

export default OperatingProceduresView;
