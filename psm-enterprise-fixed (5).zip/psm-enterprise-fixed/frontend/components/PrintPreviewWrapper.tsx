import React, { FC, ReactNode } from 'react';
interface Props { children?: ReactNode; [key: string]: unknown; }
const PrintPreviewWrapper: FC<Props> = ({ children }) => <>{children}</>;
export default PrintPreviewWrapper;
