import React, { FC, useState, useRef, useEffect, useCallback, memo } from 'react';
import {
  Search, Bell, ChevronDown, Settings, LogOut, User, Shield,
  Command, X, LayoutDashboard, Factory, Menu, Hexagon,
  CheckCircle2, AlertTriangle, AlertCircle, Info, Clock, Dot,
} from 'lucide-react';

export interface Notification {
  id: string | number;
  title: string;
  desc: string;
  time: string;
  type: 'Alert' | 'Task' | 'Warning' | 'Info';
  read: boolean;
}

export interface AppHeaderProps {
  user?: { fullName?: string; role?: string; email?: string } | null;
  companyName?: string;
  activeElement?: string;
  activeLabel?: string;
  breadcrumbs?: { label: string; id?: string }[];
  notifications?: Notification[];
  unreadCount?: number;
  onMarkAllRead?: () => void;
  onMarkRead?: (id: string | number) => void;
  onNavigate?: (element: string) => void;
  onLogout?: () => void;
  onSettingsClick?: () => void;
  onSearchOpen?: () => void;
  onMobileMenuToggle?: () => void;
  onToggleCollapse?: () => void;
  sidebarCollapsed?: boolean;
  isAdmin?: boolean;
  units?: string[];
  activeUnit?: string;
  onUnitChange?: (unit: string) => void;
}

const ROLE_LABELS: Record<string, string> = {
  Admin: 'ادمین', PSMManager: 'مدیر PSM', HSEManager: 'مدیر HSE',
  UnitHead: 'سرپرست واحد', ProcessEngineer: 'مهندس فرآیند',
  Supervisor: 'سرپرست شیفت', Operator: 'اپراتور',
  Inspector: 'بازرس', ContractorMgr: 'مسئول پیمانکار', Viewer: 'ناظر',
};

const NOTIF_CONFIG: Record<string, { color: string; icon: FC<{ size?: number }> }> = {
  Alert: { color: '#ef4444', icon: ({ size = 14 }) => <AlertCircle size={size} /> },
  Task:  { color: '#3b82f6', icon: ({ size = 14 }) => <CheckCircle2 size={size} /> },
  Warning: { color: '#f59e0b', icon: ({ size = 14 }) => <AlertTriangle size={size} /> },
  Info:  { color: '#10b981', icon: ({ size = 14 }) => <Info size={size} /> },
};

const NotificationPanel: FC<{
  notifications: Notification[];
  unreadCount: number;
  onMarkRead: (id: string | number) => void;
  onMarkAllRead: () => void;
  onClose: () => void;
}> = ({ notifications, unreadCount, onMarkRead, onMarkAllRead, onClose }) => (
  <div
    className="absolute left-0 top-[calc(100%+8px)] w-80 rounded-2xl shadow-2xl z-[300] overflow-hidden"
    style={{
      background: 'linear-gradient(180deg, #101827 0%, #0c1422 100%)',
      border: '1px solid rgba(255,255,255,0.1)',
      boxShadow: '0 20px 60px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.05)',
    }}
  >
    <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
      <span className="text-sm font-semibold text-slate-200">اعلان‌ها</span>
      <div className="flex items-center gap-2">
        {unreadCount > 0 && (
          <button onClick={onMarkAllRead} className="text-[11px] text-blue-400 hover:text-blue-300 transition-colors">
            همه خوانده شد
          </button>
        )}
        <button onClick={onClose} className="p-1 rounded-lg hover:bg-white/8 transition-colors text-slate-500">
          <X size={14} />
        </button>
      </div>
    </div>
    <div className="overflow-y-auto max-h-72">
      {notifications.length === 0 ? (
        <div className="py-8 text-center text-slate-500 text-sm">بدون اعلان</div>
      ) : (
        notifications.map(n => {
          const cfg = NOTIF_CONFIG[n.type] ?? NOTIF_CONFIG.Info;
          const NIcon = cfg.icon;
          return (
            <button
              key={n.id}
              onClick={() => onMarkRead(n.id)}
              className="w-full text-right px-4 py-3 flex items-start gap-3 transition-colors hover:bg-white/4"
              style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}
            >
              <span className="shrink-0 mt-0.5 rounded-lg p-1.5" style={{ background: `${cfg.color}20` }}>
                <span style={{ color: cfg.color }}><NIcon size={13} /></span>
              </span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-[12px] font-medium text-slate-200 truncate">{n.title}</span>
                  {!n.read && <Dot size={16} style={{ color: '#3b82f6' }} className="shrink-0 animate-pulse" />}
                </div>
                <div className="text-[11px] text-slate-500 truncate mt-0.5">{n.desc}</div>
                {n.time && (
                  <div className="flex items-center gap-1 mt-1">
                    <Clock size={10} style={{ color: 'rgba(100,116,139,0.5)' }} />
                    <span className="text-[10px]" style={{ color: 'rgba(100,116,139,0.5)' }}>{n.time}</span>
                  </div>
                )}
              </div>
            </button>
          );
        })
      )}
    </div>
  </div>
);

const AppHeader: FC<AppHeaderProps> = ({
  user,
  companyName,
  breadcrumbs = [],
  notifications = [],
  unreadCount = 0,
  onMarkAllRead,
  onMarkRead,
  onLogout,
  onSettingsClick,
  onSearchOpen,
  onMobileMenuToggle,
  units = [],
  activeUnit,
  onUnitChange,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showUnitMenu, setShowUnitMenu] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);
  const userRef = useRef<HTMLDivElement>(null);
  const unitRef = useRef<HTMLDivElement>(null);

  const handleClickOutside = useCallback((e: MouseEvent) => {
    if (notifRef.current && !notifRef.current.contains(e.target as Node)) setShowNotifications(false);
    if (userRef.current && !userRef.current.contains(e.target as Node)) setShowUserMenu(false);
    if (unitRef.current && !unitRef.current.contains(e.target as Node)) setShowUnitMenu(false);
  }, []);

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [handleClickOutside]);

  // Keyboard shortcut for search
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        onSearchOpen?.();
      }
    };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [onSearchOpen]);

  const roleLabel = ROLE_LABELS[user?.role ?? ''] ?? user?.role ?? '';

  return (
    <header
      dir="rtl"
      style={{
        height: '60px',
        background: 'linear-gradient(90deg, #08101f 0%, #080e1c 100%)',
        borderBottom: '1px solid rgba(255,255,255,0.07)',
        boxShadow: '0 1px 20px rgba(0,0,0,0.4)',
        zIndex: 100,
      }}
      className="flex items-center px-4 gap-3 sticky top-0 shrink-0"
    >
      {/* Mobile menu toggle */}
      <button
        onClick={onMobileMenuToggle}
        className="md:hidden p-2 rounded-lg hover:bg-white/8 transition-colors"
        style={{ color: 'rgba(148,163,184,0.6)' }}
      >
        <Menu size={18} />
      </button>

      {/* Breadcrumbs */}
      <div className="flex items-center gap-1.5 flex-1 min-w-0">
        {breadcrumbs.length > 0 ? (
          <>
            <Hexagon size={14} style={{ color: '#f59e0b', opacity: 0.7 }} className="shrink-0" />
            {breadcrumbs.map((crumb, i) => (
              <React.Fragment key={i}>
                {i > 0 && (
                  <ChevronDown
                    size={12}
                    className="shrink-0 rotate-90"
                    style={{ color: 'rgba(100,116,139,0.4)' }}
                  />
                )}
                <span
                  className={`text-[12.5px] truncate font-medium ${
                    i === breadcrumbs.length - 1
                      ? 'text-slate-200'
                      : 'text-slate-500 hover:text-slate-400 cursor-pointer transition-colors'
                  }`}
                >
                  {crumb.label}
                </span>
              </React.Fragment>
            ))}
          </>
        ) : (
          <div className="flex items-center gap-2">
            <Hexagon size={14} style={{ color: '#f59e0b', opacity: 0.7 }} className="shrink-0" />
            <span className="text-[12.5px] font-semibold text-slate-300">{companyName || 'PSM Enterprise'}</span>
          </div>
        )}
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-2 shrink-0">

        {/* Workspace/Unit switcher */}
        {units.length > 0 && (
          <div ref={unitRef} className="relative">
            <button
              onClick={() => setShowUnitMenu(o => !o)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-all text-[12px] font-medium"
              style={{
                background: showUnitMenu ? 'rgba(245,158,11,0.12)' : 'rgba(255,255,255,0.05)',
                color: showUnitMenu ? '#f59e0b' : 'rgba(148,163,184,0.8)',
                border: `1px solid ${showUnitMenu ? 'rgba(245,158,11,0.3)' : 'rgba(255,255,255,0.07)'}`,
              }}
            >
              <Factory size={13} />
              <span className="hidden sm:block max-w-[100px] truncate">{activeUnit || 'انتخاب واحد'}</span>
              <ChevronDown size={11} style={{ transform: showUnitMenu ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />
            </button>
            {showUnitMenu && (
              <div
                className="absolute left-0 top-[calc(100%+8px)] rounded-xl shadow-2xl z-[300] overflow-hidden min-w-[160px]"
                style={{
                  background: 'linear-gradient(180deg, #101827 0%, #0c1422 100%)',
                  border: '1px solid rgba(255,255,255,0.1)',
                }}
              >
                {units.map(unit => (
                  <button
                    key={unit}
                    onClick={() => { onUnitChange?.(unit); setShowUnitMenu(false); }}
                    className="w-full text-right px-3.5 py-2.5 text-[12.5px] flex items-center gap-2 transition-colors hover:bg-white/5"
                    style={{ color: unit === activeUnit ? '#f59e0b' : 'rgba(148,163,184,0.8)' }}
                  >
                    {unit === activeUnit && <CheckCircle2 size={12} style={{ color: '#f59e0b' }} />}
                    {unit !== activeUnit && <span className="w-3" />}
                    {unit}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Floating Search */}
        <button
          onClick={onSearchOpen}
          className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg transition-all"
          style={{
            background: 'rgba(255,255,255,0.04)',
            border: '1px solid rgba(255,255,255,0.07)',
            color: 'rgba(100,116,139,0.7)',
            minWidth: 120,
          }}
          title="جستجو (Ctrl+K)"
        >
          <Search size={13} />
          <span className="text-[11.5px] hidden sm:block flex-1 text-right">جستجو...</span>
          <span
            className="hidden sm:flex items-center gap-0.5 text-[10px] font-mono px-1 py-0.5 rounded"
            style={{ background: 'rgba(255,255,255,0.06)', color: 'rgba(100,116,139,0.6)' }}
          >
            <Command size={9} />K
          </span>
        </button>

        {/* Notifications */}
        <div ref={notifRef} className="relative">
          <button
            onClick={() => { setShowNotifications(o => !o); setShowUserMenu(false); setShowUnitMenu(false); }}
            className="relative p-2 rounded-lg transition-all"
            style={{
              background: showNotifications ? 'rgba(59,130,246,0.1)' : 'rgba(255,255,255,0.04)',
              color: showNotifications ? '#3b82f6' : 'rgba(100,116,139,0.7)',
              border: `1px solid ${showNotifications ? 'rgba(59,130,246,0.25)' : 'rgba(255,255,255,0.07)'}`,
            }}
          >
            <Bell size={15} />
            {unreadCount > 0 && (
              <span
                className="absolute -top-1 -right-1 min-w-[16px] h-4 flex items-center justify-center text-[9px] font-bold rounded-full text-white"
                style={{ background: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)', boxShadow: '0 0 8px rgba(239,68,68,0.5)' }}
              >
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>
          {showNotifications && (
            <NotificationPanel
              notifications={notifications}
              unreadCount={unreadCount}
              onMarkRead={(id) => { onMarkRead?.(id); }}
              onMarkAllRead={() => { onMarkAllRead?.(); }}
              onClose={() => setShowNotifications(false)}
            />
          )}
        </div>

        {/* User Menu */}
        <div ref={userRef} className="relative">
          <button
            onClick={() => { setShowUserMenu(o => !o); setShowNotifications(false); setShowUnitMenu(false); }}
            className="flex items-center gap-2 pl-2.5 pr-1.5 py-1 rounded-lg transition-all"
            style={{
              background: showUserMenu ? 'rgba(139,92,246,0.1)' : 'rgba(255,255,255,0.04)',
              border: `1px solid ${showUserMenu ? 'rgba(139,92,246,0.25)' : 'rgba(255,255,255,0.07)'}`,
            }}
          >
            <div
              className="w-6 h-6 rounded-md flex items-center justify-center text-[11px] font-bold shrink-0"
              style={{ background: 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)' }}
            >
              <span className="text-white">{user?.fullName?.[0] ?? 'U'}</span>
            </div>
            <div className="hidden sm:block text-right">
              <div className="text-[12px] font-medium text-slate-300 leading-tight">{user?.fullName ?? 'کاربر'}</div>
              <div className="text-[10px] leading-tight" style={{ color: 'rgba(100,116,139,0.7)' }}>{roleLabel}</div>
            </div>
            <ChevronDown size={11} style={{ color: 'rgba(100,116,139,0.5)', transform: showUserMenu ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />
          </button>

          {showUserMenu && (
            <div
              className="absolute left-0 top-[calc(100%+8px)] w-52 rounded-xl shadow-2xl z-[300] overflow-hidden"
              style={{
                background: 'linear-gradient(180deg, #101827 0%, #0c1422 100%)',
                border: '1px solid rgba(255,255,255,0.1)',
              }}
            >
              <div className="px-3.5 py-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center text-[13px] font-bold"
                    style={{ background: 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)' }}>
                    <span className="text-white">{user?.fullName?.[0] ?? 'U'}</span>
                  </div>
                  <div>
                    <div className="text-[12.5px] font-semibold text-slate-200">{user?.fullName ?? 'کاربر'}</div>
                    <div className="text-[10.5px]" style={{ color: 'rgba(100,116,139,0.7)' }}>{roleLabel}</div>
                  </div>
                </div>
              </div>
              <div className="py-1">
                <button
                  onClick={() => { onSettingsClick?.(); setShowUserMenu(false); }}
                  className="w-full text-right flex items-center gap-2.5 px-3.5 py-2.5 text-[12.5px] transition-colors hover:bg-white/5"
                  style={{ color: 'rgba(148,163,184,0.8)' }}
                >
                  <Settings size={14} style={{ color: 'rgba(100,116,139,0.7)' }} />
                  تنظیمات
                </button>
                <button
                  className="w-full text-right flex items-center gap-2.5 px-3.5 py-2.5 text-[12.5px] transition-colors hover:bg-white/5"
                  style={{ color: 'rgba(148,163,184,0.8)' }}
                >
                  <User size={14} style={{ color: 'rgba(100,116,139,0.7)' }} />
                  پروفایل
                </button>
              </div>
              <div style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }} className="py-1">
                <button
                  onClick={() => { onLogout?.(); setShowUserMenu(false); }}
                  className="w-full text-right flex items-center gap-2.5 px-3.5 py-2.5 text-[12.5px] transition-colors hover:bg-red-500/8"
                  style={{ color: 'rgba(239,68,68,0.7)' }}
                >
                  <LogOut size={14} />
                  خروج از سیستم
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default memo(AppHeader);
