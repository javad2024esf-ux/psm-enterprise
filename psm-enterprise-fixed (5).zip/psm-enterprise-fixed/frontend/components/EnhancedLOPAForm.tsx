import React, { FC } from 'react';
interface Props { token?: string; activeUnit?: string; onExport?: () => void; [key: string]: unknown; }
const EnhancedLOPAForm: FC<Props> = () => (
  <div className="flex items-center justify-center h-64 text-slate-500 text-sm" dir="rtl">فرم LOPA</div>
);

export default EnhancedLOPAForm;
