import React, { FC } from 'react';
import { ShieldOff, ArrowRight } from 'lucide-react';

const AccessDenied: FC<{ onBack?: () => void }> = ({ onBack }) => (
  <div className="flex flex-col items-center justify-center h-64 gap-4" dir="rtl">
    <div className="w-14 h-14 rounded-2xl flex items-center justify-center" style={{ background: 'rgba(239,68,68,0.1)' }}>
      <ShieldOff size={28} className="text-red-400" />
    </div>
    <div className="text-center">
      <h3 className="text-base font-semibold text-slate-300">دسترسی محدود</h3>
      <p className="text-sm text-slate-500 mt-1">شما مجوز مشاهده این بخش را ندارید.</p>
    </div>
    {onBack && (
      <button onClick={onBack} className="flex items-center gap-2 text-sm text-slate-400 hover:text-slate-300 transition-colors">
        <ArrowRight size={14} />
        بازگشت
      </button>
    )}
  </div>
);

export default AccessDenied;
