import React, { FC } from 'react';
import { GapAssessment } from '../types';
interface Props { token?: string; activeUnit?: string; onExport?: () => void; onNavigate?: (el: string) => void; gapAssessment?: GapAssessment | null; }
const Dashboard: FC<Props> = () => (
  <div className="flex items-center justify-center h-64 text-slate-500 text-sm" dir="rtl">داشبورد عملیاتی</div>
);
export default Dashboard;
