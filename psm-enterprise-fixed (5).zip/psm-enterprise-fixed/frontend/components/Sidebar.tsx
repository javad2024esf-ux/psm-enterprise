import React, { memo, useState, useCallback, useEffect, useRef, FC } from 'react';
import { PSMElement } from '../types';
import { useAuth } from '../src/context/AuthContext';
import { ELEMENT_ICONS } from '../constants';
import {
  LayoutDashboard, Settings, Target, ListChecks,
  ChevronRight, ShieldCheck, LogOut, Bell, GitBranch,
  BarChart3, ChevronDown, Activity, Zap, Shield,
  TrendingUp, AlertTriangle, FileBarChart2, LucideIcon,
  PanelLeftClose, PanelLeft, Layers, Hexagon,
} from 'lucide-react';

export interface SidebarProps {
  activeElement: string;
  onSelect: (element: string) => void;
  collapsed?: boolean;
  onToggleCollapse?: () => void;
  mobileOpen?: boolean;
  onMobileClose?: () => void;
  user?: unknown;
  onLogout?: () => void;
  disabledModules?: string[];
  companyName?: string;
  isAdmin?: boolean;
}

const ELEMENT_LABELS: Partial<Record<PSMElement, string>> = {
  [PSMElement.CULTURE]: 'فرهنگ ایمنی',
  [PSMElement.STANDARDS]: 'استانداردها',
  [PSMElement.COMPETENCY]: 'شایستگی',
  [PSMElement.WORKFORCE]: 'مشارکت نیروکار',
  [PSMElement.STAKEHOLDER]: 'ذینفعان',
  [PSMElement.KNOWLEDGE]: 'PSI - اطلاعات فرآیند',
  [PSMElement.HIRA]: 'HAZOP / HIRA',
  [PSMElement.PROCEDURES]: 'رویه‌های عملیاتی',
  [PSMElement.SAFE_WORK]: 'مجوز کار ایمن',
  [PSMElement.ASSET_INTEGRITY]: 'یکپارچگی دارایی‌ها',
  [PSMElement.CONTRACTOR]: 'پیمانکاران',
  [PSMElement.TRAINING]: 'آموزش',
  [PSMElement.MOC]: 'مدیریت تغییر',
  [PSMElement.READINESS]: 'PSSR',
  [PSMElement.CONDUCT_OPS]: 'انضباط عملیاتی',
  [PSMElement.EMERGENCY]: 'آمادگی اضطراری',
  [PSMElement.INCIDENT]: 'بررسی حوادث',
  [PSMElement.METRICS]: 'شاخص‌های عملکرد',
  [PSMElement.AUDIT]: 'ممیزی و بازرسی',
  [PSMElement.MANAGEMENT_REVIEW]: 'بازنگری مدیریت',
  [PSMElement.TRADE_SECRET]: 'اطلاعات محرمانه',
  [PSMElement.ACTION_REGISTER]: 'ثبت اقدام مرکزی',
};

const ELEMENT_COLORS: Partial<Record<PSMElement, string>> = {
  [PSMElement.CULTURE]: '#f59e0b',
  [PSMElement.STANDARDS]: '#3b82f6',
  [PSMElement.COMPETENCY]: '#8b5cf6',
  [PSMElement.WORKFORCE]: '#10b981',
  [PSMElement.STAKEHOLDER]: '#14b8a6',
  [PSMElement.KNOWLEDGE]: '#f97316',
  [PSMElement.HIRA]: '#ef4444',
  [PSMElement.PROCEDURES]: '#3b82f6',
  [PSMElement.SAFE_WORK]: '#f59e0b',
  [PSMElement.ASSET_INTEGRITY]: '#6366f1',
  [PSMElement.CONTRACTOR]: '#0891b2',
  [PSMElement.TRAINING]: '#8b5cf6',
  [PSMElement.MOC]: '#f59e0b',
  [PSMElement.READINESS]: '#10b981',
  [PSMElement.CONDUCT_OPS]: '#14b8a6',
  [PSMElement.EMERGENCY]: '#ef4444',
  [PSMElement.INCIDENT]: '#f97316',
  [PSMElement.METRICS]: '#3b82f6',
  [PSMElement.AUDIT]: '#8b5cf6',
  [PSMElement.MANAGEMENT_REVIEW]: '#f59e0b',
  [PSMElement.TRADE_SECRET]: '#94a3b8',
  [PSMElement.ACTION_REGISTER]: '#6366f1',
};

const ITEM_MODULE: Record<string, string> = {
  'LOPA': 'HAZOP', 'BOWTIE': 'HAZOP', 'WORKFLOW': 'AUDIT',
  'MANAGEMENT_REPORT': 'MANAGEMENT_REVIEW', 'GAP_ANALYSIS': 'AUDIT',
  [PSMElement.ACTION_REGISTER]: 'ACTION_REGISTER',
  [PSMElement.CULTURE]: 'CULTURE', [PSMElement.STANDARDS]: 'STANDARDS',
  [PSMElement.COMPETENCY]: 'COMPETENCY', [PSMElement.WORKFORCE]: 'WORKFORCE',
  [PSMElement.STAKEHOLDER]: 'STAKEHOLDER', [PSMElement.KNOWLEDGE]: 'KNOWLEDGE',
  [PSMElement.HIRA]: 'HIRA', [PSMElement.PROCEDURES]: 'PROCEDURES',
  [PSMElement.SAFE_WORK]: 'SAFE_WORK', [PSMElement.ASSET_INTEGRITY]: 'ASSET_INTEGRITY',
  [PSMElement.CONTRACTOR]: 'CONTRACTOR', [PSMElement.TRAINING]: 'TRAINING',
  [PSMElement.MOC]: 'MOC', [PSMElement.READINESS]: 'READINESS',
  [PSMElement.CONDUCT_OPS]: 'CONDUCT_OPS', [PSMElement.EMERGENCY]: 'EMERGENCY',
  [PSMElement.INCIDENT]: 'INCIDENT', [PSMElement.METRICS]: 'METRICS',
  [PSMElement.AUDIT]: 'AUDIT', [PSMElement.MANAGEMENT_REVIEW]: 'MANAGEMENT_REVIEW',
  [PSMElement.TRADE_SECRET]: 'KNOWLEDGE',
};

interface GroupDef {
  id: string;
  label: string;
  icon: LucideIcon;
  accentColor: string;
  items?: { id: string; label: string; color: string; icon: LucideIcon }[];
  elements?: PSMElement[];
}

const GROUPS: GroupDef[] = [
  {
    id: 'overview', label: 'مرکز فرماندهی', icon: Activity, accentColor: '#f59e0b',
    items: [
      { id: 'DASHBOARD', label: 'داشبورد عملیاتی', color: '#f59e0b', icon: LayoutDashboard },
      { id: 'GAP_ANALYSIS', label: 'آنالیز شکاف RBPS', color: '#8b5cf6', icon: Target },
      { id: 'LOPA', label: 'LOPA — تحلیل خطر', color: '#06b6d4', icon: BarChart3 },
      { id: 'BOWTIE', label: 'BowTie — نمودار خطر', color: '#14b8a6', icon: GitBranch },
      { id: 'WORKFLOW', label: 'موتور Workflow', color: '#3b82f6', icon: Zap },
      { id: 'MANAGEMENT_REPORT', label: 'گزارش‌گیری مدیریتی', color: '#6366f1', icon: FileBarChart2 },
      { id: PSMElement.ACTION_REGISTER, label: 'ثبت اقدام مرکزی', color: '#6366f1', icon: ListChecks },
    ],
  },
  {
    id: 'pillar1', label: 'تعهد به ایمنی', icon: Shield, accentColor: '#3b82f6',
    elements: [PSMElement.CULTURE, PSMElement.STANDARDS, PSMElement.COMPETENCY, PSMElement.WORKFORCE, PSMElement.STAKEHOLDER],
  },
  {
    id: 'pillar2', label: 'درک خطرات', icon: AlertTriangle, accentColor: '#ef4444',
    elements: [PSMElement.KNOWLEDGE, PSMElement.HIRA],
  },
  {
    id: 'pillar3', label: 'مدیریت ریسک', icon: ShieldCheck, accentColor: '#10b981',
    elements: [PSMElement.PROCEDURES, PSMElement.SAFE_WORK, PSMElement.ASSET_INTEGRITY, PSMElement.CONTRACTOR, PSMElement.TRAINING, PSMElement.MOC, PSMElement.READINESS],
  },
  {
    id: 'pillar4', label: 'یادگیری از تجربه', icon: TrendingUp, accentColor: '#f97316',
    elements: [PSMElement.CONDUCT_OPS, PSMElement.EMERGENCY, PSMElement.INCIDENT, PSMElement.METRICS, PSMElement.AUDIT, PSMElement.MANAGEMENT_REVIEW, PSMElement.TRADE_SECRET],
  },
];

interface NavItemProps {
  id: string;
  label: string;
  icon: LucideIcon;
  color: string;
  isActive: boolean;
  collapsed: boolean;
  disabled?: boolean;
  onClick: () => void;
  shortcut?: string;
}

const NavItem: FC<NavItemProps> = ({ label, icon: Icon, color, isActive, collapsed, disabled, onClick, shortcut }) => {
  const [hovered, setHovered] = useState(false);
  return (
    <div className="relative">
      <button
        onClick={onClick}
        disabled={disabled}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        aria-label={label}
        style={{
          background: isActive
            ? `linear-gradient(135deg, ${color}18 0%, ${color}08 100%)`
            : hovered ? 'rgba(255,255,255,0.04)' : 'transparent',
          borderRight: isActive ? `2px solid ${color}` : '2px solid transparent',
          color: isActive ? '#f1f5f9' : hovered ? 'rgba(241,245,249,0.75)' : 'rgba(148,163,184,0.7)',
          opacity: disabled ? 0.35 : 1,
          transition: 'all 0.18s cubic-bezier(0.4,0,0.2,1)',
        }}
        className={`w-full flex items-center text-[12.5px] font-medium rounded-lg mb-0.5 relative overflow-hidden
          ${collapsed ? 'justify-center p-2.5' : 'gap-2.5 pr-3 pl-2.5 py-2'}`}
      >
        {isActive && (
          <span
            className="absolute inset-0 opacity-0 animate-pulse"
            style={{ background: `radial-gradient(ellipse at right, ${color}14 0%, transparent 70%)` }}
          />
        )}
        <span className="relative shrink-0" style={{ color: isActive ? color : hovered ? 'rgba(148,163,184,0.9)' : 'rgba(100,116,139,0.7)' }}>
          <Icon size={15} strokeWidth={isActive ? 2.2 : 1.8} />
        </span>
        {!collapsed && (
          <>
            <span className="truncate relative flex-1 text-right">{label}</span>
            {shortcut && (
              <span className="text-[10px] opacity-40 font-mono bg-white/5 px-1 py-0.5 rounded shrink-0">{shortcut}</span>
            )}
          </>
        )}
      </button>
      {collapsed && hovered && (
        <div
          className="absolute right-full top-1/2 -translate-y-1/2 mr-2.5 px-2.5 py-1.5 text-white text-xs rounded-lg shadow-2xl whitespace-nowrap z-[200] pointer-events-none"
          style={{
            background: 'linear-gradient(135deg, #1e293b 0%, #0f172a 100%)',
            border: '1px solid rgba(255,255,255,0.1)',
            boxShadow: `0 0 0 1px rgba(0,0,0,0.4), 0 8px 24px rgba(0,0,0,0.5), 0 0 0 0 ${color}40`,
          }}
        >
          <span style={{ color }}>{label}</span>
        </div>
      )}
    </div>
  );
};

interface GroupSectionProps {
  group: GroupDef;
  activeElement: string;
  collapsed: boolean;
  disabledModules: string[];
  canRead: (id: string) => boolean;
  onSelect: (id: string) => void;
  defaultOpen?: boolean;
}

const GroupSection: FC<GroupSectionProps> = ({ group, activeElement, collapsed, disabledModules, canRead, onSelect, defaultOpen = false }) => {
  const [open, setOpen] = useState(defaultOpen);
  const contentRef = useRef<HTMLDivElement>(null);

  const items = group.items ?? (group.elements ?? []).map(el => ({
    id: el,
    label: ELEMENT_LABELS[el] ?? el,
    color: ELEMENT_COLORS[el] ?? '#64748b',
    icon: ELEMENT_ICONS[el] ?? Layers,
  }));

  const isGroupActive = items.some(item => item.id === activeElement);

  useEffect(() => {
    if (isGroupActive) setOpen(true);
  }, [isGroupActive]);

  const GroupIcon = group.icon;

  if (collapsed) {
    return (
      <div className="mb-1">
        <div className="relative group">
          <div
            className="flex justify-center items-center py-2.5 cursor-default"
            style={{ borderRight: `2px solid ${isGroupActive ? group.accentColor : 'transparent'}` }}
          >
            <GroupIcon
              size={16}
              style={{ color: isGroupActive ? group.accentColor : 'rgba(100,116,139,0.6)' }}
              strokeWidth={isGroupActive ? 2.2 : 1.8}
            />
          </div>
          <div
            className="absolute right-full top-0 mr-2 py-1.5 rounded-xl shadow-2xl z-[200] pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity min-w-[180px]"
            style={{ background: 'linear-gradient(135deg, #1e293b 0%, #0f172a 100%)', border: '1px solid rgba(255,255,255,0.1)' }}
          >
            <div className="px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider mb-1" style={{ color: group.accentColor }}>
              {group.label}
            </div>
            {items.map(item => (
              <button
                key={item.id}
                onClick={() => onSelect(item.id)}
                className="w-full text-right px-3 py-1.5 text-[12px] flex items-center gap-2 hover:bg-white/5 transition-colors"
                style={{ color: item.id === activeElement ? item.color : 'rgba(148,163,184,0.8)' }}
              >
                <item.icon size={13} />
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mb-1">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center gap-2 py-1.5 pr-2.5 pl-1.5 rounded-lg mb-0.5 group transition-colors"
        style={{
          color: isGroupActive ? group.accentColor : 'rgba(100,116,139,0.7)',
        }}
      >
        <GroupIcon size={13} strokeWidth={2} className="shrink-0" />
        <span className="flex-1 text-right text-[11px] font-semibold uppercase tracking-wider">{group.label}</span>
        <ChevronDown
          size={12}
          className="shrink-0 transition-transform duration-300"
          style={{ transform: open ? 'rotate(0deg)' : 'rotate(-90deg)' }}
        />
      </button>

      <div
        ref={contentRef}
        className="overflow-hidden"
        style={{
          maxHeight: open ? `${(items.length + 1) * 40}px` : '0px',
          transition: 'max-height 0.35s cubic-bezier(0.4,0,0.2,1)',
          opacity: open ? 1 : 0,
          transitionProperty: 'max-height, opacity',
          transitionDuration: open ? '0.35s, 0.2s' : '0.3s, 0.15s',
          transitionDelay: open ? '0s, 0s' : '0s, 0s',
        }}
      >
        <div className="pr-3 pb-1">
          {items.map(item => {
            const moduleId = ITEM_MODULE[item.id];
            const disabled = disabledModules.includes(item.id) || (!!moduleId && !canRead(moduleId));
            return (
              <NavItem
                key={item.id}
                id={item.id}
                label={item.label}
                icon={item.icon}
                color={item.color}
                isActive={activeElement === item.id}
                collapsed={false}
                disabled={disabled}
                onClick={() => !disabled && onSelect(item.id)}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
};

const Sidebar: FC<SidebarProps> = ({
  activeElement,
  onSelect,
  collapsed = false,
  onToggleCollapse,
  mobileOpen = false,
  onMobileClose,
  onLogout,
  disabledModules = [],
  companyName,
  isAdmin = false,
}) => {
  const { can, user } = useAuth();
  const canRead = useCallback((moduleId: string) => can(moduleId, 'read'), [can]);

  return (
    <>
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden"
          onClick={onMobileClose}
        />
      )}

      <aside
        dir="rtl"
        style={{
          width: collapsed ? 'var(--sidebar-collapsed)' : 'var(--sidebar-width)',
          transition: 'width 0.3s cubic-bezier(0.4,0,0.2,1)',
          background: 'linear-gradient(180deg, #080e1d 0%, #060b17 100%)',
          borderLeft: '1px solid rgba(255,255,255,0.06)',
          boxShadow: '2px 0 20px rgba(0,0,0,0.4)',
          zIndex: 50,
        }}
        className={`
          flex flex-col h-screen fixed top-0 right-0 overflow-hidden
          ${mobileOpen ? 'translate-x-0' : 'translate-x-full md:translate-x-0'}
          transition-transform md:transition-none
        `}
      >
        {/* Brand / Logo Area */}
        <div
          className="flex items-center shrink-0 relative overflow-hidden"
          style={{
            height: '60px',
            borderBottom: '1px solid rgba(255,255,255,0.06)',
            padding: collapsed ? '0 14px' : '0 16px',
          }}
        >
          <div
            className="absolute inset-0 opacity-20"
            style={{ background: 'radial-gradient(ellipse at top right, rgba(245,158,11,0.3) 0%, transparent 60%)' }}
          />
          <div className="flex items-center gap-2.5 relative w-full">
            <div
              className="shrink-0 flex items-center justify-center rounded-lg"
              style={{
                width: 32, height: 32,
                background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
                boxShadow: '0 0 16px rgba(245,158,11,0.35)',
              }}
            >
              <Hexagon size={18} className="text-white" strokeWidth={2.5} />
            </div>
            {!collapsed && (
              <div className="flex-1 min-w-0">
                <div className="text-white font-bold text-[13px] tracking-tight leading-tight">PSM Enterprise</div>
                <div className="text-[10px] truncate" style={{ color: 'rgba(245,158,11,0.7)' }}>
                  {companyName || 'سیستم مدیریت ایمنی'}
                </div>
              </div>
            )}
            {!collapsed && (
              <button
                onClick={onToggleCollapse}
                className="shrink-0 p-1.5 rounded-lg transition-colors hover:bg-white/8"
                style={{ color: 'rgba(148,163,184,0.5)' }}
                title="جمع کردن نوار کناری"
              >
                <PanelLeftClose size={15} />
              </button>
            )}
          </div>
        </div>

        {/* Collapsed expand button */}
        {collapsed && (
          <button
            onClick={onToggleCollapse}
            className="mx-auto mt-2 p-1.5 rounded-lg transition-colors hover:bg-white/8"
            style={{ color: 'rgba(148,163,184,0.4)' }}
            title="باز کردن نوار کناری"
          >
            <PanelLeft size={15} />
          </button>
        )}

        {/* Navigation scroll area */}
        <nav
          className="flex-1 overflow-y-auto overflow-x-hidden py-3"
          style={{ scrollbarWidth: 'thin' }}
        >
          <div className={collapsed ? 'px-2' : 'px-2.5'}>
            {GROUPS.map((group, idx) => (
              <GroupSection
                key={group.id}
                group={group}
                activeElement={activeElement}
                collapsed={collapsed}
                disabledModules={disabledModules}
                canRead={canRead}
                onSelect={onSelect}
                defaultOpen={idx === 0}
              />
            ))}

            {/* Divider */}
            <div className="my-3 mx-1" style={{ height: 1, background: 'rgba(255,255,255,0.05)' }} />

            {/* Settings & Admin */}
            {isAdmin && (
              <NavItem
                id="USERS"
                label="کاربران و دسترسی"
                icon={ShieldCheck}
                color="#8b5cf6"
                isActive={activeElement === 'USERS'}
                collapsed={collapsed}
                onClick={() => onSelect('USERS')}
              />
            )}
            <NavItem
              id="SETTINGS"
              label="تنظیمات"
              icon={Settings}
              color="#64748b"
              isActive={activeElement === 'SETTINGS'}
              collapsed={collapsed}
              onClick={() => onSelect('SETTINGS')}
            />
          </div>
        </nav>

        {/* User Footer */}
        <div
          className="shrink-0 relative overflow-hidden"
          style={{
            borderTop: '1px solid rgba(255,255,255,0.06)',
            padding: collapsed ? '10px 8px' : '10px 12px',
            background: 'rgba(0,0,0,0.2)',
          }}
        >
          {collapsed ? (
            <button
              onClick={onLogout}
              className="w-full flex justify-center p-2 rounded-lg hover:bg-red-500/10 transition-colors"
              style={{ color: 'rgba(239,68,68,0.6)' }}
              title="خروج"
            >
              <LogOut size={16} />
            </button>
          ) : (
            <div className="flex items-center gap-2.5">
              <div
                className="shrink-0 w-7 h-7 rounded-lg flex items-center justify-center text-[11px] font-bold"
                style={{ background: 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)', color: 'white' }}
              >
                {(user as { fullName?: string })?.fullName?.[0] ?? 'U'}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[12px] font-medium text-slate-300 truncate">
                  {(user as { fullName?: string })?.fullName ?? 'کاربر'}
                </div>
                <div className="text-[10px] truncate" style={{ color: 'rgba(100,116,139,0.8)' }}>
                  {(user as { role?: string })?.role ?? ''}
                </div>
              </div>
              <button
                onClick={onLogout}
                className="shrink-0 p-1.5 rounded-lg hover:bg-red-500/10 transition-colors"
                style={{ color: 'rgba(239,68,68,0.5)' }}
                title="خروج"
              >
                <LogOut size={14} />
              </button>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};

export default memo(Sidebar);
