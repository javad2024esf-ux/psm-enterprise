import React, { FC } from 'react';
interface Props { token?: string; activeUnit?: string; [key: string]: unknown; }
const WorkPermitView: FC<Props> = () => (
  <div className="flex items-center justify-center h-64 text-slate-500 text-sm" dir="rtl">مجوز کار</div>
);
export const WorkPermitList: FC<Props> = () => null;
export const WorkPermitDetail: FC<Props> = () => null;
export const WorkPermitCreate: FC<Props> = () => null;
export default WorkPermitView;
