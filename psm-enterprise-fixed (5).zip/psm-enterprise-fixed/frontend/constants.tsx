import React from 'react';
import {
  FileText, ShieldAlert, Users, BookOpen, HardHat, ClipboardCheck, Wrench, Flame,
  RefreshCcw, AlertTriangle, LifeBuoy, SearchCheck, Lock, Heart, Scroll, GraduationCap,
  Globe, Binary, Radio, Gauge, Repeat, ListChecks, LucideIcon,
} from 'lucide-react';
import { PSMElement } from './types';

export const ELEMENT_ICONS: Record<string, LucideIcon> = {
  [PSMElement.CULTURE]: Heart,
  [PSMElement.STANDARDS]: Scroll,
  [PSMElement.COMPETENCY]: Binary,
  [PSMElement.WORKFORCE]: Users,
  [PSMElement.STAKEHOLDER]: Globe,
  [PSMElement.KNOWLEDGE]: FileText,
  [PSMElement.HIRA]: ShieldAlert,
  [PSMElement.PROCEDURES]: BookOpen,
  [PSMElement.SAFE_WORK]: Flame,
  [PSMElement.ASSET_INTEGRITY]: Wrench,
  [PSMElement.CONTRACTOR]: HardHat,
  [PSMElement.TRAINING]: GraduationCap,
  [PSMElement.MOC]: RefreshCcw,
  [PSMElement.READINESS]: ClipboardCheck,
  [PSMElement.CONDUCT_OPS]: Radio,
  [PSMElement.EMERGENCY]: LifeBuoy,
  [PSMElement.INCIDENT]: AlertTriangle,
  [PSMElement.METRICS]: Gauge,
  [PSMElement.AUDIT]: SearchCheck,
  [PSMElement.MANAGEMENT_REVIEW]: Repeat,
  [PSMElement.TRADE_SECRET]: Lock,
  [PSMElement.ACTION_REGISTER]: ListChecks,
};

export const COLORS = {
  primary: '#0369a1', secondary: '#0f172a', accent: '#f59e0b', danger: '#e11d48', success: '#059669',
};

export const COMPANY_UNITS = ['کل شرکت'];
