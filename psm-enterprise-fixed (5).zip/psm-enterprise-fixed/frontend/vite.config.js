import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'url';

// ✅ FIXED: Dynamic port and API URL configuration using environment variables
export default defineConfig({
  plugins: [react()],
  base: '/',
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
      '@components': fileURLToPath(new URL('./components', import.meta.url)),
      '@utils': fileURLToPath(new URL('./utils', import.meta.url)),
    },
  },
  server: {
    // Use VITE_PORT from .env.local or default to 5173
    port: parseInt(process.env.VITE_PORT || '5173'),
    
    // API proxy configuration
    proxy: {
      '/api': {
        // Use VITE_API_URL from .env.local or default to http://localhost:3000
        target: process.env.VITE_API_URL || 'http://localhost:3000',
        changeOrigin: true,
      },
    },
  },
  define: {
    __DEV__: JSON.stringify(true),
  },
});
