import React, { Suspense, FC } from 'react';
import { ErrorBoundary } from 'react-error-boundary';
import { ToastProvider } from './src/context/ToastContext';
import { AuthProvider } from './src/context/AuthContext';
import { PSMProvider } from './src/context/PSMContext';
import App from './App';
import { Shield, Loader2, RefreshCw } from 'lucide-react';

const ErrorFallback: FC<{ error: Error; resetErrorBoundary: () => void }> = ({ error, resetErrorBoundary }) => (
  <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800" dir="rtl">
    <div className="max-w-md w-full mx-4">
      <div className="bg-slate-800 rounded-2xl border border-white/10 shadow-2xl p-8 text-center">
        <div className="w-16 h-16 bg-red-500/15 rounded-full flex items-center justify-center mx-auto mb-4">
          <Shield className="text-red-400" size={32} />
        </div>
        <h2 className="text-xl font-bold text-slate-100 mb-2">خطای غیرمنتظره</h2>
        <p className="text-slate-400 mb-5 text-sm leading-relaxed">
          متأسفانه یک مشکل رخ داده است. لطفاً مجدداً تلاش کنید یا صفحه را رفرش کنید.
        </p>
        <details className="text-right mb-5">
          <summary className="text-sm text-slate-500 cursor-pointer hover:text-slate-400 list-none">
            جزئیات خطا
          </summary>
          <pre className="mt-3 p-3 bg-slate-900 rounded-lg text-[11px] text-red-400 overflow-auto max-h-40 text-left border border-red-500/20">
            {error.message}
          </pre>
        </details>
        <div className="flex gap-3">
          <button
            onClick={resetErrorBoundary}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors font-semibold text-sm"
          >
            <RefreshCw size={15} />
            تلاش مجدد
          </button>
          <button
            onClick={() => window.location.reload()}
            className="flex-1 px-4 py-2.5 bg-slate-700 text-slate-300 rounded-xl hover:bg-slate-600 transition-colors font-semibold text-sm"
          >
            بارگذاری مجدد
          </button>
        </div>
      </div>
    </div>
  </div>
);

const AppLoader: React.FC = () => (
  <div className="min-h-screen flex items-center justify-center bg-[#0f172a]" dir="rtl">
    <div className="flex flex-col items-center gap-6">
      <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center shadow-[0_8px_30px_rgba(14,165,233,0.4)] animate-pulse">
        <Shield className="text-white" size={38} />
      </div>
      <div className="flex items-center gap-2 text-slate-400 text-sm">
        <Loader2 size={16} className="animate-spin text-sky-400" />
        <span>در حال بارگذاری PSM Enterprise...</span>
      </div>
    </div>
  </div>
);

const Root: React.FC = () => {
  return (
    <React.StrictMode>
      <ErrorBoundary
        FallbackComponent={ErrorFallback}
        onReset={() => { window.location.href = '/'; }}
        onError={(error, info) => {
          if (import.meta.env.DEV) {
            console.error('[ErrorBoundary] Caught:', error, info);
          }
        }}
      >
        <ToastProvider>
          <AuthProvider>
            <PSMProvider>
              <Suspense fallback={<AppLoader />}>
                <App />
              </Suspense>
            </PSMProvider>
          </AuthProvider>
        </ToastProvider>
      </ErrorBoundary>
    </React.StrictMode>
  );
};

export default Root;
