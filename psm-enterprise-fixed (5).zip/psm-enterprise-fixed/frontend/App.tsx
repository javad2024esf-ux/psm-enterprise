import { ConfirmProvider } from './components/ConfirmDialog';
import React, { useState, useEffect, useCallback, lazy, Suspense, memo } from 'react';
import { useAuth } from './src/context/AuthContext';
import { webApi } from './src/webApi';
import LoginView from './components/LoginView';
import Sidebar from './components/Sidebar';
import AppHeader from './components/AppHeader';
import CompanySetup from './components/CompanySetup';
import GlobalSearch from './components/GlobalSearch';
import AccessDenied from './components/AccessDenied';
import { useNotifications } from './src/hooks/useNotifications';
import {
  exportMOC, exportIncidents, exportTraining, exportAudit,
  exportMechanicalIntegrity, exportContractors, exportPermits,
  exportPSSR, exportEmergency, exportActionRegister, exportHAZOP,
  exportPSI, exportMetrics, exportManagementReview, exportGapAnalysis,
  exportConductOps, exportTradeSecret, exportWorkforce, exportStakeholders,
  exportGeneric
} from './utils/excelExport';

// ─── Lazy-loaded components ──────────────────────────────────────────────────
const Dashboard = lazy(() => import('./components/Dashboard'));
const HIRAView = lazy(() => import('./components/HIRAView'));
const PSIView = lazy(() => import('./components/PSIView'));
const MocView = lazy(() => import('./components/MocView'));
const IncidentView = lazy(() => import('./components/IncidentView'));
const PermitView = lazy(() =>
  import('./features/permit/PermitView')?.then(m => ({ default: (m as Record<string, React.ComponentType>).PermitView || m.default }))
);
const PSSRView = lazy(() => import('./components/PSSRView'));
const MechanicalIntegrityView = lazy(() => import('./components/MechanicalIntegrityView'));
const EmergencyView = lazy(() => import('./components/EmergencyView'));
const AuditView = lazy(() => import('./components/AuditView'));
const ParticipationView = lazy(() => import('./components/ParticipationView'));
const TrainingView = lazy(() => import('./components/TrainingView'));
const OperatingProceduresView = lazy(() => import('./components/OperatingProceduresView'));
const ContractorsView = lazy(() => import('./components/ContractorsView'));
const TradeSecretView = lazy(() => import('./components/TradeSecretView'));
const SettingsView = lazy(() => import('./components/SettingsView'));
const HelpPanel = lazy(() => import('./components/HelpPanel'));
const GenericElementView = lazy(() => import('./components/GenericElementView'));
const CultureView = lazy(() => import('./components/CultureView'));
const StandardsView = lazy(() => import('./components/StandardsView'));
const CompetencyView = lazy(() => import('./components/CompetencyView'));
const StakeholderView = lazy(() => import('./components/StakeholderView'));
const ConductOpsView = lazy(() => import('./components/ConductOpsView'));
const MetricsView = lazy(() => import('./components/MetricsView'));
const ManagementReviewView = lazy(() => import('./components/ManagementReviewView'));
const UsersView = lazy(() => import('./components/UsersView'));
const RolePermissionBuilder = lazy(() => import('./components/RolePermissionBuilder'));
const ActionRegisterView = lazy(() => import('./components/ActionRegisterView'));
const GapAnalysisModule = lazy(() =>
  import('./components/GapAnalysisModule')?.then(m => ({ default: (m as Record<string, React.ComponentType>).GapAnalysisModule }))
);
const WorkflowDashboard = lazy(() => import('./components/WorkflowDashboard'));
const ManagementReportView = lazy(() => import('./components/ManagementReportView'));
const LOPADashboard = lazy(() => import('./components/LOPADashboard'));

import { PSMElement, ProcessUnit, GapAssessment } from './types';
import { ELEMENT_ICONS } from './constants';
import { Shield, Loader2, HelpCircle, Printer } from 'lucide-react';
import html2pdf from 'html2pdf.js';

const PRINTABLE_PAGES = [
  'GAP_ANALYSIS', PSMElement.HIRA, PSMElement.MOC, PSMElement.INCIDENT,
  PSMElement.AUDIT, PSMElement.TRAINING, PSMElement.ASSET_INTEGRITY,
  PSMElement.EMERGENCY, PSMElement.PROCEDURES, PSMElement.METRICS,
  PSMElement.MANAGEMENT_REVIEW, PSMElement.READINESS, PSMElement.SAFE_WORK,
  PSMElement.CONTRACTOR, PSMElement.WORKFORCE, PSMElement.STAKEHOLDER,
  PSMElement.CONDUCT_OPS, PSMElement.KNOWLEDGE, PSMElement.TRADE_SECRET,
  PSMElement.CULTURE, PSMElement.STANDARDS, PSMElement.COMPETENCY,
  PSMElement.ACTION_REGISTER,
];
const PRINTABLE_SET = new Set(PRINTABLE_PAGES);

// Page label map for breadcrumbs
const PAGE_LABELS: Record<string, string> = {
  DASHBOARD: 'داشبورد عملیاتی',
  GAP_ANALYSIS: 'آنالیز شکاف RBPS',
  LOPA: 'LOPA — تحلیل خطر',
  BOWTIE: 'BowTie — نمودار خطر',
  WORKFLOW: 'موتور Workflow',
  MANAGEMENT_REPORT: 'گزارش‌گیری مدیریتی',
  SETTINGS: 'تنظیمات',
  USERS: 'کاربران و دسترسی',
  [PSMElement.ACTION_REGISTER]: 'ثبت اقدام مرکزی',
  [PSMElement.CULTURE]: 'فرهنگ ایمنی',
  [PSMElement.STANDARDS]: 'استانداردها',
  [PSMElement.COMPETENCY]: 'شایستگی',
  [PSMElement.WORKFORCE]: 'مشارکت نیروکار',
  [PSMElement.STAKEHOLDER]: 'ذینفعان',
  [PSMElement.KNOWLEDGE]: 'PSI - اطلاعات فرآیند',
  [PSMElement.HIRA]: 'HAZOP / HIRA',
  [PSMElement.PROCEDURES]: 'رویه‌های عملیاتی',
  [PSMElement.SAFE_WORK]: 'مجوز کار ایمن',
  [PSMElement.ASSET_INTEGRITY]: 'یکپارچگی دارایی‌ها',
  [PSMElement.CONTRACTOR]: 'پیمانکاران',
  [PSMElement.TRAINING]: 'آموزش',
  [PSMElement.MOC]: 'مدیریت تغییر',
  [PSMElement.READINESS]: 'PSSR',
  [PSMElement.CONDUCT_OPS]: 'انضباط عملیاتی',
  [PSMElement.EMERGENCY]: 'آمادگی اضطراری',
  [PSMElement.INCIDENT]: 'بررسی حوادث',
  [PSMElement.METRICS]: 'شاخص‌های عملکرد',
  [PSMElement.AUDIT]: 'ممیزی و بازرسی',
  [PSMElement.MANAGEMENT_REVIEW]: 'بازنگری مدیریت',
  [PSMElement.TRADE_SECRET]: 'اطلاعات محرمانه',
};

const ModuleLoader: React.FC = memo(() => (
  <div className="flex items-center justify-center h-64" dir="rtl">
    <div className="flex items-center gap-3 text-slate-400">
      <Loader2 size={20} className="animate-spin text-sky-400" />
      <span className="text-sm font-medium">در حال بارگذاری ماژول...</span>
    </div>
  </div>
));
ModuleLoader.displayName = 'ModuleLoader';

const SplashScreen: React.FC = () => (
  <div className="min-h-screen flex flex-col items-center justify-center bg-[#0f172a]" dir="rtl">
    <div className="flex flex-col items-center gap-6">
      <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center shadow-[0_8px_30px_rgba(14,165,233,0.4)] animate-pulse">
        <Shield className="text-white" size={38} />
      </div>
      <div className="flex flex-col items-center gap-2">
        <p className="text-white font-black text-xl">PSM Enterprise</p>
        <div className="flex items-center gap-2 text-slate-400 text-sm">
          <Loader2 size={16} className="animate-spin text-sky-400" />
          <span>در حال بارگذاری...</span>
        </div>
      </div>
    </div>
  </div>
);

const COMPANY_UNITS = ['کل شرکت', 'واحد تولید ۱', 'واحد تولید ۲', 'واحد خدمات'];

function App() {
  const { user, token, isLoading, isLoggedIn, logout, can, isAdmin } = useAuth();
  const [activeElement, setActiveElement] = useState<string>('DASHBOARD');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [companyName, setCompanyName] = useState('');
  const [needsSetup, setNeedsSetup] = useState(false);
  const [activeUnit, setActiveUnit] = useState<string>(COMPANY_UNITS[0]);
  const [disabledModules, setDisabledModules] = useState<string[]>([]);
  const [gapAssessment, setGapAssessment] = useState<GapAssessment | null>(null);

  const { notifications, unreadCount, markAsRead, markAllAsRead } = useNotifications(token, isLoggedIn);

  // Load company config
  useEffect(() => {
    if (!isLoggedIn || !token) return;
    (async () => {
      try {
        const cfg = await (webApi as Record<string, ((t: string) => Promise<{ companyName?: string; disabledModules?: string[] }>) | undefined>)?.getCompanyConfig?.(token);
        if (cfg?.companyName) setCompanyName(cfg.companyName);
        if (cfg?.disabledModules) setDisabledModules(cfg.disabledModules);
        else setNeedsSetup(false);
      } catch {
        // ignore
      }
    })();
  }, [isLoggedIn, token]);

  const handleSelect = useCallback((el: string) => {
    setActiveElement(el);
    setMobileSidebarOpen(false);
  }, []);

  const handleExport = useCallback(async () => {
    if (!token) return;
    const el = activeElement as PSMElement;
    try {
      const exportMap: Record<string, () => Promise<void>> = {
        [PSMElement.MOC]: () => exportMOC(token),
        [PSMElement.INCIDENT]: () => exportIncidents(token),
        [PSMElement.TRAINING]: () => exportTraining(token),
        [PSMElement.AUDIT]: () => exportAudit(token),
        [PSMElement.ASSET_INTEGRITY]: () => exportMechanicalIntegrity(token),
        [PSMElement.CONTRACTOR]: () => exportContractors(token),
        [PSMElement.SAFE_WORK]: () => exportPermits(token),
        [PSMElement.READINESS]: () => exportPSSR(token),
        [PSMElement.EMERGENCY]: () => exportEmergency(token),
        [PSMElement.ACTION_REGISTER]: () => exportActionRegister(token),
        [PSMElement.HIRA]: () => exportHAZOP(token),
        [PSMElement.KNOWLEDGE]: () => exportPSI(token),
        [PSMElement.METRICS]: () => exportMetrics(token),
        [PSMElement.MANAGEMENT_REVIEW]: () => exportManagementReview(token),
        GAP_ANALYSIS: () => exportGapAnalysis(token),
        [PSMElement.CONDUCT_OPS]: () => exportConductOps(token),
        [PSMElement.TRADE_SECRET]: () => exportTradeSecret(token),
        [PSMElement.WORKFORCE]: () => exportWorkforce(token),
        [PSMElement.STAKEHOLDER]: () => exportStakeholders(token),
      };
      if (exportMap[el]) await exportMap[el]();
      else await exportGeneric(token, el);
    } catch (err) {
      console.error('Export error:', err);
    }
  }, [activeElement, token]);

  const handlePrint = useCallback(async () => {
    const main = document.getElementById('main-content');
    if (!main) return;
    const opt = {
      margin: 10, filename: `PSM-${activeElement}.pdf`,
      image: { type: 'jpeg', quality: 0.95 },
      html2canvas: { scale: 2, useCORS: true, direction: 'rtl' },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
    };
    await html2pdf().set(opt).from(main).save();
  }, [activeElement]);

  const breadcrumbs = [
    { label: 'PSM Enterprise', id: 'DASHBOARD' },
    ...(activeElement !== 'DASHBOARD' ? [{ label: PAGE_LABELS[activeElement] ?? activeElement }] : []),
  ];

  if (isLoading) return <SplashScreen />;
  if (!isLoggedIn) return <LoginView />;
  if (needsSetup && isAdmin) return <CompanySetup onComplete={() => setNeedsSetup(false)} />;

  const renderContent = () => {
    const commonProps = { token: token!, activeUnit, onExport: handleExport };

    const checkAccess = (moduleId: string) => {
      if (!can(moduleId, 'read')) return <AccessDenied />;
      return null;
    };

    switch (activeElement) {
      case 'DASHBOARD': return <Suspense fallback={<ModuleLoader />}><Dashboard {...commonProps} onNavigate={handleSelect} gapAssessment={gapAssessment} /></Suspense>;
      case 'GAP_ANALYSIS': return checkAccess('AUDIT') ?? <Suspense fallback={<ModuleLoader />}><GapAnalysisModule {...commonProps} onAssessmentChange={setGapAssessment} /></Suspense>;
      case 'LOPA': return checkAccess('HAZOP') ?? <Suspense fallback={<ModuleLoader />}><LOPADashboard {...commonProps} /></Suspense>;
      case 'BOWTIE': return checkAccess('HAZOP') ?? <Suspense fallback={<ModuleLoader />}><GenericElementView element="BOWTIE" {...commonProps} /></Suspense>;
      case 'WORKFLOW': return checkAccess('AUDIT') ?? <Suspense fallback={<ModuleLoader />}><WorkflowDashboard {...commonProps} /></Suspense>;
      case 'MANAGEMENT_REPORT': return checkAccess('MANAGEMENT_REVIEW') ?? <Suspense fallback={<ModuleLoader />}><ManagementReportView {...commonProps} /></Suspense>;
      case PSMElement.ACTION_REGISTER: return checkAccess('ACTION_REGISTER') ?? <Suspense fallback={<ModuleLoader />}><ActionRegisterView {...commonProps} /></Suspense>;
      case PSMElement.CULTURE: return checkAccess('CULTURE') ?? <Suspense fallback={<ModuleLoader />}><CultureView {...commonProps} /></Suspense>;
      case PSMElement.STANDARDS: return checkAccess('STANDARDS') ?? <Suspense fallback={<ModuleLoader />}><StandardsView {...commonProps} /></Suspense>;
      case PSMElement.COMPETENCY: return checkAccess('COMPETENCY') ?? <Suspense fallback={<ModuleLoader />}><CompetencyView {...commonProps} /></Suspense>;
      case PSMElement.WORKFORCE: return checkAccess('WORKFORCE') ?? <Suspense fallback={<ModuleLoader />}><ParticipationView {...commonProps} /></Suspense>;
      case PSMElement.STAKEHOLDER: return checkAccess('STAKEHOLDER') ?? <Suspense fallback={<ModuleLoader />}><StakeholderView {...commonProps} /></Suspense>;
      case PSMElement.KNOWLEDGE: return checkAccess('KNOWLEDGE') ?? <Suspense fallback={<ModuleLoader />}><PSIView {...commonProps} /></Suspense>;
      case PSMElement.HIRA: return checkAccess('HIRA') ?? <Suspense fallback={<ModuleLoader />}><HIRAView {...commonProps} /></Suspense>;
      case PSMElement.PROCEDURES: return checkAccess('PROCEDURES') ?? <Suspense fallback={<ModuleLoader />}><OperatingProceduresView {...commonProps} /></Suspense>;
      case PSMElement.SAFE_WORK: return checkAccess('SAFE_WORK') ?? <Suspense fallback={<ModuleLoader />}><PermitView token={token!} activeUnit={activeUnit} /></Suspense>;
      case PSMElement.ASSET_INTEGRITY: return checkAccess('ASSET_INTEGRITY') ?? <Suspense fallback={<ModuleLoader />}><MechanicalIntegrityView {...commonProps} /></Suspense>;
      case PSMElement.CONTRACTOR: return checkAccess('CONTRACTOR') ?? <Suspense fallback={<ModuleLoader />}><ContractorsView {...commonProps} /></Suspense>;
      case PSMElement.TRAINING: return checkAccess('TRAINING') ?? <Suspense fallback={<ModuleLoader />}><TrainingView {...commonProps} /></Suspense>;
      case PSMElement.MOC: return checkAccess('MOC') ?? <Suspense fallback={<ModuleLoader />}><MocView {...commonProps} /></Suspense>;
      case PSMElement.READINESS: return checkAccess('READINESS') ?? <Suspense fallback={<ModuleLoader />}><PSSRView {...commonProps} /></Suspense>;
      case PSMElement.CONDUCT_OPS: return checkAccess('CONDUCT_OPS') ?? <Suspense fallback={<ModuleLoader />}><ConductOpsView {...commonProps} /></Suspense>;
      case PSMElement.EMERGENCY: return checkAccess('EMERGENCY') ?? <Suspense fallback={<ModuleLoader />}><EmergencyView {...commonProps} /></Suspense>;
      case PSMElement.INCIDENT: return checkAccess('INCIDENT') ?? <Suspense fallback={<ModuleLoader />}><IncidentView {...commonProps} /></Suspense>;
      case PSMElement.METRICS: return checkAccess('METRICS') ?? <Suspense fallback={<ModuleLoader />}><MetricsView {...commonProps} /></Suspense>;
      case PSMElement.AUDIT: return checkAccess('AUDIT') ?? <Suspense fallback={<ModuleLoader />}><AuditView {...commonProps} /></Suspense>;
      case PSMElement.MANAGEMENT_REVIEW: return checkAccess('MANAGEMENT_REVIEW') ?? <Suspense fallback={<ModuleLoader />}><ManagementReviewView {...commonProps} /></Suspense>;
      case PSMElement.TRADE_SECRET: return checkAccess('KNOWLEDGE') ?? <Suspense fallback={<ModuleLoader />}><TradeSecretView {...commonProps} /></Suspense>;
      case 'SETTINGS': return <Suspense fallback={<ModuleLoader />}><SettingsView token={token!} user={user} /></Suspense>;
      case 'USERS': return isAdmin ? <Suspense fallback={<ModuleLoader />}><UsersView token={token!} /></Suspense> : <AccessDenied />;
      default: return <Suspense fallback={<ModuleLoader />}><GenericElementView element={activeElement as PSMElement} {...commonProps} /></Suspense>;
    }
  };

  return (
    <ConfirmProvider>
      <div className="flex h-screen overflow-hidden" dir="rtl" style={{ background: 'var(--bg-base)' }}>
        {/* Sidebar */}
        <Sidebar
          activeElement={activeElement}
          onSelect={handleSelect}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(c => !c)}
          mobileOpen={mobileSidebarOpen}
          onMobileClose={() => setMobileSidebarOpen(false)}
          onLogout={logout}
          disabledModules={disabledModules}
          companyName={companyName}
          isAdmin={isAdmin}
          user={user}
        />

        {/* Main area — shifts with sidebar */}
        <div
          className="flex flex-col flex-1 overflow-hidden transition-all duration-300"
          style={{
            marginRight: sidebarCollapsed ? 'var(--sidebar-collapsed)' : 'var(--sidebar-width)',
          }}
        >
          {/* Header */}
          <AppHeader
            user={user ?? undefined}
            companyName={companyName}
            breadcrumbs={breadcrumbs}
            notifications={notifications}
            unreadCount={unreadCount}
            onMarkAllRead={markAllAsRead}
            onMarkRead={markAsRead}
            onNavigate={handleSelect}
            onLogout={logout}
            onSettingsClick={() => handleSelect('SETTINGS')}
            onSearchOpen={() => setSearchOpen(true)}
            onMobileMenuToggle={() => setMobileSidebarOpen(o => !o)}
            sidebarCollapsed={sidebarCollapsed}
            onToggleCollapse={() => setSidebarCollapsed(c => !c)}
            isAdmin={isAdmin}
            units={COMPANY_UNITS}
            activeUnit={activeUnit}
            onUnitChange={setActiveUnit}
          />

          {/* Content */}
          <main
            id="main-content"
            className="flex-1 overflow-y-auto overflow-x-hidden"
            style={{ background: 'var(--bg-base)' }}
          >
            <div className="p-4 md:p-6 min-h-full">
              {renderContent()}
            </div>
          </main>

          {/* Floating action buttons */}
          <div className="fixed bottom-5 left-5 flex flex-col gap-2 z-40">
            {PRINTABLE_SET.has(activeElement) && (
              <button
                onClick={handlePrint}
                className="w-9 h-9 rounded-full flex items-center justify-center transition-all shadow-lg hover:shadow-xl"
                style={{
                  background: 'rgba(15,26,48,0.9)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  color: 'rgba(148,163,184,0.7)',
                  backdropFilter: 'blur(8px)',
                }}
                title="چاپ / PDF"
              >
                <Printer size={15} />
              </button>
            )}
            <button
              onClick={() => setShowHelp(true)}
              className="w-9 h-9 rounded-full flex items-center justify-center transition-all shadow-lg hover:shadow-xl"
              style={{
                background: 'rgba(15,26,48,0.9)',
                border: '1px solid rgba(255,255,255,0.1)',
                color: 'rgba(148,163,184,0.7)',
                backdropFilter: 'blur(8px)',
              }}
              title="راهنما"
            >
              <HelpCircle size={15} />
            </button>
          </div>
        </div>

        {/* Global Search */}
        {searchOpen && (
          <GlobalSearch
            isOpen={searchOpen}
            onClose={() => setSearchOpen(false)}
            onNavigate={(el) => { handleSelect(el); setSearchOpen(false); }}
          />
        )}

        {/* Help panel */}
        {showHelp && (
          <Suspense fallback={null}>
            <HelpPanel
              activeElement={activeElement}
              onClose={() => setShowHelp(false)}
            />
          </Suspense>
        )}
      </div>
    </ConfirmProvider>
  );
}

export default App;
