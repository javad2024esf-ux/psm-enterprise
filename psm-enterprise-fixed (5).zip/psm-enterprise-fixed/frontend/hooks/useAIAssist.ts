import { useState, useCallback } from 'react';

export interface AIContext {
  equipment?: string;
  hazard?: string;
  cause?: string;
  consequence?: string;
  safeguards?: string;
  scenario?: string;
  process_type?: string;
  ipl_type?: string;
  initiating_frequency?: number;
  target_risk?: number;
  consequence_severity?: number;
}

export interface UseAIAssistReturn {
  aiLoading: boolean;
  aiError: string | null;
  aiSuggestions: string[];
  getSuggestionsForHazop: (fieldType: 'cause' | 'consequence' | 'safeguard' | 'action', context: AIContext) => Promise<void>;
  getSuggestionsForLOPA: (fieldType: 'ipl' | 'sil', context: AIContext) => Promise<void>;
  assessRisk: (context: AIContext) => Promise<any>;
  estimateIPLPFD: (ipl_type: string, ipl_description?: string) => Promise<number | null>;
  setAiSuggestions: (suggestions: string[]) => void;
  setAiError: (error: string | null) => void;
}

export const useAIAssist = (): UseAIAssistReturn => {
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);

  const getSuggestionsForHazop = useCallback(
    async (fieldType: 'cause' | 'consequence' | 'safeguard' | 'action', context: AIContext) => {
      setAiLoading(true);
      setAiError(null);
      setAiSuggestions([]);

      try {
        const endpoints: Record<string, string> = {
          cause: '/api/ai-assist/hazop/suggest-cause',
          consequence: '/api/ai-assist/hazop/suggest-consequence',
          safeguard: '/api/ai-assist/hazop/suggest-safeguard',
          action: '/api/ai-assist/hazop/suggest-action',
        };

        const response = await fetch(endpoints[fieldType], {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(context),
        });

        const data = await response.json();

        if (data.success && data.suggestions) {
          setAiSuggestions(Array.isArray(data.suggestions) ? data.suggestions : [data.suggestions]);
        } else {
          setAiError(data.error || 'Failed to get suggestions');
        }
      } catch (err) {
        setAiError(err instanceof Error ? err.message : 'Network error');
      } finally {
        setAiLoading(false);
      }
    },
    []
  );

  const getSuggestionsForLOPA = useCallback(
    async (fieldType: 'ipl' | 'sil', context: AIContext) => {
      setAiLoading(true);
      setAiError(null);
      setAiSuggestions([]);

      try {
        const endpoints: Record<string, string> = {
          ipl: '/api/ai-assist/lopa/suggest-ipl',
          sil: '/api/ai-assist/lopa/recommend-sil',
        };

        const response = await fetch(endpoints[fieldType], {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(context),
        });

        const data = await response.json();

        if (data.success) {
          if (fieldType === 'sil' && data.guidance) {
            setAiSuggestions([
              `SIL ${data.recommended_sil} (RRF: ${data.required_rrf?.toFixed(1)})`,
              data.guidance,
            ]);
          } else if (data.suggestions) {
            setAiSuggestions(Array.isArray(data.suggestions) ? data.suggestions : [data.suggestions]);
          }
        } else {
          setAiError(data.error || 'Failed to get suggestions');
        }
      } catch (err) {
        setAiError(err instanceof Error ? err.message : 'Network error');
      } finally {
        setAiLoading(false);
      }
    },
    []
  );

  const assessRisk = useCallback(async (context: AIContext) => {
    setAiLoading(true);
    setAiError(null);

    try {
      const response = await fetch('/api/ai-assist/hazop/assess-risk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(context),
      });

      const data = await response.json();

      if (data.success && data.assessment) {
        return data.assessment;
      } else {
        setAiError(data.error || 'Failed to assess risk');
        return null;
      }
    } catch (err) {
      setAiError(err instanceof Error ? err.message : 'Network error');
      return null;
    } finally {
      setAiLoading(false);
    }
  }, []);

  const estimateIPLPFD = useCallback(async (ipl_type: string, ipl_description?: string) => {
    setAiLoading(true);
    setAiError(null);

    try {
      const response = await fetch('/api/ai-assist/lopa/estimate-pfd', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ipl_type, ipl_description }),
      });

      const data = await response.json();

      if (data.success && typeof data.estimated_pfd === 'number') {
        return data.estimated_pfd;
      } else {
        setAiError(data.error || 'Failed to estimate PFD');
        return null;
      }
    } catch (err) {
      setAiError(err instanceof Error ? err.message : 'Network error');
      return null;
    } finally {
      setAiLoading(false);
    }
  }, []);

  return {
    aiLoading,
    aiError,
    aiSuggestions,
    getSuggestionsForHazop,
    getSuggestionsForLOPA,
    assessRisk,
    estimateIPLPFD,
    setAiSuggestions,
    setAiError,
  };
};
