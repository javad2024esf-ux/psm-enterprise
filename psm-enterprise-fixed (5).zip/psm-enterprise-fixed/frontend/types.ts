export enum ProcessUnit {
  ALL_UNITS = 'کل شرکت',
}

export enum PSMElement {
  CULTURE = 'فرهنگ ایمنی فرآیند',
  STANDARDS = 'استانداردها و کدها',
  COMPETENCY = 'شایستگی و دانش',
  WORKFORCE = 'مشارکت نیروی کار',
  STAKEHOLDER = 'ذینفعان',
  KNOWLEDGE = 'اطلاعات ایمنی فرآیند (PSI)',
  HIRA = 'شناسایی خطرات و ارزیابی ریسک (HIRA)',
  PROCEDURES = 'رویه‌های عملیاتی',
  SAFE_WORK = 'مجوز کار ایمن',
  ASSET_INTEGRITY = 'یکپارچگی دارایی‌ها (MI)',
  CONTRACTOR = 'مدیریت پیمانکاران',
  TRAINING = 'آموزش و صلاحیت',
  MOC = 'مدیریت تغییر (MOC)',
  READINESS = 'آمادگی راه‌اندازی (PSSR)',
  CONDUCT_OPS = 'انضباط عملیاتی',
  EMERGENCY = 'آمادگی اضطراری',
  INCIDENT = 'بررسی حوادث',
  METRICS = 'شاخص‌های عملکرد',
  AUDIT = 'ممیزی و بازرسی',
  MANAGEMENT_REVIEW = 'بازنگری مدیریت',
  TRADE_SECRET = 'حفاظت از اطلاعات محرمانه',
  ACTION_REGISTER = 'ثبت اقدام مرکزی',
}

export enum RiskLevel {
  LOW = 'کم',
  MEDIUM = 'متوسط',
  HIGH = 'زیاد',
  CRITICAL = 'بحرانی',
}

export interface RiskMatrixCell {
  severity: number;
  frequency: number;
  level: RiskLevel;
  score: number;
}

export type StakeholderCategory = 'Regulator' | 'EmergencyServices' | 'Community' | 'Contractor' | 'InternalDept' | 'Supplier';
export type EngagementType = 'Meeting' | 'Drill' | 'Report' | 'Email' | 'Inspection' | 'MOC_Notification';
export type InfluenceLevel = 'High' | 'Low';
export type InterestLevel = 'High' | 'Low';

export interface Stakeholder {
  id: string; name: string; category: StakeholderCategory; contactPerson: string;
  phone: string; email?: string; influence: InfluenceLevel; interest: InterestLevel;
  isEmergencyContact: boolean; relationshipStatus: 'Green' | 'Yellow' | 'Red'; lastEngagementDate: string;
}

export interface EngagementRecord {
  id: string; stakeholderId: string; date: string; type: EngagementType;
  title: string; summary: string; outcome: string; followUpRequired: boolean;
  status: 'Completed' | 'Pending';
}

export interface FieldObservation {
  id: string; date: string; observer: string; observedPerson: string;
  procedureId: string; taskDescription: string; complianceScore: number;
  findings: string[]; status: 'Safe' | 'AtRisk'; correctiveAction?: string;
}

export interface IowRecord {
  id: string; tag: string; parameter: string; limitType: 'Standard' | 'Critical';
  currentValue: number; limitValue: number; durationMinutes: number;
  status: 'Normal' | 'Excursion'; startTime: string;
}

export interface SOP {
  id: string; title: string; number: string; code: string; unit: string;
  category: string; lastReview: string; nextReview: string; revDate: string;
  nextRev: string; status: string; owner: string; version?: string;
}

export interface BypassRecord {
  id: string; tag: string; description: string; reason: string;
  appliedBy: string; authorizedBy: string; startTime: string;
  expectedRemoval: string; riskControls: string[];
}

export interface HazopStudy {
  id: string; title: string; unit: string; date: string;
  status: 'Planned' | 'In Progress' | 'Completed' | 'On Hold';
  teamLeader: string; nodesCount: number; deviationsCount?: number; completionPercent?: number;
}

export interface HazopNode {
  id: string; unit: string; name: string; description: string; designIntent: string;
}

export interface HazopEntry {
  id: string; nodeId: string; parameter: string; deviation: string; guideWord?: string;
  causes: string[]; consequences: string[]; safeguards: string[];
  severity: number; likelihood: number; riskLevel: string; recommendations: string[];
  lopaRequired: boolean; responsible?: string; targetDate?: string; status?: string;
}

export interface IPL {
  id: string; category: 'BPCS' | 'Alarm' | 'SIS' | 'Relief' | 'Passive' | 'Human';
  description: string; pfd: number; rpf: number; independent: boolean; audited: boolean;
}

export interface LopaScenario {
  id: string; hazopRefId: string; title: string; initiatingEventFreq: number;
  targetRiskFreq: number; consequenceSeverity: number; ipls: IPL[]; notes: string;
  status: 'پیش‌نویس' | 'تایید شده' | 'دارای شکاف ایمنی';
}

export interface BowTieBarrier {
  id: string; label: string; type: 'Hardware' | 'Human' | 'System';
  status: 'Effective' | 'Degraded' | 'Failed';
}

export interface BowTieThreat { id: string; description: string; barriers: BowTieBarrier[]; }
export interface BowTieConsequence { id: string; description: string; barriers: BowTieBarrier[]; }

export interface BowTieDiagram {
  id: string; title: string; hazard: string; topEvent: string;
  threats: BowTieThreat[]; consequences: BowTieConsequence[]; unit: string;
}

export type MocType = 'Permanent' | 'Temporary' | 'Emergency';
export type MocStatus = 'Draft' | 'RiskAssessment' | 'TechnicalReview' | 'Approval' | 'Implementation' | 'PSSR' | 'Closed' | 'Cancelled';
export type MocRiskLevel = 'Low' | 'Medium' | 'High';

export interface MocImpacts {
  hazop: boolean; procedures: boolean; psi: boolean;
  environmental: boolean; training: boolean; equipment: boolean;
}

export interface MocAction {
  id: string; description: string; assignee: string; dueDate: string; status: 'Pending' | 'Closed';
}

export interface MocApproval {
  role: string; status: 'Pending' | 'Approved' | 'Rejected'; name?: string; date?: string;
}

export interface PssrChecklistItem {
  id: string; categoryId: string; question: string;
  status: 'Pending' | 'Pass' | 'Fail' | 'NA'; verifiedBy?: string; comment?: string;
}

export interface MocRequest {
  id: string; title: string; description: string; justification: string;
  type: MocType; initiator: string; unit: string; status: MocStatus;
  createdAt: string; isTemporary: boolean; expiryDate?: string;
  riskLevel: MocRiskLevel; impacts: MocImpacts; linkedDocs: string[];
  approvals: MocApproval[]; actions: MocAction[]; pssrItems?: PssrChecklistItem[];
}

export interface GapAssessment {
  id: string; unit: string; date: string; auditor: string;
  status: 'InProgress' | 'Finalized';
  scores: Record<string, unknown>; gaps: Gap[]; actions: GapActionPlan[];
}

export interface Gap {
  id: string; elementId: string; gapValue: number; criticalityScore: number;
  severity: 'Critical' | 'Major' | 'Minor'; category: 'System' | 'Compliance' | 'Competency' | 'Governance';
  description: string; status: 'Open' | 'Closed';
}

export interface GapActionPlan {
  id: string; gapId: string; task: string; assignee: string;
  dueDate: string; status: 'Open' | 'InProgress' | 'Done';
}

export interface ChemicalInfo {
  id: string; casNumber: string; nameFa: string; nameEn: string;
  physicalState: string; flashPoint: string; lel_uel: string;
  toxicity: { tlv: string; idlh: string; erpg2: string };
}

export interface ProcessEquipment {
  tag: string; name: string; type: string; unit: string;
  designPressure: string; designTemp: string; safeOperatingLimits: unknown[];
  service: string; safetyDevices?: string[];
}

export interface ProcessTechnology {
  id: string; unit: string; title: string; description: string; hazards: string[];
}

export interface KnowledgeAsset {
  id: string; title: string; category: string; revision: string;
  revisionDate: string; status: string; approvedBy: string;
  linkedUnit: string; fileUrl?: string;
}

export interface ExpertProfile { id: string; name: string; role: string; unit: string; }

export interface ProcedureStep {
  id: string; order: number; action: string;
  role: 'Board Operator' | 'Field Operator' | 'Supervisor';
  criticality: 'Routine' | 'Safety Critical' | 'Quality Critical';
  hazards: string[]; safeLimitRef: string; equipmentRef: string[];
}

export interface OperatingProcedure {
  id: string; code: string; title: string;
  type: 'Normal' | 'Startup' | 'Shutdown' | 'Emergency' | 'Temporary';
  unit: string; version: string; status: string; owner: string;
  nextReviewDate: string; lastReviewDate: string; steps: ProcedureStep[];
  linkedPsiIds: string[]; requiredCompetencies: string[];
}

export interface IsolationPoint {
  id: string; tag: string; description: string; method: string;
  status: 'Isolated' | 'De-Isolated'; verifiedBy?: string;
}

export interface GasTestRecord {
  id: string; time: string; oxygen: number; lel: number; h2s: number; co: number; tester: string;
}

export type PermitStatus = 'Draft' | 'Requested' | 'RiskAssessed' | 'Approved' | 'Active' | 'Suspended' | 'Closed';
export type PermitType = 'Hot Work' | 'Cold Work' | 'Confined Space' | 'Electrical' | 'Excavation' | 'Lifting';

export interface PermitToWork {
  id: string; type: PermitType; unit: string; location: string; description: string;
  createdAt: string; validFrom: string; validTo: string; requester: string; issuer: string;
  areaOwner: string; performingAuthority: string; status: PermitStatus; riskLevel: string;
  hazards: string[]; controls: string[]; ppe: string[]; isolations: IsolationPoint[];
  gasTests: GasTestRecord[]; isNonRoutine: boolean; mocId?: string;
}

export interface EmergencyResponseStep { id: string; order: number; role: string; action: string; isCritical: boolean; }

export interface EmergencyScenario {
  id: string; title: string; type: 'Fire' | 'Toxic' | 'Spill' | 'Utility' | 'Natural';
  unit: string; riskLevel: RiskLevel; triggerCondition: string;
  steps: EmergencyResponseStep[]; lastDrillDate?: string; erpDocumentId?: string;
}

export interface DrillRecord {
  id: string; scenarioId: string; date: string; type: 'Tabletop' | 'Field' | 'FullScale';
  duration: string; participants: number; score: number; gapsIdentified: string[];
  status: 'Planned' | 'Completed';
}

export interface EmergencyResource {
  id: string; name: string;
  category: 'FireFighting' | 'Medical' | 'Detection' | 'Communication' | 'PPE';
  location: string; status: 'Available' | 'Maintenance' | 'Out of Service';
  lastInspection: string; nextInspection: string; unit: string;
}

export interface CultureSurveyResult {
  id: string; date: string; unit: string; dimensionScores: Record<string, number>; participationRate: number;
}

export interface LeadershipVisit {
  id: string; date: string; leaderName: string; role: string; unit: string;
  focusArea: string; observations: string; positiveFindings: string; status: 'Completed';
}

export interface ProcessSafetyConcern {
  id: string; date: string; unit: string; category: string; description: string;
  status: 'Open' | 'Investigating' | 'Closed'; reporter: string;
}

export type StandardCategory = 'National (IPS/IGS)' | 'International (API/NFPA)' | 'Corporate' | 'Legal/HSE';

export interface StandardDef {
  id: string; code: string; title: string; category: StandardCategory;
  version: string; publicationDate: string; nextReviewDate: string;
  status: 'Current' | 'UnderReview' | 'Obsolete'; owner: string;
  applicability: string[]; description: string; file?: string;
}

export interface StandardRequirement {
  id: string; standardId: string; clauseNumber: string; description: string;
  priority: 'High' | 'Medium' | 'Low';
}

export interface ComplianceAuditRecord {
  id: string; requirementId: string; unit: string;
  status: 'Compliant' | 'NonCompliant' | 'NotApplicable';
  evidence?: string; gapId?: string; auditedBy: string; auditDate: string;
}

export type SkillLevel = 0 | 1 | 2 | 3 | 4;

export interface CompetencySkill {
  id: string; title: string; category: string; description: string; validityMonths: number;
}

export interface RoleProfile {
  id: string; title: string; department: string; isCritical: boolean;
  requiredSkills: { skillId: string; minLevel: number }[];
}

export interface EmployeeCompetencyRecord {
  skillId: string; currentLevel: number; lastAssessmentDate: string;
  nextReviewDate: string; status: 'Valid' | 'Expired' | 'Pending';
}
