// This component is suitable for React.lazy() code splitting
import React from 'react';

export function silFromPFD(pfdAvg: number): SILLevel { if (!isFinite(pfdAvg) || pfdAvg <= 0) return 'SIL 4'; if (pfdAvg <= 0.0001) return 'SIL 4'; if (pfdAvg <= 0.001) return 'SIL 3'; if (pfdAvg <= 0.01) return 'SIL 2'; if (pfdAvg <= 0.1) return 'SIL 1'; return 'بدون نیاز به SIL';

export function silFromRRF(rrf: number): SILLevel { if (!isFinite(rrf) || rrf >= 10000) return 'SIL 4'; if (rrf >= 1000) return 'SIL 3'; if (rrf >= 100) return 'SIL 2'; if (rrf >= 10) return 'SIL 1'; return 'بدون نیاز به SIL';
} export export interface LOPAIPLLike { pfd: number;

} export export interface SILScenarioResult { totalPFD: number; totalRRF: number; residualRisk: number; requiredRRF: number; gapMet: boolean; achievedSIL: SILLevel; requiredSIL: SILLevel;

export function calcScenarioSIL(input: SILScenarioInput): SILScenarioResult { const validPfds = input.ipls.map(i => (i.pfd > 0 && i.pfd <= 1 ? i.pfd : 1)); const totalPFD = validPfds.reduce((acc, pfd) => acc * pfd, 1); const totalRRF = totalPFD > 0 ? 1 / totalPFD : Infinity; const residualRisk = input.initiatingFrequency * totalPFD; const requiredRRF = input.targetRisk > 0 ? input.initiatingFrequency / input.targetRisk : Infinity; const gapMet = residualRisk <= input.targetRisk; return { totalPFD, totalRRF, residualRisk, requiredRRF, gapMet, achievedSIL: silFromPFD(totalPFD), requiredSIL: silFromRRF(requiredRRF), };
}
