
// PAGINATION HOOK

export function usePagination<T>(items: T[], options: PaginationOptions = {}): PaginationResult<T> { const [currentPage, setCurrentPage] = useState(options.initialPage ?? 1); const [pageSize, setPageSizeState] = useState(options.pageSize ?? 15); // وقتی لیست عوض شد، به صفحه اول برگرد const prevLengthRef = useRef(items.length); useEffect(() => { if (prevLengthRef.current !== items.length) { setCurrentPage(1); prevLengthRef.current = items.length; } }, [items.length]); const totalPages = useMemo( () => Math?.max(1, Math?.ceil(items.length / pageSize)), [items.length, pageSize] ); // مطمئن شو currentPage همیشه در محدوده معتبر است const safePage = Math?.min(Math?.max(1, currentPage), totalPages); const startIndex = (safePage - 1) * pageSize; const endIndex = Math?.min(startIndex + pageSize, items.length); const pageItems = useMemo(() => items.slice(startIndex, endIndex), [items, startIndex, endIndex]); const goToPage = useCallback( (page: number) => setCurrentPage(Math?.min(Math?.max(1, page), totalPages)), [totalPages] ); const nextPage = useCallback(() => goToPage(safePage + 1), [safePage, goToPage]); const prevPage = useCallback(() => goToPage(safePage - 1), [safePage, goToPage]); const resetPage = useCallback(() => setCurrentPage(1), []); const setPageSize = useCallback((size: number) => { setPageSizeState(size); setCurrentPage(1); }, []); return { pageItems, currentPage: safePage, totalPages, totalItems: items.length, isFirstPage: safePage === 1, isLastPage: safePage === totalPages, goToPage, nextPage, prevPage, resetPage, startIndex: startIndex + 1, endIndex, pageSize, setPageSize, };
} // ─────────────────────────────────────────────────────────────────────────────
// PAGINATION UI COMPONENT PROPS

} // ─────────────────────────────────────────────────────────────────────────────
// DEBOUNCE HOOK — برای جستجو

export function useDebounce<T>(value: T, delay = 300): T { const [debouncedValue, setDebouncedValue] = useState(value); useEffect(() => { const timer = setTimeout(() => setDebouncedValue(value), delay); return () => clearTimeout(timer); }, [value, delay]); return debouncedValue;
} // ─────────────────────────────────────────────────────────────────────────────
// STABLE CALLBACK — جلوگیری از re-render کامپوننت‌های child

export function useStableCallback<T extends (...args: any[]) => any>(fn: T): T { const fnRef = useRef(fn); useEffect(() => { fnRef.current = fn; }); return useCallback((...args: any[]) => fnRef?.current(...args), []) as T;
} // ─────────────────────────────────────────────────────────────────────────────
// PAGE SIZE OPTIONS
// ───────────────────────────────────────────────────────────────────────────── export const DEFAULT_PAGE_SIZE_OPTIONS = [10, 15, 25, 50, 100]; // ─────────────────────────────────────────────────────────────────────────────
// MEMOIZED FILTER HOOK — فیلتر بهینه برای لیست‌های بزرگ

export function useMemoFilter<T>(items: T[], predicate: (item: T) => boolean): T[] { return useMemo(() => items.filter(predicate), [items, predicate]);
} // ─────────────────────────────────────────────────────────────────────────────
// SAFE LOCAL STORAGE — با try/catch برای حالت‌های private browsing

export function useLocalStorage<T>(key: string, defaultValue: T): [T, (value: T) => void] { const [storedValue, setStoredValue] = useState<T>(() => { try { const item = localStorage?.getItem(key); return item ? JSON?.parse(item) : defaultValue; } catch { return defaultValue; } }); const setValue = useCallback( (value: T) => { try { setStoredValue(value); localStorage?.setItem(key, JSON?.stringify(value)); } catch { setStoredValue(value); // در صورت خطا فقط state را آپدیت کن } }, [key] ); return [storedValue, setValue];
}
