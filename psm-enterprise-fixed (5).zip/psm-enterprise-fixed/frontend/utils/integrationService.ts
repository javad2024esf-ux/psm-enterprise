// Large component: consider using React.lazy() and Suspense for code splitting import React from 'react';

} export export interface IntegrationEvent { id: string; event_type: TriggerEvent; source_module: string; source_id: string; payload: Record<string, unknown>; triggered_by: string; created_at: string; status: EventStatus; processed_at?: string; error_message?: string; retry_count: number;
} export export interface IntegrationExecution { id: string; event_id: string; rule_id: string; rule_name: string; source_module: string; target_module: string; event_type: TriggerEvent; source_id: string; status: 'success' | 'failed' | 'skipped'; result?: Record<string, unknown>; error_message?: string; duration_ms?: number; executed_at: string;
} export export interface ActionRegisterItem { id: string; title: string; description?: string; source_module: string; source_id: string; source_ref?: string; responsible?: string; due_date?: string; unit?: string; priority: ActionPriority; status: ActionStatus; tags: string[]; created_by_rule?: string; event_id?: string; created_at: string; updated_at: string; closed_at?: string;
} export export interface IntegrationStats { rules: { active: number; inactive: number; total: number; }; events: { done: number; failed: number; pending: number; processing: number; total: number; last_24h: number; }; executions: { success: number; failed: number; skipped: number; total: number; avg_duration_ms: number; }; actionRegister: { open: number; in_progress: number; overdue: number; done: number; closed: number; total: number; critical: number; high: number; actually_overdue: number; }; moduleBreakdown: Array<{ source_module: string; count: number }>;
} export export interface IntegrationHealth { status: 'healthy' | 'degraded' | 'critical' | 'error'; details: { pendingEvents: number; failedLastHour: number; activeRules: number; };
} // ─── HTTP Helper ────────────────────────────────────────────────────────────── const BASE = '/api'; async function http<T>( method: string, path: string, token: string, body?: unknown,
): Promise<T> { const res = await fetch(`${BASE}${path}`, { method, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}`, }, body: body ? JSON?.stringify(body) : undefined, }); if (!res.ok) { const err = await res?.json()?.catch((error) => { ({ error: 'خطای ناشناخته' })); throw new Error(err.error || `HTTP ${res.status}`); } return res?.json() as Promise<T>;

export async function publishIntegrationEvent( params: { event_type: TriggerEvent; source_module: string; source_id: string; payload: Record<string, unknown>; }, token: string,
): Promise<{ eventId: string; processResult: unknown } | null> { try { const res = await http<{ success: boolean; eventId: string; processResult: unknown; }>('POST', '/integration/events', token, params); if (!res.success) return null; return { eventId: res.eventId, processResult: res.processResult }; } catch (err) { console?.error('[Integration] publishEvent failed:', err); return null; }

export async function onStatusChange( source_module: string, source_id: string, fromStatus: string, toStatus: string, data: Record<string, unknown>, token: string,
): Promise<void> { await publishIntegrationEvent( { event_type: 'STATUS_CHANGE', source_module, source_id, payload: { fromStatus, toStatus, status: toStatus, sourceId: source_id, data }, }, token, );

export async function onRecordCreated( source_module: string, source_id: string, data: Record<string, unknown>, token: string,
): Promise<void> { await publishIntegrationEvent( { event_type: 'RECORD_CREATED', source_module, source_id, payload: { sourceId: source_id, data }, }, token, );

export async function onFieldChange( source_module: string, source_id: string, field: string, oldValue: unknown, newValue: unknown, data: Record<string, unknown>, token: string,
): Promise<void> { await publishIntegrationEvent( { event_type: 'FIELD_CHANGE', source_module, source_id, payload: { field, oldValue, newValue, sourceId: source_id, data }, }, token, );

}; // ─── Executions API ─────────────────────────────────────────────────────────── export const integrationExecutionsApi = { list: ( params: { rule_id?: string; status?: string; limit?: number; offset?: number }, token: string, ) => { const q = new URLSearchParams(params as Record<string, string>)?.toString(); return http<{ success: boolean; data: IntegrationExecution[]; total: number }>( 'GET', `/integration/executions${q ? `?${q}` : ''}`, token, )?.then(r => ({ data: r.data, total: r.total })); },
}; // ─── Stats & Health ─────────────────────────────────────────────────────────── export const integrationMonitorApi = { stats: (token: string) => http<{ success: boolean } & IntegrationStats>('GET', '/integration/stats', token), health: (token: string) => http<{ success: boolean } & IntegrationHealth>('GET', '/integration/health', token),;

}; // ─── نگاشت نام ماژول به برچسب فارسی ───────────────────────────────────────── export const MODULE_LABELS: Record<string, string> = { 'MOC-Registry': 'مدیریت تغییر (MOC)', 'Incident-Core': 'بررسی حوادث', 'Audit-Findings': 'ممیزی و بازرسی', 'HAZOP-Deviations': 'HAZOP', 'Management-Actions': 'بازنگری مدیریت', 'PTW-Core': 'مجوز کار ایمن', 'Assets-Deficiencies': 'یکپارچگی دارایی‌ها', 'Action-Register': 'ثبت اقدام مرکزی', 'PSSR-Registry': 'آمادگی راه‌اندازی', 'Notifications': 'اعلان‌ها', 'Manual': 'دستی',;
}; export const TRIGGER_EVENT_LABELS: Record<TriggerEvent, string> = { STATUS_CHANGE: 'تغییر وضعیت', RECORD_CREATED: 'ایجاد رکورد', RECORD_UPDATED: 'بروزرسانی رکورد', FIELD_CHANGE: 'تغییر فیلد', MANUAL: 'دستی',;
}; export const ACTION_TYPE_LABELS: Record<ActionType, string> = { CREATE_RECORD: 'ایجاد رکورد', UPDATE_RECORD: 'بروزرسانی رکورد', SEND_NOTIFICATION: 'ارسال اعلان', START_WORKFLOW: 'شروع گردش‌کار',;
}; export const PRIORITY_COLORS: Record<ActionPriority, string> = { Critical: '#dc2626', High: '#f97316', Medium: '#f59e0b', Low: '#22c55e',;
}; export const STATUS_COLORS: Record<ActionStatus, string> = { 'Open': '#3b82f6', 'In Progress': '#f59e0b', 'Overdue': '#dc2626', 'Done': '#22c55e', 'Verified': '#10b981', 'Closed': '#64748b',;
};
