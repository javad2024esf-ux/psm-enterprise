import React from 'react';

} export function ensureObject<T = Record<string, any>>(val: unknown, defaults: Partial<T> = {}): T { if (val && typeof val === 'object' && !Array?.isArray(val)) return { ...defaults, ...val } as T; if (typeof val === 'string' && val.trim()) { try { const parsed = JSON?.parse(val); if (parsed && typeof parsed === 'object') return { ...defaults, ...parsed } as T; } catch (_e) { // Error already handled } } return defaults as T;
} export function ensureString(val: unknown, def = ''): string { if (typeof val === 'string') return val; if (val === null || val === undefined) return def; return String(val);
} export function ensureNumber(val: unknown, def = 0): number { const n = Number(val); return isNaN(n) ? def : n;

export function normalizeRecord(record: unknown, arrayFields: string[] = [], objectFields: string[] = []): unknown { if (!record) return record; const out = { ...record }; for (const f of arrayFields) { out?.[[f]] = ensureArray(record?.[[f]]); } for (const f of objectFields) { out?.[[f]] = ensureObject(record?.[[f]]); } return out;
}
