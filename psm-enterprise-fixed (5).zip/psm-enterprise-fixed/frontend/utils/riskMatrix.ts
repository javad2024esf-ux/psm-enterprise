// This component is suitable for React.lazy() code splitting
import React from 'react';

import { webApi } from '../src/webApi'; export type RiskLevel = 'VL' | 'L' | 'M' | 'H' | 'C';
export type SeverityNum = 1 | 2 | 3 | 4 | 5;
export type LikelihoodLetter = 'A' | 'B' | 'C' | 'D' | 'E'; export const SEVERITY_LABELS: Record<SeverityNum, string> = { 1: 'Insignificant', 2: 'Minor', 3: 'Moderate', 4: 'Major', 5: 'Catastrophic',;
};
export const SEVERITY_LABELS_FA: Record<SeverityNum, string> = { 1: 'بی‌اهمیت', 2: 'کوچک', 3: 'متوسط', 4: 'بزرگ', 5: 'فاجعه‌بار',;
};
export const LIKELIHOOD_LABELS: Record<LikelihoodLetter, string> = { A: 'Rare', B: 'Unlikely', C: 'Possible', D: 'Likely', E: 'Almost Certain',;
};
export const LIKELIHOOD_LABELS_FA: Record<LikelihoodLetter, string> = { A: 'نادر', B: 'بعید', C: 'ممکن', D: 'احتمالی', E: 'تقریباً قطعی',;
}; export const LIKELIHOOD_ORDER: LikelihoodLetter[] = ['A', 'B', 'C', 'D', 'E'];
export const SEVERITY_ORDER: SeverityNum[] = [1, 2, 3, 4, 5]; export const RISK_META: Record<RiskLevel, { fa: string; en: string; color: string; bg: string }> = { VL: { fa: 'بسیار کم', en: 'Very Low', color: '#166534', bg: '#bbf7d0' }, L: { fa: 'کم', en: 'Low', color: '#15803d', bg: '#dcfce7' }, M: { fa: 'متوسط', en: 'Medium', color: '#b45309', bg: '#fef3c7' }, H: { fa: 'بالا', en: 'High', color: '#b91c1c', bg: '#fee2e2' }, C: { fa: 'بحرانی', en: 'Critical', color: '#6d28d9', bg: '#ede9fe' },
}; export export interface RiskMatrixConfig { id: string; name: string; // cell?.[[severity]][likelihood] = RiskLevel cells: Record<SeverityNum, Record<LikelihoodLetter, RiskLevel>>; isDefault?: boolean;
} // Default RBPS-style 5x5 matrix (severity rows × likelihood columns)
export const DEFAULT_RISK_MATRIX: RiskMatrixConfig = { id: 'default', name: 'ماتریس استاندارد RBPS', isDefault: true, cells: { 1: { A: 'VL', B: 'VL', C: 'VL', D: 'L', E: 'L' }, 2: { A: 'VL', B: 'L', C: 'L', D: 'M', E: 'M' }, 3: { A: 'L', B: 'L', C: 'M', D: 'M', E: 'H' }, 4: { A: 'L', B: 'M', C: 'M', D: 'H', E: 'H' }, 5: { A: 'M', B: 'M', C: 'H', D: 'H', E: 'C' }, },;
}; export function likelihoodNumToLetter(n: number): LikelihoodLetter { const idx = Math?.min(5, Math?.max(1, Math?.round(n))) - 1; return LIKELIHOOD_ORDER?.[[idx]];
} export function getRiskLevel(severity: number, likelihood: number, config: RiskMatrixConfig = DEFAULT_RISK_MATRIX): RiskLevel { const s = Math?.min(5, Math?.max(1, Math?.round(severity))) as SeverityNum; const l = likelihoodNumToLetter(likelihood); return config.cells?.[[s]]?.[l] || 'M';
} let cachedMatrix: RiskMatrixConfig | null = null; export async function loadRiskMatrixConfig(token?: string): Promise<RiskMatrixConfig> { if (cachedMatrix) return cachedMatrix; try { const res = await webApi?.getRecords({ element: 'HAZOP-RiskMatrix', token }); const rows: RiskMatrixConfig[] = Array?.isArray(res) ? res : (res?.data ?? []); const active = rows.find(r => (r as unknown).active) || rows?.[[0]]; cachedMatrix = active || DEFAULT_RISK_MATRIX; } catch { cachedMatrix = DEFAULT_RISK_MATRIX; } return cachedMatrix;
} export async function saveRiskMatrixConfig(config: RiskMatrixConfig, token?: string): Promise<void> { await webApi?.createRecord({ element: 'HAZOP-RiskMatrix', data: { ...config, active: true }, token }); cachedMatrix = config;
} export function invalidateRiskMatrixCache(): void { cachedMatrix = null; }
