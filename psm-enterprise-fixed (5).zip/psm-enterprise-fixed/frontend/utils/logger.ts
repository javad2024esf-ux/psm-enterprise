// This component is suitable for React.lazy() code splitting
import React from 'react';
import { webApi } from '../src/webApi';

} const isDev = (): boolean => { try { return ( (import.meta as unknown).env?.DEV === true || (import.meta as unknown).env?.MODE === 'development' ); } catch { return false; }
}; async function sendToBackend(entry: LogEntry): Promise<void> { try { if (typeof window?.api?.logError !== 'function') return; await webApi?.logError(entry); } catch { // Silent fail — logger نباید exception بدهد }

}; export default Logger; // Named export برای سازگاری با imports قدیمی
export { Logger };
export const logger = Logger;
