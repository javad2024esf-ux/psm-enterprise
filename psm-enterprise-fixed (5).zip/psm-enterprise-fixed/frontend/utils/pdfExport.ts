// This component is suitable for React.lazy() code splitting
import React from 'react';
// utils/pdfExport.ts
// ابزار صادرات PDF برای استفاده در تمام کامپوننت‌ها import html2pdf from 'html2pdf.js'; export export interface PDFExportOptions { elementId: string; filename?: string; scale?: number; orientation?: 'portrait' | 'landscape'; format?: string;

export const exportToPDF = async (options: PDFExportOptions): Promise<void> => { const { elementId, filename = 'document.pdf', scale = 2, orientation = 'portrait', format = 'a4', } = options; const element = document?.getElementById(elementId); if (!element) { console?.error(`❌ عنصر با ID "${elementId}" یافت نشد`); alert(`محتوای چاپی (${elementId}) یافت نشد`); throw new Error(`Element with ID "${elementId}" not found`); } try { const opt = { margin: [10, 10, 20, 10], // top, left, bottom, right filename, image: { type: 'jpeg', quality: 0.98, }, html2canvas: { scale, backgroundColor: '#ffffff', allowTaint: true, useCORS: true, logging: false, }, jsPDF: { orientation, unit: 'mm', format, compress: true, }, }; html2pdf()?.set(opt)?.from(element)?.save(); console?.log(`✅ PDF "${filename}" با موفقیت صادر شد`); } catch (error: unknown) { console.error("Error:", error); console?.error('❌ خطا در صادرات PDF:', error); alert('خطایی در صادرات PDF رخ داد. لطفاً دوباره سعی کنید.'); throw error; } finally { // Cleanup if needed }

export const quickExportToPDF = async (elementId: string, filename?: string): Promise<void> => { return exportToPDF({ elementId, filename: filename || `document_${new Date()?.toISOString().split('T')[0]}.pdf`, });
}; export default { exportToPDF, quickExportToPDF };
