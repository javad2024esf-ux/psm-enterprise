// This component is suitable for React.lazy() code splitting

import { PermitRecord, GasTest, PermitStatus, ApprovalRole } from '../types/permit.types';
import { normalizePermit } from '../utils/permit.utils';
import { webApi } from '../../../src/webApi'; export interface UsePermitReturn { permits: PermitRecord[]; loading: boolean; error: string | null; fetchPermits: () => Promise<void>; addPermit: (permit: PermitRecord) => Promise<void>; updatePermit: (id: string, updates: Partial<PermitRecord>) => Promise<void>; deletePermit: (id: string) => Promise<void>; updateStatus: (id: string, status: PermitStatus) => Promise<void>; addGasTest: (id: string, test: GasTest) => Promise<void>; approvePermit: (id: string, role: ApprovalRole, name: string, approved: boolean) => Promise<void>;

};
