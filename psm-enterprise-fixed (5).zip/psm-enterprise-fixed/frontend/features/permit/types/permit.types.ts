// This component is suitable for React.lazy() code splitting

export type PermitStatus = 'draft' | 'pending' | 'gas_test' | 'safety_review' | 'active' | 'suspended' | 'closed' | 'expired' | 'rejected';
export type CheckAnswer = 'yes' | 'no' | 'na' | null;
export type ApprovalRole = 'requester' | 'facility_manager' | 'safety_officer'; export export interface ChecklistItem { id: string; text: string;
} export export interface GasTest { id: string; time: string; o2: number; lel: number; ppm: number; tester: string; note?: string;
} export export interface Approval { role: ApprovalRole; name: string; date?: string; status: 'pending' | 'approved' | 'rejected'; note?: string;
} export export interface PermitRecord { id: string; permitNo: string; type: PermitType; unit: ProcessUnit; cmmsNo?: string; equipmentName?: string; location: string; description: string; status: PermitStatus; requestor: string; supervisor?: string; validFrom: string; validTo: string; shiftType: 'daily' | 'maintenance'; startTime?: string; endTime?: string; hazards?: string; precautions?: string; envConditions: { flammable: boolean; toxic: boolean; corrosive: boolean; electric: boolean; pressure: boolean; hot: boolean; }; checklist: Record<string, CheckAnswer>; ppeList: string[]; gasTests: GasTest[]; approvals: Approval[]; // radiography specific radioSourceType?: string; radioSourceNo?: string; radioPower?: string; radioSerial?: string; radioSafeDistance?: string; notes?: string; createdAt: string; updatedAt: string;
} export export interface PermitTypeConfig { label: string; labelEn: string; emoji: string; formCode: string; color: string; glow: string; darkBg: string; darkBorder: string; icon: React.ReactNode;
} export export interface PermitStatusConfig { label: string; color: string; bg: string; border: string; step: number;
} export export interface GasTestResult { label: string; color: string;
} export export interface FilterState { searchTerm: string; typeFilter: PermitType | ''; statusFilter: PermitStatus | ''; requestorFilter: string;
} export export interface ViewMode { mode: 'grid' | 'table';
}
