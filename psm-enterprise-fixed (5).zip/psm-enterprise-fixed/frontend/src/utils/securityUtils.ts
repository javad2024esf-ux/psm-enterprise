// This component is suitable for React.lazy() code splitting
import React from 'react';

