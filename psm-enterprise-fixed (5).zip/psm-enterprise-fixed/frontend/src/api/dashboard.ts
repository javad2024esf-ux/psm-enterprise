export interface LopaKpis { total_analyses: number; }
export const getDashboard = async (_token: string) => ({});
