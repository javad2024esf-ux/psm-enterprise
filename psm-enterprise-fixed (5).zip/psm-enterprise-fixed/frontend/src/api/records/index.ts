export async function addRecord(_opts: { element: string; data: unknown; token?: string }) { return {}; }
export async function getRecords(_opts: { element: string; token?: string }) { return []; }
export async function updateRecord(_opts: { element: string; id: string; data: unknown; token?: string }) { return {}; }
export async function deleteRecord(_opts: { element: string; id: string; token?: string }) { return; }
