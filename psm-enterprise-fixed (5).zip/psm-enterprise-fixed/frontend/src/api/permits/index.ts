export interface PermitListItem { id: string; }
export interface PermitDetail extends PermitListItem { tenant?: string; }
