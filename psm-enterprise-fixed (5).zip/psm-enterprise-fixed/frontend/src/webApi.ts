const TOKEN_KEY = 'psm_auth_token';

function getToken(): string {
  return sessionStorage?.getItem(TOKEN_KEY) || localStorage?.getItem(TOKEN_KEY) || '';
}

function setToken(token: string): void {
  sessionStorage?.setItem(TOKEN_KEY, token);
}

function clearToken(): void {
  sessionStorage?.removeItem(TOKEN_KEY);
  localStorage?.removeItem(TOKEN_KEY);
}

function sanitizeInput(input: string): string {
  if (!input) return '';
  return input.replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g, '').trim().substring(0, 10000);
}

async function req<T = unknown>(
  method: string, path: string, body?: unknown, token?: string
): Promise<T> {
  const tk = token ?? getToken();
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (tk) { headers['Authorization'] = `Bearer ${tk}`; }
  const res = await fetch(path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  if (!res.ok) {
    const errText = await res.text().catch(() => res.statusText);
    throw new Error(errText || `HTTP ${res.status}`);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

const get = (path: string, token?: string) => req('GET', path, undefined, token);
const post = (path: string, body: unknown, token?: string) => req('POST', path, body, token);
const patch = (path: string, body: unknown, token?: string) => req('PATCH', path, body, token);
const del = (path: string, token?: string) => req('DELETE', path, undefined, token);

async function getRecords({ element, token, filter }: { element: string; token?: string; filter?: Record<string, unknown> }) {
  const params = new URLSearchParams({ collection: element });
  if (filter) { Object.entries(filter).forEach(([k, v]) => { if (v !== undefined) params.set(k, String(v)); }); }
  return get(`/api/records?${params.toString()}`, token);
}

async function addRecord({ element, data, token }: { element: string; data: unknown; token?: string }) {
  return post('/api/records', { collection: element, data: sanitizeInput ? data : data }, token);
}

async function updateRecord({ element, id, data, token }: { element: string; id: string; data: unknown; token?: string }) {
  return patch(`/api/records/${id}?collection=${element}`, data, token);
}

async function deleteRecord({ element, id, token }: { element: string; id: string; token?: string }) {
  return del(`/api/records/${id}?collection=${element}`, token);
}

async function getNotifications(token: string, _includeRead: boolean) {
  try { return await get('/api/notifications', token) as unknown[]; } catch { return []; }
}

async function getCompanyConfig(token: string) {
  try { return await get('/api/company/config', token) as { companyName?: string; disabledModules?: string[] }; }
  catch { return {}; }
}

async function updateCompanyConfig(token: string, data: unknown) {
  return post('/api/company/config', data, token);
}

async function getCompany(token: string) {
  try { return await get('/api/company', token); } catch { return null; }
}

async function getLicense(token: string) {
  try { return await get('/api/license', token); } catch { return null; }
}

async function activateLicense(token: string, key: string) {
  return post('/api/license/activate', { key }, token);
}

async function getAISettings(token: string) {
  try { return await get('/api/ai/settings', token); } catch { return null; }
}

async function updateAISettings(token: string, data: unknown) {
  return post('/api/ai/settings', data, token);
}

async function aiComplete(token: string, prompt: string, context?: string) {
  return post('/api/ai/complete', { prompt, context }, token);
}

export const webApi = {
  getRecords, addRecord, updateRecord, deleteRecord,
  getNotifications, getCompanyConfig, updateCompanyConfig,
  getCompany, getLicense, activateLicense,
  getAISettings, updateAISettings, aiComplete,
  setToken, clearToken, getToken,
};
