import { useState, useEffect, useCallback } from 'react';
import { webApi } from '../webApi';

export interface LicenseInfo { isValid: boolean; expiresAt?: string; maxUsers?: number; }
export interface UseLicenseReturn { license: LicenseInfo | null; loading: boolean; activate: (key: string) => Promise<boolean>; }

export function useLicense(): UseLicenseReturn {
  const [license, setLicense] = useState<LicenseInfo | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    const token = localStorage.getItem('psm_auth_token') ?? '';
    webApi.getLicense(token).then(l => {
      setLicense(l as LicenseInfo ?? { isValid: true });
      setLoading(false);
    }).catch(() => { setLicense({ isValid: true }); setLoading(false); });
  }, []);

  const activate = useCallback(async (key: string): Promise<boolean> => {
    const token = localStorage.getItem('psm_auth_token') ?? '';
    try {
      await webApi.activateLicense(token, key);
      setLicense({ isValid: true });
      return true;
    } catch { return false; }
  }, []);

  return { license, loading, activate };
}
