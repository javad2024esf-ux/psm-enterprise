import { useState, useEffect, useCallback } from 'react';
import { webApi } from '../webApi';

export interface Notification {
  id: string | number;
  title: string;
  desc: string;
  time: string;
  type: 'Alert' | 'Task' | 'Warning' | 'Info';
  read: boolean;
}

export interface UseNotificationsResult {
  notifications: Notification[];
  unreadCount: number;
  markAsRead: (id: string | number) => void;
  markAllAsRead: () => void;
  reload: () => void;
}

export function useNotifications(token: string | null, isLoggedIn: boolean): UseNotificationsResult {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const load = useCallback(async () => {
    if (!isLoggedIn || !token) return;
    try {
      const backendNotifs = (await (webApi as Record<string, ((token: string, flag: boolean) => Promise<unknown[]>) | undefined>)?.getNotifications?.(token, false)) ?? [];
      if (Array.isArray(backendNotifs) && backendNotifs.length > 0) {
        setNotifications(
          backendNotifs.map((n: unknown) => {
            const item = n as Record<string, unknown>;
            return {
              id: item.id as string,
              title: item.title as string,
              desc: item.description as string,
              time: typeof item.createdAt === 'string' ? item.createdAt.slice(0, 10) : '',
              type: (item.type as Notification['type']) ?? 'Info',
              read: !!item.isRead,
            };
          })
        );
        return;
      }

      const api = webApi as Record<string, ((opts: { element: string; token: string }) => Promise<unknown[]>) | undefined>;
      const [mocs, incidents, auditNCs, permits] = await Promise.all([
        api?.getRecords?.({ element: 'MOC-Registry', token }),
        api?.getRecords?.({ element: 'Incident-Core', token }),
        api?.getRecords?.({ element: 'Audit-NC', token }),
        api?.getRecords?.({ element: 'PTW-Core', token }),
      ]);

      const notifs: Notification[] = [];

      ((mocs ?? []) as Record<string, unknown>[])
        .filter(m => ['Technical_Review', 'HSE_Review'].includes(m.status as string))
        .slice(0, 3)
        .forEach(m => notifs.push({ id: m.id as string, title: 'MOC در انتظار تایید', desc: m.title as string, time: typeof m.createdAt === 'string' ? m.createdAt.slice(0, 10) : '', type: 'Task', read: false }));

      ((incidents ?? []) as Record<string, unknown>[])
        .filter(i => i.status !== 'Closed')
        .slice(0, 3)
        .forEach(i => notifs.push({ id: i.id as string, title: 'حادثه باز: ' + i.type, desc: i.title as string, time: i.date as string ?? '', type: 'Alert', read: false }));

      ((auditNCs ?? []) as Record<string, unknown>[])
        .filter(n => n.status !== 'Closed')
        .slice(0, 2)
        .forEach(n => notifs.push({ id: n.id as string, title: 'عدم انطباق باز', desc: n.description as string ?? '', time: typeof n.createdAt === 'string' ? n.createdAt.slice(0, 10) : '', type: 'Warning', read: true }));

      ((permits ?? []) as Record<string, unknown>[])
        .filter(p => p.status === 'Active')
        .slice(0, 2)
        .forEach(p => notifs.push({ id: p.id as string, title: 'مجوز کار فعال', desc: (p.description as string) ?? (p.location as string) ?? '', time: p.validFrom as string ?? '', type: 'Info', read: true }));

      setNotifications(
        notifs.length > 0
          ? notifs
          : [{ id: 0, title: 'خوش آمدید', desc: 'هیچ موردی در انتظار اقدام نیست.', time: '', type: 'Info', read: true }]
      );
    } catch (err) {
      console.error('[useNotifications] Failed:', err);
    }
  }, [token, isLoggedIn]);

  useEffect(() => { load(); }, [load]);

  const markAsRead = useCallback((id: string | number) => {
    setNotifications(prev => prev.map(n => (n.id === id ? { ...n, read: true } : n)));
  }, []);

  const markAllAsRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  }, []);

  const unreadCount = notifications.filter(n => !n.read).length;

  return { notifications, unreadCount, markAsRead, markAllAsRead, reload: load };
}
