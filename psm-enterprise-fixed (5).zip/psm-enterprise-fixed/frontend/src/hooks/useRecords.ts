import { useState, useEffect, useCallback } from 'react';
import { webApi } from '../webApi';

export function useRecords<T = unknown>(element: string, token?: string) {
  const [records, setRecords] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);
  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const res = await webApi.getRecords({ element, token });
      setRecords((Array.isArray(res) ? res : []) as T[]);
    } catch { setRecords([]); }
    setLoading(false);
  }, [element, token]);
  useEffect(() => { reload(); }, [reload]);
  return { records, loading, reload };
}
