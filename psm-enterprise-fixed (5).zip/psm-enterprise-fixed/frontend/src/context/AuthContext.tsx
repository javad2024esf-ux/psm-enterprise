import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode, FC } from 'react';

const PAGE_TO_MODULE: Record<string, string> = {
  'MOC-Registry': 'MOC', 'MOC-Actions': 'MOC', 'MOC-Approvals': 'MOC',
  'Incident-Core': 'INCIDENT', 'Incident-Actions': 'INCIDENT', 'Incident-Timeline': 'INCIDENT',
  'PTW-Core': 'SAFE_WORK', 'PTW-Isolations': 'SAFE_WORK', 'PTW-GasTests': 'SAFE_WORK',
  'PTW-StopWork': 'SAFE_WORK', 'PTW-Bypasses': 'SAFE_WORK',
  'PSSR-Registry': 'READINESS', 'PSSR-Checklist': 'READINESS', 'PSSR-Deficiencies': 'READINESS',
  'HAZOP-Studies': 'HAZOP', 'HAZOP-Nodes': 'HAZOP', 'HAZOP-Deviations': 'HAZOP',
  'HAZOP-BowTie': 'HAZOP', 'HAZOP-LOPA': 'HAZOP', 'HAZOP-Team': 'HAZOP',
  'HAZOP-RiskMatrix': 'HAZOP', 'HAZOP-Recommendations': 'HAZOP', 'HAZOP-Equipment-Registry': 'HAZOP',
  'HIRA-Studies': 'HIRA', 'HIRA-HazopNodes': 'HIRA', 'HIRA-HazopDeviations': 'HIRA',
  'HIRA-Assessments': 'HIRA', 'HIRA-Activities': 'HIRA', 'HIRA-Hazards': 'HIRA',
  'PSI-Chemicals': 'KNOWLEDGE', 'PSI-Equipment': 'KNOWLEDGE', 'PSI-Technology': 'KNOWLEDGE',
  'PSI-KnowledgeAssets': 'KNOWLEDGE', 'Knowledge-Assets': 'KNOWLEDGE',
  'Assets-Registry': 'ASSET_INTEGRITY', 'Assets-Inspections': 'ASSET_INTEGRITY',
  'Assets-RBI': 'ASSET_INTEGRITY', 'Assets-Deficiencies': 'ASSET_INTEGRITY', 'Assets-Maintenance': 'ASSET_INTEGRITY',
  'SOP-Library': 'PROCEDURES', 'SOP-Procedures': 'PROCEDURES', 'SOP-Steps': 'PROCEDURES', 'Operating-Procedures': 'PROCEDURES',
  'Training-Courses': 'TRAINING', 'Training-Sessions': 'TRAINING', 'Training-Records': 'TRAINING',
  'Training-Employees': 'TRAINING', 'Training-Programs': 'TRAINING',
  'Audit-Program': 'AUDIT', 'Audit-NC': 'AUDIT', 'Audit-Checklist': 'AUDIT', 'Audit-Findings': 'AUDIT',
  'Contractor-Companies': 'CONTRACTOR', 'Contractor-Workers': 'CONTRACTOR',
  'Contractor-Audits': 'CONTRACTOR', 'Contractor-Permits': 'CONTRACTOR',
  'Stakeholders-DB': 'STAKEHOLDER', 'Stakeholder-Interactions': 'STAKEHOLDER',
  'Culture-Walks': 'CULTURE', 'Culture-BBS': 'CULTURE', 'Culture-Surveys': 'CULTURE',
  'Workforce-Participation': 'WORKFORCE', 'Workforce-Committees': 'WORKFORCE',
  'Workforce-SWA': 'WORKFORCE', 'Workforce-Campaigns': 'WORKFORCE',
  'Standards-Library': 'STANDARDS', 'Standards-Gaps': 'STANDARDS', 'Standards-Compliance': 'STANDARDS',
  'Competency-Skills': 'COMPETENCY', 'Competency-Profiles': 'COMPETENCY', 'Competency-Assessments': 'COMPETENCY',
  'ERP-Scenarios': 'EMERGENCY', 'ERP-Drills': 'EMERGENCY', 'ERP-Resources': 'EMERGENCY',
  'ERP-ICS': 'EMERGENCY', 'ERP-MutualAid': 'EMERGENCY',
  'ConductOps-Observations': 'CONDUCT_OPS', 'ConductOps-IOW': 'CONDUCT_OPS',
  'ConductOps-Bypasses': 'CONDUCT_OPS', 'ConductOps-Handovers': 'CONDUCT_OPS',
  'ConductOps-Handover': 'CONDUCT_OPS', 'ConductOps-Logs': 'CONDUCT_OPS', 'ConductOps-Walkdown': 'CONDUCT_OPS',
  'TradeSecret-Docs': 'KNOWLEDGE', 'TradeSecret-NDAs': 'KNOWLEDGE',
  'TradeSecret-Requests': 'KNOWLEDGE', 'TradeSecret-Logs': 'KNOWLEDGE',
  'Management-Reviews': 'MANAGEMENT_REVIEW', 'Management-Actions': 'MANAGEMENT_REVIEW', 'MgmtReview-Sessions': 'MANAGEMENT_REVIEW',
  'Metrics-KPI': 'METRICS', 'Metrics-History': 'METRICS',
  'Gap-Assessments': 'GAP_ANALYSIS', 'Gap-Actions': 'GAP_ANALYSIS',
  'Action-Register': 'ACTION_REGISTER', 'Notifications': 'NOTIFICATIONS',
  'AuditLog': 'AUDIT_LOG', 'documents': 'DOCUMENTS', 'USERS': 'USERS', 'WORKFLOW': 'WORKFLOW', 'LOPA': 'LOPA',
};

export interface AuthUser {
  id: string; username: string; fullName: string; email: string; role: string;
  department: string; unit: string; status: string; lastLogin: string | null;
  mustChangePassword: boolean;
}

export type PermissionAction = 'read' | 'write' | 'approve' | 'delete';

export interface AuthContextValue {
  user: AuthUser | null; token: string | null;
  permissions: Record<string, Record<PermissionAction, number>> | null;
  isLoading: boolean; isLoggedIn: boolean;
  login: (username: string, password: string) => Promise<{ success: boolean; error?: string; user?: AuthUser; token?: string }>;
  logout: () => void;
  can: (collection: string, _action: PermissionAction) => boolean;
  isAdmin: boolean; isPSMManager: boolean; isHSEManager: boolean;
  isUnitHead: boolean; isSupervisor: boolean; isOperator: boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);
const TOKEN_KEY = 'psm_auth_token';

export const AuthProvider: FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [permissions, setPermissions] = useState<Record<string, Record<string, number>> | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const restore = async () => {
      const saved = localStorage.getItem(TOKEN_KEY);
      if (!saved) { setIsLoading(false); return; }
      try {
        const res = await fetch('/api/auth/me', { headers: { Authorization: `Bearer ${saved}` } })
          .then(r => r.ok ? r.json() : null).catch(() => null);
        if (res?.success && res.user) {
          setToken(saved); setUser(res.user); setPermissions(res.permissions ?? null);
        } else { localStorage.removeItem(TOKEN_KEY); }
      } catch { localStorage.removeItem(TOKEN_KEY); }
      finally { setIsLoading(false); }
    };
    restore();
  }, []);

  const login = useCallback(async (username: string, password: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      }).then(r => r.json()).catch((e) => { console.error('[auth/login] failed:', e); return null; });
      if (res === null) return { success: false, error: 'خطای اتصال به سیستم — بک‌اند در دسترس نیست' };
      if (res?.success && res.token) {
        localStorage.setItem(TOKEN_KEY, res.token);
        setToken(res.token); setUser(res.user ?? null);
        const me = await fetch('/api/auth/me', { headers: { Authorization: `Bearer ${res.token}` } })
          .then(r => r.ok ? r.json() : null).catch(() => null);
        if (me?.success) {
          setPermissions(me.permissions ?? null);
          if (me.user) setUser(me.user);
        }
        return { success: true, user: res.user ?? null, token: res.token };
      }
      return { success: false, error: res?.error ?? 'خطای ورود' };
    } catch { return { success: false, error: 'خطای اتصال به سیستم' }; }
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY); setToken(null); setUser(null); setPermissions(null);
  }, []);

  const can = useCallback((collection: string, _action: PermissionAction): boolean => {
    if (!user) return false;
    if (user.role === 'Admin') return true;
    if (!permissions) return false;
    const mapped = PAGE_TO_MODULE[collection] || null;
    const moduleKey = (mapped || collection).toUpperCase().replace(/-/g, '_');
    const permsAny = permissions as unknown as Record<string, Record<string, number> | Record<string, Record<string, number>>>;
    const modulesMap = permsAny['__modules__'] as Record<string, Record<string, number>> | undefined;
    if (modulesMap) {
      const perm = modulesMap[moduleKey];
      if (perm !== undefined) return !!perm[_action];
      return false;
    }
    const perms = permsAny[collection] ?? permsAny['__default__'];
    if (!perms) return false;
    return !!(perms as Record<string, number>)[_action];
  }, [user, permissions]);

  const role = user?.role ?? '';
  const value: AuthContextValue = {
    user, token, permissions: permissions as Record<string, Record<PermissionAction, number>> | null,
    isLoading, isLoggedIn: !!user, login, logout, can,
    isAdmin: role === 'Admin',
    isPSMManager: role === 'PSMManager' || role === 'Admin',
    isHSEManager: role === 'HSEManager' || role === 'Admin',
    isUnitHead: role === 'UnitHead' || role === 'Admin',
    isSupervisor: role === 'Supervisor' || role === 'Admin',
    isOperator: role === 'Operator' || role === 'Admin',
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}

export const PermissionGate: FC<{
  collection: string; action: PermissionAction; children: ReactNode; fallback?: ReactNode;
}> = ({ collection, action, children, fallback = null }) => {
  const { can } = useAuth();
  return can(collection, action) ? <>{children}</> : <>{fallback}</>;
};
