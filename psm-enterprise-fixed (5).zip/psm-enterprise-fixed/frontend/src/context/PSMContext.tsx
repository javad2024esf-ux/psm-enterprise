import React, { createContext, useContext, useCallback, FC, ReactNode } from 'react';
import { webApi } from '../webApi';

export type StatusType = 'باز' | 'در حال بررسی' | 'در حال اقدام' | 'بسته شده';
export const calculateRisk = (severity: number, likelihood: number) => severity * likelihood;

export interface PSMApi {
  getRecords: (collection: string, filters?: Record<string, unknown>) => Promise<unknown[]>;
  createRecord: (collection: string, data: unknown) => Promise<unknown>;
  updateRecord: (collection: string, id: number | string, data: unknown) => Promise<unknown>;
  deleteRecord: (collection: string, id: number | string) => Promise<void>;
  getRecord: (collection: string, id: number | string) => Promise<unknown>;
}

export interface PSMContextType { api: PSMApi; }
const PSMContext = createContext<PSMContextType | null>(null);

export const PSMProvider: FC<{ children: ReactNode }> = ({ children }) => {
  const api: PSMApi = {
    getRecords: useCallback(async (collection: string, filters?: Record<string, unknown>) => {
      try {
        const result = await webApi.getRecords({ element: collection, filter: filters });
        if (!result) return [];
        if (Array.isArray(result)) return result as unknown[];
        const r = result as { rows?: unknown[] };
        if (r.rows) return r.rows;
        return [];
      } catch { return []; }
    }, []),
    createRecord: useCallback(async (collection: string, data: unknown) => {
      const result = await webApi.addRecord({ element: collection, data });
      if (!result) throw new Error('ایجاد رکورد ناموفق');
      return result;
    }, []),
    updateRecord: useCallback(async (collection: string, id: number | string, data: unknown) => {
      const result = await webApi.updateRecord({ element: collection, id: String(id), data });
      if (!result) throw new Error('به‌روزرسانی رکورد ناموفق');
      return result;
    }, []),
    deleteRecord: useCallback(async (collection: string, id: number | string) => {
      await webApi.deleteRecord({ element: collection, id: String(id) });
    }, []),
    getRecord: useCallback(async (collection: string, id: number | string) => {
      const all = await webApi.getRecords({ element: collection });
      const arr = Array.isArray(all) ? all as Record<string, unknown>[] : [];
      return arr.find(r => String(r.id) === String(id)) ?? null;
    }, []),
  };
  return <PSMContext.Provider value={{ api }}>{children}</PSMContext.Provider>;
};

export const usePSM = (): PSMContextType => {
  const context = useContext(PSMContext);
  if (!context) throw new Error('PSMContext must be inside PSMProvider');
  return context;
};
