import React, { createContext, useContext, FC, ReactNode } from 'react';
import toast, { Toaster } from 'react-hot-toast';

export interface ToastContextType {
  success: (message: string) => void;
  error: (message: string) => void;
  info: (message: string) => void;
  warning: (message: string) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const ToastProvider: FC<{ children: ReactNode }> = ({ children }) => {
  const value: ToastContextType = {
    success: (msg) => toast.success(msg, { position: 'top-center', style: { background: '#1e293b', color: '#e2e8f0', border: '1px solid rgba(16,185,129,0.3)' } }),
    error: (msg) => toast.error(msg, { position: 'top-center', style: { background: '#1e293b', color: '#e2e8f0', border: '1px solid rgba(239,68,68,0.3)' } }),
    info: (msg) => toast(msg, { position: 'top-center', style: { background: '#1e293b', color: '#e2e8f0', border: '1px solid rgba(59,130,246,0.3)' } }),
    warning: (msg) => toast(msg, { icon: '⚠️', position: 'top-center', style: { background: '#1e293b', color: '#e2e8f0', border: '1px solid rgba(245,158,11,0.3)' } }),
  };
  return (
    <ToastContext.Provider value={value}>
      {children}
      <Toaster />
    </ToastContext.Provider>
  );
};

export const useToast = (): ToastContextType => {
  const context = useContext(ToastContext);
  if (!context) throw new Error('useToast must be inside ToastProvider');
  return context;
};
