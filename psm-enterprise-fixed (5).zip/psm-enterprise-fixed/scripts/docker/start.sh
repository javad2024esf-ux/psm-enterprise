#!/bin/bash

# ╔═══════════════════════════════════════════════════════════════╗
# ║  PSM Enterprise — Docker Startup Script                      ║
# ║  Usage: ./scripts/docker/start.sh [dev|prod]                 ║
# ╚═══════════════════════════════════════════════════════════════╝

set -e

ENV=${1:-dev}
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Functions
print_header() {
    echo -e "${BLUE}╔═══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║${NC} $1"
    echo -e "${BLUE}╚═══════════════════════════════════════════════════════════════╝${NC}"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${YELLOW}→${NC} $1"
}

# Main logic
cd "$PROJECT_ROOT"

print_header "PSM Enterprise — Docker Startup"

# Check if .env exists
if [ ! -f .env ]; then
    print_info "Creating .env from .env.example..."
    cp .env.example .env
    print_info "Please edit .env with your configuration"
    read -p "Press Enter to continue..."
fi

# Select environment
if [ "$ENV" = "dev" ]; then
    print_info "Starting in DEVELOPMENT mode"
    COMPOSE_FILE="docker-compose.dev.yml"
    SERVICES="postgres backend frontend adminer"
elif [ "$ENV" = "prod" ]; then
    print_info "Starting in PRODUCTION mode"
    COMPOSE_FILE="docker-compose.prod.yml"
    SERVICES="postgres backend frontend nginx backup"
else
    print_error "Unknown environment: $ENV"
    echo "Usage: $0 [dev|prod]"
    exit 1
fi

# Check docker and docker-compose
if ! command -v docker &> /dev/null; then
    print_error "Docker is not installed"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    print_error "Docker Compose is not installed"
    exit 1
fi

print_success "Docker and Docker Compose are installed"

# Show what will start
print_info "Starting services: $SERVICES"
echo ""

# Start containers
print_info "Starting containers..."
docker-compose -f "$COMPOSE_FILE" up -d

# Wait for database to be ready
print_info "Waiting for database to be ready..."
for i in {1..30}; do
    if docker-compose -f "$COMPOSE_FILE" exec -T postgres pg_isready -U postgres &> /dev/null; then
        print_success "Database is ready"
        break
    fi
    if [ $i -eq 30 ]; then
        print_error "Database did not become ready"
        exit 1
    fi
    echo -n "."
    sleep 2
done

# Wait for backend to be ready
print_info "Waiting for backend to be ready..."
for i in {1..30}; do
    if curl -sf http://localhost:3000/health &> /dev/null; then
        print_success "Backend is ready"
        break
    fi
    if [ $i -eq 30 ]; then
        print_error "Backend did not become ready"
        exit 1
    fi
    echo -n "."
    sleep 2
done

echo ""
print_header "Services Started Successfully"

if [ "$ENV" = "dev" ]; then
    echo -e "${GREEN}Frontend:   ${NC}http://localhost:5173"
    echo -e "${GREEN}Backend:    ${NC}http://localhost:3000"
    echo -e "${GREEN}API Docs:   ${NC}http://localhost:3000/health"
    echo -e "${GREEN}Adminer:    ${NC}http://localhost:8080"
    echo -e "${GREEN}Database:   ${NC}postgres://localhost:5432/psm"
else
    echo -e "${GREEN}Frontend:   ${NC}https://localhost (with SSL)"
    echo -e "${GREEN}Backend:    ${NC}http://localhost:3000 (internal)"
    echo -e "${GREEN}API:        ${NC}https://localhost/api"
    echo -e "${GREEN}Database:   ${NC}Internal (not exposed)"
fi

echo ""
print_info "Useful commands:"
echo "  View logs:        docker-compose -f $COMPOSE_FILE logs -f"
echo "  Stop services:    docker-compose -f $COMPOSE_FILE down"
echo "  Restart service:  docker-compose -f $COMPOSE_FILE restart backend"
echo "  Exec bash:        docker-compose -f $COMPOSE_FILE exec backend bash"
echo ""

print_success "All systems ready! Happy coding! 🚀"
