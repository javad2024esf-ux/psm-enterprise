#!/bin/bash

# ╔═══════════════════════════════════════════════════════════════╗
# ║  PSM Enterprise — Docker Logs Script                         ║
# ║  Usage: ./scripts/docker/logs.sh [backend|frontend|postgres] ║
# ╚═══════════════════════════════════════════════════════════════╝

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

SERVICE=${1:-all}
ENV=${2:-dev}

# Determine compose file
if [ "$ENV" = "prod" ]; then
    COMPOSE_FILE="docker-compose.prod.yml"
else
    COMPOSE_FILE="docker-compose.dev.yml"
fi

cd "$PROJECT_ROOT"

if [ "$SERVICE" = "all" ]; then
    docker-compose -f "$COMPOSE_FILE" logs -f
else
    docker-compose -f "$COMPOSE_FILE" logs -f "$SERVICE"
fi
