#!/bin/bash

# ╔═══════════════════════════════════════════════════════════════╗
# ║  PSM Enterprise — Docker Stop Script                         ║
# ║  Usage: ./scripts/docker/stop.sh [dev|prod]                  ║
# ╚═══════════════════════════════════════════════════════════════╝

set -e

ENV=${1:-dev}
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

cd "$PROJECT_ROOT"

if [ "$ENV" = "dev" ]; then
    COMPOSE_FILE="docker-compose.dev.yml"
elif [ "$ENV" = "prod" ]; then
    COMPOSE_FILE="docker-compose.prod.yml"
else
    echo -e "${RED}✗${NC} Unknown environment: $ENV"
    echo "Usage: $0 [dev|prod]"
    exit 1
fi

echo -e "${BLUE}→${NC} Stopping containers..."
docker-compose -f "$COMPOSE_FILE" down

echo -e "${GREEN}✓${NC} All services stopped"
